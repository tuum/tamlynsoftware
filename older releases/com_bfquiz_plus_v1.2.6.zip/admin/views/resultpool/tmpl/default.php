<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 24 2012-03-23 12:48:07Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">

    <table class="adminlist">
    <tr>
    	<td>
    	<?php
    	   $row =& $this->items;
    	   echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE' );
    	   echo ' '.$row->score;
    	?>
    	</td>
    </tr>
    </table>

    <table class="adminlist">
    <thead>
        <tr>
            <th width="50%">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_QUESTION' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_ANSWER' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE' ); ?>
            </th>
            <th width="25%">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SOLUTION' ); ?>
            </th>
        </tr>
    </thead>
    <?php

    $table="#__bfquiz_plus";

    $numberQns=$this->items2->qnsPerQuiz;

    $k=0;
    for ($i=1, $n=$numberQns+1; $i < $n; $i++)
    {
    	$tempqid="qid".$i;
    	$tempanswer="answer".$i;

        //get question details
        $rows2=bfquiz_plusHelper::getDataQuestion($row->$tempqid);
        if(isset($rows2[0])){
			$row2=$rows2[0];
		}else{
			$row2="";
		}

        if(isset($row2->question)){

        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
			    <?php echo $row2->question; ?>

            </td>
			<td>
			    <?php

			    if(!isset($row2->field_name)){
			       $row2->field_name = "";
			    }

				if(!isset($row2->question_type)){
				   $row2->question_type = "";
				}

			    $tempvalue = $row2->field_name;

			    if(!isset($tempvalue)){
			       $tempvalue = "";
			    }


			    if(isset($row->$tempanswer)){
			      echo $row->$tempanswer;
			    }
			    ?>
			</td>
			<td>
			    <?php
			       $score=BFQuiz_PlusController::getScore($row2->field_name,$table,$row->$tempanswer);
			       echo $score;
			    ?>
			</td>
			<td>
			   <?php
			      echo $row2->solution;
			   ?>
			</td>
        </tr>
        <?php
        }

        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<input type="hidden" name="option" value="com_bfquiz_plus" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="resultpool" />

</form>

<br>
<a href="http://www.tamlyncreative.com.au/software/" target="_blank"><img src="./components/com_bfquiz_plus/images/bflogo.jpg" width="125" height="42" align="right" border="0"></a>