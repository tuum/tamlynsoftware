<?php
/**
 * $Id: edit.php 46 2012-12-09 05:16:43Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
 defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&view=results'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<!-- Begin Emailitem -->
	<div class="span10 form-horizontal">
		<table class="table table-striped" id="resultList">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
<div id="editcell">
    <table class="adminlist">
<?php } ?>
    <tr>
    	<td>
    	<?php
    	   $row =& $this->item;
    	   echo $row->Name.'<br>';
    	   echo $row->Email.'<br>';
    	   echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE' );
    	   echo ' '.$row->score;
    	?>
    	</td>
    </tr>
    </table>

	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
    <table class="adminlist">
    <?php } ?>
    <?php if( floatval($version->RELEASE) >= 3 ) { ?>
    <table class="table table-striped" id="resultList">
    <?php } ?>
    <thead>
        <tr>
            <th width="50%">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_QUESTION' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_ANSWER' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE' ); ?>
            </th>
            <th width="25%">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SOLUTION' ); ?>
            </th>
        </tr>
    </thead>
    <?php

    $table="#__bfquiz_plus";

    $k = 0;
    for ($i=0, $n=count( $this->items2 ); $i < $n; $i++)
    {
        $row =& $this->item;
        $row2 =& $this->items2[$i];

        if(isset($row2->question)){

        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
			    <?php echo $row2->question; ?>

            </td>
			<td>
			    <?php

			    if(!isset($row2->field_name)){
			       $row2->field_name = "";
			    }

				if(!isset($row2->question_type)){
				   $row2->question_type = "";
				}

			    $tempvalue = $row2->field_name;

			    if(!isset($tempvalue)){
			       $tempvalue = "";
			    }


			    if(isset($row->$tempvalue)){
			      echo $row->$tempvalue;
			    }
			    ?>
			</td>
			<td>
			    <?php
			       $score=BFQuiz_PlusController::getScore($row2->field_name,$table,$row->$tempvalue);
			       echo $score;
			    ?>
			</td>
			<td>
			   <?php
			      echo $row2->solution;
			   ?>
			</td>
        </tr>
        <?php
        }

        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<input type="hidden" name="option" value="com_bfquiz_plus" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="results" />
<input type="hidden" name="cid" value="<?php echo (int)$catid; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>