<?php
/**
 * $Id: edit.php 40 2012-09-23 04:17:28Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'scorecat.cancel' || document.formvalidator.isValid(document.id('scorecatitem-form'))) {
			Joomla.submitform(task, document.getElementById('scorecatitem-form'));
		}
		else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&view=scorecat&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="scorecatitem-form" class="form-validate">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<!-- Begin matrixanswer -->
	<div class="span10 form-horizontal">

	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFQUIZPLUS_TITLE_DETAILS') : JText::sprintf('COM_BFQUIZPLUS_TITLE_DETAILS', $this->item->id); ?></a></li>
		</ul>
		<div class="tab-content">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<div class="width-60 fltlft">
		<fieldset class="adminform">
<?php } ?>
			<div class="tab-pane active" id="details">
				<h4><?php echo empty($this->item->id) ? JText::_('COM_BFQUIZPLUS_TITLE_DETAILS') : JText::sprintf('COM_BFQUIZPLUS_TITLE_SCORE_CAT', $this->item->id); ?></h4>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
				</div>
				<?php } ?>

				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('congratulationsText'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('congratulationsText'); ?></div>
				</div>
				<?php } ?>

				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('congratulationsText'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('congratulationsText'); ?>
				<?php } ?>

				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('additionalInformationText'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('additionalInformationText'); ?></div>
				</div>
				<?php } ?>

				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('additionalInformationText'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('additionalInformationText'); ?>
				<?php } ?>

			</div>
		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
	</div>
	<?php } ?>

	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
		</div>
	</fieldset>

	</div>
	<?php } ?>

	<input type="hidden" name="task" value="" />
	<?php echo JHtml::_('form.token'); ?>
</form>