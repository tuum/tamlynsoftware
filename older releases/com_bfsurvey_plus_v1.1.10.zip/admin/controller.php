<?php
/**
 * $Id: controller.php 47 2013-06-02 11:31:03Z tuum $
 * bfsurvey_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die;

/**
 * bfsurvey_plus Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfsurvey_plusController extends JControllerLegacy
{
	protected $default_view = 'questions';
	/**
	 * Method to display a view.
	 *
	 * @param	boolean			$cachable	If true, the view output will be cached
	 * @param	array			$urlparams	An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
	 *
	 * @return	JController		This object to support chaining.
	 * @since	1.5
	 */
	public function display($cachable = false, $urlparams = false)
	{
		require_once JPATH_COMPONENT.'/helpers/bfsurvey_plus.php';

		// Load the submenu.
		//bfsurvey_plusHelper::addSubmenu(JRequest::getCmd('view', 'bfsurvey_plus'));

		$view		= JRequest::getCmd('view', 'questions');
		$layout 	= JRequest::getCmd('layout', 'default');
		$id			= JRequest::getInt('id');

		// Check for edit form.
		if ($view == 'question' && $layout == 'edit' && !$this->checkEditId('com_bfsurvey_plus.edit.question', $id)) {
			// Somehow the person just went to the form - we don't allow that.
			$this->setError(JText::sprintf('JLIB_APPLICATION_ERROR_UNHELD_ID', $id));
			$this->setMessage($this->getError(), 'error');
			$this->setRedirect(JRoute::_('index.php?option=com_bfsurvey_plus&view=question', false));

			return false;
		}

		parent::display();
		bfsurvey_plusHelper::displayVersion();

		return $this;
	}

	function stats()
	{
		JRequest::setVar( 'view', 'statscategory' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function show()
	{
		JRequest::setVar( 'view', 'stats' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Used to import Question from BF Survey Plus Free
	*/
	function import()
	{
		JRequest::setVar( 'view', 'import' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Used for DB Clean up and other maintenance
	*/
	function maintenance()
	{
		JRequest::setVar( 'view', 'maintenance' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function csvExport()
	{
		JRequest::setVar( 'view', 'csvexport' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'question' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * display the report form
	 * @return void
	 */
	function report()
	{
		JRequest::setVar( 'view', 'report' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * display the category form
	 * @return void
	 */
	function category()
	{
		JRequest::setVar( 'view', 'category' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

      public static function getCategory()
	  	{
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('id, title');
			$query->from('#__categories');
			$query->where('published = 1');
			$query->where('extension = '.$db->quote('com_bfsurvey_plus') );
			$query->order('title');
			$db->setQuery((string)$query);
	  		$options = $db->loadObjectList( );
	  	    return $options;
	}


		public static function getQuestions($catid)
		{
		    $db = JFactory::getDBO();
			$table="#__bfsurvey_plus";

		    // get questions
			$query = "SELECT * FROM ".$table." where `catid`=".$catid." AND `published`=1 ORDER BY ordering";

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			return $rows;

		}

	public static function getStatsCheckbox($question, $response, $catid){

	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfsurveyplus_".$catid;

	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where($db->escape( $question ) .' like '.$db->quote('%'.$db->escape( $response, true ).'%') );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStats($question, $response, $catid){

	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfsurveyplus_".(int)$catid;

	    $query->from($db->quoteName($table));
		$query->select('*');
		//$query->where(trim($db->escape( $question )).' = '.$db->quote(trim($db->escape( $response, true ))) );
		$query->where(trim($db->escape( $question )).' = '.$db->quote(trim( $response, true )) );

		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsOther($question, $response, $catid){
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
			$query->select('*');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}
			$total = count($rows);

			$query->clear();
			//now get all the question
			$query->from($db->quoteName('#__bfsurvey_plus'));
			$query->select('*');
			$query->where('field_name='.$db->quote($db->escape( $question )));

			$db->setQuery( $query);
			$rows2 = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}

			$count=0;
			foreach($rows2 as $qn){
				for($i=1; $i < 21; $i++){
					$tempoption="option".$i;
					$query->clear();
					$query->select('*');
					$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
					$query->where( $db->quote(JString::trim($db->escape( $question )))."=". $db->quote(JString::trim($db->escape( $qn->$tempoption, true ))) );

					$db->setQuery( $query);
					$rows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						return false;
					}

					$count=$count+count($rows);
				}
			}

			$num = $total-$count;

			return $num;
	}

	public static function getStatsText($field_name, $catid){

		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfsurveyplus_".$catid;

		$query->from($db->quoteName($table));
		$query->select($db->escape( $field_name ));
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		return $rows;
	}

    function importquestions(){
	   $db = JFactory::getDBO();

	   $table1="#__bfsurvey_plustrial";
	   $table2="#__bfsurvey_plus";
	   $table3="#__bfsurvey_plus_old";
	   $table4="#__categories";

	   // Rename jos_bfsurvey_plus to jos_bfsurvey_plus_old
	   $query = "RENAME TABLE `".$table2."` TO `".$table3."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }

	   // Rename jos_bfsurvey_plusfree to jos_bfsurvey_plus
	   $query = "RENAME TABLE `".$table1."` TO `".$table2."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }

	   //Move categores from BF Survey Plus Free to BF Survey Plus
	   $query = "UPDATE ".$table4." set `extension` = 'com_bfsurvey_plus' where `extension` = 'com_bfsurvey_plustrial'";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }

	   echo JText::_( 'Update complete!' );

	}

	/*
	 * This funciton updates your database table from BF Survey Pro to BF Survey Plus
	 */
	function importQuestionsPro(){
		$db = JFactory::getDbo();

		$query = "RENAME TABLE `#__bfsurvey_plus` TO `#__bfsurvey_plus.old`";

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_pro`
			ADD `archived` tinyint(1) NOT NULL DEFAULT '0',
			ADD `approved` tinyint(1) NOT NULL DEFAULT '1',
			ADD `access` int(11) NOT NULL DEFAULT '1',
			ADD `language` char(7) NOT NULL DEFAULT '',
			ADD `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `created_by` int(10) unsigned NOT NULL DEFAULT '0',
			ADD `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
			ADD `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `image1` varchar(255) NOT NULL,
			ADD `image2` varchar(255) NOT NULL,
			ADD `image3` varchar(255) NOT NULL,
			ADD `image4` varchar(255) NOT NULL,
			ADD `image5` varchar(255) NOT NULL,
			ADD `image6` varchar(255) NOT NULL,
			ADD `image7` varchar(255) NOT NULL,
			ADD `image8` varchar(255) NOT NULL,
			ADD `image9` varchar(255) NOT NULL,
			ADD `image10` varchar(255) NOT NULL,
			ADD `image11` varchar(255) NOT NULL,
			ADD `image12` varchar(255) NOT NULL,
			ADD `image13` varchar(255) NOT NULL,
			ADD `image14` varchar(255) NOT NULL,
			ADD `image15` varchar(255) NOT NULL,
			ADD `image16` varchar(255) NOT NULL,
			ADD `image17` varchar(255) NOT NULL,
			ADD `image18` varchar(255) NOT NULL,
			ADD `image19` varchar(255) NOT NULL,
			ADD `image20` varchar(255) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_pro` CHANGE `published` `state` tinyint(3) NOT NULL default '0';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "RENAME TABLE `#__bfsurvey_pro` TO `#__bfsurvey_plus`;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$this->setRedirect(JRoute::_('index.php?option=com_bfsurvey_plus&view=maintenance', false));
	}

	public static function getQuestion($field_name,$catid)
	{
		$db = JFactory::getDBO();

		// get question
		$query = "SELECT question FROM #__bfsurvey_plus where catid=".$catid." AND field_name='".$field_name."'";

		$db->setQuery( $query);
		//$rows = $db->loadObjectList();
		$result=$db->loadResult();

	    return $result;
    }

	public static function getRatingQuestion($field_name,$catid)
	{
		$db = JFactory::getDBO();

		//see if last two digits are a number
		if(is_numeric (substr($field_name, -2))){
		   $myfield_name = substr($field_name, 0, -2);
		   $option = "option".(int)substr($field_name, -2);
		}else if(is_numeric (substr($field_name, -1))){ //is last digit numeric
		   $myfield_name = substr($field_name, 0, -1);
		   $option = "option".(int)substr($field_name, -1);
		}else{
		   $field_name = ""; // not a rating question
		}

		if($field_name != ""){
		   // get question
		   $query = "SELECT `".$option."` FROM #__bfsurvey_plus where catid=".$catid." AND field_name='".$myfield_name."'";

		   $db->setQuery( $query);
		   $rows = $db->loadObjectList();
		   $result=$db->loadResult();

	       return $result;
	    }else{
	       return "";
	    }

    }

	public static function exportMysqlToCsv($sql_query,$filename = 'export.csv')
	{
	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    $csv_enclosed = '"';
	    $csv_escaped = "\\";

		$app = JFactory::getApplication();
		$host = $app->getCfg('host');
		$db = $app->getCfg('db');
		$user = $app->getCfg('user');
		$password = $app->getCfg('password');
		$dbtype = $app->getCfg('dbtype');

	    // Gets the data from the database
		if($dbtype == 'mysqli'){
			$link = mysqli_connect($host, $user, $password, $db);
			@mysqli_query($link, 'set character set "utf8"');
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$result = mysqli_query($link, $sql_query);
		}else if($dbtype == 'sqlsrv'){
			$config = array(
				'Database' => $db,
				'uid' => $user,
				'pwd' => $password,
				'CharacterSet' => 'UTF-8',
				'ReturnDatesAsStrings' => true);

			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$link = sqlsrv_connect($host, $config);
			$result = sqlsrv_query($link, $sql_query);
			if( $result === false ) {
     			die( print_r( sqlsrv_errors(), true));
			}
			$fields_cnt = sqlsrv_num_fields($result);
		}else{
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
	    	$result = mysql_query($sql_query);
	    	$fields_cnt = mysql_num_fields($result);
		}

	    $schema_insert = '';

		if($dbtype == 'mysqli'){
			$fields = mysqli_fetch_fields($result);
			$i=0;
			foreach ($fields as $field) {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes($field->name)) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		        $i++;
			}
			$fields_cnt = $i;
		}else if($dbtype == 'sqlsrv'){
			//this bit just really doesnt work with SQL server.
			//todo - fix CSV export for SQLSRV

			if( sqlsrv_fetch( $result ) === false )
			{
			     echo "Error in retrieving row.\n";
			     die( print_r( sqlsrv_errors(), true));
			}
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(sqlsrv_get_field( $result, $i) )) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}else{
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}

	    $out = trim(substr($schema_insert, 0, -1));
	    $out .= $csv_terminated;

	    // Format the data
	    if($dbtype == 'sqlsrv'){
	    	$row = sqlsrv_fetch_array($result);
	    }else{
	    	$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
		}

	    while ($row)
	    {
	        $schema_insert = '';
	        for ($j = 0; $j < $fields_cnt; $j++)
	        {
	            if ($row[$j] == '0' || $row[$j] != '')
	            {

	                if ($csv_enclosed == '')
	                {
	                    $schema_insert .= $row[$j];
	                } else
	                {
	                    $schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
	                }
	            } else
	            {
	                $schema_insert .= '';
	            }

	            if ($j < $fields_cnt - 1)
	            {
	                $schema_insert .= $csv_separator;
	            }
	        } // end for

	        $out .= $schema_insert;
	        $out .= $csv_terminated;

			if($dbtype == 'sqlsrv'){
				$row = sqlsrv_fetch_array($result);
			}else{
				$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
			}
	    } // end while

	    header("Content-Length: " . strlen($out));
	    // Output to browser with appropriate mime type, you choose ;)
	    header('Content-Encoding: UTF-8');
		header('Content-type: text/csv; charset=UTF-8');
	   	header("Pragma: no-cache");
		header("Expires: 0");
	    header("Content-Disposition: attachment; filename=$filename");
	    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	    echo $out;
	    exit;

   }

function saveOrder( )
{
	$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
	global $mainframe;

	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

	// Initialize variables
	$db			= JFactory::getDBO();
	$total		= count( $cid );
	$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
	JArrayHelper::toInteger($order, array(0));

	$row = JTable::getInstance('question', 'Table');
	$groupings = array();

	// update ordering values
	for( $i=0; $i < $total; $i++ ) {
		$row->load( (int) $cid[$i] );
		// track categories
		$groupings[] = $row->catid;

		if ($row->ordering != $order[$i]) {
			$row->ordering = $order[$i];
			if (!$row->store()) {
				JError::raiseError(500, $db->getErrorMsg() );
			}
		}
	}

	// execute updateOrder for each parent group
	$groupings = array_unique( $groupings );
	foreach ($groupings as $group){
		$row->reorder('catid = '.(int) $group);
	}

	$msg 	= JText::_('COM_BFSURVEYPLUS_NEW_ORDERING_SAVED');
	$mainframe->redirect( 'index.php?option=com_bfsurvey_plus', $msg );
}


   /**********************************************************************************
    * This function will search through your answer table for fields that don't have
    * associated questions, and will automatically detele them.
    * Used by maintenance view.
    **********************************************************************************/
	function dbcleanup(){
		require_once JPATH_COMPONENT.'/helpers/bfsurvey_plus.php';
		bfsurvey_plusHelper::addSubmenu('maintenance');

		JToolBarHelper::title( JText::_( 'COM_BFSURVEYPLUS_TOOLBAR_MAINTENANCE' ), 'bfsurvey_toolbar_title' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$table="#__bfsurvey_plus";

		//first get all the categories
		$query->select('DISTINCT catid');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
	 	$rows1 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}


	   // get field names and categories
		$query->clear();
		$query->select('field_name, catid, question_type');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

       for($n=0;$n < count($rows1); $n++){
          $row1 = &$rows1[$n];
          $table2="#__bfsurveyplus_".$row1->catid;

          echo $table2."<br>";

          //now get the fields for the selected table
		  $fields = $db->getTableColumns( $table2, true );

		  if(!$fields){
	         global $mainframe;
		     JError::raiseWarning( 500, JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_TABLE').' '.$table2.' '.JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_DOES_NOT_EXIST') );
		     JError::raiseNotice( 500, JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_IGNORE_WARNING') );
		     return null;
	      }

   	      if( sizeof( $fields ) ) {
            // We found some fields so let's create the list
            $options = array();
            foreach( $fields as $field => $type ) {
            	$options[] = $field;

            	//now is there a question associated with this field?
            	$found=0;
            	for($i=0;$i < count($rows); $i++){
					$row = &$rows[$i];

				 	if($row->catid == $row1->catid){ // is this question in the same category
						if($row->field_name == $field | $field == "id" | $field == "Name" | $field == "Company" | $field == "Email" | $field == "DateReceived" | $field == "ip" | $field == "uid" | $field == "state"){
						   $found=1;
						   $i=count($rows);
						}
					}

					//rating question
					if($row->question_type == 9){
					   if(strlen($row->field_name) > strlen($field)){
					      $mylen=strlen($field);
					   }else{
					      $mylen=strlen($row->field_name);
					   }

					   if($row->field_name == substr($field, 0, $mylen)){
					      $found=1;
					   }
					}
	      		}

	      		if($found==0){
	      		   echo JText::_( "COM_BFSURVEYPLUS_ERROR_CANT_FIND_FIELD");
	      		   echo " ";
	      		   echo $field;
	      		   $query="ALTER TABLE ".$db->quoteName($table2)." DROP ".$field;
	      		   $db->setQuery( $query );
				   if (!$db->query())
				   {
				   	   echo $db->getErrorMsg();
				   	   return false;
				   }
				   ?>
				   <br>
				   <?php
	               echo JText::_( "COM_BFSURVEYPLUS_ERROR_FIELD");
	               echo " ";
	               echo $field;
	               echo " ";
	               echo JText::_( "COM_BFSURVEYPLUS_ERROR_HAS_BEEN_DELETED");
	               echo " ";
	               echo $table2;
	               ?>
	               <br>
	               <?php
	      		}

      		}
   		  }

	   }

	   echo JText::_( "COM_BFSURVEYPLUS_FINISHED_DB_CLEANUP");
	}

   /**********************************************************************************
    * This function will backup your BF Survey Plus tables
    **********************************************************************************/
	function dbbackup(){
		require_once JPATH_COMPONENT.'/helpers/bfsurvey_plus.php';
		bfsurvey_plusHelper::addSubmenu('maintenance');

		JToolBarHelper::title( JText::_( 'COM_BFSURVEYPLUS_TOOLBAR_MAINTENANCE' ), 'bfsurvey_toolbar_title' );

	   $table="#__bfsurvey_plus";

	   $myExport = bfsurvey_plusController::exportMyTable($table);

		$table="#__bfsurveyplus_email";
		$myExport .= bfsurvey_plusController::exportMyTable($table);

	   $db = JFactory::getDBO();

	   //get all survey category id numbers
	   $query = "SELECT id, title FROM #__categories WHERE extension='com_bfsurvey_plus'";

	   $db->setQuery( $query );
	   $rows = $db->loadObjectList();

	   foreach($rows as $row){
	      $table="#__bfsurveyplus_".$row->id;
	      $myExport .= "\n";
	      $myExport .= bfsurvey_plusController::exportMyTable($table);
	   }

	   echo JText::_( 'COM_BFSURVEYPLUS_BACKUP_PREPARED' );
	   echo "<br>";

	   // excel export
	   print '<form id="mySQLExport" name="mySQLExport" method="POST" action="./components/com_bfsurvey_plus/mysqlexport.php">';

	   print '<DIV ID="myExport" style="display:none;"><textarea name="myExport">'.$myExport.'</textarea></div>';

	   ?>
	   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'Save backup to file' ); ?>" />
	   <?php
	   print "</form>";

	   echo "<br>";
	   echo $myExport;
   }


   function exportMyTable($table){
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

       // Get the structure of the question table
	   $mytable = $db->getTableCreate( $table );

	   if(!$mytable){
		  JError::raiseWarning( 500, JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_TABLE').' '.$table.' '.JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_CANNOT_BE_FOUND') );
		  JError::raiseNotice( 500, JText::_('COM_BFSURVEYPLUS_ERROR_MYSQL_IGNORE_WARNING') );
		  return null;
	   }

	   // Grab the fields for the selected table
	   $fields = $db->getTableColumns( $table, true );

	   //now get the question data
		$query->select('*');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows = $db->loadRowList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

	   $myfields=array_values($fields);

	   $d=null;
	   foreach($rows as $cr){
	      $d .= "INSERT INTO " . $db->quoteName($table) . " VALUES (";
	      for($i=0; $i<sizeof($cr); $i++){
	         $myfield=$myfields[$i];
	         if($cr[$i] == ''){
	            if($myfield == "tinyint" | $myfield == "int"){
	               $d .= "0,";
	            }else{
	               $d .= "'',";
	            }
	         }else{
	            //add delimited before apostrophe
	            $d .= "'".addcslashes($cr[$i],"'")."',";
	         }
	      }

	      $d = substr($d, 0, strlen($d) - 1);
	      $d .= ");\n";
	   }

	   $myexport= $mytable[$table];
	   $myexport.=";\n\n";
	   $myexport .=$d;

	   return $myexport;
   }

	function emailtemplate()
	{
		JRequest::setVar( 'view', 'emailtemplate' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	static function buildAnswerTables(){
		//automatic table builder
		$database = JFactory::getDBO();
		$config = JFactory::getConfig();

		require_once JPATH_COMPONENT.'/controller.php';
		$mycategory = bfsurvey_plusController::getCategory();

		$db = JFactory::getDBO();
		$app = JFactory::getApplication();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_plus'));
		$query->select('*');
		$query->where('state = 1');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();
		$debug = "";
		$dbtype = $app->getCfg('dbtype');

		if( sizeof( $mycategory ) ) {
		    foreach( $mycategory as $mycat  ) {
			    $myid = $mycat->id;
			    $table="#__bfsurveyplus_".$myid;

			    $result = $database->getTableList();
			    if (!in_array($app->getCfg('dbprefix')."bfsurveyplus_".$myid, $result)) {
				   for ($i=0, $n=count( $items ); $i < $n; $i++)
				   {
				    	$found=0;
				   		$row = $items[$i];

						$myFieldsMissing="";
						if($row->catid == $myid){
						   if($row->question_type == 10){ //heading
					        	// don't add field for heading question
					       }else if($row->question_type == 9){ //rating
					        	// don't add field for rating question
					       }else{
					       		if($dbtype == 'sqlsrv'){
					       			$myFieldsMissing.= "[".$row->field_name."] [nvarchar](max),";
					       		}else{
					       			if(is_callable(array('JDatabaseMySQL', 'quoteName'))){
			 			      			$myFieldsMissing.= $db->quoteName($row->field_name)." TEXT,";
					       			}else{
					       				//joomla 1.6 support
					       				$myFieldsMissing.= "`".$row->field_name."` TEXT,";
					       			}
					       		}
			 			   }
						}
		       		}

		       		if($dbtype == 'sqlsrv'){
				       $query="CREATE TABLE [".$table."](
			  			    [id] [bigint] IDENTITY(1,1) NOT NULL,
			      			[Name] [nvarchar](150) NOT NULL,
			      			[Company] [nvarchar](150) NOT NULL,
			      			[Email] [nvarchar](150) NOT NULL,
			      			[uid] [int],
			      			[DateReceived] [datetime] NOT NULL,
			      			[ip] [nvarchar](50) NOT NULL,
			      			[state] [smallint],
			  			    ".$myFieldsMissing."
							 CONSTRAINT [PK_".$table."_id] PRIMARY KEY CLUSTERED
							(
								[id] ASC
							)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
				    	);";
		       		}else{
				       $query="CREATE TABLE ".$table." (
			  			    `id` int(11) NOT NULL auto_increment,
			      			`Name` varchar(150) default NULL,
			      			`Company` varchar(150) default NULL,
			      			`Email` varchar(150) default NULL,
			      			`uid` int(11) NOT NULL default 0,
			      			`DateReceived` datetime NOT NULL,
			      			`ip` varchar(50) default NULL,
			      			`state` tinyint(3) NOT NULL default '0',
			  			    ".$myFieldsMissing."
			      			PRIMARY KEY  (`id`)
				    	);";
		       		}

			       $db->setQuery( $query );
			       if (!$db->query())
			       {
			       	   return $db->getErrorMsg();
			       }
			    }else{
			        //table already exists

				    $db = JFactory::getDBO();
				    // Grab the fields for the selected table
				    $fields = $db->getTableColumns( $table, true );

				    if( sizeof( $fields ) ) {
				       // We found some fields so let's create the HTML list
				       $options = array();
				       foreach( $fields as $field => $type ) {
					           $options[] = JHTML::_( 'select.option', $field, $field );
				       }

					   //what type of field, eg VARCHAR, INT, DATETIME etc.
					   $fieldType=array();
				       foreach( $fields as $field ) {
					      $fieldType[] = $field;
				       }
				    }

					for ($i=0, $n=count( $items ); $i < $n; $i++)
			 		{
		 		    	$found=0;
					    $row = $items[$i];
					    $myindex=0;
					    foreach( $fields as $field => $type ) {
				           if ($row->field_name == $field) {
					          $found=1;
					   	   }

					   	   if($found==0){
					   	      $myindex++;
					   	   }
					    }

					    if($found == 1){
					        if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type==""){
					           //do nothing
					        }else{
								if($dbtype == 'sqlsrv'){
									switch(strtoupper($row->field_type)){
										case "INT": 	$mytype = "[int]";
														break;
										case "DATE":	$mytype = "[datetime]";
														break;
										case "TINYINT": $mytype = "[smallint]";
														break;
										case "FLOAT":	$mytype = "[numeric](10, 2)";
														break;
										case "DOUBLE":	$mytype = "[numeric]";
														break;
										case "VARCHAR":	$mytype = "[nvarchar](".$row->fieldSize.")";
														break;
										case "TEXT" :	$mytype = "[nvarchar](max)";
														break;
										case "default":	$mytype = "[nvarchar](255)";
									}
								}else{
									$mytype = $row->field_type;
									if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
										$mytype = $row->field_type."(".$row->fieldSize.")";
									}
								}

								if($dbtype == 'sqlsrv'){
					           		$query="ALTER TABLE ".$db->quoteName($table)." ALTER COLUMN [".$row->field_name."] ".$mytype.";";
								}else{
									if(is_callable(array('JDatabaseMySQL', 'quoteName'))){
										$query="ALTER TABLE ".$db->quoteName($table)." CHANGE ".$db->quoteName($row->field_name)." ".$db->quoteName($row->field_name)." ".$mytype.";";
									}else{
										//joomla 1.6 support
										$query="ALTER TABLE ".$db->quoteName($table)." CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
									}
								}

				  	    	   $db->setQuery( $query );
				  	       	   if (!$db->query())
				  	       	   {
				  	       	      return $db->getErrorMsg();
				  	       	   }
					        }
					    }

					    if($row->question_type == 9){ //rating
					        // don't add field for rating question
					        $found=1;
					    }

					    if($row->question_type == 10){ //Heading
					        // don't add field for heading question
					        $found=1;
					    }

			 		    if($found == 0 & $row->catid == $myid){

							if($dbtype == 'sqlsrv'){
								$query="ALTER TABLE ".$db->quoteName($table)."
					    			    ADD [".$row->field_name."] [nvarchar](max)
			  					;";
							}else{
								if(is_callable(array('JDatabaseMySQL', 'quoteName'))){
									$query="ALTER TABLE ".$db->quoteName($table)."
						    			    ADD ".$db->quoteName($row->field_name)." TEXT
				  					;";
								}else{
									//joomla 1.6 support
									$query="ALTER TABLE ".$db->quoteName($table)."
						    			    ADD `".$row->field_name."` TEXT
				  					;";
								}
							}

				  	       $db->setQuery( $query );
				  	       if (!$db->query())
				  	       {
				  	       	   return $db->getErrorMsg();
				  	       }
					    }

					    // now special case for rating question
					    if($row->question_type == 9){   // rating question
					        for ($y=0, $x=20; $y < $x; $y++ ) {
					            $tempvalue="option".($y+1);
					            $tempfield=$row->field_name;
					            $tempfield.="".($y+1);

								$found=0;

					            if($row->$tempvalue == ""){
					                 //do nothing
					            }else{
					    			foreach( $fields as $field => $type ) {
						       			if ($tempfield == $field) {
							       		   	$found=1;
						  	   			}
						  			}

									if($found == 0 & $row->catid == $myid){

										if($dbtype == 'sqlsrv'){
										   $query="ALTER TABLE ".$db->quoteName($table)."
								    			   ADD [".$tempfield."] [nvarchar](max)
						  	  	    	   ;";
										}else{
									       $query="ALTER TABLE ".$db->quoteName($table)."
								    			   ADD ".$db->quoteName($tempfield)." TEXT
						  	  	    	   ;";
										}

							  	       $db->setQuery( $query );
							  	       if (!$db->query())
							  	       {
							  	       	   echo $db->getErrorMsg();
							  	    	   return false;
							  	       }

								    }else if($found == 1){
										if($dbtype == 'sqlsrv'){
											switch(strtoupper($row->field_type)){
												case "INT": 	$mytype = "[int]";
																break;
												case "DATE":	$mytype = "[datetime]";
																break;
												case "TINYINT": $mytype = "[smallint]";
																break;
												case "FLOAT":	$mytype = "[numeric](10, 2)";
																break;
												case "DOUBLE":	$mytype = "[numeric]";
																break;
												case "VARCHAR":	$mytype = "[nvarchar](".$row->fieldSize.")";
																break;
												case "TEXT" :	$mytype = "[nvarchar](max)";
																break;
												case "default":	$mytype = "[nvarchar](255)";
											}
										}else{
											$mytype = $row->field_type;
											if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
												$mytype = "".$row->field_type."(".$row->fieldSize.")";
											}
										}

										if($dbtype == 'sqlsrv'){
											$query="ALTER TABLE ".$db->quoteName($table)." ALTER COLUMN [".$tempfield."] ".$mytype.";";
										}else{
											$query="ALTER TABLE ".$db->quoteName($table)." CHANGE ".$db->quoteName($tempfield)." ".$db->quoteName($tempfield)." ".$mytype.";";
										}

				  	    	   			$db->setQuery( $query );
				  	       	   			if (!$db->query())
				  	       	   			{
				  	       	   			   return $db->getErrorMsg();
				  	       	   			}
					    			}

						  		}

					    	}

					    }

					}

		        }
		   }

		}

		return "";
	}
}
?>
