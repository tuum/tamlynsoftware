<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoDispatcher extends F0FDispatcher
{
	public function onBeforeDispatch()
	{
		$result = parent::onBeforeDispatch();

		if ($result)
		{
			$view = F0FInflector::singularize($this->input->getCmd('view', $this->defaultView));

			// only front end view is xmlsitemap. Any other view should give error
			if ($view != 'xmlsitemap'){
				$url = JUri::base() . 'index.php';
				JFactory::getApplication()->redirect($url, JText::_('BFSEO_ERR_NOTAUTHORIZED'), 'error');

				return;
			}
		}

		return $result;
	}
}