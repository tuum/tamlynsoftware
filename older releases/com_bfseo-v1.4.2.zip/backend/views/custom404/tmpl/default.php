<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');
JHtml::_('behavior.modal');

if (version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

JHtml::_('bootstrap.framework');
JHtml::_('behavior.framework', true);

$htaccess = sprintf(JText::_('COM_BFSEO_HTACCESS_FILE_MISSING_CLICK'), JUri::base() . 'index.php?option=com_bfseo&view=htaccess');

$custom404 = JComponentHelper::getParams('com_bfseo')->get('custom404', false);
$custom404Msg = sprintf(JText::_('COM_BFSEO_TITLE_PAGE_404_MSG'), JUri::base() . 'index.php?option=com_config&view=component&component=com_bfseo');

$conf = JFactory::getConfig();
$sef = (bool)$conf->get('sef');
$sefMsg = sprintf(JText::_('COM_BFSEO_TITLE_SEF_DISABLED'), JUri::base() . 'index.php?option=com_config');


$custom404Edit = JUri::base().'index.php?option=com_bfseo&view=custom404edit&id=';
?>

		<?php if ($this->ordering) : ?>
			<div class="alert alert-info">
				<a class="close" data-dismiss="alert">&#215;</a>
				<?php echo JText::_('COM_BFSEO_PLG_BFSEOREDIRECT_ORDERING_FIXED'); ?>
			</div>
		<?php endif; ?>

		<?php if (!file_exists(JPATH_ROOT . '/.htaccess')): ?>
			<p class='alert alert-warning'>
				<?php echo $htaccess ?>
			</p>
		<?php endif ?>

		<?php if (!$custom404): ?>
			<p class='alert alert-warning'>
				<?php echo $custom404Msg ?>
			</p>
		<?php endif ?>

		<?php if (!$sef): ?>
			<p class='alert alert-warning'>
				<?php echo $sefMsg ?>
			</p>
		<?php endif ?>

<div class="row-fluid">
	<div class='span12'>
		<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
			<?php if (empty($this->items)): ?>
				<div class="alert"><?php echo JText::_('COM_BFSEO_NO_CUSTOM_404') ?></div>
			<?php endif ?>
			<table class='table table-condensed metatable'>
			<tr>
				<th>ID</th>
				<th><input name="checkall-toggle" class="checkbox" onclick="Joomla.checkAll(this);" type="checkbox"></th>
				<th>Title</th>
				<th>Language</th>
				<th>HTML</th>
			</tr>
			<?php foreach ($this->items as $item): ?>
			<tr>
				<td width="4%"><?php echo $item->bfseo_404_id ?></td>
				<td width="4%"><input id="cb<?php echo $item->bfseo_404_id ?>" name="cb[<?php echo $item->bfseo_404_id ?>]" type="checkbox" onclick="Joomla.isChecked(this.checked);"></td>
				<td width="20%"><a href="<?php echo $custom404Edit . $item->bfseo_404_id ?>"><?php echo $item->title ?></a></td>
				<td width="10%"><?php echo $item->lang  ?></td>
				<td width="70%"><?php echo htmlentities(substr($item->html, 0, 100)) ?></td>
			</tr>
			<?php endforeach ?>
			</table>
			<input type="hidden" name="option" value="com_bfseo"/>
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="boxchecked" value="0" />
			<?php echo JHtml::_( 'form.token' ); ?>
		</form>
	</div>
</div>


