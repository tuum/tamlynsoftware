<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelCustom404Edit extends F0FModel
{
	public function __construct($config = array())
	{
		$config['table'] = '404';

		parent::__construct($config);
	}

	public function getPage($id)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->clear();
		$query->select('*');
		$query->from('#__bfseo_404s');
		$query->where('bfseo_404_id=' . $id);
		$db->setQuery($query);
		$db->query();
		$row = $db->loadObject();
		if (!$row) {
			JError::raiseError(500, $db->getErrorMsg());
		}

		return $row;
	}

	public function save($data)
	{
		if (!$data['id']) {
			return $this->saveNew($data);
		}

		if (!$data['title']) {
			return false;
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfseo_404s');
		$query->where('bfseo_404_id=' . $data['id']);
		$db->setQuery($query);
		$db->query();
		$row = $db->loadObject();
		$query = $db->getQuery(true);
		if ($row) {
			$query->update('#__bfseo_404s');
		} else {
			$query->insert('#__bfseo_404s');
		}

		$query->set('title=' . $db->q($data['title']));
		$query->set('lang=' . $db->q($data['lang']));
		$query->set('html=' . $db->q($data['html']));
		$query->where('bfseo_404_id=' . $data['id']);
		$db->setQuery($query);
		if (!$db->query()) {
			return false;
		}
		return true;
	}

	private function saveNew($data)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->insert('#__bfseo_404s');
		$query->set('title=' . $db->q($data['title']));
		$query->set('lang=' . $db->q($data['lang']));
		$query->set('html=' . $db->q($data['html']));
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {
			JError::raiseError(500, $db->getErrorMsg());
		}
		return true;
	}
}
