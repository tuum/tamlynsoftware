<?php
/**
 *  @package BF SEO
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelConfigcheck extends F0FModel
{
	public function check()
	{
		//do stuff

		return true;
	}
}