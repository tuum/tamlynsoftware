<?php
/*
 * @package BF SEO Redirect System Plugin
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF SEO is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF SEO is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF SEO.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF SEO from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

class PlgSystemBfseoredirect extends JPlugin
{
	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);

		JError::setErrorHandling(E_ERROR, 'callback', array('PlgSystemBfseoredirect', 'handleError'));

		set_exception_handler(array('PlgSystemBfseoredirect', 'handleError'));
	}

	public static function handleError(&$error)
	{
		$app = JFactory::getApplication();

		if ($app->isAdmin() || $error->getCode() != 404) {
			JError::customErrorPage($error);
		}

		$custom404 = JComponentHelper::getParams('com_bfseo')->get('custom404');

		if ($custom404) {

			$db = JFactory::getDbo();
			$query = $db->getQuery(true);

			$lang = JFactory::getLanguage()->getTag();;

			$query->clear();
			$query->select('*');
			$query->from('#__bfseo_404s');
			if ($lang) {
				$query->where('lang='.$db->q($lang));
			}
			$query->where('published=1');
			$db->setQuery($query);
			$db->query();
			$row = $db->loadObject();
			if (!$row) {
				JError::customErrorPage($error);
			}
			$body = $row->html;

			$app = JFactory::getApplication();
			$siteurl = JUri::base();
			$sitename = $app->getCfg('sitename');
			$sitemail = $app->getCfg('mailfrom');
			$fromname = $app->getCfg('fromname');

			$body = str_replace('{siteurl}', $siteurl, $body);
			$body = str_replace('{sitename}', $sitename, $body);
			$body = str_replace('{sitemail}', $sitemail, $body);
			$body = str_replace('{fromname}', $fromname, $body);
			$body = str_replace('{errorcode}', $error->getCode(), $body);
			$body = str_replace('{errormessage}', $error->getMessage(), $body);

			header("HTTP/1.0 404 Not Found");

			JResponse::setBody($body);
			echo JResponse::toString();

			@ob_flush();
			jexit();
		}

		JError::customErrorPage($error);
	}

	public function onAfterInitialise()
	{

		$app = JFactory::getApplication();

		if ($app->isAdmin()) {

			return;
		}

		// get current url
		$uri = JFactory::getURI();
		$url = $uri->toString();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->clear();
		$query->select('*');
		$query->from('#__bfseo_urls');
		$query->where('url=' . $db->q($url));
		$query->where("new_url<>''");
		$query->where('published=1');
		$db->setQuery($query);
		$db->query();
		$row = $db->loadObject();
		if (!$row) {
			return;
		}

		// update hits
		$query->clear();
		$query->update('#__bfseo_urls');
		$query->where('bfseo_urls_id=' . $row->bfseo_urls_id);
		$query->set('hits=hits+1');
		$db->query();

		@ob_end_clean();

		switch ($row->redir_status) {
			case 307:
				header("HTTP/1.1 307 Temporary Redirect");
				break;
			default:
				header("HTTP/1.1 301 Moved Permanently");
		}
		header('Location: ' . $row->new_url);

		jexit();
	}

}
