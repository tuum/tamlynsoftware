<?php
echo $this->disclaimerText;

$app = JFactory::getApplication();
$menu = $app->getMenu()->getActive();
$itemid = 0;
if ($menu) {
	$itemid = $menu->id;
}
?>

<br/><br/>
<a class="btn btn-success" href="index.php?option=com_bfauction&view=auctions&Itemid=<?php echo $itemid ?>">Go to Auction</a>
<br/><br/>