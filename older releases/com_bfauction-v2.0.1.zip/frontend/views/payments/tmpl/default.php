<?php

defined('_JEXEC') or die();

jimport ('joomla.html.html.bootstrap');

$gateways = array(
	'paypal' => 'Paypal',
);

$orderStatus = array(
	'C' => 'Paid',
	'P' => 'Pending',
	'E' => 'Failed',
	'D' => 'Denied',
	'RF' => 'Refunded',
	'CRV' => 'Cancelled Reversal',
	'RV' => 'Reversed',
);

$item = $this->item;

$statusText = isset($orderStatus[$item->orderStatus]) ? $orderStatus[$item->orderStatus] : '-';

$commission  = $item->currentBid * ($item->commissionAmount/100);
$tax 		 = ($item->currentBid + $commission) * ($item->taxAmount/100);
$quantity 	 = $item->quantity > 1 ? $item->quantity : 1;
$totalAmount = ($item->currentBid + $item->shipping + $tax + $commission) * $quantity;
$delivery	 = $item->deliveryOption;

?>

	<!-- check why this 3 divs are not loaded -->
	<div class="joomla-version-3 joomla-version-34">
		<div class="akeeba-bootstrap">
			<div class="row-fluid">
				<!-- -->

				<div class="row-fluid">
					<legend>Payment Status</legend>
					<div class="bfauction_Introtext">Information about your purchase:</div>
				</div>


				<div class="row-fluid">
					<div class="span7 form-horizontal">

						<fieldset>
							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="gateway"><?php echo JText::_('Order ID'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->orderId; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="gateway"><?php echo JText::_('Gateway'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $gateways[$item->processor]; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="status"><?php echo JText::_('Status'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $statusText; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_TITLE_TITLE'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->title; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('Price'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($item->currentBid) ?></div>
								</div>
							</div>

							<?php if ($item->commissionAmount > 0): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('Commission'); ?>:</label>
									</div>
									<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($commission) ?> (<?php echo $item->commissionAmount ?>%)</div>
									</div>
								</div>
							<?php endif; ?>

							<?php if ($item->taxAmount > 0): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('Commission'); ?>:</label>
									</div>
									<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($tax) ?> (<?php echo $item->taxAmount ?>%)</div>
									</div>
								</div>
							<?php endif; ?>

							<?php if ($item->shipping > 0): ?>
							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('Shipping'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($item->shipping) ?></div>
								</div>
							</div>
							<?php endif; ?>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('Quantity'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->quantity; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('Delivery'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->deliveryOption == COM_BFAUCTION_DELIVERY_DIRECT ?  JText::_('COM_BFAUCTION_DELIVERY_OPTION2') : JText::_('COM_BFAUCTION_DELIVERY_OPTION1') ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('Amount'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div><strong><?php echo bfauctionHelper::toCurrency($item->totalAmount) ?></strong>
									</div>
								</div>
							</div>

							<?php if (isset($this->paymentButton)): ?>
								<div class="control-group">
										<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><strong><?php echo $this->paymentButton; ?></strong>
										</div>
									</div>
								</div>
							<?php endif; ?>

						</fieldset>
					</div>
				</div>


			</div>
		</div>
	</div>


