<?php
/**
 * $Id: default.php 90 2014-05-11 12:54:57Z tuum $
 * Bid now view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

jimport ('joomla.html.html.bootstrap');

//check form is submitted from our site
JRequest::checkToken() or die( 'Invalid Token' );

$user = JFactory::getUser();
$nextBid = JFactory::getApplication()->input->post->get('bid', 0, 'float');

$item = $this->items[0];

require_once( JPATH_COMPONENT.'/assets/confirm.php' );

// Overrides
if ($item->bidIncrement > 0) {
	$this->cparams->bidIncrement = $item->bidIncrement;
}
if ($item->shipping > 0) {
	$this->cparams->shipping = $item->shipping;
}
if ($item->commissionAmount > 0) {
	$this->cparams->commissionAmount = $item->commissionAmount;
}
if ($item->taxAmount > 0) {
	$this->cparams->taxAmount = $item->taxAmount;
}
?>


<div class="row-fluid">
	<div class="bfauction_Introtext">
		<?php echo JText::_( 'COM_BFAUCTION_TITLE_ARE_YOU_SURE_BID' ); ?>&nbsp;<span class='itemTitle'><?php echo $item->title; ?>&nbsp;(<?php if($item->productId){ echo $item->productId; }else{ echo $item->bfauction_item_id; } ?></span>)?
	</div>
</div>

<div class="row-fluid">
	<div class="span7 form-horizontal">
		<fieldset>
			<form action="<?php echo JRoute::_('index.php?option=com_bfauction&view=auctions&task=mybid'); ?>" method="post" name="adminForm" id="adminForm">

			<div class="control-group">
				<div class="control-label bfauction_Label">
					<label for="BidNow">
						<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_NOW' ); ?>:
					</label>
				</div>
				<div class="controls bfauction_Details bidnowForm">
					<?php echo $this->cparams->currencySymbolAfter ? '' : $this->cparams->bfcurrency; ?>
					<input class="inputbox" type="text" name="bid" id="bid" size="5" value="<?php echo $nextBid; ?>" onblur="process()" />&nbsp;<?php echo $this->cparams->currencySymbolAfter ? $this->cparams->bfcurrency : ''; ?>
					<input type="hidden" name="option" value="com_bfauction" />
					<input type="hidden" name="task" value="mybid" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="cid" value="<?php echo $item->bfauction_item_id; ?>" />
					<input type="hidden" name="bidIncrement" value="<?php echo $this->cparams->bidIncrement; ?>" />
					<input type="hidden" name="tax" id="tax">
					<input type="hidden" name="commission" id="commission">
					<?php echo JHTML::_( 'form.token' ); ?>
				</div>
			</div>

			<?php if($item->shipping > 0) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="shipping">
							<?php echo JText::_( 'COM_BFAUCTION_TITLE_SHIPPING' ); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<strong><?php echo $this->cparams->currencySymbolAfter ? '' : $this->cparams->bfcurrency; ?><?php echo $this->cparams->shipping;?>&nbsp;<?php echo $this->cparams->currencySymbolAfter ? $this->cparams->bfcurrency : ''; ?></strong>
					</div>
				</div>
			<?php } ?>

			<?php if($this->cparams->includeCommission){ ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_COMMISSION' ); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="currencyCommission"><?php echo $this->cparams->currencySymbolAfter ? '' : $this->cparams->bfcurrency; ?></div><?php echo $this->cparams->commissionAmount ?><div id="divCommission"></div>
						&nbsp;<?php echo $this->cparams->currencySymbolAfter ? $this->cparams->bfcurrency : ''; ?>
					</div>
				</div>
			<?php } ?>

			<?php if($item->taxableItem && $this->cparams->includeTax){ ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="Bid">
							<?php echo JText::_( 'COM_BFAUCTION_TITLE_TAX' ); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="currencyTax" style="float: left; text-align: left;"><?php echo $this->cparams->currencySymbolAfter? '' : $this->cparams->bfcurrency; ?></div><?php echo $this->cparams->taxAmount ?><div id="divTax" style="float: left; text-align: left;"></div>
						&nbsp;<?php echo $this->cparams->currencySymbolAfter ? $this->cparams->bfcurrency : ''; ?>
					</div>
				</div>
			<?php } ?>

			<div class="control-group">
				<div class="controls bfauction_Details">
					<i><?php echo JText::_( 'COM_BFAUCTION_TITLE_MINIMUM_BID_INCREMENT' ); ?>&nbsp;<strong><?php echo $this->cparams->currencySymbolAfter ? '' : $this->cparams->bfcurrency; ?><?php echo $this->cparams->bidIncrement; ?></strong></i>
					&nbsp;<?php echo $this->cparams->currencySymbolAfter ? $this->cparams->bfcurrency : ''; ?>
				</div>
			</div>

			<div class="control-group">
				<div class="controls bfauction_Details">
					<input class="btn btn-small btn-success" name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_BID_NOW_COMMIT' ); ?>" />
					<input type="button" class="btn btn-small btn-danger" onclick="window.location='<?php echo JRoute::_('index.php?option=com_bfauction&view=auction&id='.$item->bfauction_item_id); ?>';return false;" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_CANCEL'); ?>">
				</div>
			</div>

		</form>
		</fieldset>
	</div>
</div>


<script language="javascript" type="text/javascript">
<!--
process();
//-->
</script>