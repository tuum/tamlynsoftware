<?php
defined('_JEXEC') or die();

class BfauctionDispatcher extends F0FDispatcher
{
	public function onBeforeDispatch() {
		$result = parent::onBeforeDispatch();

		if($result) {
			// Load Akeeba Strapper
			include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
			AkeebaStrapper::bootstrap();
			AkeebaStrapper::jQueryUI();
			AkeebaStrapper::addCSSfile('media://com_bfauction/css/frontend.css');
			F0FTemplateUtils::addCSS('media://com_bfauction/css/lytebox.css');
			//F0FTemplateUtils::addJS('media://com_bfauction/js/lytebox.js');
			AkeebaStrapper::addJSfile('media://com_bfauction/js/lytebox.js');
		}

		return $result;
	}

	static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
	{
		$conf	= JFactory::getConfig();

		$mailfrom 	= $conf->get('config.mailfrom');
		$fromname 	= $conf->get('config.fromname');

		$emailBody = $body;
		$mode = 1;

		JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
	}

	static function getEmailTemplate($title)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_emailitems');
		$query->where('enabled = 1 AND title='.$db->quote( $db->escape($title), false ));
		//$query->where('bfauction_category_id = '.(int)$category);
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	static function getEmailType($id, $contentType, $status, $catid)
	{
		$emailType="";

		//which event is triggering the email?

		//let's get all the email templates for this category
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('title, condition_trigger, condition_field1, condition_criteria1, condition_value1');
		$query->from($db->quoteName('#__bfauction_emailitems'));
		$query->where('bfauction_category_id = '.(int)$catid);
		$query->where('enabled');
		$db->setQuery((string)$query);
		$myemailitems = $db->loadObjectList();

		// has status (or any other field) changed since last save?
		// look at history table
		$table1 = JTable::getInstance('Contenthistory');
		$table2 = JTable::getInstance('Contenthistory');

		$query->clear();
		$query->from($db->quoteName('#__ucm_history'));
		$query->select('version_id');
		$query->where('ucm_type_id = '.(int)$contentType);
		$query->where('ucm_item_id = '.(int)$id);
		$query->order('save_date DESC');
		$db->setQuery((string)$query);
		$myids = $db->loadObjectList();

		$id1 = $myids[0]->version_id;
		$id2 = isset($myids[1]->version_id) ? $myids[1]->version_id : $myids[0]->version_id;

		$myresult = array();

		foreach($myemailitems as $i => $emailitem):
		//what is the email trigger?

		if($emailitem->condition_trigger=="0")
		{
			if(count($myids)==1 || count($myids)==0)
			{
				//initial save or content history turned off
				$emailType[$i]=$emailitem->title;
			}
			else
			{
				//not first save as this item has content history
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==1)
		{
			//field changes
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			if($condition_criteria1 == -1 || $condition_value1 == '')
			{
				// only care if this field has changed or not
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so use this email template
						$emailType[$i]=$emailitem->title;
					}
				}
			}
			else
			{
				// we want this field to change, but also have a specific value
				// basically we only want one email triggered for this status, regardless of whether there are multiple changes
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so now check if it has specific value
						if ($condition_criteria1<>"-1")
						{
							foreach (array($table1, $table2) as $mytable)
							{
								$object = new stdClass;
								$object->data = ContenthistoryHelper::prepareData($mytable);
								$object->version_note = $mytable->version_note;
								$object->save_date = $mytable->save_date;
								$myresult[] = $object;
							}

							if($condition_criteria1 == 1)
							{
								if($status == $condition_value1){
									//field is the same, so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 0)
							{
								if($status < $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 2)
							{
								if($status > $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 3)
							{
								if($status <> $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
						}
					}
				}
			}
		}
		else if($emailitem->condition_trigger==2)
		{
			//field has specific value
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			//we only care about the updated value on the form
			if ($table1->load($id1) && $condition_criteria1<>"-1")
			{
				foreach ($table1 as $mytable)
				{
					$object = new stdClass;
					$object->data = ContenthistoryHelper::prepareData($mytable);
					$object->version_note = $mytable->version_note;
					$object->save_date = $mytable->save_date;
					$myresult[] = $object;
				}

				if($condition_criteria1 == 1)
				{
					if($status == $condition_value1){
						//field is the same, so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 0)
				{
					if($status < $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 2)
				{
					if($status > $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 3)
				{
					if($status <> $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
			}
		}
		else
		{
			$emailType[$i]="";
		}
		endforeach;

		return $emailType;
	}

	static function sendEmail($myemail, $table, $catid)
	{
		$id = 'bfauction_item_id';
		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction&view=auction&id='. $table->$id.'">'.$table->$id.'</a>';

		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url

		$myemail[0]->subject=preg_replace('/{bfauction_item_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->subject); // insert id
		$myemail[0]->description=preg_replace('/{bfauction_item_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->description); // insert description

		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfauction_items'));
		$query->select('field_name');
		$query->where('bfauction_category_id = '.(int)$catid);
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		//get list of all fields in the database
		foreach($myFields AS $field)
		{
			$fieldname=$field->field_name;
			if(is_array($table->$fieldname)){
				$table->$fieldname = implode(",", $table->$fieldname);
			}
			$myemail[0]->description=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->description);
			$myemail[0]->subject=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->subject);
		}

		$emailSubject = $myemail[0]->subject;
		$body = $myemail[0]->description;
		$sendEmailTo = $myemail[0]->sendTo;

		BauctionDispatcher::sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject);
	}

	static function triggerEmails($emailType, $id, $bidId){
		$app = JFactory::getApplication();
		$params = $app->getParams();
		$dateFormat = $params->get( 'dateFormat' );

		if($emailType == "Outbid" | $emailType == "LoosingBid"){
			//get previous high bidder from bid history
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			// if there is no previous bidder, don't send any outbid or loosing email.
			if($rows == null){
				return false;
			}

			// do not send outbid email if this is the first bid on an item
			if(count($rows)<2){
				return false;
			}

			//don't send outbid or loosing email if the same person bids twice in a row
			if($rows[0]->created_by == $rows[1]->created_by){
				return false;
			}

			//set bid id for loosing email so we send to the correct person
			if($emailType == "LoosingBid"){
				$bidId = $rows[1]->id;
			}
		}else if($emailType == "Watchlist"){
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('a.*');
			$query->from('#__bfauction_watchlists AS a');
			$query->where('a.bfauction_watchlist_id = '.(int)$id);
			$query->select('c.email, c.username');
			$query->join('LEFT', '#__users AS c ON c.id = a.created_by');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$id = (int)$rows[0]->itemid;
		}

		$myemail = BfauctionDispatcher::getEmailTemplate($emailType);
		$myitem =  BfauctionDispatcher::getItem($id);

		if($myemail == null){
			//no email template found so don't send anything
			return false;
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get bid details
		if($bidId == null){
			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');
			//get the bid with the largest id
		}else{
			//get a sepecific bid
			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->where('bfauction_bid_id = '.(int)$bidId);
			$query->order('bid_time desc');
		}

		$db->setQuery((string)$query);
		$bids = $db->loadObjectList();

		//get seller details
		$query->clear();
		$query->select('*');
		$query->from('#__users');
		$query->where('id = '.(int)$myitem[0]->created_by);

		$db->setQuery((string)$query);
		$userdetail = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$sellername = $userdetail[0]->name; //get seller name
		$selleremail = $userdetail[0]->email; //get seller email

		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction&view=auction&id='. $myitem[0]->id.'">'.$myitem[0]->title.'</a>';

		//repace fields with actual data
		if($emailType != "Watchlist"){
			$myemail[0]->description=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->description); // insert bfcurrency
			$myemail[0]->description=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->description); // insert bid amount
			$myemail[0]->description=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->description); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->description); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->description); // insert user name
		}else{
			$myemail[0]->description=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->description); // insert user name
		}
		$myemail[0]->description=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->description); // insert item title
		$myemail[0]->description=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->description); // insert item id
		$myemail[0]->description=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->description); // insert product id
		$myemail[0]->description=preg_replace('/{sellername}/', $sellername , $myemail[0]->description); // insert seller name
		$myemail[0]->description=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->description); // insert seller email
		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->description); // insert deliverymethod

		if($emailType != "Watchlist"){
			$myemail[0]->subject=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->subject); // insert bfcurrency
			$myemail[0]->subject=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->subject); // insert bid amount
			$myemail[0]->subject=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->subject); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->subject); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->subject); // insert user name
		}else{
			$myemail[0]->subject=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->subject); // insert user name
		}
		$myemail[0]->subject=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->subject); // insert item title
		$myemail[0]->subject=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->subject); // insert item id
		$myemail[0]->subject=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->subject); // insert product id
		$myemail[0]->subject=preg_replace('/{sellername}/', $sellername , $myemail[0]->subject); // insert seller name
		$myemail[0]->subject=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->subject); // insert seller email
		$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
		$myemail[0]->subject=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->subject); // insert url

		$subject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		if($emailType == "Outbid"){
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $rows[1]->email, $subject);
		}else if($emailType == "Watchlist"){
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $rows[0]->email, $subject);
		}else{
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $bids[0]->email, $subject);
		}

		return true;
	}

	static function getItem($itemId)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id = '.(int)$itemId);
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	/*
	 * Function checkIfAuctionHasEnded
	 * This function loops through all active auction items
	 * and sees if auction has ended since this function last run.
	 * It also triggers the watchlist emails if there is less than 24hours
	 * left on an auction item.
	 */
	public static function checkIfAuctionHasEnded()
	{
		$app		= JFactory::getApplication();
		$params		= $app->getParams();
		$dst_fix = $params->get('dst');
		$allowEmail = $params->get('allowEmail');
		$allowAutoBidding = $params->get('allowAutoBidding');

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('bfauction_item_id AS id');
		$query->select('endDate');
		$query->select('currentBid');
		$query->select('buyNowPrice');
		$query->select('reservePrice');
		$query->select('quantity');
		$query->select('quantityPurchased');
		$query->select('created_by, tax, commission');
		$query->from('#__bfauction_items');
		$query->where('winEmailSent = 0');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList( );

		// is dst on on that particular date ?
		$now = JFactory::getDate();
		$date=$now->format('Y-m-d H:i:s');
		if (is_numeric( $date))
		{
			$ts = $date;
		} else {
			$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		$now = JFactory::getDate();
		$currentDate=$now->format('Y-m-d H:i:s');

		//get date for watchlist
		$now->modify("+24 hours");
		$adjustedEndDate=$now->format('Y-m-d H:i:s');

		// Check if any auctions have finished since this last run
		foreach($rows as $row){
			if ($currentDate > $row->endDate){
				//mark winEmailSent as true
				$now = JFactory::getDate();
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);
				if( ($row->currentBid == $row->buyNowPrice) || !($allowEmail) ){
					//don't send emails for BuyNow purchase or when emails are turned off
					//but still set the flag winEmailSent so we know auction has finished.
					$query->update('#__bfauction_items');
					$query->set('winEmailSent= 2');
					if(is_callable(array('JDate', 'toSql'))){
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toSql() ), false ));
					}else{
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toMySQL() ), false ));
					}
					$query->where('id = '.(int)$row->id);

					//send Seller email
					if($allowEmail)
					{
						BfauctionDispatcher::triggerEmails("Seller", (int)$row->id, NULL);
					}
				}else{
					//auction finished, trigger winning email

					//-------------------------------------
					$maxbid=0;
					if($allowAutoBidding){
						//are there any automatic bids for this item?
						$db			= JFactory::getDBO();

						$query->clear();
						$query->select('a.username, a.created_by, a.email, a.bid, a.maxbid, a.itemid, a.id, a.bid_time, a.bidCurrency, a.deliveryOption');
						$query->from('#__bfauction_bids AS a');
						$query->where('a.itemid='.(int)$row->id);
						$query->where('a.maxbid>0');
						$query->order('a.id DESC');
						$db->setQuery((string)$query);
						$autobidrows = $db->loadObjectList();
						if ($db->getErrorNum())
						{
							echo $db->stderr();
							return false;
						}
						if($autobidrows){
							$maxbid = $autobidrows[0]->maxbid;
						}
					}

					//-------------------------------------

					//is reserve price met?
					if($row->currentBid < $row->reservePrice){
						//reserve price not met, but is there an automatic bid?
						if($maxbid >= $row->reservePrice){
							//automatic bid is greater than reserve, so set current bid to be reserve price

							$db = JFactory::getDbo();
							$query	= $db->getQuery(true);

							// do we also need to recalcualte tax, commission etc?
							$query->update('#__bfauction_items');
							$query->set('currentBid = '.(float)$row->reservePrice);
							$query->set('saleType = 1');
							$query->where('bfauction_item_id = '.(int)$row->id);

							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							$query->clear();
							if(is_callable(array('JDatabaseQuery', 'columns'))){
								$query->insert('#__bfauction_bids');
								$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('created_by'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
								$query->values( (int)$row->id.', '.$db->quote( $db->escape($autobidrows[0]->username), false ).', '.(int)$row->created_by.', '.$db->quote( $db->escape($autobidrows[0]->email), false ).', '.(float)$row->reservePrice.', '.$db->quote($autobidrows[0]->bid_time, false ).', '.$db->quote($autobidrows[0]->bidCurrency, false ).', '.(float)$row->tax.', '.(float)$row->commission.', '.(float)$autobidrows[0]->maxbid.', '.(int)$row->quantity.', '.$db->quote( $db->escape($autobidrows[0]->deliveryOption), false ) );
							}else{
								//joomla 1.6
								$query = 'INSERT INTO #__bfauction_bids (`itemid`, `username`, `created_by`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
										. ' VALUES ('.(int)$row->id.', '.$db->quote( $db->escape($autobidrows[0]->username), false ).', '.(int)$row->created_by.', '.$db->quote( $db->escape($autobidrows[0]->email), false ).', '.(float)$row->reservePrice.',  "'.$autobidrows[0]->bid_time.'", "'.$autobidrows[0]->bidCurrency.'", '.(float)$row->tax.', '.(float)$row->commission.', '.(float)$autobidrows[0]->maxbid.', '.(int)$row->quantity.', '.$db->quote( $db->escape($autobidrows[0]->deliveryOption), false ).')'
												;
							}
							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							BfauctionDispatcher::triggerEmails("WinningBid", (int)$row->id, NULL);
							BfauctionDispatcher::triggerEmails("Seller", (int)$row->id, NULL);
						}else{
							//reserve not met, and no automatic bid
							BfauctionDispatcher::triggerEmails("ReserveNotMet", (int)$row->id, NULL);
						}
					}else{
						BfauctionDispatcher::triggerEmails("WinningBid", (int)$row->id, NULL);
						BfauctionDispatcher::triggerEmails("Seller", (int)$row->id, NULL);
					}
					BfauctionDispatcher::triggerEmails("LoosingBid", (int)$row->id, NULL);

					$query->clear();
					$query->update('#__bfauction_items');
					$query->set('winEmailSent= 1');
					if(is_callable(array('JDate', 'toSql'))){
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toSql() ), false ));
						$query->set('quantity = '.(int)$row->quantityPurchased);
					}else{
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toMySQL() ), false ));
						$query->set('quantity = '.(int)$row->quantityPurchased);
					}
					$query->where('bfauction_item_id = '.(int)$row->id);

					//for multiple quantity items, is there still some available?
					$newQuantity = $row->quantity - $row->quantityPurchased;
					if($newQuantity > 1){
						JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction/tables');
						$row2 = JTable::getInstance('item', 'Table');
						$id = $row->id;

						$row2->load((int) $id);
						//exitsting item is archived and new copy is created with unique id.
						$row2->bfauction_item_id			= "";
						$row2->state     	= 1;
						$row2->highBidder	= "";
						$row2->currentBid	= 0;
						$row2->ordering 		= 0;
						$row2->winEmailSent	= 0;
						$row2->winEmailDate = '0000-00-00 00:00:00';
						$row2->saleType 	= 0;
						$row2->quantityPurchased = 0;
						$row2->deliveryOption = "";

						if($row2->relistid == 0){
							$row2->relistid = (int) $id;

							//Use images from original item.
							$row2->imageShared = (int) $id;
						}
						$row2->quantity		= (int)$newQuantity;

						// set end date to be 7 days from now
						$date = JFactory::getDate();
						$date->modify("+7 days");

						if(is_callable(array('JDate', 'toSql'))){
							$row2->endDate = $date->toSql();
						}else{
							$row2->endDate = $date->toMySQL();
						}

						if (!$row2->check()) {
							return JError::raiseWarning(500, $row2->getError());
						}
						if (!$row2->store()) {
							return JError::raiseWarning(500, $row2->getError());
						}
					}
				}

				$db->setQuery((string)$query);
				$db->query();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return;
				}
			}

			// Check to see if any watchlist emails need to be sent for this item
			//is it less than 24 hours before auction ends
			if ($adjustedEndDate > $row->endDate){
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);

				$query->select('bfauction_watchlist_id AS id');
				$query->from('#__bfauction_watchlists');
				$query->where('itemid = '.$row->id);
				$query->where('emailSent = 0');

				$db->setQuery((string)$query);
				$rowsWatchlist = $db->loadObjectList( );

				foreach($rowsWatchlist as $rowWatch){
					BfauctionDispatcher::triggerEmails("Watchlist", (int)$rowWatch->id, NULL);

					$rightNow = JFactory::getDate();
					$db2 = JFactory::getDbo();
					$query2	= $db2->getQuery(true);
					$query2->update('#__bfauction_watchlists');
					$query2->set('emailSent= 1');
					if(is_callable(array('JDate', 'toSql'))){
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toSql() ), false ));
					}else{
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toMySQL() ), false ));
					}
					$query2->where('bfauction_watchlist_id = '.(int)$rowWatch->id);

					$db2->setQuery((string)$query2);
					$db2->query();
					if ($db2->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db2->getErrorNum(), $db2->getErrorMsg()).'<br />';
						return;
					}
				}
			}
		}
	}
}