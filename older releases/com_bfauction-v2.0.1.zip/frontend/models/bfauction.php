<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionModelBfauction extends F0FModel
{
	public static function getCategoryAccess($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('access');
		$query->from('#__bfauction_categories');
		$query->where('bfauction_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	public static function getCategoryAccessResults($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('accessResults');
		$query->from('#__bfauction_categories');
		$query->where('bfauction_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	public static function getStatsAccess($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('accessStats');
		$query->from('#__bfauction_categories');
		$query->where('bfauction_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @param	int		The category ID.
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_bfauction';
		} else {
			$assetName = 'com_bfauction.category.'.(int) $categoryId;
		}

		$actions = array(
				'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}
}