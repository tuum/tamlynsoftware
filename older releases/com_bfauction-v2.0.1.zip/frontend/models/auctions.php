<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelAuctions extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'items';
	}

	public function buildQuery($overrideLimits = false)
	{
		$app = JFactory::getApplication();
		$menu = $app->getMenu()->getActive();
		$params = $menu->params;
		$category = $params->get('category');

		$user = JFactory::getUser();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$jinput = JFactory::getApplication()->input;
		$title = $jinput->get('title');
		$filter_order = $jinput->get('filter_order');
		$filter_order_dir = $jinput->get('filter_order_Dir');

		//first get all the auction items
		$query->select('a.*,  c.title AS category_name, b.username AS seller');
		$query->from('#__bfauction_items AS a');
		$query->where('a.enabled = 1');
		$query->where('a.startDate <= NOW()');

		if (!empty($title)) {
			$query->where("a.title like '%$title%'");
		}

		if (!$params->get('showAllCategories') && !empty($category)) {
		   $query->where('a.bfauction_category_id = '.$category);
		}

		$query->join('LEFT', '#__bfauction_categories AS c ON a.bfauction_category_id = c.bfauction_category_id');
		$query->join('LEFT', '#__users AS b ON a.created_by = b.id');

		if (!empty($filter_order) && !empty($filter_order_dir)) {
			$query->order("$filter_order $filter_order_dir");
		}else{
			$query->order('winEmailSent, endDate');
		}

		return $query;
	}

	public function &getItemList($overrideLimits = false, $group = '')
	{
		$items	= parent::getItemList();

		$mylist = array();
		foreach ($items as $item )
		{
			$types = array('jpg', 'jpeg', 'gif', 'png' );
			$item->image='';

			if ($item->imageShared > 0) {
				$id = $item->imageShared;
			} else {
				$id = $item->bfauction_item_id;
			}

			foreach($types as $type)
			{
				$temp_pic = JPATH_SITE."/images/com_bfauction/".$id."img1_t.".$type;
				if (file_exists($temp_pic))
				{
					$item->image = "./images/com_bfauction/".$id."img1_t.".$type;
				}
			}
			array_push($mylist, $item);
		}
		return $items;
	}

	public function getForm($data = array(), $loadData = true, $source = null)
	{
		$form = parent::getForm($data, $loadData, $source);

		if(isset($data["bfauction_item_id"]))
		{
			$form->id = $data["bfauction_item_id"];

			if ($data['imageShared'] > 0) {
				$id = $data['imageShared'];
			} else {
				$id = $form->id;
			}

			for($i=1; $i < 21; $i++ )
			{
				$imagename='image'.$i;
				$imagefullname='imagefull'.$i;

				$types = array('jpg', 'jpeg', 'gif', 'png' );
				foreach($types as $type)
				{
					$temp_pic = JPATH_SITE."/images/com_bfauction/".$id."img".$i."_t.".$type;
					if (file_exists($temp_pic))
					{
						$form->$imagename="./images/com_bfauction/".$id."img".$i."_t.".$type;
						$form->$imagefullname= "./images/com_bfauction/".$id."img".$i.".".$type;
					}
				}
			}

			//get seller
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('b.username AS seller');
			$query->from('#__bfauction_items AS a');
			$query->join('LEFT', '#__users AS b ON a.created_by = b.id');
			$query->where('a.bfauction_item_id = '.$form->id);

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();

			if(isset($rows[0]->seller))
			{
				$form->seller = $rows[0]->seller;
			}
		}

		return $form;
	}

	function getLastBidData()
	{
		$id = JFactory::getApplication()->input->get('id', 0,'INT');

		// Load the data
		if (empty( $this->_lastbiddata )) {
			$query = ' SELECT * FROM #__bfauction_bids '
					. '  WHERE `itemid` = '.(int)$id.''
							. ' ORDER BY bid_time desc'
									;
									$this->_db->setQuery( $query );
									$this->_lastbiddata = $this->_db->loadObject();
		}
		if (!$this->_lastbiddata) {
			$this->_lastbiddata = new stdClass();
			$this->_lastbiddata->id = 0;
			$this->_lastbiddata->title = null;
			$this->_lastbiddata->maxbid = 0;
		}
		return $this->_lastbiddata;
	}

	static function getUserProfile($user_id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__user_profiles').' AS a');
		$query->select('a.profile_value AS address1');
		$query->select('b.profile_value AS address2');
		$query->select('c.profile_value AS city');
		$query->select('d.profile_value AS region');
		$query->select('e.profile_value AS postcode');
		$query->select('f.profile_value AS country');
		$query->select('g.profile_value AS phone');
		$query->join('LEFT', '#__user_profiles AS b ON b.user_id = a.user_id AND b.profile_key = \'profile.address2\'');
		$query->join('LEFT', '#__user_profiles AS c ON c.user_id = a.user_id AND c.profile_key = \'profile.city\'');
		$query->join('LEFT', '#__user_profiles AS d ON d.user_id = a.user_id AND d.profile_key = \'profile.region\'');
		$query->join('LEFT', '#__user_profiles AS e ON e.user_id = a.user_id AND e.profile_key = \'profile.postcode\'');
		$query->join('LEFT', '#__user_profiles AS f ON f.user_id = a.user_id AND f.profile_key = \'profile.country\'');
		$query->join('LEFT', '#__user_profiles AS g ON g.user_id = a.user_id AND g.profile_key = \'profile.phone\'');
		$query->where('a.user_id ='.$user_id.' AND a.profile_key = \'profile.address1\'');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		if($rows){
			return $rows[0];
		}else{
			return null;
		}
	}
}