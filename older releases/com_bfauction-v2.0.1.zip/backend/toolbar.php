<?php
/**
 *  @package BF Auction
*  @copyright Copyright (c)2014 Tamlyn Software
*  @license GNU General Public License version 3, or later
*/

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionToolbar extends F0FToolbar
{
	public function onLogsBrowse()
	{
		//$this->onBrowse();

		if (F0FPlatform::getInstance()->isBackend() || $this->renderFrontendSubmenu)
		{
			$this->renderSubmenu();
		}

		if (!F0FPlatform::getInstance()->isBackend() && !$this->renderFrontendButtons)
		{
			return;
		}

		// Set toolbar title
		$option = $this->input->getCmd('option', 'com_bfauction');
		$subtitle_key = strtoupper($option . '_TITLE_' . $this->input->getCmd('view', 'cpanel'));
		JToolBarHelper::title(JText::_(strtoupper($option)) . ' &ndash; <small>' . JText::_($subtitle_key) . '</small>', str_replace('com_', '', $option));

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
	}

	public function onCategoriesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
	}

	public function onItemsBrowse()
	{
		//show toolbar on front end
		$this->renderFrontendButtons = true;

		$this->onBrowse();
		include_once JPATH_SITE.'/components/com_bfauction/models/bfauction.php';
		$canDo	= BfauctionModelBfauction::getActions();

		if (F0FPlatform::getInstance()->isBackend())
		{
			if ($canDo->get('core.admin')) {
				JToolBarHelper::custom('export', 'export', 'export', 'COM_BFAUCTION_EXPORT_CSV', false);
				JToolBarHelper::custom('import', 'import', 'import', 'COM_BFAUCTION_IMPORT_CSV', false);
			}
		}
		else
		{
			JToolBarHelper::title(JText::_('COM_BFAUCTION_TITLE_MY_AUCTION_ITEMS'));
		}

		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom( 'copy', 'copy', 'copy', 'COM_BFAUCTION_TOOLBAR_COPY' );
			JToolBarHelper::custom( 'relist', 'relist', 'relist', 'COM_BFAUCTION_TOOLBAR_RELIST', false );
		}

		if (F0FPlatform::getInstance()->isBackend())
		{
			JToolBarHelper::divider();
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
		}
	}

	public function onItemsEdit()
	{
		include_once JPATH_SITE.'/components/com_bfauction/models/bfauction.php';
		$canDo	= BfauctionModelBfauction::getActions();

		if ($canDo->get('core.create')) {
			//show toolbar on front end
			$this->renderFrontendButtons = true;

			parent::onEdit();
		}

		if (F0FPlatform::getInstance()->isBackend())
		{
			JToolBarHelper::custom( 'bids', 'bids', 'bids', 'COM_BFAUCTION_TITLE_BID_HISTORY', false );
		}
	}

	public function onItemsAdd()
	{
		include_once JPATH_SITE.'/components/com_bfauction/models/bfauction.php';
		$canDo	= BfauctionModelBfauction::getActions();

		if ($canDo->get('core.create')) {
			//show toolbar on front end
			$this->renderFrontendButtons = true;

			parent::onAdd();
		}
	}

	public function onEmailitemsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
	}

	public function onRptitemsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
	}

	public function onRptsalesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=cpanels');
	}

	public function onBidsEdit()
	{
		parent::onEdit();

		$cid = JRequest::getVar('cid');
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=item&id='.(int)$cid);
	}

	public function onBidsBrowse()
	{
		//parent::onBrowse();

		$cid = JRequest::getVar('cid');
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction&view=item&id='.(int)$cid);
	}
	
	public function onMaintenancesBrowse()
	{		
		JToolBarHelper::title(JText::_('COM_BFAUCTION') . ': ' . JText::_('COM_BFAUCTION_TITLE_MAINTENANCE'));
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfauction');
	}

}