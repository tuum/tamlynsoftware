<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

//note this class name intentionally does not inlcude underscore before plus
class BfauctionModelCategories extends F0FModel
{
	public function __construct($config = array()) {
		// fix the component name so it includes underscore before plus
		$config['option'] = 'com_bfauction';

		parent::__construct($config);

		$this->table = 'categories';
	}
}