<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$params = JComponentHelper::getParams('com_bfauction');
$downloadid = $params->get('downloadid');

$lang = JFactory::getLanguage();
$icons_root = JURI::base().'media/com_bfauction/images/';

F0FTemplateUtils::addCSS('media://com_bfauction/css/backend.css');
?>
<div id="cpanel" class="row-fluid">
	<div class="span10">

		<div class=icon>
			<a href="index.php?option=com_bfauction&view=categories">
				<div class="bfauction-icon-category"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_CATEGORIES'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfauction&view=items">
				<div class="bfauction-icon-item"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_ITEMS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfauction&view=emailitems">
				<div class="bfauction-icon-email"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_EMAIL_TEMPLATE'); ?></span>
			</a>
		</div>

		<!--
		<div class=icon>
			<a href="index.php?option=com_bfauction&view=rptitems">
				<div class="bfauction-icon-report"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_RPTITEMS'); ?></span>
			</a>
		</div>
 		-->

		<!--
		<div class=icon>
			<a href="index.php?option=com_bfauction&view=rptsales">
				<div class="bfauction-icon-sales"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_RPTSALES'); ?></span>
			</a>
		</div>
		-->

		<div class=icon>
			<a href="index.php?option=com_bfauction&view=logs">
				<div class="bfauction-icon-logs"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_USERLOG'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfauction&view=maintenance">
				<div class="bfauction-icon-maintenance"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_MAINTENANCE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://www.tamlynsoftware.com/products/bf-auction/bf-auction-user-guide.html" target="_blank">
				<div class="bfauction-icon-documentation"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_USERGUIDE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/contact-us/support-tickets.html" target="_blank">
				<div class="bfauction-icon-help"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_SUPPORT_TICKETS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://extensions.joomla.org/extensions/e-commerce/auction/19721" target="_blank">
				<div class="bfauction-icon-rate"> </div>
				<span><?php echo JText::_('COM_BFAUCTION_TITLE_RATE_AND_REVIEW'); ?></span>
			</a>
		</div>
	</div>
</div>

<div class="ak_clr"></div>

<div class="row-fluid footer">
<div class="span12">
	<?php global $bfauction_version; ?>
	<p style="font-size: small" class="well">Copyright &copy;<?php echo date('Y');?> Tamlyn Software. All Rights Reserved.
		<?php echo JText::_( 'COM_BFAUCTION_VERSION'); ?>
		<?php echo $bfauction_version; ?>
	</p>
</div>
</div>