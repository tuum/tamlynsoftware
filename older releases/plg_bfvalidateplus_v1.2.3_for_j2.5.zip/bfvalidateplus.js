/**
 * @version		$Id: bfvalidateplus.js 2 2011-11-15 05:11:30Z tuum $
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

Object.append(Browser.Features, {
	inputemail: (function() {
		var i = document.createElement("input");
		i.setAttribute("type", "email");
		return i.type !== "text";
	})()
});

/**
 * Unobtrusive Form Validation library
 *
 * Inspired by: Chris Campbell <www.particletree.com>
 *
 * @package		Joomla.Framework
 * @subpackage	Forms
 * @since		1.5
 * @modified by		Tim Plummer <tim@tamlyncreative.com.au>
 * @changes		11/10/2008 - Tim added radio & checkbox validation
 *				21/11/2008 - Tim fix for numeric validation
 *				13/03/2009 - Tim fix for par.parentNode is undefined (J.parentNode is null or not a object)
 *              10/06/2009 - Tim added validate-dropdown
 *				10/10/2009 - Tim added checkbox2, checkbox3 and checkbox4
 *				26/11/2009 - Tim added checkbox5-10
 *				09/04/2011 - Tim upgraded for Joomla 1.6 (NOTE: J1.6 now has validation here /media/system/js/validate.js)
 *				15/06/2011 - Tim added select-one validation for dropdown
 *				18/02/2014 - Fixed checkbox validation issue in J2.5
 */
var JFormValidator = new Class({
	initialize: function()
	{
		// Initialize variables
		this.handlers	= Object();
		this.custom		= Object();

		// Default handlers
		this.setHandler('username',
			function (value) {
				regex = new RegExp("[\<|\>|\"|\'|\%|\;|\(|\)|\&]", "i");
				return !regex.test(value);
			}
		);

		this.setHandler('password',
			function (value) {
				regex=/^\S[\S ]{2,98}\S$/;
				return regex.test(value);
			}
		);

		this.setHandler('numeric',
			function (value) {
				regex=/^(\d|-)?(\d|,)*\.?\d*$/;
				return regex.test(value);
			}
		);

		this.setHandler('email',
			function (value) {
				regex=/^[a-zA-Z0-9._-]+(\+[a-zA-Z0-9._-]+)*@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,4}$/;
				return regex.test(value);
			}
		);	
		
		this.setHandler('dropdown',
			function (value) {
				if(value == -1){
				   return false;
				}else{
				   return true;
				}
			}
		);		

		// Attach to forms with class 'form-validate'
		var forms = $$('form.form-validate');
		forms.each(function(form){ this.attachToForm(form); }, this);
	},

	setHandler: function(name, fn, en)
	{
		en = (en == '') ? true : en;
		this.handlers[name] = { enabled: en, exec: fn };
	},

	attachToForm: function(form)
	{
		// Iterate through the form object and attach the validate method to all input fields.
		form.getElements('input,textarea,select,button').each(function(el){
			if (el.hasClass('required')) {
				el.set('aria-required', 'true');
				el.set('required', 'required');
			}			
			if ((document.id(el).get('tag') == 'input' || document.id(el).get('tag') == 'button') && document.id(el).get('type') == 'submit') {
				if (el.hasClass('validate')) {
					el.onclick = function(){return document.formvalidator.isValid(this.form);};
				}
			} else {
				el.addEvent('blur', function(){return document.formvalidator.validate(this);});
				if (el.hasClass('validate-email') && Browser.Features.inputemail) {
					el.type = 'email';
				}				
			}
		});
	},

	validate: function(el)
	{
		el = document.id(el);
		
		// Ignore the element if its currently disabled, because are not submitted for the http-request. For those case return always true.
		if(el.get('disabled')) {
			this.handleResponse(true, el);
			return true;
		}
		
		// If the field is required make sure it has a value
		if (el.hasClass('required')) {
			if(el.getProperty('type') == "select-one"){
				var si = el.selectedIndex;
                        	value = el.options[si].value;
				if(value==-1){
				   	   this.handleResponse(false, el);
				   	   return false;
				}else{   
				   	   this.handleResponse(true, el);
				   	   return true;
				}
			}		
			//if (el.get('tag')=='fieldset' && (el.hasClass('radio') || el.hasClass('checkboxes'))) {
			if(el.getProperty('type') == "radio" || el.getProperty('type') == "checkbox"){
			// checkbox and radio can be blank
				
				   if(el.getProperty('type') == "radio"){
					var options = el.getParent().getParent().getElementsByTagName('input');
					
					var nl, i;
					var counter=0;
					//is at least one radio selected
					for (i=0, nl = options; i<nl.length; i++) {
						//alert(nl[i].value);
						if (nl[i].checked){
							counter=1;
					 	}
				   	}
				   	
				   	if(counter==1){
				   	   this.handleResponse(true, el);
				   	   return true;
				   	}else{
				   	   this.handleResponse(false, el);
				   	   return false;
				   	}
					
				   }else if(el.getProperty('type') == "checkbox"){	
					var options = el.getParent().getParent().getElementsByTagName('input');
										
					var nl, i;
					var counter=0;
					//find out how many checkboxes are selected
					for (i=0, nl = options; i<nl.length; i++) {
						if (nl[i].checked){
							counter++;
					 	}
				   	}
				   	
				   	if(el.hasClass('validate-checkbox2')){
				   	   //are exactly two checkboxes selected
				   	   if(counter==2){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
				   	}else if(el.hasClass('validate-checkbox3')){
				   	   //are exactly three checkboxes selected
				   	   if(counter==3){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox4')){
				   	   //are exactly four checkboxes selected
				   	   if(counter==4){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox5')){
				   	   //are exactly five checkboxes selected
				   	   if(counter==5){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox6')){
				   	   //are exactly six checkboxes selected
				   	   if(counter==6){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox7')){
				   	   //are exactly seven checkboxes selected
				   	   if(counter==7){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox8')){
				   	   //are exactly eight checkboxes selected
				   	   if(counter==8){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox9')){
				   	   //are exactly nine checkboxes selected
				   	   if(counter==9){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }
					}else if(el.hasClass('validate-checkbox10')){
				   	   //are exactly ten checkboxes selected
				   	   if(counter==10){
				   	   	this.handleResponse(true, el);
						return true;
					   }else{
						this.handleResponse(false, el);
						return false;
				   	   }				   	   				   	   			   	   			   	   				   	   				   	   
				   	}else if(counter>0){
				   	   //default validate-checkbox at least one checkox is selected
					   this.handleResponse(true, el);
					   return true;
					}else{
					   this.handleResponse(false, el);
					   return false;
				   	}
					
				   }else{
					for(var i=0;i < el.length;i++) {
				    
						if (document.id(el.get('id')+i)) {
						if (document.id(el.get('id')+i).checked) {
							break;
						}
					}
					else {
						this.handleResponse(false, el);
						return false;
					}
				   }
				}
			}
			else if (!(el.get('value'))) {
				this.handleResponse(false, el);
				return false;
			}
		}

		// Only validate the field if the validate class is set
		var handler = (el.className && el.className.search(/validate-([a-zA-Z0-9\_\-]+)/) != -1) ? el.className.match(/validate-([a-zA-Z0-9\_\-]+)/)[1] : "";
		if (handler == '') {
			this.handleResponse(true, el);
			return true;
		}
		
		// Check the additional validation types
		if ((handler) && (handler != 'none') && (this.handlers[handler]) && el.get('value')) {
			// Execute the validation handler and return result
			if (this.handlers[handler].exec(el.get('value')) != true) {
				this.handleResponse(false, el);
				return false;
			}
		}		

		// Return validation state
		this.handleResponse(true, el);
		return true;
	},

	isValid: function(form)
	{
		var valid = true;

		// Validate form fields
		//var elements = form.getElements('fieldset').concat($A(form.elements));
		var elements = form.getElements('fieldset').concat(Array.from(form.elements));
		for (var i=0;i < elements.length; i++) {
			if (this.validate(elements[i]) == false) {
				valid = false;
			}
		}

		// Run custom form validators if present
		new Hash(this.custom).each(function(validator){
			if (validator.exec() != true) {
				valid = false;
			}
		});

		return valid;
	},

	handleResponse: function(state, el)
	{
		// Find the label object for the given field if it exists
		if (!(el.labelref)) {
			var labels = $$('label');
			labels.each(function(label){
				if (label.get('for') == el.get('id')) {
					el.labelref = label;
				}
			});
		}

		// Set the element and its label (if exists) invalid state
		if (state == false) {
			el.addClass('invalid');
			el.set('aria-invalid', 'true');
			if (el.labelref) {
				document.id(el.labelref).addClass('invalid');
				document.id(el.labelref).set('aria-invalid', 'true');
			}
		} else {
			el.removeClass('invalid');
			el.set('aria-invalid', 'false');
			if (el.labelref) {
				document.id(el.labelref).removeClass('invalid');
				document.id(el.labelref).set('aria-invalid', 'false');
			}

			if(el.getProperty('type') == "checkbox"){
				//now for checkbox, remove all the other invalid from other fields
				var options = el.getParent().getParent().getElementsByTagName('input');
				var nl, i;

				//loop through all the checkboxes in this group
				for (i=0, nl = options; i<nl.length; i++) {
					el1 = document.id(nl[i].id);

					if(el1){
		      				el1.removeClass('invalid');
					      	el1.set('aria-invalid', 'false');
					      	el1.set('aria-required', 'false');
					      	el1.removeAttribute("required");

						if (el1.labelref) {
							document.id(el1.labelref).removeClass('invalid');
							document.id(el1.labelref).set('aria-invalid', 'false');
						}
					}
				}
			}


		}
	}
});

document.formvalidator = null;
window.addEvent('domready', function(){
	document.formvalidator = new JFormValidator();
});