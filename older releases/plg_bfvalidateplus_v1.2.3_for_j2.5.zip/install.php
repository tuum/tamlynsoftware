<?php
/**
 * $Id: install.php 2 2011-11-15 05:11:30Z tuum $
 * BF Validate Plus Plugin
 *
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU General Public License version 3 or later.
 *
 *	  BF Validate Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Validate Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Validate Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access
defined('_JEXEC') or die;

/**
 * @subpackage	plg_system_bfvalidate
 * @since		1.5
 */
class plgBFValidatePlusInstallerScript
{
	/**
	 * Post-flight extension installer method.
	 *
	 * This method runs after all other installation code.
	 *
	 * @param	$type
	 * @param	$parent
	 *
	 * @return	void
	 * @since	1.5
	 */
	function postflight($type, $parent)
	{
		?>
		<p><big><strong>BF Validate Plus</strong> version %s has been successfully installed for the first time or upgraded.</big></p>
		<?php
	}
}

?>