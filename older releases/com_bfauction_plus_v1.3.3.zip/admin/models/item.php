<?php
/**
 * $Id: item.php 75 2013-06-16 05:35:03Z tuum $
 * Item Model for bfauction_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.modeladmin');

/**
 * Item Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusModelitem extends JModelAdmin
{
	/**
	 * @var		string	The prefix to use with controller messages.
	 * @since	1.6
	 */

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param	object	A record object.
	 * @return	boolean	True if allowed to delete the record. Defaults to the permission set in the component.
	 * @since	1.6
	 */
	protected function canDelete($record)
	{
		if (!empty($record->id)) {
			if ($record->state != -2) {
				return ;
			}
			$user = JFactory::getUser();

			if ($record->catid) {
				return $user->authorise('core.delete', 'com_bfauction_plus.category.'.(int) $record->catid);
			}
			else {
				return parent::canDelete($record);
			}
		}
	}

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param	object	A record object.
	 * @return	boolean	True if allowed to change the state of the record. Defaults to the permission set in the component.
	 * @since	1.6
	 */
	protected function canEditState($record)
	{
		$user = JFactory::getUser();

		if (!empty($record->catid)) {
			return $user->authorise('core.edit.state', 'com_bfauction_plus.category.'.(int) $record->catid);
		}
		else {
			return parent::canEditState($record);
		}
	}

	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param	type	The table type to instantiate
	 * @param	string	A prefix for the table class name. Optional.
	 * @param	array	Configuration array for model. Optional.
	 * @return	JTable	A database object
	 * @since	1.6
	 */
	public function getTable($type = 'Item', $prefix = 'Table', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param	array	$data		An optional array of data for the form to interogate.
	 * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
	 * @return	JForm	A JForm object on success, false on failure
	 * @since	1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app	= JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_bfauction_plus.item', 'item', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) {
			return false;
		}

		// Determine correct permissions to check.
		if ($this->getState('bfauction_plus.id')) {
			// Existing record. Can only edit in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.edit');
		} else {
			// New record. Can only create in selected categories.
			$form->setFieldAttribute('catid', 'action', 'core.create');
		}

		// Modify the form based on access controls.
		if (!$this->canEditState((object) $data)) {
			// Disable fields for display.
			$form->setFieldAttribute('ordering', 'disabled', 'true');
			$form->setFieldAttribute('state', 'disabled', 'true');
			$form->setFieldAttribute('publish_up', 'disabled', 'true');
			$form->setFieldAttribute('publish_down', 'disabled', 'true');

			// Disable fields while saving.
			// The controller has already verified this is a record you can edit.
			$form->setFieldAttribute('ordering', 'filter', 'unset');
			$form->setFieldAttribute('state', 'filter', 'unset');
			$form->setFieldAttribute('publish_up', 'filter', 'true');
			$form->setFieldAttribute('publish_down', 'filter', 'true');
		}

		return $form;
	}

	/**
	 * Method to get the script that have to be included on the form
	 *
	 * @return string	Script files
	 */
	public function getScript()
	{
		return 'administrator/components/com_bfauction_plus/models/forms/question.js';
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_bfauction_plus.edit.bfauction_plus.data', array());

		if (empty($data)) {
			$data = $this->getItem();

			// Prime some default values.
			if ($this->getState('bfauction_plus.id') == 0) {
				$app = JFactory::getApplication();
			}
		}

		return $data;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @since	1.6
	 */
	protected function prepareTable($table)
	{
		jimport('joomla.filter.output');
		$date = JFactory::getDate();
		$user = JFactory::getUser();

		if (empty($table->id)) {
			// Set the values

			// Set ordering to the last item if not set
			if (empty($table->ordering)) {
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__bfauction_plus');
				$max = $db->loadResult();

				$table->ordering = $max+1;
			}
		}
		else {
			// Set the values
		}
	}

	/**
	 * A protected method to get a set of ordering conditions.
	 *
	 * @param	object	A record object.
	 * @return	array	An array of conditions to add to add to ordering queries.
	 * @since	1.6
	 */
	protected function getReorderConditions($table)
	{
		$condition = array();
		$condition[] = 'catid = '.(int) $table->catid;
		return $condition;
	}

/**
 * @author		Tim Plummer
 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
 */
    function saveImages($post,$files,$config,$model,$cid)
    {
    	$app = JFactory::getApplication();

		$conf = "";
		$conf->max_width = $config->get('max_width');
		$conf->max_height = $config->get('max_height');
		$conf->max_width_t = $config->get('max_width_t');
		$conf->max_height_t = $config->get('max_height_t');
		$conf->max_image_size = $config->get('max_image_size');

		for($i = 1; $i < 21; $i++){
			// image5 delete
			if ( $post['d_img'.$i] == "delete") {
				$pict = JPATH_SITE."/images/com_bfauction_plus/".$this->getState('item.id')."img".$i.".jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
				$pict = JPATH_SITE."/images/com_bfauction_plus/".$this->getState('item.id')."img".$i."_t.jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
			}

			if (isset( $files['img'.$i])) {
				if ( $files['img'.$i]['size'] > $conf->max_image_size) {
					$app->redirect("index.php?option=com_bfauction_plus&view=items", JText::_('COM_BFAUCTIONPLUS_IMAGETOOBIG'));
					return;
				}
			}

			// image5 upload
			if (isset( $files['img'.$i]) and !$files['img'.$i]['error'] ) {
				$path= JPATH_SITE."/images/com_bfauction_plus/";
				$model->createImageAndThumb($files['img'.$i]['tmp_name'],
											$this->getState('item.id')."img".$i.".jpg",
											$this->getState('item.id')."img".$i."_t.jpg",
											$conf->max_width,
											$conf->max_height,
											$conf->max_width_t,
											$conf->max_height_t,
											"",
											$path,
											$files['img'.$i]['name']);
			}
		}

		//$app->redirect("index.php?option=com_bfauction_plus&view=items");
    }

/**
 * @author		Tim Plummer
 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
 */
	function createImageAndThumb($src_file,$image_name,$thumb_name,
								$max_width,
							    $max_height,
								$max_width_t,
								$max_height_t,
								$tag,
								$path,
								$orig_name)
	{
		if (intval(ini_get('memory_limit')) < 64)
			ini_set('memory_limit', '64M');

		$src_file = urldecode($src_file);

		$orig_name = strtolower($orig_name);
		$findme  = '.jpg';
		$pos = strpos($orig_name, $findme);
		if ($pos === false)
		{
			$findme  = '.jpeg';
			$pos = strpos($orig_name, $findme);
			if ($pos === false)
			{
				$findme  = '.gif';
				$pos = strpos($orig_name, $findme);
				if ($pos === false)
				{
					$findme  = '.png';
					$pos = strpos($orig_name, $findme);
					if ($pos === false)
					{
						return;
					}
					else
					{
						$type = "png";
					}
				}
				else
				{
					$type = "gif";
				}
			}
			else
			{
				$type = "jpeg";
			}
		}
		else
		{
			$type = "jpeg";
		}

		$max_h = $max_height;
		$max_w = $max_width;
		$max_thumb_h = $max_height_t;
		$max_thumb_w = $max_width_t;

		if ( file_exists( "$path/$image_name")) {
			unlink( "$path/$image_name");
		}

		if ( file_exists( "$path/$thumb_name")) {
			unlink( "$path/$thumb_name");
		}

		$read = 'imagecreatefrom' . $type;
		$write = 'image' . $type;

		$src_img = $read($src_file);

		// height/width
		$imginfo = getimagesize($src_file);
		$src_w = $imginfo[0];
		$src_h = $imginfo[1];

		$zoom_h = $max_h / $src_h;
	    $zoom_w = $max_w / $src_w;
	    $zoom   = min($zoom_h, $zoom_w);
	    $dst_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
	    $dst_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$zoom_h = $max_thumb_h / $src_h;
	    $zoom_w = $max_thumb_w / $src_w;
	    $zoom   = min($zoom_h, $zoom_w);
	    $dst_thumb_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
	    $dst_thumb_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$dst_img = imagecreatetruecolor($dst_w,$dst_h);
		$white = imagecolorallocate($dst_img,255,255,255);
		imagefill($dst_img,0,0,$white);
		imagecopyresampled($dst_img,$src_img, 0,0,0,0, $dst_w,$dst_h,$src_w,$src_h);
		if($type == 'jpeg'){
	        $desc_img = $write($dst_img,"$path/$image_name", 75);
		}else{
	        $desc_img = $write($dst_img,"$path/$image_name", 2);
		}

		imagedestroy($dst_img);

		$dst_t_img = imagecreatetruecolor($dst_thumb_w,$dst_thumb_h);
		$white = imagecolorallocate($dst_t_img,255,255,255);
		imagefill($dst_t_img,0,0,$white);
		imagecopyresampled($dst_t_img,$src_img, 0,0,0,0, $dst_thumb_w,$dst_thumb_h,$src_w,$src_h);
		if($type == 'jpeg'){
	        $desc_img = $write($dst_t_img,"$path/$thumb_name", 75);
		}else{
	        $desc_img = $write($dst_t_img,"$path/$thumb_name", 2);
		}

		imagedestroy($dst_t_img);
	}
}