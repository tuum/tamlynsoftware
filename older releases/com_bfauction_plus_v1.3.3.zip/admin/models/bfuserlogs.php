<?php
/**
 * $Id: bfuserlogs.php 58 2012-08-19 07:11:25Z tuum $
 * BF User log Component for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF User Log is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
// import the Joomla modellist library
jimport('joomla.application.component.modellist');
/**
 * BFUserLogList Model
 */
class bfauction_plusModelBFUserLogs extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id', 'a.id',
				'a.id', 'a.uid',
				'a.site', 'a.visitDate',
				'a.login', 'a.published',
				'a.publish_up', 'a.publish_down',
				'b.name', 'b.username', 'b.email',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return	string	An SQL query
	 */
	protected function getListQuery()
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('a.id, a.uid, a.site, a.visitDate, a.login, a.published, a.publish_up, a.publish_down, b.name, b.username, b.email');
		$query->from('#__bfuserlog AS a');

		$query->join('LEFT', '#__users AS b ON b.id = a.uid');

		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published)) {
			$query->where('a.published = '.(int) $published);
		} elseif ($published === '') {
			$query->where('(a.published IN (0, 1))');
		}

		// Filter by login.
		if ($login = $this->getState('filter.login')) {
			if($login != "0"){
				$query->where('a.login = ' . $db->quote($login));
			}
		}

		// Filter by site.
		if ($site = $this->getState('filter.site')) {
			if($site != "0"){
				$query->where('a.site = ' . $db->quote($site));
			}
		}

		// Filter by search
		$search = $this->getState('filter.search');
		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.uid = '.(int) substr($search, 3));
			} else {
				$search = $db->Quote('%'.$db->getEscaped($search, true).'%');
				$query->where('(LOWER(b.name) LIKE '.$search.') OR (LOWER(b.username) LIKE '.$search.') OR (LOWER(b.email) LIKE '.$search.')');
			}
		}

		$filter_date_from = $this->getState('filter.date_from');
        if (strlen($filter_date_from))
        {
            $query->where("a.visitDate >= '".$filter_date_from."'");
        }

        $filter_date_to = $this->getState('filter.date_to');
        if (strlen($filter_date_to))
        {
            $query->where("a.visitDate <= '".$filter_date_to."'");
        }

		//is inactive user filter turned on
		if ($login = $this->getState('filter.login')) {
			if($login == "3"){  //inactive
				$query->clear();
				$query->select('b.id AS id, b.id AS uid, a.site, a.visitDate, a.login, a.published, a.publish_up, a.publish_down, b.name, b.username, b.email');
				$query->from('#__users AS b');

				if (strlen($filter_date_to) && !strlen($filter_date_from)){
		            $query->join('LEFT OUTER', '#__bfuserlog AS a ON b.id = a.uid AND a.visitDate <= "'.$filter_date_to.'"');
		        }elseif(!strlen($filter_date_to) && strlen($filter_date_from)){
					$query->join('LEFT OUTER', '#__bfuserlog AS a ON b.id = a.uid AND a.visitDate >= "'.$filter_date_from.'"');
		        }else if(strlen($filter_date_to) && strlen($filter_date_from)){
		        	$query->join('LEFT OUTER', '#__bfuserlog AS a ON b.id = a.uid AND a.visitDate >= "'.$filter_date_from.'" AND a.visitDate <= "'.$filter_date_to.'"');
		        }else{
					$query->join('LEFT OUTER', '#__bfuserlog AS a ON b.id = a.uid');
		        }

				$query->where('a.login IS NULL');
			}
		}

		return $query;
	}

	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app = JFactory::getApplication('administrator');

		// Load the filter state.
		$search = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$published = $this->getUserStateFromRequest($this->context.'.filter.state', 'filter_published', '', 'string');
		$this->setState('filter.state', $published);

		$filter_date_from = $this->getUserStateFromRequest('filter.date_from', 'filter_date_from', '');
		$this->setState('filter.date_from', $filter_date_from);

		$filter_date_to = $this->getUserStateFromRequest('filter.date_to', 'filter_date_to', '');
		$this->setState('filter.date_to', $filter_date_to);

		$site = $this->getUserStateFromRequest('filter.site', 'filter_site', '');
		$this->setState('filter.site', $site);

		$login = $this->getUserStateFromRequest('filter.login', 'filter_login', '');
		$this->setState('filter.login', $login);

		// List state information.
		parent::populateState('a.ordering', 'asc');
	}
}
