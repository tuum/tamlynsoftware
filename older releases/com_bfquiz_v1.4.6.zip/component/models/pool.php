<?php
/**
 * $Id: pool.php 2 2011-11-15 04:37:51Z tuum $
 * Pool Model for bfquiz Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * Pool Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquizModelpool extends JModel
{
	/**
	 * Questions data array
	 *
	 * @var array
	 */
	var $_data;
	var $_pooldata;
	var $_randompool = array();
	var $_randomquestions = array();

	 /**
	  * Items total
	  * @var integer
	  */
	 var $_total = null;



	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
	    global $mainframe;
	    $db =& JFactory::getDBO();
	    $catid = JRequest::getVar('catid',0);

		$query = 'SELECT b.*,  cc.title AS category_name'
						. ' FROM #__bfquiz AS b'
						. ' LEFT JOIN #__categories AS cc ON cc.id = b.catid'
						. ' WHERE b.published AND b.catid = '.(int)$catid
						. ' ORDER BY b.parent, b.ordering'
		;
		
		return $query;
	}

	/**
	 * Retrieves the data
	 * @return array Array of objects containing the data from the database
	 */
	function getData()
	{
		// if data hasn't already been obtained, load it
		if (empty($this->_data)) {
		    $query = $this->_buildQuery();
		    $this->_data = $this->_getList( $query );
		}
	
		$session =& JFactory::getSession();
		if($session->has('_randompool')){
		    // do nothing as we already know the order of the questions
		}else{
			//generate the order of questions
			
			//what is the question pool associated with this category
			if (empty($this->_pooldata)) {
		    	$query2 = $this->_buildQueryPool();
		    	$this->_pooldata = $this->_getList( $query2 );
			}
			
			$session->set('_randomid',$this->_pooldata[0]->id);
			$session->set('qnsPerPage',$this->_pooldata[0]->qnsPerPage);
			
			//how many questions per quiz?
			$qnsPerQuiz=$this->_pooldata[0]->qnsPerQuiz;
		
			if($qnsPerQuiz > count( $this->_data )){
				global $mainframe;
				JError::raiseWarning( 500, 'There are not enough questions in your pool to generate this quiz.' );
				$mainframe->redirect( 'index.php' );   				
			}
		
			//are there any mandaotry questions
			$mandatoryQns=explode(",",$this->_pooldata[0]->mandatoryQns);
			
			//now stick all question ids in array, excluding mandatory questions
			$z=0;
			for ($i=0, $n=count( $this->_data ); $i < $n; $i++)
			{
				$row = &$this->_data[$i];
				if($mandatoryQns){
					if (in_array($row->id, $mandatoryQns)) {
						//do nothing
					}else{
						$_randomquestions[$z]=$row->id;
						$z++;
					}
				}else{
					$_randomquestions[$z]=$row->id;
					$z++;
				}
			}
			
			//randomly reorder questions
            shuffle($_randomquestions);
			
            //now put random questions in randompool array
            for($i=0; $i < $qnsPerQuiz; $i++){
            	$_randompool[$i]=$_randomquestions[$i];
            }
            	
            //now figure out what to do with mandatory questions
			if($mandatoryQns[0] != null){
				//mandatory position
				$mandatoryPos=$this->_pooldata[0]->mandatoryPos;
				if($mandatoryPos == "Start" | $mandatoryPos == "Random"){
				   for($i=0; $i < sizeof($mandatoryQns); $i++){
				      $_randompool[$i]=$mandatoryQns[$i];
				   }
				}else if($mandatoryPos == "End"){
				   $y=0;
				   for($i=(sizeof($_randompool)-sizeof($mandatoryQns)); $i < sizeof($_randompool); $i++){
				      $_randompool[$i]=$mandatoryQns[$y];
				      $y++;
				   }
				}
				
				if($mandatoryPos == "Random"){
					shuffle($_randompool);
				}
			}            
            
			$session->set('_randompool',$_randompool);
		}
			
		return $this->_data;
	}
	
	function _buildQueryPool(){
	    global $mainframe;
	    $db =& JFactory::getDBO();
	    $catid = JRequest::getVar('catid',0);

		$query = 'SELECT *'
						. ' FROM #__bfquiz_pool'
						. ' WHERE published AND catid = '.(int)$catid
		;
		
		return $query;	
	}

	function __construct()
	  {
	 	parent::__construct();

		global $mainframe, $option;

	  }

      function getTotal()
	    {
	   	// Load the content if it doesn't already exist
	   	if (empty($this->_total)) {
	   	    $query = $this->_buildQuery();
	   	    $this->_total = $this->_getListCount($query);
	   	}
	   	return $this->_total;
	  }

}
