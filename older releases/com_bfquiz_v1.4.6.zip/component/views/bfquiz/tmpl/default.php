<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
*
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php

$Itemid = JRequest::getVar('Itemid');
$menu =& JMenu::getInstance('site');
$config = & $menu->getParams( $Itemid );

$session =& JFactory::getSession();

/*********************** TIMED QUIZ ******************************/
$timedQuiz = $this->params->get('timedQuiz');
$timeLimit = $this->params->get( 'timeLimit' );
$timerText = $this->params->get( 'timerText' );
$timerCompleteText = $this->params->get( 'timerCompleteText' );

// $minutes and $seconds are added together to get total time.
$minutes = $timeLimit; // Enter minutes
$seconds = 0; // Enter seconds
$time_limit = ($minutes * 60) + $seconds; // Convert total time into seconds
// Add $time_limit (total time) to start time. And store into session variable.
if(!$session->has('start_time'.$Itemid)){
	$session->set('start_time'.$Itemid, mktime(date('G'),date('i'),date('s'),date('m'),date('d'),date('Y')) + $time_limit);
} 

$targetDate = $session->get('start_time'.$Itemid);
$actualDate = time();

// Define date format
$dateFormat = "Y-m-d H:i:s";

$secondsDiff = $targetDate - $actualDate;

$remainingDay     = floor($secondsDiff/60/60/24);
$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

$targetDateDisplay = date($dateFormat,$targetDate);
$actualDateDisplay = date($dateFormat,$actualDate);
?>
<script language="Javascript">
<!--
  // get variable from php
  var days = <?php echo $remainingDay; ?>;
  var hours = <?php echo $remainingHour; ?>;
  var minutes = <?php echo $remainingMinutes; ?>;
  var seconds = <?php echo $remainingSeconds; ?>;
  var timerCompleteText = "<?php echo $timerCompleteText ?>";
  var timedQuiz = "<?php echo $timedQuiz ?>";
  
function setCountDown ()
{
  seconds--;
  if (seconds < 0){
      minutes--;
      seconds = 59
  }
  if (minutes < 0){
      hours--;
      minutes = 59
  }
  if (hours < 0){
      days--;
      hours = 23
  }
  //document.getElementById("txt").innerHTML = hours+" hours, "+minutes+" minutes, "+seconds+" seconds";
  if(seconds < 10){
	  seconds = "0"+seconds;
  }
  document.getElementById("txt").value = minutes+":"+seconds;

  if(days < 0){
     clearInterval(ct);
     document.getElementById("txt").value = "0:00";
     document.getElementById("next_question").value = -1;
  	 document.mysurvey.submit();
     alert(timerCompleteText);
  }

  //setTimeout ( "setCountDown()", 1000 );
}

if(timedQuiz=="1"){
    var ct = setInterval("setCountDown()",1000); // Start clock.
 }

//-->
</script>
<?php

if($remainingSeconds < 10){
	$remainingSecs = "0".$remainingSeconds;
}else{
    $remainingSecs = $remainingSeconds;
}

$timerinit="".$remainingMinutes.":".$remainingSecs;
/*****************************************************************/

if(!$session->has('dateReceived')){
   $now =& JFactory::getDate();
   $session->set('dateReceived', $now->toMySQL());
}

$introText = $this->params->get( 'introText' );
$quizTitle = $this->params->get( 'quizTitle' );
$thankyouText = $this->params->get( 'thankyouText' );
$emailText = $this->params->get( 'emailText' );
$nameText = $this->params->get( 'nameText' );
$allowEmail = $this->params->get( 'allowEmail' );
$allowAuthorEmail = $this->params->get( 'authorEmail' );
$sendEmailTo = $this->params->get( 'sendEmailTo' );
$submitText = $this->params->get( 'submitText' );
$anonymous = $this->params->get( 'anonymous' );
$anonymousText = $this->params->get( 'anonymousText' );
$anonymousYes = $this->params->get( 'anonymousYes' );
$anonymousNo = $this->params->get( 'anonymousNo' );
$nameText = $this->params->get( 'nameText' );
$emailText = $this->params->get( 'emailText' );
$showName = $this->params->get( 'showName' );
$showEmail = $this->params->get( 'showEmail' );
$errorText = $this->params->get( 'errorText' );
$use_captcha = $this->params->get( 'use_captcha' );
$registeredUsers = $this->params->get( 'registeredUsers' );
$preventMultiple = $this->params->get( 'preventMultiple' );
$preventMultipleEmail = $this->params->get( 'preventMultipleEmail' );
$preventMultipleUID = $this->params->get( 'preventMultipleUID' );
$scoringMethod = $this->params->get( 'scoringMethod' );
$randomOptions = $this->params->get( 'randomOptions' );
$answerAfterQuestion = $this->params->get( 'answerAfterQuestion' );

$user="";
$emailcount=0;
$uidcount=0;

if($anonymous == ""){
   $anonymous = "1";
}

if($showName == ""){
   $showName = "1";
}

if($showEmail == ""){
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );

if($catid == 0){
	global $mainframe;
	JError::raiseWarning( 500, JText::_('COM_BFQUIZ_ERROR_SELECT_CATEGORY') );
	$mainframe->redirect( 'index.php' );   
}

$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

$ip = BFQuizController::getIP();
$ipcount = BFQuizController::checkIP($table,$ip);

//increment page no
$page_no = JRequest::getVar( 'page_no' );
if(!empty($page_no)){
   $start_qn = JRequest::getVar( 'start_qn', 0, 'post', 'int' );
   $end_qn = JRequest::getVar( 'end_qn', 0, 'post', 'int' );

   // get answers to last question(s)
   $numberQns = $end_qn - $start_qn;
   if($numberQns < 1){
      $numberQns = 1;
   }
   
   for($y = ($page_no-$numberQns)+1;$y < $page_no+1; $y++){
	  $qid = JRequest::getVar( 'question'.$y, 0, 'post', 'int' );
      $session->set('question'.$y, $qid);
      $session->set('questiontype'.$y, JRequest::getVar( 'question_type'.$y, 0, 'post', 'int' ) );
      
	  if( JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) != NULL ){
            if($session->get('questiontype'.$y) == "2"){   //checkbox
                  $session->set('q'.$qid, JRequest::getVar( 'q'.$qid, array(), 'post', 'array' ) );
            }else{
                  $session->set('q'.$qid, JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) );
            }
      }else{
      	$session->set('q'.$qid, "");
      }
      
      
      if($session->has('q'.$qid.'_OTHER_')){
      	$session->set('q'.$qid.'_OTHER_', JRequest::getVar( 'q'.$qid.'_OTHER_', "", 'POST', 'string'  ) );
      }else{
      	$session->set('q'.$qid.'_OTHER_', "");
      }
      $session->set('field_name'.$y, JRequest::getVar( 'field_name'.$y, 0, 'post', 'string' ) );
      $session->set('page_no', $y);
   }

	//do you want to show incorrect answers after each question
	for($y = ($page_no-$numberQns)+1;$y < $page_no+1; $y++){
		if($answerAfterQuestion){
			$qid = JRequest::getVar( 'question'.$y, 0, 'post', 'int' );
			$answer = $session->get('q'.$qid);
			$fieldname = $session->get('field_name'.$page_no);
			BFQuizController::showIncorrect2($answer,$fieldname,$qid);
		}
	}   
   
   $page_no = $page_no + 1;

   $score = JRequest::getVar('score');

}else{
   // defaults for first page
   $page_no = 1;
   $start_qn = -1;
   $end_qn = 0;
   $score=0;
   $numberQns=1;
}

if($page_no - $numberQns == 1){  // second page
	$session->set('fullname', JRequest::getVar( 'fullname', '', 'post', 'string' ));
	$session->set('email', JRequest::getVar( 'email', '', 'post', 'string' ));
	$session->set('sendEmailTo', JRequest::getVar( 'sendEmailTo', '', 'post', 'string' ));
	$session->set('uid', JRequest::getVar( 'uid', 0, 'post', 'int' ));

	if($session->get('fullname') == ""){
      $session->set('fullname', "Anonymous");
	}

   $preventMultipleEmail = JRequest::getVar( 'preventMultipleEmail', 0, '' );
   $emailcount = BFQuizController::checkEmail($table, $session->get('email'));

   /**
	Captcha
	*/
	if ($use_captcha) {
   		$correct=BFQuizController::_checkCaptcha();
   		if (!$correct) {
   			JError::raiseWarning("666",JText::_("COM_BFQUIZ_CAPTCHA_WRONG") );
   			$page_no=1;
   			$start_qn = -1;
   			$end_qn = 0;
   		}else{
   		   // captcha is correct
		}
	}
}

$total_qns=count( $this->items );

$next_question = JRequest::getVar( 'next_question', 0, 'post', 'int' );

//Use conditional branching to determine next question
if($page_no > 1){
   if($qid == ""){
      $next_question = 0;
   }else{
   	  if($next_question == -1){ //quiz auto submitted due to timer
   	  	//do nothing
   	  }else{
         $next_question = BFQuizController::getNextQuestion($qid, $session->get('q'.$qid) );
   	  }
   }
}else{
   $next_question=0;
}

if($next_question == 0){
   // default to next question
   if($start_qn == -1){
      //first page
      $start_qn = $start_qn +1;
   }else{
      $start_qn = $end_qn;
   }
   $end_qn = $end_qn + 1;
}else if($next_question == -1){ // end of quiz
   $start_qn = $total_qns;

   // null answers to all other questions
   for($i=$page_no; $i < $total_qns+1; $i++){
      $session->set('question'.$i, "");
      $session->set('questiontype'.$i, "");
   }
}else{
   $page=0;
   for($i=0; $i < $total_qns; $i++){
      //blank out questions that were skipped
      if($i > $page_no-1){
   	     $session->set('question'.$i, "");
		 $session->set('questiontype'.$i, "");
      }

      $row = &$this->items[$i];
      if($row->id == $next_question){
         $i = $total_qns+1;
      }

      $page++;
   }
   $start_qn = $page-1;
   $end_qn = $page;
   $page_no = $page;
}

?>

<?php
 $user = &JFactory::getUser();

 if($registeredUsers == "1"){
    $emailcount = BFQuizController::checkEmail($table,$user->email);
    $uidcount = BFQuizController::checkUID($table,$user->id);
 }

 if (($user->id) | $registeredUsers != "1") { // test if registerd users only

    if($ipcount < 1 | $preventMultiple != "1"){  // check if IP address has already completed quiz

        if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed quiz

        	if($uidcount < 1 | $preventMultipleUID != "1"){  // check if UID has already completed quiz
?>

<?php if($start_qn > $total_qns-1)
{
// no more questions left

// need to write this all to db now.
global $mainframe;
$qntable=$mainframe->getCfg('dbprefix')."bfquiz";

// save basic details to db, and generate id
$result = BFQuizController::save($session->get('fullname'), $session->get('email'), $table);
//save userid
BFQuizController::saveField($result,"uid", $session->get('uid'), $table);

$emailBody = "";
$answerSeq="";

for ($i=1; $i < $total_qns+1; $i++)
{
   $check_msg = "";
   $qid = $session->get('question'.$i);

   $question = BFQuizController::getQuestion($qid);
   $answer = $session->get('q'.$qid);

   if($session->get('questiontype'.$i) == 1){ // radio
      if($answer == "_OTHER_"){
         $answer = $session->get('q'.$qid.'_OTHER_');
      }
   }

	if($session->get('questiontype'.$i) == 2){ // checkbox
		if($answer==""){
			// do nothing
		}else{
			foreach($answer as $value) {
				if($value == "_OTHER_"){
					$value = $session->get('q'.$qid.'_OTHER_');
				}
				$check_msg .= "$value\n";
			}
			$answer = $check_msg;
		}
	}

   	if($answer == ""){
    	// do nothing
   	}else{
    	$emailBody .= "<br>".$question.": <br>".JText::_("COM_BFQUIZ_ANSWER").": ".$answer."<br>";
   	}
   
   if($session->get('field_name'.$i) == ""){
      // do nothing
   	}else if($session->get('field_name'.$i) == "NULL"){
      // do nothing
   }else{ // save data to db
      BFQuizController::saveField($result, $session->get('field_name'.$i), $answer, $table);
      $score=$score+BFQuizController::getScore($session->get('field_name'.$i), $qntable, $answer);
      if($scoringMethod == 1){
         $answerSeq.=BFQuizController::getAnswerSeq($session->get('field_name'.$i), $answer);
      }
   }
}

//save score
BFQuizController::saveField($result,"score",$score,$table);

//save answer sequence
BFQuizController::saveField($result,"answerseq",$answerSeq,$table);

echo "<div class=\"bfquizOptions\">";
echo $thankyouText;
echo "</div>";
echo "<br>";
BFQuizController::showResultsScoreCategory($result,$table,$catid);
BFQuizController::showResults($score);
echo "<br>";
if(!$answerAfterQuestion){
	$myIncorrect=BFQuizController::showIncorrect($result,$table);
}else{
	$myIncorrect="";
}

	//------------------------------------ email ------------------------------------------------------------
	$emailBodyIncorrect = "<br>".JText::_("COM_BFQUIZ_INCORRECT_ANSWERS")."<br>".$myIncorrect."<br>";

	$adminEmail = BFQuizController::getEmailTemplate("Admin", $catid);
	
	$maxScore = bfquizController::getMaxScore($catid);
	
	//repace fields with actual data
	$adminEmail[0]->description=preg_replace('/{score}/', $score , $adminEmail[0]->description); // insert score
	$adminEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $adminEmail[0]->description); // insert maximum score
	$adminEmail[0]->description=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->description); // insert category
	$adminEmail[0]->description=preg_replace('/{name}/', $session->get('fullname') , $adminEmail[0]->description); // insert name
	$adminEmail[0]->description=preg_replace('/{email}/', $session->get('email') , $adminEmail[0]->description); // insert email						
	
	$adminEmail[0]->subject=preg_replace('/{score}/', $score , $adminEmail[0]->subject); // insert score
	$adminEmail[0]->subject=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->subject); // insert category
	$adminEmail[0]->subject=preg_replace('/{name}/', $session->get('fullname') , $adminEmail[0]->subject); // insert name
	$adminEmail[0]->subject=preg_replace('/{email}/', $session->get('email') , $adminEmail[0]->subject); // insert email						
		
	$subject = $adminEmail[0]->subject;
	$body = $adminEmail[0]->description;
	if($adminEmail[0]->showQuestions == 1){
		$body .= $emailBody;
	}
	
	if($adminEmail[0]->showIncorrect == 1){
		$body .= $emailBodyIncorrect;
	}

	$Itemid = JRequest::getVar('Itemid');
	$menu =& JMenu::getInstance('site');
	$config = & $menu->getParams( $Itemid );

   	$allowEmail = $config->get( 'allowEmail' );
   	$sendEmailTo = $config->get( 'sendEmailTo' );

   	if($allowEmail){
		BFQuizController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);
   	}

	$authorEmail = BFQuizController::getEmailTemplate("Author", $catid);
	
	//repace fields with actual data
	$authorEmail[0]->description=preg_replace('/{score}/', $score , $authorEmail[0]->description); // insert score
	$authorEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $authorEmail[0]->description); // insert score
	$authorEmail[0]->description=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->description); // insert category
	$authorEmail[0]->description=preg_replace('/{name}/', $session->get('fullname') , $authorEmail[0]->description); // insert name
	$authorEmail[0]->description=preg_replace('/{email}/', $session->get('email') , $authorEmail[0]->description); // insert email						
	
	$authorEmail[0]->subject=preg_replace('/{score}/', $score , $authorEmail[0]->subject); // insert score
	$authorEmail[0]->subject=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->subject); // insert category
	$authorEmail[0]->subject=preg_replace('/{name}/', $session->get('fullname') , $authorEmail[0]->subject); // insert name
	$authorEmail[0]->subject=preg_replace('/{email}/', $session->get('email') , $authorEmail[0]->subject); // insert email						
		
	$subject = $authorEmail[0]->subject;
	$body = $authorEmail[0]->description;
	if($authorEmail[0]->showQuestions == 1){
		$body .= $emailBody;
	}
	
	if($authorEmail[0]->showIncorrect == 1){
		$body .= $emailBodyIncorrect;
	}   	
   	
	if($allowAuthorEmail == "1" & $session->get('email')!=""){
		BFQuizController::sendHTMLNotificationEmail($body, $session->get('email'), $subject);
	}
	//------------------------------------ end email ------------------------------------------------------------	


if($scoringMethod == 1){
   BFQuizController::checkABCD($session->get('field_name1'), $answerSeq, $result, $table);
}else if($scoringMethod == 2){
   BFQuizController::checkscorerange($session->get('field_name1'), $score, $result, $table);
}

//clear session data
$session->set('start_time'.$Itemid, null);
$session->set('dateReceived', null);

for($y=0; $y < $page_no+1; $y++){
	$session->set('question'.$y, null);
	$session->set('q'.$qid, null);
	$session->set('q'.$qid.'_OTHER_', null);
	$session->set('field_name'.$y, null);
}

$session->set('page_no', null);
$session->set('fullname', null);
$session->set('email', null);
$session->set('sendEmailTo', null);
$session->set('uid', null);

for($i=$page_no; $i < $total_qns+1; $i++){
	$session->set('question'.$i, null);
	$session->set('questiontype'.$i, null);
}
//end clear session data

?>

<?php
}else{
?>

<script language="Javascript">
<!--
	// get variable from php
	var showName = "<?php echo $showName ?>";
	var showEmail = "<?php echo $showEmail ?>";
	var toggle = 1;
	var total_qns = "<?php echo $total_qns ?>";

	function ToggleDetails(){
   		if(toggle == 1){
   		   // hide details
   		   if(showName=="1"){
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		   }

           if(showEmail=="1"){
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1"){
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		   }

		   if(showEmail=="1"){
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
           }
		   toggle=1;
        }
	}

//-->
</script>


<?php
// Check that the class exists before trying to use it
if (class_exists('BFBehavior')) {
 BFBehavior::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f)) {
	    f.check='';
		f.check.value='<?php echo JUtility::getToken(); ?>';//send token
		return true;
	}
	else {
		alert( '<?php echo addslashes($errorText) ?>' );
	}
	return false;
}
function imposeMaxLength(Object, MaxLen)
{
  return (Object.value.length < MaxLen);
}
</script>

<form action="<?php echo JRoute::_( 'index.php?option=com_bfquiz&view=BFQuiz&Itemid='.$Itemid ); ?>" method="POST" name="myquiz" id="myquiz" class="form-validate" onSubmit="return myValidate(this);">

<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="score" value="<?php echo $score ?>" />

<table width="100%">
	<thead>
		<tr>
			<th>
				<div class="bfquizTitle"><?php echo JText::_( $quizTitle ); ?></div>
			</th>
		</tr>
	</thead>

<?php if($timedQuiz == "1"){ ?>
<tr>
   <td>
		<div class="timeremaining"><?php echo JText::_($timerText); ?> <input id="txt" name="txt" readonly value="<?php echo $timerinit; ?>"></div>
   </td>
</tr>
<?php } ?>

<?php if($page_no == 1){
   // only show this bit on first page
?>

<tr>
    <td>
    <div class="bfquizIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="bfquizQuestionFooter">
	</div>
    </td>
</tr>

<?php if($showName == "1"){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table>
       <tr>
           <td>
               <div class="BFQuizCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="BFQuizCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table>
        <tr>
            <td width="70">
                <div class="BFQuizCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="BFQuizCustomerOptions">
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $user->name; ?>' >
   				<input type="hidden" name="uid" id="uid" value='<?php echo $user->id; ?>' >
   				</div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="fullname" id="fullname" value='<?php echo $user->name; ?>' >
   <input type="hidden" name="uid" id="uid" value='<?php echo $user->id; ?>' >
<?php
      }
?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table>
		       <tr>
		           <td width="70">
		               <div class="BFQuizCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="BFQuizCustomerOptions">
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $user->email; ?>' >
		               </div>
		           </td>
		       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="email" id="email" value='<?php  echo $user->email; ?>' >
<?php
      }
?>

<tr>
<td>
<?php if ($use_captcha) {
	// Check that the class exists before trying to use it
	if (class_exists('plgSystemBigocaptcha')) {
	?>
	<!-- Bigo Captcha -->
	<img src="index.php?option=com_bfquiz&task=displaycaptcha&catid=<?php echo $catid; ?>&use_captcha=<?php echo $use_captcha; ?>">
	<br />
	<input type="text" name="word"/><br>
	<?php echo JText::_( "COM_BFQUIZ_CAPTCHA_INPUT_WORD"); ?>
	<?php
	}else{
	   echo JText::_( "COM_BFQUIZ_INSTALL_CAPTCHA");
	}
	?>
<?php } ?>
</td>
</tr>

<?php
   }  // end only show on first page
?>

<?php
$k = 0;

for ($i=$start_qn; $i < $end_qn; $i++)
{
	$row = &$this->items[$i];

	$numChildren=0;

	//is this a parent item?
	if($row->parent == 0){
	   $numChildren=BFQuizController::getNumChildren($row->id);
	   $end_qn = $end_qn + $numChildren;
	   $page_no = $page_no + $numChildren;
	}
?>

    <?php if($row->suppressQuestion != "1"){ ?>
	<tr>
	    <th>
	       <div class="bfquizQuestion"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<?php } ?>

	<tr>
	    <th>
	      <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="bfquizOptions">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == ""){
	          // do nothing
	       }else{
	          ?>
	          <div class="bfquiz_helptext">
	          <?php echo JHTML::_('content.prepare', $row->helpText); ?>
	          </div>
	          <?php	          
	       }

	       if(!isset($row->prefix)){
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix)){
	          $row->suffix = "";
	       }

	       $sequence = $row->id;

	       if($row->question_type == "0"){  //text
	           $mylength="65";
	           if($row->fieldSize < 65){
	              $mylength=$row->fieldSize;
	           }
	           if($row->mandatory){
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
				  }else{
	              ?>
		             <div class="BFQuizSuppressQuestion">
	                 <?php echo JText::_($row->prefix); ?>
	                 </div>
	                 <div class="BFQuizSuppressOptions">
	                 <?php
	                    echo "<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
	                 ?>
	                 </div>
       			  <?php
       			  }
	           }else{
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize."> ".$row->suffix;
	              }else{
	              ?>
	                <div class="BFQuizSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="BFQuizSuppressOptions">
	                <?php
	                   echo "<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	                ?>
	                </div>
       			  <?php
       			  }
	           }
	       }else if($row->question_type == "1"){  // Radio

		      if($randomOptions != "1"){

	       		    for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != ""){
							if($row->horizontal == "1"){
		 	  			    	$myclass="bfradiohorizontal";
		 	  			    }else{
		 	  			    	$myclass="bfradio";
		 	  			    }		 	  			       	       		        	
				  			if($row->mandatory & class_exists('BFBehavior')){
				  			   ?>

				  			   <?php echo JText::_($row->prefix); ?>
				  			   <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				  			   <?php
				  			}else{
				  			   ?>
				  			   <?php echo JText::_($row->prefix); ?>
				  			   <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				  			   <?php
			  				}

			  				if($row->horizontal == "1"){
					    	    echo "&nbsp;&nbsp;&nbsp;";
		   		   	    	}else{
		   		   	    	    echo "<br>";
		   		   	    	}
	       	        	}
	       	     	}

	       	  }else{
				//-------------------------------random options--------------------------------------------------
				$numofoptions=0;
                $myoptions = array();
                //how many options are there?
                for($x=0; $x < 20; $x++)
                {
                   $numofoptions = $x;
                   $tempvalue="option".($x+1);

                   if($row->$tempvalue == ""){
                      $x=20;
                   }else{
                      $myoptions[$x]= $x;
                   }
                }

                //randomly reorder questions
                shuffle($myoptions);

                for($y=0; $y < 20; $y++)
                {
                    if($y+1 > $numofoptions){
                       $z = $y;
                    }else{
                       $z = $myoptions[$y];
                    }

                    $tempvalue="option".($z+1);
                    $tempnext="next_question".($z+1);

                    if($row->$tempvalue != ""){
                       if($row->mandatory & class_exists('BFBehavior')){
                          ?>

                          <?php if($row->horizontal == "1"){
                             $myclass="bfradiohorizontal";
                          }else{
                             $myclass="bfradio";
                          } ?>

                          <?php echo JText::_($row->prefix); ?>
                          <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }else{
                          ?>
                          <?php echo JText::_($row->prefix); ?>
                          <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }

                       if($row->horizontal == "1"){
                          echo "&nbsp;&nbsp;&nbsp;";
                       }else{
                          echo "<br>";
                       }
                     }
                  }
	              //-------------------------------end random options--------------------------------------------------

	       	  }

		   }else if($row->question_type == "2"){  // Checkbox

				if($row->horizontal == "1"){
				   $myclass="bfradiohorizontal";
				}else{
				   $myclass="bfradio";
				}

			    for($z=0; $z < 20; $z++)
			   {
			       $tempvalue="option".($z+1);
	   	           if($row->$tempvalue != ""){
	   	              if($row->$tempvalue == "_OTHER_"){
	   	                 if($row->mandatory & class_exists('BFBehavior')){
	       	                echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'" class="'.$row->validation_type.'" onchange="MakeOtherMandatory('.$sequence.','.$z.')">'.JText::_($row->otherprefix).'</label><INPUT id="q'.$sequence.''.$z.'_other" name="q'.$sequence.'_OTHER_" class="">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       	             }else{
	       	                echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->otherprefix).'</label><INPUT id="q'.$sequence.''.$z.'" name="q'.$sequence.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       	             }
	       	          }else{
			             if($row->mandatory & class_exists('BFBehavior')){
	   	                    echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" class="'.$row->validation_type.'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				         }else{
	   	                    echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" >'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
	   	                 }
				   	  }
			  		  if($row->horizontal == "1"){
					      echo "&nbsp;&nbsp;&nbsp;";
		   		   	  }else{
		   		   	      echo "<br>";
		   		   	  }
	   	           }
	   	        }
	       }else if($row->question_type == "3"){  // Textarea
	           if($row->mandatory){
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" class="required" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');" ></textarea> '.JText::_($row->suffix);
		       }else{
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');"></textarea> '.JText::_($row->suffix);
		       }
	       }

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
		   echo '<input type="hidden" name="field_name'.($i+1).'" value="'.$row->field_name.'">';
	       ?>
	       </div>
	       <div class="bfquizQuestionFooter">

	       </div>
	    </th>
	</tr>
	<?php
	$k = 1 - $k;
}
?>
</table>


<?php
$num=count( $this->items );
?>

<input type="hidden" name="page_no" value="<?php echo $page_no ?>" />
<input type="hidden" name="start_qn" id="start_qn" value="<?php echo $start_qn ?>" />
<input type="hidden" name="next_question" id="next_question" value="<?php echo $next_question ?>" />
<input type="hidden" name="end_qn" value="<?php echo $end_qn ?>" />
<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="task" value="add" />
<input type="hidden" name="allowEmail" value="<?php echo $allowEmail ?>" />
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
</form>

<table width="200" border=1>
<tr>
<td>
<div class="progressbar_color_1" style="height:5px;width:<?php echo (($page_no/$total_qns)*100) ?>%"></div>
</td>
</tr>
</table>

<?php
}  // end check start_qn
?>

<?php
	      }else{
	  	     echo JText::_( "COM_BFQUIZ_UID_ALREADY_COMPLETED");
	      }

      }else{
  	     echo JText::_( "COM_BFQUIZ_EMAIL_ALREADY_COMPLETED");
      }

   }else{
      echo JText::_( "COM_BFQUIZ_IP_ALREADY_COMPLETED");
   }

}else{
   echo JText::_( "COM_BFQUIZ_MUST_LOGIN");
}
?>
