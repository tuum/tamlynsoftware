<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php
if($this->catid != 0){  // make sure category is selected
	
//for pagination	
global $mainframe, $option;
$items = 0;
$limitstart = 0;
$limit = 0;	
jimport('joomla.html.pagination');
$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">
    <table width="100%">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'ID' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'Name' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'Email' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'UID' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'Date' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'Score' ); ?>
            </th>
        </tr>
    </thead>
    <?php
    $k = 0;
    $catid	= JRequest::getVar( 'cid', 0, '', 'int' );

    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row =& $this->items[$i];
        $link 		= JRoute::_( 'index.php?option=com_bfquiz&view=response&cid='. $row->id.'&catid='. $this->catid.'&'.JUtility::getToken().'=1');
        $checked 	= JHTML::_('grid.id',   $i, $row->id );
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
                <a href="<?php echo $link; ?>"><?php echo $row->id; ?></a>
            </td>
            <td>
                <a href="<?php echo $link; ?>">
                <?php
                   if(!isset($row->Name )){
                      $row->Name  = "";
                   }

                   if($row->Name == ""){
                      echo "< blank >";
                   }else{
                      echo $row->Name;
                   }
                ?>
                </a>
            </td>
            <td>
				<?php
                   if(!isset($row->Email)){
                      $row->Email = "";
                   }
                ?>
			    <?php echo $row->Email; ?>
            </td>
            <td align="center">
				<?php
                   if(!isset($row->uid)){
                      $row->uid = "";
                   }
                ?>
			    <?php echo $row->uid; ?>
            </td>
            <td>
				<?php
                   if(!isset($row->DateReceived)){
                      $row->DateReceived = "";
                   }
                ?>
			    <?php echo $row->DateReceived; ?>
            </td>
            <td align="right">
				<?php
                   if(!isset($row->score)){
                      $row->score = "";
                   }
                ?>
			    <?php echo $row->score; ?>
            </td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
 
 	<tfoot>
	    <tr>
	      <td><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>
    </table>
</div>


<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="task" value="response" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="catid" value="<?php echo $catid ?>" />
</form>

<?php

}else{

   echo JText::_( '<br>You must select a category in Parameters Basic');

}

?>