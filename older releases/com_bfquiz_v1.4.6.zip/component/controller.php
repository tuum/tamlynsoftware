<?php
/**
 * $Id: controller.php 2 2011-11-15 04:37:51Z tuum $
 * bfquiz default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * bfquiz Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class BFQuizController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

	/**
	 * Method to display the stats view
	 */
	function stats()
	{
		JRequest::setVar( 'view', 'stats' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * Method to display the save as you go view
	 */
	function sayg()
	{
		JRequest::setVar( 'view', 'sayg' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * Method to display the my quizzes view
	 */
	function myquizzes()
	{
		JRequest::setVar( 'view', 'myquizzes' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * Method to display the random question pool view
	 */
	function pool()
	{
		JRequest::setVar( 'view', 'pool' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}	
	
	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFQUIZ_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfquiz', $msg );
	}

	/**
	 * Get the questions from #__bfquiz for the current cateogry
	 * 
	 * @return	array of questions
	 */
	function getQuestions()
	{
	    $db =& JFactory::getDBO();

	    $catid	= JRequest::getVar( 'catid', 0, '', 'int' );

		// get questions
		if($catid == 0){
			$query = 'SELECT b.*,  cc.title AS category_name'
								. ' FROM #__bfquiz AS b'
								. ' LEFT JOIN #__categories AS cc ON cc.id = b.catid'
								. ' WHERE b.published'
								. ' ORDER BY b.catid, b.ordering'
			;

		}else{
		    $query = "SELECT * FROM #__bfquiz where catid=".(int)$catid." and published ORDER BY ordering";
		}

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
	}

	/**
	 * Get questions from specified category
	 * 
	 * @param int	$catid	Category id number
	 */
	function getQuestionsResponse($catid)
	{
	    $db =& JFactory::getDBO();

	    // get questions
		$query = "SELECT * FROM #__bfquiz where `catid`=".(int)$catid." AND `published`=1 ORDER BY ordering";

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		return $rows;
	}

	/**
	 * Get all the responses for the specific category
	 * 
	 * @param int $catid	Category id number
	 */
	function getAnswers($catid)
	{
		    $db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

		    // get questions
			$query = "SELECT * FROM ".$table."";


			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			return $rows;
	}

	/**
	 * Get the next question based on conditional branching
	 * 
	 * @param int $question		id number of the current question
	 * @param string $response	Answer selected for the current question
	 * 
	 * @return	int	$next_question	id number of the next question
	 */
	function getNextQuestion($question, $response)
	{
		$db =& JFactory::getDBO();

		// get questions
		$catid	= JRequest::getVar( 'catid', 0, '', 'int' );
		if($catid == 0){
		   $query = "SELECT * FROM #__bfquiz where id=".(int)$question."";
		}else{
		   $query = "SELECT * FROM #__bfquiz where catid=".(int)$catid." and id=".(int)$question."";
		}

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$next_question=0;

		if($rows[0]->question_type == 0){  // textbox
		   $next_question = $rows[0]->next_question1;
		}

		if($rows[0]->option1 == $response){
		   $next_question = $rows[0]->next_question1;
		}else if($rows[0]->option2 == $response){
		   $next_question = $rows[0]->next_question2;
		}else if($rows[0]->option3 == $response){
		   $next_question = $rows[0]->next_question3;
		}else if($rows[0]->option4 == $response){
		   $next_question = $rows[0]->next_question4;
		}else if($rows[0]->option5 == $response){
		   $next_question = $rows[0]->next_question5;
		}else if($rows[0]->option6 == $response){
		   $next_question = $rows[0]->next_question6;
		}else if($rows[0]->option7 == $response){
		   $next_question = $rows[0]->next_question7;
		}else if($rows[0]->option8 == $response){
		   $next_question = $rows[0]->next_question8;
		}else if($rows[0]->option9 == $response){
		   $next_question = $rows[0]->next_question9;
		}else if($rows[0]->option10 == $response){
		   $next_question = $rows[0]->next_question10;
		}else if($rows[0]->option11 == $response){
		   $next_question = $rows[0]->next_question11;
		}else if($rows[0]->option12 == $response){
		   $next_question = $rows[0]->next_question12;
		}else if($rows[0]->option13 == $response){
		   $next_question = $rows[0]->next_question13;
		}else if($rows[0]->option14 == $response){
		   $next_question = $rows[0]->next_question14;
		}else if($rows[0]->option15 == $response){
		   $next_question = $rows[0]->next_question15;
		}else if($rows[0]->option16 == $response){
		   $next_question = $rows[0]->next_question16;
		}else if($rows[0]->option17 == $response){
		   $next_question = $rows[0]->next_question17;
		}else if($rows[0]->option18 == $response){
		   $next_question = $rows[0]->next_question18;
		}else if($rows[0]->option19 == $response){
		   $next_question = $rows[0]->next_question19;
		}else if($rows[0]->option20 == $response){
		   $next_question = $rows[0]->next_question20;
		}

		//special case for checkbox
		//take the lowest next question id out of those selected
		$check_msg="";
		if ($rows[0]->question_type == 2 & $response != NULL)	// checkbox
		{
			foreach($response as $value)
         	{
               $check_msg .= "$value\n";
           	}
       		$response = $check_msg;
			
			for($i=0; $i < 20; $i++){
	             $myoption="option".($i+1);
	             $mynextquestion="next_question".($i+1);

	             if($rows[0]->$myoption){
	                //does answer contain this option
	                $response=" ".$response;
	                if(strpos(strtoupper($response), strtoupper($rows[0]->$myoption) )){
						//is next question id lower than current?
	                	if($rows[0]->$mynextquestion < $next_question | $next_question==0){
							$next_question=$rows[0]->$mynextquestion;
						}
			  	    }
			  	 }
	          }       		  		
		}
		
		return $next_question;

	}

	/**
	 * Get the question text for this question
	 * 
	 * @param 	int		$question	id number of the current question
	 * 
	 * @return	string	$result		Text of the question
	 */
	function getQuestion($question)
	{
		$db =& JFactory::getDBO();

		// get question
		$query = "SELECT question FROM #__bfquiz where id=".(int)$question."";

		$db->setQuery( $query);
		$result=$db->loadResult();

	    return $result;
    }

    /**
     * Get all the details for the specified question
     * 
     * @param 	int 	$question	id number of the question
     * 
     * @return	array	$rows		All the fields for that question
     */
	function getQuestionDetails($question)
	{
		$db =& JFactory::getDBO();

		// get question
		$query = "SELECT * FROM #__bfquiz where id=".(int)$question."";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

	    return $rows;
    }    

    /**
     * Save the default fields for this response
     * 
     * @param string	$name	Name of the person completing the quiz
     * @param string	$email	Email address of the person completing the quiz
     * @param string	$table	Answer table name
     * 
     * @return	int		id number of the row inserted in the answer table
     */
	function save($name,$email,$table)
	{
	    $db =& JFactory::getDBO();

		// todays date
		$now =& JFactory::getDate();
		$DateCompleted = $now->toMySQL();
		
		$session =& JFactory::getSession();
		if($session->has('dateReceived')){
   			$dateReceived=$session->get('dateReceived');
		}else{
			$dateReceived=$DateCompleted;
		}
		$ip = BFQuizController::getIP();

		// save data
		$query = "INSERT INTO ".$table." ( `id` , `Name`, `Email`, `DateReceived`,`ip`,`DateCompleted`) values ('','$name','$email','$dateReceived','$ip','$DateCompleted')";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return $db->insertid();
	}

	/**
	 * Used to see if this IP address has already completed the quiz
	 * 
	 * @param string $table		Name of the answer table
	 * @param string $ip		IP address of the person taking the quiz
	 * 
	 * @return	int	Number of times this IP address appears in the answer table
	 */
	function checkIP($table,$ip){
	   $db =& JFactory::getDBO();

	   $query = "SELECT count(ip) from ".$table." where `ip`='".$ip."'";

	   $db->setQuery( $query);
	   $result=$db->loadResult();

	   return $result;

	}

	/**
	 * Check to see if person with the email address has already completed the quiz
	 * 
	 * @param string	$table		Answer table
	 * @param string	$myemail	Email address of person taking the quiz
	 * 
	 * @return	int		Number of times this email address has taken the quiz
	 */
	function checkEmail($table,$myemail){
	   $db =& JFactory::getDBO();

	   if($myemail == ""){
	      // don't check anonymous responses
	      return 0;
	   }else{
	      $query = "SELECT count(Email) from ".$table." where `Email`='".$myemail."'";

	      $db->setQuery( $query);
	      $result=$db->loadResult();

	      return $result;
	   }
	}

	/**
	 * Check to see if person with this user id (UNID) has completed the quiz
	 * 
	 * @param string	$table	Answer table
	 * @param int		$myUID	User id number of the current user
	 * 
	 * @return	int		Number of times this user has completed the quiz
	 */
	function checkUID($table,$myUID){
	   $db =& JFactory::getDBO();

	   if($myUID == "" | $myUID == 0){
	      // don't check anonymous responses
	      return 0;
	   }else{
	      $query = "SELECT count(uid) from ".$table." where `uid`='".(int)$myUID."'";

	      $db->setQuery( $query);
	      $result=$db->loadResult();

	      return $result;
	   }
	}

	/**
	 * Get the question data based on field name
	 * 
	 * @param int 		$id			id number of the question
	 * @param string 	$field_name	name of the field to get data for
	 * @param string	$table		Name of the question table
	 * 
	 * @return string	data in that field
	 */
	function getField($id,$field_name,$table)
	{
	    $db =& JFactory::getDBO();

		// get answer
		$query = "SELECT `".$field_name."` FROM ".$table." where id=".(int)$id."";

		$db->setQuery( $query);
		$result=$db->loadResult();

	    return $result;
	}
	
	/**
	 * Get the field name for a question
	 * 
	 * @param 	int		$id		id number of the quesiton
	 * 
	 * @return	string	field name
	 */
	function getFieldName($id){
		$db =& JFactory::getDBO();
		$query = "SELECT `field_name` FROM #__bfquiz where id=".(int)$id;
		
		$db->setQuery( $query);
		$result=$db->loadResult();

	    return $result;
	}

	/**
	 * Save the data for this question based on the field name
	 * 
	 * @param int 		$id			id number of the answer row
	 * @param string 	$field_name	Name of the database field to save the answer in
	 * @param string 	$answer		Answer selected in the quiz
	 * @param string 	$table		Answer table name
	 * 
	 * @return	boolean	True for success, false for failure
	 */
	function saveField($id,$field_name,$answer,$table)
	{
	    $db =& JFactory::getDBO();

		// save data
		$query = 'UPDATE '.$table.' SET `'.$field_name.'`='.$db->quote( $db->getEscaped( $answer ), false ).' where `id`='.(int)$id.'';

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

	/**
	 * This function processes the answers given for an all questions on one page quiz.
	 * 
	 * @return null
	 */
	function updateOnePage()
	{
		//get parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$registeredUsers = $config->get( 'registeredUsers' );
		$preventMultipleEmail = $config->get( 'preventMultipleEmail' );
		$preventMultipleUID = $config->get( 'preventMultipleUID' );
		$scoringMethod = $config->get( 'scoringMethod' );
		$thankyouText = $config->get( 'thankyouText' );
		$allowAuthorEmail = $config->get( 'authorEmail' );

		global $mainframe;
		$qntable=$mainframe->getCfg('dbprefix')."bfquiz";
		$fullname = JRequest::getVar( 'fullname', "", 'post', 'string' );
		$email = JRequest::getVar( 'email', "", 'post', 'string' );
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		$table=$mainframe->getCfg('dbprefix')."bfquiz_".$catid;

		$emailcount = BFQuizController::checkEmail($table,$email);

		$user = &JFactory::getUser();
		if($registeredUsers == "1"){
		   $uidcount = BFQuizController::checkUID($table,$user->id);
		}else{
		   $uidcount = 0;
		}

		if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed quiz

	    // save basic details to db, and generate id
		$id = BFQuizController::save($fullname,$email,$table);

		//save uid
		BFQuizController::saveField($id,"uid",$user->id,$table);

		$emailBody = "";
		$score=0;
		$answerSeq="";

		$items =& BFQuizController::getQuestions();

		$total_qns=count( $items );

		for ($i=0; $i < $total_qns; $i++)
		{
		    $check_msg = "";
			$row = $items[$i];
			$fieldName = $row->field_name;

		    if($row->question_type == 1){ // radio
		      if(JRequest::getVar($fieldName) == "_OTHER_"){
		         $temp = $fieldName;
		         $temp .= '_OTHER_';
		         $answer = JRequest::getVar($temp);
		      }else{
		         $answer = JRequest::getVar($fieldName);
		      }
			}else if($row->question_type == "2"){  // Checkbox
		   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );
				if($name == ""){
				   //do nothing
				}else{
		   			foreach($name as $value) {
		    		   	if($value == "_OTHER_"){
		    		      	$temp = $fieldName;
		        	        $temp .= '_OTHER_';
					      	$value = JRequest::getVar($temp);
       				   	}
			 		   $check_msg .= "$value\n";
			 		}
		   		}
			    $answer = $check_msg;
			}else{
			   $answer = JRequest::getVar($fieldName);
			}

		   	if($answer == ""){
    			// do nothing
   			}else{
   				$question = BFQuizController::getQuestion($items[$i]->id);
    			$emailBody .= "<br>".$question.": <br>".JText::_("COM_BFQUIZ_ANSWER").": ".$answer."<br>";
   			}

			if($fieldName == ""){
			   // do nothing
			}else{
  			   BFQuizController::saveField($id,$fieldName,$answer,$table);
  			   $score=$score+BFQuizController::getScore($fieldName,$qntable,$answer);
  		       if($scoringMethod == 1){
			      $answerSeq.=BFQuizController::getAnswerSeq($fieldName,$answer);
      		   }
  			}
		}

		//save score
		BFQuizController::saveField($id,"score",$score,$table);

		//save answer sequence
		BFQuizController::saveField($id,"answerseq",$answerSeq,$table);

		echo "<div class=\"bfquizOptions\">";
		echo $thankyouText;
		echo "</div>";
		echo "<br>";
		BFQuizController::showResultsScoreCategory($id,$table,$catid);
		BFQuizController::showResults($score);
		echo "<br>";
		$myIncorrect=BFQuizController::showIncorrect($id,$table);
		
		//------------------------------------ email ------------------------------------------------------------
		$emailBodyIncorrect = "<br>".JText::_("COM_BFQUIZ_INCORRECT_ANSWERS")."<br>".$myIncorrect."<br>";

		$adminEmail = BFQuizController::getEmailTemplate("Admin", $catid);
		
		$maxScore = bfquizController::getMaxScore($catid);
	
		//repace fields with actual data
		$adminEmail[0]->description=preg_replace('/{score}/', $score , $adminEmail[0]->description); // insert score
		$adminEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $adminEmail[0]->description); // insert maximum score
		$adminEmail[0]->description=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->description); // insert category
		$adminEmail[0]->description=preg_replace('/{name}/', $fullname , $adminEmail[0]->description); // insert name
		$adminEmail[0]->description=preg_replace('/{email}/', $email , $adminEmail[0]->description); // insert email						
	
		$adminEmail[0]->subject=preg_replace('/{score}/', $score , $adminEmail[0]->subject); // insert score
		$adminEmail[0]->subject=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->subject); // insert category
		$adminEmail[0]->subject=preg_replace('/{name}/', $fullname , $adminEmail[0]->subject); // insert name
		$adminEmail[0]->subject=preg_replace('/{email}/', $email , $adminEmail[0]->subject); // insert email						
		
		$subject = $adminEmail[0]->subject;
		$body = $adminEmail[0]->description;
		if($adminEmail[0]->showQuestions == 1){
			$body .= $emailBody;
		}
	
		if($adminEmail[0]->showIncorrect == 1){
			$body .= $emailBodyIncorrect;
		}

		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

	   	$allowEmail = $config->get( 'allowEmail' );
	   	$sendEmailTo = $config->get( 'sendEmailTo' );

	   	if($allowEmail){
			BFQuizController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);
   		}

		$authorEmail = BFQuizController::getEmailTemplate("Author", $catid);
		
		//repace fields with actual data
		$authorEmail[0]->description=preg_replace('/{score}/', $score , $authorEmail[0]->description); // insert score
		$authorEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $authorEmail[0]->description); // insert maximum score
		$authorEmail[0]->description=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->description); // insert category
		$authorEmail[0]->description=preg_replace('/{name}/', $fullname , $authorEmail[0]->description); // insert name
		$authorEmail[0]->description=preg_replace('/{email}/', $email , $authorEmail[0]->description); // insert email						
		
		$authorEmail[0]->subject=preg_replace('/{score}/', $score , $authorEmail[0]->subject); // insert score
		$authorEmail[0]->subject=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->subject); // insert category
		$authorEmail[0]->subject=preg_replace('/{name}/', $fullname , $authorEmail[0]->subject); // insert name
		$authorEmail[0]->subject=preg_replace('/{email}/', $email , $authorEmail[0]->subject); // insert email						
		
		$subject = $authorEmail[0]->subject;
		$body = $authorEmail[0]->description;
		if($authorEmail[0]->showQuestions == 1){
			$body .= $emailBody;
		}
	
		if($authorEmail[0]->showIncorrect == 1){
			$body .= $emailBodyIncorrect;
		}   	
   	
		if($allowAuthorEmail == "1" & $email!=""){
			BFQuizController::sendHTMLNotificationEmail($body, $email, $subject);
		}
		//------------------------------------ end email ------------------------------------------------------------	
			
		if($scoringMethod == 1){
		   BFQuizController::checkABCD($fieldName,$answerSeq,$id,$table);
		}else if($scoringMethod == 2){
		   BFQuizController::checkscorerange($fieldName,$score,$id,$table);
		}

		}else{
		   echo JText::_( "COM_BFQUIZ_EMAIL_ALREADY_COMPLETED");
      	}
      	
      	//clear session data
      	$session =& JFactory::getSession();
		$session->set('start_time'.$Itemid, null);
		$session->set('dateReceived', null);
	}

    function sendEmail($body){
    	$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

    	$allowEmail = $config->get( 'allowEmail' );
    	$sendEmailTo = $config->get( 'sendEmailTo' );
    	$emailSubject = $config->get( 'emailSubject' );
		$emailBody = $config->get( 'emailBody' );

	   if($allowEmail){
	       // Send email
		   BFQuizController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
		}else{
		   // do nothing
		}
    }

	function sendEmailAuthor($body,$author){
    	$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

    	$allowEmail = $config->get( 'allowEmail' );

      if($allowEmail){
          // Send email
         $sendEmailTo = $author;
    	 $emailSubject = $config->get( 'emailSubject' );
		 $emailBody = $config->get( 'emailBody' );
         BFQuizController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
      }else{
         // do nothing
      }
    }

    function sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody)
	{
	    $mailer =& JFactory::getMailer();

	    $mailer->addRecipient($sendEmailTo);
		$mailer->setSubject($emailSubject);
		$mailer->setBody($emailBody.$body.'');

		if ($mailer->Send() !== true)
		{
		    // an error has occurred
		    // a notice will have been raised by $mailer
		}
	}

	function getIP() {

		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
			$ip=$_SERVER['REMOTE_ADDR'];
		return $ip;
	}

	function getStatsCheckbox($question, $response, $catid){
		$db =& JFactory::getDBO();
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

		$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."` like'%".$db->getEscaped( $response, true )."%'";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		$n = count($rows);
		return $n;
	}

	function getStats($question, $response, $catid){

			$db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

			// get answers
			$config =& JComponentHelper::getParams( 'com_bfquiz_stats' );

			$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."`='". $db->getEscaped( $response, true )."'";
		  	
			$db->setQuery( $query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$n = count($rows);
			return $n;
	}
	
	function getStatsPool($id, $response, $poolid, $qnsPerQuiz){
			$db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$poolid.'_pool';
			$total = 0;

			for($i=1; $i < $qnsPerQuiz+1; $i++){
				$tempqid = "qid".$i;
				$tempanswer = "answer".$i;

		  		$query = "SELECT * FROM ".$table." WHERE `".$tempqid."`=".$id." AND `".$tempanswer."`=".$db->quote( $db->getEscaped( $response ), false );

				$db->setQuery( $query);
				$rows = $db->loadObjectList();
				if ($db->getErrorNum())
				{
					echo $db->stderr();
					return false;
				}
				$n = count($rows);

				$total = $total + $n;
			}

			return $total;
	}

	/***********************
	 *	Captcha functions!
	 ***********************/
	function displaycaptcha() {
		global $mainframe;

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 0, '', 'int');

		if ($use_captcha) {
			$Ok = null;
			$mainframe->triggerEvent('onCaptcha_Display', array($Ok));
			if (!$Ok) {
				echo JText::_( "COM_BFQUIZ_CAPTCHA_ERROR_DISPLAYING" );
			}
		}
	}

	/**
	@return boolean
	*/
	function _checkCaptcha() {
		global $mainframe;

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 1, '', 'int');


		// not using captcha!
		if (!$use_captcha) {
			return true;
		}
		$return = false;
		$word = JRequest::getVar('word', false, '', 'CMD');

		$mainframe->triggerEvent('onCaptcha_confirm', array($word, &$return));
		if ($return) {
			return true;
		} else return false;
	}


	/**********************
	 * Scoring functions
	 **********************/
	 function showResults($score){
	    $db =& JFactory::getDBO();

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$showResults = $config->get( 'showResults' );

	    if($showResults){
	       ?>
		      <div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS"); ?> <?php echo $score; ?></strong></div>
		      <br>
		  <?php
	    }else{
	       // do nothing - show results menu parameter set to no
	    }
	 }
	 
	function showResultsScoreCategory($id, $table, $catid){		
		$db =& JFactory::getDBO();		
		$query = "SELECT * FROM #__bfquiz WHERE catid=".(int)$catid." AND scorecatid>0";

		$db->setQuery( $query);
		$result=$db->loadObjectList();
		
		$db =& JFactory::getDBO();		
		$query2 = "SELECT * FROM ".$table." WHERE id=".(int)$id;

		$db->setQuery( $query2);
		$result2=$db->loadObjectList();
		
		$scorecategoryA=0;
		$scorecategoryB=0;
		$scorecategoryC=0;
		$scorecategoryD=0;
		$scorecategoryE=0;
		$scorecategoryF=0;
		$countA=0;
		$countB=0;
		$countC=0;
		$countD=0;
		$countE=0;
		$countF=0;
		global $mainframe;
		$qntable=$mainframe->getCfg('dbprefix')."bfquiz";
		if(count($result)){
			foreach($result as $row){
				$fieldName = $row->field_name;
				switch($row->scorecatid){
					case 1:	$scorecategoryA = $scorecategoryA + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countA++;
							break;
					case 2:	$scorecategoryB = $scorecategoryB + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countB++;
							break;
					case 3:	$scorecategoryC = $scorecategoryC + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countC++;
							break;
					case 4:	$scorecategoryD = $scorecategoryD + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countD++;
							break;
					case 5:	$scorecategoryE = $scorecategoryE + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countE++;
							break;
					case 6:	$scorecategoryF = $scorecategoryF + BFQuizController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
							$countF++;
							break;																																			
				}
			}
			?>
			<?php if($countA){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_A"); ?> <?php echo $scorecategoryA; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_A_INFORMATION"); ?></div>
			<br>
			<?php } ?>
			<?php if($countB){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_B"); ?> <?php echo $scorecategoryB; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_B_INFORMATION"); ?></div>
			<br>
			<?php } ?>
			<?php if($countC){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_C"); ?> <?php echo $scorecategoryC; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_C_INFORMATION"); ?></div>
			<br>
			<?php } ?>
			<?php if($countD){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_D"); ?> <?php echo $scorecategoryD; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_D_INFORMATION"); ?></div>
			<br>
			<?php } ?>
			<?php if($countE){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_E"); ?> <?php echo $scorecategoryE; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_E_INFORMATION"); ?></div>
			<br>
			<?php } ?>
			<?php if($countF){ ?>
			<div class="bfquizOptions"><strong><?php echo JText::_("COM_BFQUIZ_CONGRATULATIONS_F"); ?> <?php echo $scorecategoryF; ?></strong></div>
			<div class="bfquizScoreCategoryInfo"><?php echo JText::_("COM_BFQUIZ_SCORECATEGORY_F_INFORMATION"); ?></div>
			<br>
			<?php } ?>															
			<?php				
		}		
	}

	function getScore($field_name,$table,$answer)
	{
		$db =& JFactory::getDBO();

		$query = "SELECT `id` FROM ".$table." where field_name='".$field_name."'";

		$db->setQuery( $query);
		$result=$db->loadResult();
		$id=$result;

		// get answer
		$query = "SELECT * FROM ".$table." where id=".(int)$id;

		$db->setQuery( $query);
		$rows = $db->loadObjectList();

		$myresult=&$rows[0];
		$score=0;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$scoringMethod = $config->get( 'scoringMethod' );

		$view=JRequest::getVar('view');
		if($view=="stats" & !(is_numeric($myresult->score1))){
			$scoringMethod =1;
		}

		if($scoringMethod == 1){
			$score=1;
		}else{
			if(is_numeric($myresult->score1)){
				$numanswers=0;
				//special case for checkbox question type
				if($myresult->question_type == 2){
					//how many correct answers?
					$numanswers=(int)($myresult->answer1)+(int)($myresult->answer2)+(int)($myresult->answer3)+(int)($myresult->answer4)+(int)($myresult->answer5)+(int)($myresult->answer6)+(int)($myresult->answer7)+(int)($myresult->answer8)+(int)($myresult->answer9)+(int)($myresult->answer10)+(int)($myresult->answer11)+(int)($myresult->answer12)+(int)($myresult->answer13)+(int)($myresult->answer14)+(int)($myresult->answer15)+(int)($myresult->answer16)+(int)($myresult->answer17)+(int)($myresult->answer18)+(int)($myresult->answer19)+(int)($myresult->answer20);
				}
			  
				for ($z=0; $z < 20; $z++){
					$tempoption="option".($z+1); 
					$tempscore="score".($z+1);
					if(trim(strtoupper($answer))==trim(strtoupper($myresult->$tempoption))){
						$score=$myresult->$tempscore;
						$z = 20;
					}
				}

				//special case for multiple answers
				if($numanswers>1){
					//get correct answer
					$correctanswer = "";
					for ($z=0; $z < 20; $z++){
						$tempvalue="answer".($z+1);
						$tempvalue2="option".($z+1);
						if($myresult->$tempvalue == 1){
							$correctanswer .= $myresult->$tempvalue2;
							$correctanswer.=" "; //add space between correct answers
						}
					}

					//remove all whitespace
					$myanswer=preg_replace('/\s+/','',$answer);
					$correctanswer=preg_replace('/\s+/','',$correctanswer);

					$score=0;
					for($i=0; $i < 20; $i++){
						$myoption="option".($i+1);
						$myscore="score".($i+1);

						if($myresult->$myoption){
							//does answer contain this option
							$answer=" ".$answer;
							if(strpos(strtoupper($answer), strtoupper($myresult->$myoption) )){
								//only assign score if all correct answers are selected
								if(trim(strtoupper($myanswer))==trim(strtoupper($correctanswer)) | $myresult->suppressQuestion == 1){
									$score=$score+(int)($myresult->$myscore);
								}
							}
						}
					}
				}
			}else{
				if($myresult->suppressQuestion == 1){
					$score=0;
				}else{
					echo JText::_("COM_BFQUIZ_ERROR_SCORE_NUMERIC");
				}
			}

		} // end else

		return $score;
	}


function showIncorrect($id,$table){
	    $db =& JFactory::getDBO();
		global $mainframe;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$showIncorrect = $config->get( 'showIncorrect' );
		$showCorrect = $config->get( 'showCorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){
	       //get questions
		   $items =& BFQuizController::getQuestions();
		   $total_qns=count( $items );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $row = &$items[$i];
		      $fieldName = $row->field_name;

			  $numanswers=0;
			  //special case for checkbox question type
			  if($row->question_type == 2){
			     //how many correct answers?
				 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
			  }

			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($row->$tempvalue == 1){
			        $correctanswer .= $row->$tempvalue2;
			        if($numanswers > 1){
			           $correctanswer.=" "; //add space between correct answers
			        }
			     }
			  }

		      //get answer
			  $answer=BFQuizController::getField($id,$fieldName,$table);

			  $answerWithSpaces=trim($answer);
			  $correctAnswerWithSpaces=trim($correctanswer);
			  
		      if($row->question_type == 2){ //checkbox
		         //(remove whitespace)
		         $answer=preg_replace('/\s+/','',$answer);
		         $correctanswer=preg_replace('/\s+/','',$correctanswer);
		      }

			  //was answer correct?
		      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1){
			     //answer was correct or question suppressed
			     if( $row->suppressQuestion == 1 ){
			         //still do nothing as question is suppressed
			     }else{
					if( $showCorrect == 1 ){
			     	//show correct answer
			  	 	?>
					<tr>
		    			<th>
	    			   	<div class="bfquizQuestion"><?php echo JText::_( $row->question ); ?></div>
	    				</th>
					</tr>
					<tr>
					    <th>
			      			<div class="bfquizOptions">
			      			<?php echo JText::_("COM_BFQUIZ_YOUR_ANSWER_OF"); ?>
			      			<?php echo $answerWithSpaces; ?>
			      			<?php echo JText::_("COM_BFQUIZ_WAS_CORRECT"); ?>
			      	    	</div>
			      		</th>
		      		</tr>
		      		<tr>
		      	   	<td>&nbsp;</td>
		      		</tr>
					<?php
			     	}		     	
			     }
			  }else{
				 //first one
				 if($i==0){
				    ?>
				    <div class="bfquizOptions">
				    <?php echo JText::_( "COM_BFQUIZ_INCORRECT_ANSWERS" ); ?></div>
				    <br>
				    <?php
				 }

	             //show solution
			  	 ?>
				<tr>
	    			<th>
	    			   <div class="bfquizQuestion"><?php echo JText::_( $row->question ); ?></div>
	    			</th>
				</tr>
				<tr>
				    <th>
			      		<div class="bfquizOptions">
			      		<font color="red">
			      		<?php echo JText::_("COM_BFQUIZ_YOUR_ANSWER_OF"); ?>
			      		<?php echo $answerWithSpaces; ?>
			      		<?php echo JText::_("COM_BFQUIZ_WAS_INCORRECT"); ?>
			      		<br>
			      		<?php echo JText::_("COM_BFQUIZ_CORRECT_ANSWER_IS"); ?>
			      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
			      		</font>
			      		<br><br>
			      		<?php echo $row->solution; ?>
			      	    </div>
			      	</th>
		      	</tr>
		      	<tr>
		      	   <td>&nbsp;</td>
		      	</tr>
				<?php

				//now prepare above for email
				$myIncorrect.="<br>".JText::_( $row->question ).": <br>".JText::_('COM_BFQUIZ_YOUR_ANSWER_OF')."".$answerWithSpaces."".JText::_('COM_BFQUIZ_WAS_INCORRECT')."<br>".JText::_('COM_BFQUIZ_CORRECT_ANSWER_IS')."".$correctAnswerWithSpaces."<br><br>";
	          }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }

function showIncorrect2($answer,$fieldname,$qid){
	    $db =& JFactory::getDBO();
		global $mainframe;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfquiz";

		$showIncorrect = $config->get( 'showIncorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){

	       //get questions
		   $myitem =& BFQuizController::getOneQuestion($qid);
		   $total_qns=count( $myitem );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $row = &$myitem[$i];
		      $fieldName = $row->field_name;

		   	  $numanswers=0;
			  //special case for checkbox question type
			  if($row->question_type == 2){
			     //how many correct answers?
				 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
			  }

			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($row->$tempvalue == 1){
			        $correctanswer .= $row->$tempvalue2;
			        if($numanswers > 1){
			           $correctanswer.=" "; //add space between correct answers
			        }
			     }
			  }
			  
		   	  if( is_array($answer) ){
			     $answer = implode(" ",$answer);
			  }

			  $answerWithSpaces=trim($answer);
			  $correctAnswerWithSpaces=trim($correctanswer);
			  
		      if($row->question_type == 2){ //checkbox
		         //(remove whitespace)
		         $answer=preg_replace('/\s+/','',$answer);
		         $correctanswer=preg_replace('/\s+/','',$correctanswer);
		      }

		      //was answer correct?
		      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1){
			     //do nothing as answer was correct or question suppressed
			  }else{

	             //show solution
			  	?>
				<tr>
	    			<th>
	    			   <div class="bfquizQuestion"><?php echo JText::_( $row->question ); ?></div>
	    			</th>
				</tr>
				<tr>
				    <th>
			      		<div class="bfquizOptions">
			      		<font color="red">
			      		<?php echo JText::_("COM_BFQUIZ_YOUR_ANSWER_OF"); ?>
			      		<?php echo $answerWithSpaces; ?>
			      		<?php echo JText::_("COM_BFQUIZ_WAS_INCORRECT"); ?>
			      		<br>
			      		<?php echo JText::_("COM_BFQUIZ_CORRECT_ANSWER_IS"); ?>
			      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
			      		</font>
			      		<br><br>
			      		<?php echo $row->solution; ?>
			      	    </div>
			      	</th>
		      	</tr>
		      	<tr>
		      	   <td>&nbsp;</td>
		      	</tr>
				<?php

				//now prepare above for email
				$myIncorrect.="\n".JText::_( $row->question ).": \n".JText::_('COM_BFQUIZ_YOUR_ANSWER_OF')."".$answerWithSpaces."".JText::_('COM_BFQUIZ_WAS_INCORRECT')."\n".JText::_('COM_BFQUIZ_CORRECT_ANSWER_IS')."".$correctAnswerWithSpaces."\n\n";
	          }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }

	/**
	 * This is the show incorrect function used by the random question pool
	 * 
	 * @param int	$id			id number of the row in the answer table
	 * @param int	$table		answer table
	 * @param array	$randompool	array of questions selected from the question pool for this quiz
	 * 
	 * @return	string	details about the incorrect answers.
	 */
	function showIncorrectPool($id,$table,$randompool){
	    $db =& JFactory::getDBO();
		global $mainframe;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$showIncorrect = $config->get( 'showIncorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){
		   $total_qns=count( $randompool );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $qid = $randompool[$i];
		      $result = BFQuizController::getQuestionDetails($qid);
		      $row = &$result[0];
		      //$fieldName = $row->field_name;
		      
			  $numanswers=0;
			  //special case for checkbox question type
			  if($row->question_type == 2){
			     //how many correct answers?
				 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
			  }

			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($row->$tempvalue == 1){
			        $correctanswer .= $row->$tempvalue2;
			        if($numanswers > 1){
			           $correctanswer.=" "; //add space between correct answers
			        }
			     }
			  }

			  $fieldName="answer".($i+1);
		      //get answer
			  $answer=BFQuizController::getField($id,$fieldName,$table);
			  
			  $answerWithSpaces=trim($answer);
			  $correctAnswerWithSpaces=trim($correctanswer);
			  
		      if($row->question_type == 2){ //checkbox
		         //(remove whitespace)
		         $answer=preg_replace('/\s+/','',$answer);
		         $correctanswer=preg_replace('/\s+/','',$correctanswer);
		      }

			  //was answer correct?
		      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1){
			     //do nothing as answer was correct or question suppressed
			  }else{
				 //first one
				 if($i==0){
				    ?>
				    <div class="bfquizOptions">
				    <?php echo JText::_( "COM_BFQUIZ_INCORRECT_ANSWERS" ); ?></div>
				    <br>
				    <?php
				 }

	             //show solution
			  	 ?>
				<tr>
	    			<th>
	    			   <div class="bfquizQuestion"><?php echo JText::_( $row->question ); ?></div>
	    			</th>
				</tr>
				<tr>
				    <th>
			      		<div class="bfquizOptions">
			      		<font color="red">
			      		<?php echo JText::_("COM_BFQUIZ_YOUR_ANSWER_OF"); ?>
			      		<?php echo $answerWithSpaces; ?>
			      		<?php echo JText::_("COM_BFQUIZ_WAS_INCORRECT"); ?>
			      		<br>
			      		<?php echo JText::_("COM_BFQUIZ_CORRECT_ANSWER_IS"); ?>
			      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
			      		</font>
			      		<br><br>
			      		<?php echo $row->solution; ?>
			      	    </div>
			      	</th>
		      	</tr>
		      	<tr>
		      	   <td>&nbsp;</td>
		      	</tr>
				<?php

				//now prepare above for email
				$myIncorrect.="<br>".JText::_( $row->question ).": <br>".JText::_('COM_BFQUIZ_YOUR_ANSWER_OF')." ".$answerWithSpaces." ".JText::_('COM_BFQUIZ_WAS_INCORRECT')."<br>".JText::_('COM_BFQUIZ_CORRECT_ANSWER_IS')." ".$correctAnswerWithSpaces."<br><br>";
	          }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }
	 
	/**
	 * get the fields for a particular question
	 * 
	 * @param int $question	id number of question
	 */
	function getOneQuestion($question)
	{
		$db =& JFactory::getDBO();

		// get question
		$query = "SELECT * FROM #__bfquiz where id=".(int)$question."";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();

	    return $rows;
    }

    /**
     * Counts how many responses there are in the answer table
     * 
     * @param 	int	$catid	id number of the category
     * 
     * @return	int			number of responses
     */
	function getNumberResponses($catid){
	   $db =& JFactory::getDBO();
	   global $mainframe;
	   $table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

	   $query = "SELECT id FROM ".$table;

	   //echo $query;
	   $db->setQuery($query);
	   $rows = $db->loadObjectList();
	   if ($db->getErrorNum())
	   {
	   	  echo $db->stderr();
	      return false;
	   }
	   $n = count($rows);
	   return $n;
	}

	/**
	 * Works out the maximum possible score if all correct answers are selected
	 * 
	 * @param 	int $catid	category id number
	 * 
	 * @return	int			maximum score
	 */
	function getMaxScore($catid){
        $db =& JFactory::getDBO();
		global $mainframe;
	    $table=$mainframe->getCfg('dbprefix')."bfquiz";

	    $query = "SELECT * FROM ".$table." where `catid`=".(int)$catid." AND `published`=1 ORDER BY ordering";

	   //echo $query;
	   $db->setQuery($query);
	   $rows = $db->loadObjectList();
	   if ($db->getErrorNum())
	   {
	   	  echo $db->stderr();
	      return false;
	   }
	   $n = count($rows);

	   $maxScore=0;
	   for($i=0; $i < $n; $i++){
	      $tempMax=0;

		  if(is_numeric($rows[$i]->score1)){
	         for($z=1; $z < 21; $z++){
	            $score = 'score'.$z;
	            $tempScore=$rows[$i]->$score;
	            if($tempScore > $tempMax){
	               $tempMax = $tempScore;
	            }
	         }
	         $maxScore = $maxScore + $tempMax;
	      }else{
	         $maxScore++; //for ABCD scoring.
	      }
	   }

	   return $maxScore;
	}

	/**
	 * Works out the average score for this quiz so far.
	 * 
	 * @param 	int 	$catid
	 * 
	 * @return	int		average score
	 */
	function getAverageScore($catid){
	   $db =& JFactory::getDBO();
	   global $mainframe;
	   $table=$mainframe->getCfg('dbprefix')."bfquiz";
	   $table2=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

	   $query = "SELECT * FROM ".$table." where `catid`=".(int)$catid." AND `published`=1 ORDER BY ordering";
	   $query2 = "SELECT * FROM ".$table2."";

	   $db->setQuery($query);
	   $rows = $db->loadObjectList();
	   if ($db->getErrorNum())
	   {
	   	  echo $db->stderr();
	      return false;
	   }

	   $db->setQuery($query2);
	   $rows2 = $db->loadObjectList();
	   if ($db->getErrorNum())
	   {
	   	  echo $db->stderr();
	      return false;
	   }

	   $n = count($rows);
	   $n2 = count($rows2);

	   $totalScore=0;
	   for($i=0; $i < $n2; $i++){
	      $totalTempScore=0;

	      for($z=0; $z < $n; $z++){
	         $fieldName = $rows[$z]->field_name;
	         $tempScore = bfquizController::getScore($fieldName,$table,$rows2[$i]->$fieldName);
	         $totalTempScore = $totalTempScore + $tempScore;
	      }
	      $totalScore = $totalScore + $totalTempScore;
	   }

	   if($n2 >0){
	      $average = round($totalScore / $n2,2);
	   }else{
	      $average = 0;
	   }

	   return $average;
	}

	/**
	 * Works out the highest score so far. Used by the stats view.
	 * 
	 * @param 	int 	$catid	id number of the category
	 * 
	 * @return	int		highest score
	 */
	function getHighestScore($catid){
		$db =& JFactory::getDBO();
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

		$query = "SELECT MAX(score) as score FROM ".$table;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->score;
	}

	/**
	 * works out the lowest score so far
	 * 
	 * @param	int	$catid	id number of the category
	 * 
	 * @return	int			lowest score
	 */
	function getLowestScore($catid){
		$db =& JFactory::getDBO();
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfquiz_".(int)$catid;

		$query = "SELECT MIN(score) as score FROM ".$table;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->score;
	}

	/**
	 * See which ABCD answer matrix matches the conditions
	 * 
	 * @param string 	$field_name		name of the field
	 * @param string 	$answerSeq		Sequence of answers, eg. BBAACDAB
	 * @param int 		$resultid		id of the row in the answer table
	 * @param string 	$resulttable	table name
	 */
   function checkABCD($field_name,$answerSeq, $resultid, $resulttable){
      //see which answer matrix matches
      $db =& JFactory::getDBO();

      global $mainframe;
	  $qntable=$mainframe->getCfg('dbprefix')."bfquiz";
	  $matrixtable=$mainframe->getCfg('dbprefix')."bfquiz_matrix";

      //get category id
      $query = "SELECT `catid` FROM ".$qntable." where field_name='".$field_name."'";

      $db->setQuery( $query);
	  $result=$db->loadResult();
	  $catid=$result;

	  //get all ABCD answer matrix for this category
	  $query = "SELECT * FROM ".$matrixtable." where catid=".(int)$catid;
	  $db->setQuery( $query);
	  $rows = $db->loadObjectList();

	  //now we need to see if any ABCD answer matrix match

	  $n = count($rows);

	  $match=0;
	  for($z=0; $z < $n; $z++){
	     $exactMatch = $rows[$z]->exactMatch;
	     $redirectURL = $rows[$z]->redirectURL;
	     $resultText = $rows[$z]->resultText;

         if($exactMatch!=""){
 	        if($answerSeq==$exactMatch){
	           //we found a match

	           //save matrixid
			   BFQuizController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);

	           if($redirectURL==""){
	              //no redirect so show resultText
	              echo $resultText;
	           }else{
		   	      //redirect to the url
	              $msg="";
	              global $mainframe;
			      $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	           }

			   //don't bother looking at other matrix since we found match
			   $match=1;
	           $z = $n;
	        }
	     }else{  //no exactMatch set

            //need to see if other condtions match
		    $score1 = $rows[$z]->score1;
		    $score2 = $rows[$z]->score2;
		    $score3 = $rows[$z]->score3;
		    $score4 = $rows[$z]->score4;
		    $score5 = $rows[$z]->score5;
		    $condition1 = $rows[$z]->condition1;
		    $condition2 = $rows[$z]->condition2;
		    $condition3 = $rows[$z]->condition3;
		    $condition4 = $rows[$z]->condition4;
		    $condition5 = $rows[$z]->condition5;
		    $qty1 = $rows[$z]->qty1;
		    $qty2 = $rows[$z]->qty2;
		    $qty3 = $rows[$z]->qty3;
		    $qty4 = $rows[$z]->qty4;
		    $qty5 = $rows[$z]->qty5;
		    $operator1 = $rows[$z]->operator1;
		    $operator2 = $rows[$z]->operator2;
		    $operator3 = $rows[$z]->operator3;
		    $operator4 = $rows[$z]->operator4;
		    $operator5 = $rows[$z]->operator5;

			$line1=0;
			$line2=0;
			$line3=0;
			$line4=0;
			$line5=0;
			$numlines=0;

			for($i=1; $i < 6; $i++){
			   $score="score".$i;
			   $line="line".$i;
			   $qty="qty".$i;
			   $condition="condition".$i;

			   if($$score != ""){
			      $numlines++;
		          //does it match the criteria?
		          switch($$condition){
		             case 0: if(BFQuizController::timesFound($answerSeq,$$score) == $$qty){    //is equal to
		                        $$line=1;
		                     }else{
		                        $$line=0;
		                     }
		                     break;
		             case 1: if(BFQuizController::timesFound($answerSeq,$$score) < $$qty){    //is less than
			         		      $$line=1;
			         		   }else{
			         		      $$line=0;
			         		   }
		                     break;
		             case 2: if(BFQuizController::timesFound($answerSeq,$$score) > $$qty){    //is greater than
			         		      $$line=1;
			         		   }else{
			         		      $$line=0;
			         		   }
		                     break;
		             case 3: if(BFQuizController::timesFound($answerSeq,$$score) != $$qty){    //is not equal to
			         		      $$line=1;
			         		   }else{
			         		      $$line=0;
			         		   }
		                     break;
		             default: $$line=0;
		          } // end switch
		       }else{
		          $i=6; // don't bother checking other lines
		       }//end if
		    }

            //now need to use operator to combine conditions for each line
            switch($numlines){
               case 5: if($line1==1 & $line2==1 & $line3==1 &line4==1 & $line5==1){
                          $match=1;
               		   }
               		   break;
               case 4: if($line1==1 & $line2==1 & $line3==1 &line4==1){
                          $match=1;
               		   }
               		   break;
			   case 3: if($line1==1 & $line2==1 & $line3==1){
                          $match=1;
               		   }
               		   break;
			   case 2: if($line1==1 & $line2==1){
   					      $match=1;
               		   }
               		   break;
			   case 1: if($line1==1){
   					      $match=1;
               		   }
               		   break;
               default: $match=0;
            }

            if($match==1){
			  //we found a match

			  //save matrixid
			  BFQuizController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);

	          if($redirectURL==""){
			  	//no redirect so show resultText
			  	echo $resultText;
			  }else{
			  	//redirect to the url
			  	$msg="";
			  	global $mainframe;
			    $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
   		      }
   			  //don't bother looking at other matrix since we found match
			  $match=1;
			  $z = $n;
            }

		 }// end else exactMatch
	  }

	  if($match==0){  // no match found, so use default for that category
	     //get default ABCD answer matrix for this category
		 $query = "SELECT * FROM ".$matrixtable." where catid=".(int)$catid." and `default`=1";
		 $db->setQuery( $query);
	     $rows = $db->loadObjectList();

	     $redirectURL = $rows[0]->redirectURL;
	     $resultText = $rows[0]->resultText;

 		 //save matrixid
 		 BFQuizController::saveField($resultid,"matrixid",$rows[0]->id,$resulttable);

	     if($redirectURL==""){
		    //no redirect so show resultText
		    echo $resultText;
		 }else{
		    //redirect to the url
		    $msg="";
		    global $mainframe;
		    $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	     }
	  }

   }

   /**
    * This function returns how many times a character appears in a string.
    * 
    * @param string	$searchIn	string to search
    * @param char	$searchFor	character
    * 
    * @return	int	number of times character appears
    */
   function timesFound($searchIn, $searchFor){
      $result = 0;

      for($i = 0; $i < strlen($searchIn); $i++)
      {
         if($searchIn[$i] == $searchFor){
            $result++;
         }
      }

      return $result;
   }

   /**
    * Gets the answer sequence, eg. ACBAD. Used for ABCD answer matrix
    * 
    * @param 	string	$field_name	Field name selected
    * @param 	string	$answer		Answer selected
    * 
    * @return	char	$score		A or B etc.
    */
   function getAnswerSeq($field_name,$answer)
   {
   		   //get answer sequence, eg ACBAD
	       $db =& JFactory::getDBO();
	       global $mainframe;
		   $qntable=$mainframe->getCfg('dbprefix')."bfquiz";

	       $query = "SELECT `id` FROM ".$qntable." where field_name='".$field_name."'";

	       $db->setQuery( $query);
	       $result=$db->loadResult();
	       $id=$result;

	       // get answer
	       $query = "SELECT * FROM ".$qntable." where id=".(int)$id;

	       $db->setQuery( $query);
	       $rows = $db->loadObjectList();

	       $myresult=&$rows[0];
	       $score="";

   		   for ($z=0; $z < 20; $z++){
		     $tempoption="option".($z+1); 
   		   	 $tempscore="score".($z+1);
		     if(trim(strtoupper($answer))==trim(strtoupper($myresult->$tempoption))){
		     	$score=$myresult->$tempscore;
			    $z = 20;
		     }
		   }
	       		   
	        return $score;
	 }


	/**
	 * See which score range matrix matches. Used for score range matrix
	 * 
	 * @param 	string	$field_name		name of the field
	 * @param 	int		$score			score of the quiz
	 * @param 	int		$resultid		id number of the row in the answer table
	 * @param 	string	$resulttable	answer table name
	 */
   function checkscorerange($field_name,$score, $resultid, $resulttable){
      $db =& JFactory::getDBO();

      global $mainframe;
	  $qntable=$mainframe->getCfg('dbprefix')."bfquiz";
	  $scorerangetable=$mainframe->getCfg('dbprefix')."bfquiz_scorerange";

      //get category id
      $query = "SELECT `catid` FROM ".$qntable." where field_name='".$field_name."'";

      $db->setQuery( $query);
	  $result=$db->loadResult();
	  $catid=$result;

	  //get all score ranges matrix for this category
	  $query = "SELECT * FROM ".$scorerangetable." where catid=".(int)$catid."";
	  $db->setQuery( $query);
	  $rows = $db->loadObjectList();

	  //now we need to see if any score range matrix match

	  $n = count($rows);

	  $match=0;
	  for($z=0; $z < $n; $z++){
	     $scoreStart = $rows[$z]->scoreStart;
	     $scoreEnd = $rows[$z]->scoreEnd;
	     $redirectURL = $rows[$z]->redirectURL;
	     $resultText = $rows[$z]->resultText;

		 if($scoreStart == ""){  //no minimum score
		    //is score less than max
		    if($score <= $scoreEnd){
		       //we found a match

			   //save matrixid
			   BFQuizController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
		       $match=1;
		       $z = $n;

			   if($redirectURL==""){
	              //no redirect so show resultText
	              echo $resultText;
	           }else{
		   	      //redirect to the url
	              $msg="";
	              global $mainframe;
			      $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	           }
		    }
		 }

		 if($scoreEnd == ""){  //no maximum score
		    //is score more than minimum
		    if($score >= $scoreStart){
		       //we found a match

			   //save matrixid
			   BFQuizController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
		       $match=1;
		       $z = $n;

			   if($redirectURL==""){
	              //no redirect so show resultText
	              echo $resultText;
	           }else{
		   	      //redirect to the url
	              $msg="";
	              global $mainframe;
			      $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	           }
		    }
		 }

		 //is score between min & max
		 if($score >= $scoreStart & $score <= $scoreEnd){
		    //we found a match

		   //save matrixid
		   BFQuizController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
		   $match=1;
		   $z = $n;

		   if($redirectURL==""){
	           //no redirect so show resultText
	           echo $resultText;
	        }else{
		       //redirect to the url
	           $msg="";
	           global $mainframe;
		       $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	        }
		 }

	  } // end for

	  if($match==0){  // no match found, so use default for that category
	     //get default score range matrix for this category
		 $query = "SELECT * FROM ".$scorerangetable." where catid=".(int)$catid." and `default`=1";
		 $db->setQuery( $query);
		 $rows = $db->loadObjectList();

		 $redirectURL = $rows[0]->redirectURL;
		 $resultText = $rows[0]->resultText;

		 //save matrixid
		 BFQuizController::saveField($resultid,"matrixid",$rows[0]->id,$resulttable);

		 if($redirectURL==""){
		    //no redirect so show resultText
		    echo $resultText;
		 }else{
		    //redirect to the url
		    $msg="";
		    global $mainframe;
		    $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
		 }
	  }
   }

    /**
     * method to display the individual response details, as part of the my quizzes view
     */
	function myresponse()
	{
		JRequest::setVar( 'view', 'response' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * method to display results view
	 */
	function myresults()
	{
		JRequest::setVar( 'view', 'results' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Displays the results of completed quiz for currently logged in user
	* 
	* @param	int	$uid	user id of the current user
	* @return	array
	*/
	function getmyquizzes($uid)
	{
		$db =& JFactory::getDBO();

		//get all quiz category id numbers
		$query = "SELECT id, title FROM `#__categories` WHERE `section`='com_bfquiz'";

		$db->setQuery( $query );
		$rows = $db->loadObjectList();

		$query2 = "";

		$i=0;
		foreach($rows as $row){
		   if($i==0){

		      $query2 .= "SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y') as DateReceived, score, DateCompleted, ".$db->quote( $db->getEscaped( $row->title ), false )." AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken FROM #__bfquiz_".(int)$row->id." WHERE uid=".(int)$uid;
		   }else{
		      $query2 .= " UNION SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y') as DateReceived, score, DateCompleted, ".$db->quote( $db->getEscaped( $row->title ), false )." AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken FROM #__bfquiz_".(int)$row->id." WHERE uid=".(int)$uid;
		   }
		$i++;
		}
		
		$query2 .= " ORDER BY DateCompleted DESC";

		$db->setQuery( $query2);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows2;
	}

	/**
	* displays the response of a completed quiz
	* @param	int	$catid	category id number
	* @param	int	$cid	id number of row we are interested in
	* 
	* @return	array
	*/
	function response($catid,$cid)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT * FROM #__bfquiz_".(int)$catid." where `id`=".(int)$cid."";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
	}

	/**
	 * get the number of children questions associated with this parent question
	 * 
	 * @param 	int 	$pid	parent id
	 * @return	int				number of children
	 */
	function getNumChildren($pid)
	{
	    global $mainframe;
	    $db =& JFactory::getDBO();

		//find out how many children
		$query = 'SELECT COUNT(id) as count'
			. ' FROM #__bfquiz'
			. ' WHERE published AND parent='.(int)$pid
		;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->count;
	}
	
	/**
	 * Get the email template based on the name
	 * 
	 * @param 	string 	$title	Name of the email template
	 * 
	 * @return	array	Data for that email tempalte
	 */
	function getEmailTemplate($title, $catid)
    {
       	$db			=& JFactory::getDBO();
			
		$query = 'SELECT a.*,  cc.title AS category_name'
	  			. ' FROM #__bfquiz_email AS a'
	  			. ' LEFT JOIN #__categories AS cc ON cc.id = a.catid'
				. ' WHERE a.published = 1 AND a.title="'.$title.'" AND a.catid='.(int)$catid
	  			. ' ORDER BY a.title'
	  			;
	  			
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		
		if(!isset($rows)){
			//no email for that category, so just pick the first one
			$query = 'SELECT a.*,  cc.title AS category_name'
	  			. ' FROM #__bfquiz_email AS a'
	  			. ' LEFT JOIN #__categories AS cc ON cc.id = a.catid'
				. ' WHERE a.published = 1 AND a.title="'.$title.'"'
	  			. ' ORDER BY a.title'
	  			;
	  			
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}			
		}

		return $rows;
    }
    
    /**
     * Send the notification email at completion of quiz
     * 
     * @param string	$body			contents of the email
     * @param string	$sendEmailTo	email address to send to
     * @param string	$emailSubject	subject of the email
     */
    function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
       $conf	=& JFactory::getConfig();

       $mailfrom 	= $conf->getValue('config.mailfrom');
	   $fromname 	= $conf->getValue('config.fromname');

	   $emailBody = $body;
       $mode = 1;

       JUtility::sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
    }    
}
?>
