<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php

    global $mainframe;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'a.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";
?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_ID' ); ?>
			</th>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_DESCRIPTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_QNS' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PER_PAGE' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_QNS_IN_EVERY_QUIZ' ); ?>
			</th>			
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TTTLE_ORDER' ); ?>
				<?php
				echo JHTML::_('grid.order',  $this->items );
				?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfquiz&controller=poolitem&task=poolitem&cid[]='. $row->id );

        //$id = JHTML::_('grid.id', ++$i, $row->id);

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->description; ?></a>
			</td>
			<td align="center">
				<?php echo $row->qnsPerQuiz;?>
			</td>
			<td align="center">
				<?php echo $row->qnsPerPage;?>
			</td>
			<td align="center">
				<?php echo $row->mandatoryQns;?>
			</td>			
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php echo $published;?>
			</td>
            <td class="order">

			    <span><?php echo $this->pagination->orderUpIcon($i, true, 'orderupscorerange', 'Move Up', isset($this->items[$i-1]) ); ?></span>
			    <span><?php echo $this->pagination->orderDownIcon($i, $n, true, 'orderdownscorerange', 'Move Down', isset($this->items[$i+1]) ); ?></span>

				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>"<?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="9"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="pool" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />
<input type="hidden" name="controller" value="pool" />
<input type="hidden" name="c" value="pool" />
<input type='hidden' name='view' value='pool' />
<?php echo JHTML::_( 'form.token' ); ?>
</form>

<?php
//Automatic Database Table Builder

global $mainframe;
$database =& JFactory::getDBO();

$mycategory =& bfquizController::getCategoryPool();

$db =& JFactory::getDBO();

if( sizeof( $mycategory ) ) {
    foreach( $mycategory as $mycat  ) {
	    $myid = $mycat->id;
	    $table=$mainframe->getCfg('dbprefix')."bfquiz_".$myid."_pool";

	    $result = $database->getTableList();
	    if (!in_array($table, $result)) {
	       //Table does not exist

	       $myFieldsMissing="";
		   for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		   {
		   		$row = &$this->items[$i];

				if($row->id == $myid){
				   for($z=1; $z < $row->qnsPerQuiz+1; $z++){
				   	  $tempqid = "qid".$z;
				   	  $tempanswer = "answer".$z;
	 			      $myFieldsMissing.= "`".$tempqid."` int(11),";
	 			      $myFieldsMissing.= "`".$tempanswer."` TEXT,";
	 			   }
				}
       		}
	       
	       $query="CREATE TABLE `".$table."` (
  			    `id` int(11) NOT NULL auto_increment,
      			`Name` varchar(150) default NULL,
      			`Email` varchar(150) default NULL,
      			`uid` int(11) NOT NULL default 0,
      			`DateReceived` datetime NOT NULL,
      			`ip` varchar(50) default NULL,
      			`score` int(11) NOT NULL default 0,
      			`matrixid` int(11) NOT NULL default 0,
      			`answerseq` varchar(255) default NULL,
      			`DateCompleted` datetime NOT NULL,
  			    ".$myFieldsMissing."
      			PRIMARY KEY  (`id`)
	    	);";

	       $db->setQuery( $query );
	       if (!$db->query())
	       {
	       	   echo $db->getErrorMsg();
	    	   return false;
	       }
	       //Finished Table creation


	    }else{
	       //Table already exists
			$db =& JFactory::getDBO();
		    // Grab the fields for the selected table
		    $fields =& $db->getTableFields( $table, true );
		    
		    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		    {
		    	$query="";
	   			$row = &$this->items[$i];

				if($row->id == $myid){
			   		//how many fields should there be?
			   		$numfields=($row->qnsPerQuiz * 2)+10;
			   		if(sizeof( $fields[$table] ) < $numfields){
			      		$numbermissing=($numfields-sizeof( $fields[$table] ))/2;
			   			for($z=($row->qnsPerQuiz+1)-$numbermissing; $z < $row->qnsPerQuiz+1; $z++){
			   				if($z==($row->qnsPerQuiz+1)-$numbermissing){ //first one
			   					$query="ALTER TABLE `".$table."`";
			   				}
			   	  			$tempqid = "qid".$z;
			   	  			$tempanswer = "answer".$z;
			   	  			if($z==$row->qnsPerQuiz){ //last one
			   	  			   $query.= "ADD `".$tempqid."` int(11),";
			      			   $query.= "ADD `".$tempanswer."` TEXT;";
			   	  			}else{
			      			   $query.= "ADD `".$tempqid."` int(11),";
			      			   $query.= "ADD `".$tempanswer."` TEXT,";
			   	  			}
			   			}
			   		}
				}	 
				
				if($query != ""){
					$db->setQuery( $query );
	  	       		if (!$db->query())
	  	       		{
	  	       			echo $db->getErrorMsg();
		  	  	   		return false;
		       		}		
				}
		    }
	    }		   
   }

}

?>