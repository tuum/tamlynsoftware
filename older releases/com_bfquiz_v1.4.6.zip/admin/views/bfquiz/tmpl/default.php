<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
 */
    global $mainframe, $option;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'b.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";

	$context="";
	$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
	$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
	$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_state		= $mainframe->getUserStateFromRequest( $option.'filter_state',		'filter_state',		'',			'word' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm.submit();"';
	$lists['catid'] = JHTML::_('list.category',  'filter_catid', 'com_bfquiz', (int) $filter_catid, $javascript );

	// state filter
	$lists['state']	= JHTML::_('grid.state',  $filter_state );
	
	// table ordering
	$lists['order_Dir']	= $filter_order_Dir;
	$lists['order']		= $filter_order;
?>

<form action="index.php" method="post" name="adminForm">
<table>
<tr>
<td align="left" width="100%">
		&nbsp;
	</td>
	<td nowrap="nowrap">
		<?php
		echo $lists['catid'];
		echo $lists['state'];
		?>
	</td>
</tr>
</table>
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'ID' ); ?>
			</th>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_QUESTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_TYPE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_NEXT_QUESTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_DB_FIELD_NAME' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_SCORE_CATEGORY' ); ?>
			</th>			
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>
			</th>
			<th width="5%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_MANDATORY' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TTTLE_ORDER' ); ?>
				<?php
				echo JHTML::_('grid.order',  $this->items );
				?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfquiz&controller=question&task=edit&cid[]='. $row->id );

        //$id = JHTML::_('grid.id', ++$i, $row->id);

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->question; ?></a>
			</td>
			<td>
				<?php echo bfquizHelper::ShowQuestionType( $row->question_type ); ?>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php
				    for($z=1; $z < 20; $z++){
				       $tempname = "next_question".$z;
				       if($row->$tempname <> 0){
				          echo $row->$tempname;
				          echo " ";
				       }
				    }
				?>
			</td>
			<td>
				<?php echo $row->field_name; ?>
				<?php if(!isset($myFields[$row->catid])){
				   $myFields[$row->catid] = "";
				}
				?>
				<?php $myFields[$row->catid].= "`".$row->field_name."` varchar($row->fieldSize) default NULL,";	?>
			</td>
			<td align="center">
				<?php echo bfquizHelper::ShowScoreCategory( $row->scorecatid ); ?>
			</td>			
			<td align="center">
				<?php echo $published;?>
			</td>
			<td align="center">
				<?php
					if($row->mandatory){ 
						echo "<img src='./components/com_bfquiz/images/mandatory.gif' width='12'>";
					}
				?>
			</td>
            <td class="order">
			    <span><?php echo $this->pagination->orderUpIcon($i, true, 'orderup', 'Move Up', isset($this->items[$i-1]) ); ?></span>
			    <span><?php echo $this->pagination->orderDownIcon($i, $n, true, 'orderdown', 'Move Down', isset($this->items[$i+1]) ); ?></span>

				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="11"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>


</form>

<?php

//Automatic Database Table Builder

global $mainframe;
$database =& JFactory::getDBO();

$mycategory =& bfquizController::getCategory();

$db =& JFactory::getDBO();

if( sizeof( $mycategory ) ) {
	foreach( $mycategory as $mycat  ) {
		$myid = $mycat->id;
	    $table=$mainframe->getCfg('dbprefix')."bfquiz_".$myid;

	    $result = $database->getTableList();
	    if (!in_array($mainframe->getCfg('dbprefix')."bfquiz_".$myid, $result)) {
	       //Table does not exist

           $myFieldsMissing="";
		   for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		   {
		    	$found=0;
		   		$row = &$this->items[$i];

				if($row->catid == $myid){
				   if($row->question_type == 9){ //rating
			        	// don't add field for rating question
			       }else{
	 			      $myFieldsMissing.= "`".$row->field_name."` TEXT,";
	 			   }
				}
       		}


	       $query="CREATE TABLE `".$table."` (
  			    `id` int(11) NOT NULL auto_increment,
      			`Name` varchar(150) default NULL,
      			`Email` varchar(150) default NULL,
      			`uid` int(11) NOT NULL default 0,
      			`DateReceived` datetime NOT NULL,
      			`ip` varchar(50) default NULL,
      			`score` int(11) NOT NULL default 0,
      			`matrixid` int(11) NOT NULL default 0,
      			`answerseq` varchar(255) default NULL,
      			`DateCompleted` datetime NOT NULL,
  			    ".$myFieldsMissing."
      			PRIMARY KEY  (`id`)
	    	);";

	       $db->setQuery( $query );
	       if (!$db->query())
	       {
	       	   echo $db->getErrorMsg();
	    	   return false;
	       }
	       //Finished Table creation


	    }else{
	       //Table already exists

		    $db =& JFactory::getDBO();
		    // Grab the fields for the selected table
		    $fields =& $db->getTableFields( $table, true );
		    if( sizeof( $fields[$table] ) ) {
		       // We found some fields so let's create the HTML list
		       $options = array();
		       foreach( $fields[$table] as $field => $type ) {
			           $options[] = JHTML::_( 'select.option', $field, $field );
		       }
		       
		       //what type of field, eg VARCHAR, INT, DATETIME etc.
			   $fieldType=array();
		       foreach( $fields[$table] as $field ) {
			      $fieldType[] = $field;
		       }
		    }

			for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	 		{
 		    	$found=0;
			    $row = &$this->items[$i];
			    $myindex=0;
			    foreach( $fields[$table] as $field => $type ){ 
		           if ($row->field_name == $field) {
			          $found=1;
			   	   }
			   	   
			       if($found==0){
			   	      $myindex++;
			   	   }
			    }
			    
	    	    if($found == 1){
			        if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type==""){
			           //do nothing
			        }else{
			           $mytype = $row->field_type;
			           if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
			              $mytype = "".$row->field_type."(".$row->fieldSize.")";
			           }
			           $query="ALTER TABLE `".$table."` CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
		  	    	   $db->setQuery( $query );
		  	       	   if (!$db->query())
		  	       	   {
		  	       	      echo $db->getErrorMsg();
		  	    	      return false;
		  	       	   }
			        }
			    }			    


	 		    if($found == 0 & $row->catid == $myid){
			      $query="ALTER TABLE `".$table."`
		    			    ADD `".$row->field_name."` TEXT
  	  	    	  ;";

		  	       $db->setQuery( $query );
		  	       if (!$db->query())
		  	       {
		  	       	   echo $db->getErrorMsg();
		  	    	   return false;
		  	       }
			    }

				// now check if new field exists
			    $found=0;
			    foreach( $fields[$table] as $field => $type ) {
				    if ($field == "uid") {
		       		   	$found=1;
	  	   			}
	  			}
				if($found == 0){
					$query="ALTER TABLE `".$table."`
		    			   ADD `uid` int(11) NOT NULL default 0,
						   ADD `score` int(11) NOT NULL default 0,
						   ADD `matrixid` int(11) NOT NULL default 0,
      					   ADD `answerseq` varchar(255) default NULL
  	  	    	   ;";

		  	       $db->setQuery( $query );
		  	       if (!$db->query())
		  	       {
		  	       	   echo $db->getErrorMsg();
		  	    	   return false;
		  	       }
			    }
			    
	 			// now check if DateCompleted field exists
			    $found=0;
			    foreach( $fields[$table] as $field => $type ) {
				    if ($field == "DateCompleted") {
		       		   	$found=1;
	  	   			}
	  			}
				if($found == 0){
					$query="ALTER TABLE `".$table."`
		    			   ADD `DateCompleted` datetime NOT NULL
  	  	    	   ;";

		  	       $db->setQuery( $query );
		  	       if (!$db->query())
		  	       {
		  	       	   echo $db->getErrorMsg();
		  	    	   return false;
		  	       }
			    }
	    	}
	    }			   
	}
}
?>