<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php 
/*
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>

<?php

    global $mainframe;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'a.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";

	$context="";
	$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
	$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
	$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',			'word' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm.submit();"';
	$lists['catid'] = JHTML::_('list.category',  'filter_catid', 'com_bfquiz', (int) $filter_catid, $javascript );

	// table ordering
	$lists['order_Dir']	= $filter_order_Dir;
	$lists['order']		= $filter_order;

	$function = JRequest::getVar('function', 'jSelectQuestion');
?>

<form action="index.php" method="post" name="adminForm">
<table>
<tr>
	<td nowrap="nowrap">
		<?php
		echo $lists['catid'];
		?>
	</td>
</tr>
</table>
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_ID' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_QUESTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_TYPE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_NEXT_QUESTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_DB_FIELD_NAME' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );

        //$id = JHTML::_('grid.id', ++$i, $row->id);

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<a style="cursor: pointer;" onclick="window.parent.jSelectQuestion('<?php echo $row->id; ?>', '<?php echo str_replace(array("'", "\""), array("\\'", ""),$row->question); ?>', '<?php echo JRequest::getVar('object'); ?>');">
				<?php echo htmlspecialchars($row->question, ENT_QUOTES, 'UTF-8'); ?></a>
			</td>

			<td>
				<?php echo bfquizHelper::ShowQuestionType( $row->question_type ); ?>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php
				    for($z=1; $z < 20; $z++){
				       $tempname = "next_question".$z;
				       if($row->$tempname <> 0){
				          echo $row->$tempname;
				          echo " ";
				       }
				    }
				?>
			</td>
			<td>
				<?php echo $row->field_name; ?>
				<?php if(!isset($myFields[$row->catid])){
				   $myFields[$row->catid] = "";
				}
				?>
				<?php $myFields[$row->catid].= "`".$row->field_name."` varchar($row->fieldSize) default NULL,";	?>
			</td>
			<td align="center">
				<?php echo $published;?>
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="9"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="listquestions" />
<input type="hidden" name="tmpl" value="component" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>


</form>
