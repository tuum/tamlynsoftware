<?php 
/**
 * $Id: form.php 2 2011-11-15 04:37:51Z tuum $
 * Email Item view for BF Quiz Component
 *
  * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php defined('_JEXEC') or die('Restricted access'); ?>

		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.title.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_ENTER_EMAIL_TYPE', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_SELECT_CATEGORY', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_EMAIL_ITEM_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Category::This is the category that your item will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_EMAIL_TYPE' ); ?>: *
				</label>
			</td>
			<td>
			    <?php echo bfquizHelper::emailType( $this->bfquiz->title ); ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="subject">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_SUBJECT' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfquiz->subject)){
			          $this->bfquiz->subject="";
			       }
			    ?>
			    <input class="text_area" type="text" name="subject" id="subject" size="60" maxlength="250" value="<?php echo $this->bfquiz->subject;?>"/>
			</td>
		</tr>		
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->published)){
			          $this->bfquiz->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfquiz->published ); ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="description">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_EMAIL_BODY' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title='Description::This is the description of the item. This field can contain HTML.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfquiz->description)){
			          $this->bfquiz->description = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'description',  $this->bfquiz->description, '500', '300', '60', '40', array()) ; ?>
			</td>
		</tr>
	</table>

	<?php
	if(!isset($this->bfquiz->ordering)){
		$this->bfquiz->ordering="";
	}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfquiz->ordering;?>" />

	</fieldset>
</div>

<div class="col width-35">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_OPTIONS' ); ?></legend>

		<table class="admintable">
		<tr>
		   <td valign="top" align="right" class="key">
		      <?php echo JText::_( 'COM_BFQUIZ_TITLE_SHOW_QUESTIONS' ); ?>
		   </td>
		   <td>
			   	<?php
				if(!isset($this->bfquiz->showQuestions)){
					$this->bfquiz->showQuestions=0;
				}
				?>
				<label name="showQuestions_1" id="showQuestions_1"><?php echo JHTML::_( 'select.booleanlist',  'showQuestions', 'class="inputbox"', $this->bfquiz->showQuestions ); ?></label>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Show Questions::Do you want to include the questions with responses in the email?">	
			</td>		   
		</tr>	
		<tr>
			<td valign="top" align="right" class="key">	
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_SHOW_INCORRECT' ); ?>
			</td>
			<td>
				<?php
				if(!isset($this->bfquiz->showIncorrect)){
					$this->bfquiz->showIncorrect=0;
				}
				?>
				<label name="showIncorrect_1" id="showIncorrect_1"><?php echo JHTML::_( 'select.booleanlist',  'showIncorrect', 'class="inputbox"', $this->bfquiz->showIncorrect ); ?></label>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Show Incorrect::Do you want to indicate which answers are incorrect and show solutions in the email?">		
			</td>			
		</tr>
		</table>
	</fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_HELP' ); ?></legend>

		<table class="admintable">
		<tr>
		   <td colspan=2>
		      <?php echo JText::_( 'COM_BFQUIZ_HELP_FIELDS_REPLACED' ); ?>
		   </td>
		</tr>	
		<tr>
			<td valign="top" align="right" class="key">
				{score}		
			</td>
			<td>	
				<?php echo JText::_( 'COM_BFQUIZ_HELP_SCORE' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{maxscore}		
			</td>
			<td>	
				<?php echo JText::_( 'COM_BFQUIZ_HELP_MAXSCORE' ); ?>
			</td>
		</tr>		
		<tr>
			<td valign="top" align="right" class="key">		
				{category}
			</td>
			<td>			
				<?php echo JText::_( 'COM_BFQUIZ_HELP_CATEGORY' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{name}
			</td>
			<td>	
				<?php echo JText::_( 'COM_BFQUIZ_HELP_NAME' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{email}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFQUIZ_HELP_EMAIL' ); ?>
			</td>
		</tr>
		</table>
		
	</fieldset>	
</div>		

<div class="clr"></div>

<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="id" value="<?php echo $this->bfquiz->id; ?>" />
<input type="hidden" name="task" value="saveemailitem" />
<input type="hidden" name="controller" value="emailitem" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>