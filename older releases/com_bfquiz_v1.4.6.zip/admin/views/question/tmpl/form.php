<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: form.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
	<?php
	if(!isset($this->bfquiz->validation_type)){
		$this->bfquiz->validation_type = "required";
	}
	?>

		<script language="javascript" type="text/javascript">
		<!--
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.question.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_ENTER_QUESTION', true ); ?>" );
			} else if ( getSelectedValue('adminForm','question_type') == 1 & form.option1.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_FOR_RADIO', true ); ?>" );
			} else if (form.field_name.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_ENTER_FIELD_NAME', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_SELECT_CATEGORY', true ); ?>" );
			} else if(document.getElementById("field_name").value.match(" ") != null){  //can't have spaces in field names
		       alert("<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_FEILD_NAME', true ); ?>");
			} else if(document.getElementById("field_name").value.match("-") != null){  //can't have minus in field names
		       alert("<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_FEILD_NAME_MINUS', true ); ?>");
			} else {
				submitform( pressbutton );
			}
		}


		function showOptions(){
			  var i=0;
			  for (i=1;i<21;i++){
		         document.getElementById("option"+i).style.display = '';
		         document.getElementById("optionText"+i).style.display = '';
		         document.getElementById("next_question"+i).style.display = '';
		         document.getElementById("score"+i).style.display = '';
		         document.getElementById("answer"+i).style.display = '';
		      }
		}

		function hideAllOptions(){
		   var i=0;
		   for (i=1;i<21;i++){
	          document.getElementById("option"+i).style.display = 'none';
	          document.getElementById("optionText"+i).style.display = 'none';
	          if(i>1){
	             document.getElementById("next_question"+i).style.display = 'none';
	             document.getElementById("score"+i).style.display = 'none';
		         document.getElementById("answer"+i).style.display = 'none';
	          }
	       }
		}


		function hideBranching(){
   		var i=0;
		   for (i=1;i<21;i++){
	          if(i>1){
	             document.getElementById("next_question"+i).style.display = 'none';
	          }
	       }
		}

		function hideType(){
		    document.getElementById("next_question1").style.display = '';
		    document.getElementById("horizontal_values").style.display = 'none';
 		    document.getElementById("horizontalText").style.display = 'none';
 		    document.getElementById("field_size").style.display = 'none';
 		    document.getElementById("fieldSize").style.display = 'none';

		    if(document.getElementById("question_type").value == 0){  //text
			   hideAllOptions();
			   document.getElementById("option1").style.display = '';
	           document.getElementById("optionText1").style.display = '';
		       document.getElementById("mandatory_1").style.display = '';
 		       document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("field_size").style.display = '';
 		       document.getElementById("fieldSize").style.display = '';
		    }else if(document.getElementById("question_type").value == 1){  //radio
			   document.getElementById("mandatory_1").style.display = '';
		       document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("horizontal_values").style.display = '';
 		       document.getElementById("horizontalText").style.display = '';
		       showOptions();
		    }else if(document.getElementById("question_type").value == 3){  //textarea
			   hideAllOptions();
			   document.getElementById("option1").style.display = '';
	           document.getElementById("optionText1").style.display = '';
		       document.getElementById("mandatory_1").style.display = '';
 		       document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("field_size").style.display = '';
 		       document.getElementById("fieldSize").style.display = '';
		    }
		}

		var checkbox_array = new Array('required validate-checkbox','required validate-checkbox2','required validate-checkbox3','required validate-checkbox4','required validate-checkbox5','required validate-checkbox6','required validate-checkbox7','required validate-checkbox8','required validate-checkbox9','required validate-checkbox10');
		var text_array = new Array('required','required validate-numeric','required validate-email');

		function updateValidation(){
			   //get var from php
			   var validation_type = "<?php echo $this->bfquiz->validation_type ?>";
			   
			   var sda = document.getElementById('validation_type');
			   var len = sda.length;
	   		   if(document.getElementById("question_type").value == 2){  //checkbox
	   			  //remove all options first
	   			  sda.options.length=0;

				  var len2 = checkbox_array.length;
				  for(var i=0; i<len2; i++)
				  {
		          	//now add validate-checkbox
				  	var y=document.createElement('option');
				  	y.text=checkbox_array[i];
	 			  	y.value=checkbox_array[i];
	 			  	if(checkbox_array[i] == validation_type){
	  			  	   y.selected = true;
	  			  	}
				  	try
				  	{
				  	  sda.add(y,null);}
				  	  catch(ex){
				  	  sda.add(y);
				  	}
				  }

				  sda.setAttribute("value", checkbox_array[0]);

		       }else if(document.getElementById("question_type").value == 0){  //text
				  //remove all options first
	   			  sda.options.length=0;

				  var len2 = text_array.length;
				  for(var i=0; i<len2; i++)
				  {
		          	//now add validate options
				  	var y=document.createElement('option');
				  	y.text=text_array[i];
	 			  	y.value=text_array[i];
	 			  	if(text_array[i] == validation_type){
	 				   y.selected = true;
	  			  	}
				  	try
				  	{
				  	  sda.add(y,null);}
				  	  catch(ex){
				  	  sda.add(y);
				  	}
				  }

				  sda.setAttribute("value", text_array[0]);
		       }else{
		          //default validation types
				  //remove all options first
	   			  sda.options.length=0;

				  //now add validate options
				  var y=document.createElement('option');
				  y.text="default";
	 			  y.value="default";
				  try
				  {
				    sda.add(y,null);}
				    catch(ex){
				    sda.add(y);
				  }
		       }
			}		
		
		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Category::This is the quiz that your question will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_QUESTION' ); ?>: *
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="question" id="question" size="60" maxlength="250" value="<?php echo $this->bfquiz->question;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<label name="suppressText" id="suppressText"><?php echo JText::_( 'COM_BFQUIZ_TITLE_SUPPRESS_QUESTION' ); ?>:</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->suppressQuestion)){
			          $this->bfquiz->suppressQuestion = 0;
			       }
			    ?>
				<label name="suppressQuestion_1" id="suppressQuestion_1"><?php echo JHTML::_( 'select.booleanlist',  'suppressQuestion', 'class="inputbox"', $this->bfquiz->suppressQuestion ); ?></label>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Suppress Question::This will hide the question, so you only see the options.">
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->published)){
			          $this->bfquiz->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfquiz->published ); ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="helpText">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_HELP_TEXT' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title='Help text::This appears between the question and the options. It can contain HTML, and supports Allvideos tags eg. {youtube}Xr2mhMHhUMY{/youtube}.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfquiz->helpText)){
			          $this->bfquiz->helpText = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'helpText',  $this->bfquiz->helpText, '500', '300', '60', '40', array()) ; ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="field_name">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_DB_FIELD_NAME' ); ?>: *
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->field_name)){
			          $this->bfquiz->field_name = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="field_name" id="field_name" size="30" value="<?php echo $this->bfquiz->field_name;?>"/>
			    &nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Field Name::This is the name of the field in the mySQL table used to store reponses to this quiz. Field name cannot use reserved words such as 'like' or 'where', must be unique, and must not contain spaces, dashes, slashes or any other special characters.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="field_type">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_DB_FIELD_TYPE' ); ?>: *
				</label>
			</td>
			<td>
			    <?php echo bfquizHelper::FieldType( $this->bfquiz->field_type );  ?>
			    &nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Field Type::This is the data type of the mySQL field used to store responses to this question. If you are not sure, just use VARCHAR.">
			</td>
		</tr>		
		<tr>
			<td class="key">
				<label for="field_size" id="field_size">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_MAX_ANSWER_LENGTH' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->fieldSize)){
			          $this->bfquiz->fieldSize = 255;
			       }
			    ?>
			    <input class="inputbox" type="text" name="fieldSize" id="fieldSize" maxlength="5" size="30" value="<?php echo $this->bfquiz->fieldSize;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="question_type">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_TYPE' ); ?>:
				</label>
			</td>
			<td>
				<?php echo bfquizHelper::QuestionType( $this->bfquiz->question_type ); ?>
			</td>
		</tr>
		<tr>
		   <td width="100" class="key">
		      <label name="horizontalText" id="horizontalText"><?php echo JText::_('COM_BFQUIZ_TITLE_HORIZONTAL'); ?></label>
		   </td>
		   <td>
		      <?php
		         if(!isset($this->bfquiz->horizontal)){
		            $this->bfquiz->horizontal = 0;
		         }
		      ?>
		      <div id="horizontal_values">
		      <label name="horizontal_1" id="horizontal_1"><?php echo JHTML::_( 'select.booleanlist',  'horizontal', 'class="inputbox"', $this->bfquiz->horizontal ); ?></label>
		      &nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Horizontal::To display radio or checkbox options all on one line.">
		      </div>
		   </td>
		</tr>
		<tr>
			<td width="100" class="key">
				<label name="mandatoryText" id="mandatoryText"><?php echo JText::_( 'COM_BFQUIZ_TITLE_MANDATORY' ); ?>: *</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->mandatory)){
			          $this->bfquiz->mandatory = 0;
			       }
			    ?>
				<label name="mandatory_1" id="mandatory_1"><?php echo JHTML::_( 'select.booleanlist',  'mandatory', 'class="inputbox"', $this->bfquiz->mandatory ); ?></label>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Mandatory::For radio & checkbox, you must install and publish BF Validate plugin.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="validation_type">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_VALIDATION_TYPE' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			    if($this->bfquiz->question_type == 2){  //checkbox
			       echo bfquizHelper::ValidationTypeCheckbox( $this->bfquiz->validation_type );
			    }else{
			       echo bfquizHelper::ValidationType( $this->bfquiz->validation_type );
			    }
			    ?>

			    &nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Validation Type::This is the validation type for this question.">
			</td>
		</tr>		
		<tr>
			<td class="key" align="right" valign="top">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PARENT_ITEM' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->parent)){
			          $this->bfquiz->parent = 0;
			       }
			    ?>
				<?php echo bfquizHelper::Parent( $this->bfquiz ); ?>
			</td>
		</tr>
		<tr>
		   <td class="key" colspan=2>
		   &nbsp;
		   </td>
		</tr>
		<tr>
			<td class="key">
				<label for="solutionText">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_SOLUTION' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title='Solution/Answer::Explaination shown after quiz to explain correct answer.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfquiz->solution)){
			          $this->bfquiz->solution = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'solution',  $this->bfquiz->solution, '500', '300', '60', '40', array()) ; ?>
			</td>
		</tr>
	</table>

	<?php
	if(!isset($this->bfquiz->ordering)){
		$this->bfquiz->ordering = "";
	}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfquiz->ordering;?>" />

	</fieldset>
</div>
<div class="col width-35">
	<fieldset class="adminform">
	<legend><?php echo JText::_( 'Options' ); ?></legend>
	<table class="admintable">
		<tr>
		    <td>
		    </td>
		    <td>
		    </td>
		    <td>
		       <strong><?php echo JText::_('COM_BFQUIZ_TITLE_ANSWER'); ?></strong>
		    </td>
		    <td>
			   <strong><?php echo JText::_('COM_BFQUIZ_TITLE_SCORE'); ?></strong>
		    </td>
		    <td><strong><?php echo JText::_('COM_BFQUIZ_TITLE_NEXT_QUESTION_ID'); ?></strong>
		    </td>
		</tr>

		<tr>
		    <td>
		    </td>
		    <td>
		    </td>
		    <td>
		       <center>
		       <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Answer?::Tick correct answer(s) to this question.">
		       </center>
		    </td>
		    <td>
		       <center>
			   <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Score::Indicate score for selecting this option.">
			   </center>
		    </td>
		    <td>
		       <center>
		       <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Next Qn ID::Conditional branching that allows you to go to specific question if that option is selected as answer. Enter question's id number.">
		       </center>
		    </td>
		</tr>


		<?php for ($i=0, $n=20; $i < $n; $i++ ) { ?>
		<tr>
			<td width="100" class="key">
				<label name="optionText<?php echo ($i+1); ?>" id="optionText<?php echo ($i+1); ?>"><?php echo JText::_( 'Option' ); ?> <?php echo ($i+1); ?></label>
			</td>
			<td>
			    <?php $tempvalue="option".($i+1); ?>
			    <?php
			       if(!isset($this->bfquiz->$tempvalue)){
			          $this->bfquiz->$tempvalue = "";
			       }
			    ?>
				<input class="text_area" type="text" name="option<?php echo ($i+1); ?>" id="option<?php echo ($i+1); ?>" size="32" maxlength="150" value="<?php echo $this->bfquiz->$tempvalue;?>" />
			</td>

			<td>
			   <center>
			   <?php $tempnext="answer".($i+1); ?>
			   <?php
			      if(!isset($this->bfquiz->$tempnext)){
			         $this->bfquiz->$tempnext = 0;
			      }

			      if ($this->bfquiz->$tempnext==1) {
			   ?>
 	      	      <input type="checkbox" name="answer<?php echo ($i+1); ?>" value=1 id="answer<?php echo ($i+1); ?>" checked="checked" />
 	      	   <?php
	       	   }else {
	       	   ?>
	      		  <input type="checkbox" name="answer<?php echo ($i+1); ?>" id="answer<?php echo ($i+1); ?>" value=1 />
	      	   <?php
		       }
			   ?>

			   </center>
			</td>

			<td>
			   <?php $tempnext="score".($i+1); ?>
			   <?php
			      if(!isset($this->bfquiz->$tempnext)){
			         $this->bfquiz->$tempnext = 0;
			      }
			   ?>
				<input class="text_area" type="text" name="score<?php echo ($i+1); ?>" id="score<?php echo ($i+1); ?>" size="3" maxlength="10" value="<?php echo $this->bfquiz->$tempnext;?>" />
			</td>

			<td>
			   <center>
			   <?php $tempnext="next_question".($i+1); ?>
			   <?php
			      if(!isset($this->bfquiz->$tempnext)){
			         $this->bfquiz->$tempnext = "";
			      }
			   ?>
				<input class="text_area" type="text" name="next_question<?php echo ($i+1); ?>" id="next_question<?php echo ($i+1); ?>" size="3" maxlength="150" value="<?php echo $this->bfquiz->$tempnext;?>" />
				</center>
			</td>
		</tr>
		<?php } ?>

	</table>
	<table class="admintable">
	<tr>
	   <td width="100" class="key">
	      <label name="prefixText" id="prefixText"><?php echo JText::_('COM_BFQUIZ_TITLE_OPTION_PREFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfquiz->prefix)){
	            $this->bfquiz->prefix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="prefix" id="prefix" size="20" value="<?php echo $this->bfquiz->prefix;?>" />
	   </td>
	</tr>
	<tr>
	   <td width="100" class="key">
	      <label name="suffixText" id="suffixText"><?php echo JText::_('COM_BFQUIZ_TITLE_OPTION_SUFFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfquiz->suffix)){
	            $this->bfquiz->suffix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="suffix" id="suffix" size="20" value="<?php echo $this->bfquiz->suffix;?>" />
	   </td>
	</tr>
	<tr>
		<td class="key">
			<label for="field_type">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_SCORE_CATEGORY' ); ?>:
			</label>
		</td>
		<td>
		    <?php echo bfquizHelper::ScoreCategory( $this->bfquiz->scorecatid );  ?>
		    &nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Score Category::Allows questions to be grouped together for scoring">
		</td>
	</tr>	
	</table>
	</fieldset>


</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="id" value="<?php echo $this->bfquiz->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="question" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>


<script language="javascript" type="text/javascript">
<!--
hideType();
//-->
</script>