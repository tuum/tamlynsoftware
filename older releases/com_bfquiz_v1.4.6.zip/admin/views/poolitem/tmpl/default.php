<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
*
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.description.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_ENTER_DESCRIPTION', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_SELECT_CATEGORY', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-45">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Category::This is the quiz category that your answer matrix applies to.">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_DESCRIPTION' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfquiz->description)){
			          $this->bfquiz->description="";
			       }
			    ?>
				<input class="text_area" type="text" name="description" id="description" size="60" maxlength="250" value="<?php echo $this->bfquiz->description;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->published)){
			          $this->bfquiz->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfquiz->published ); ?>
			</td>
		</tr>
	</table>

	<?php
		if(!isset($this->bfquiz->ordering)){
			$this->bfquiz->ordering="";
		}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfquiz->ordering;?>" />

	</fieldset>

</div>
<div class="col width-45">
	<fieldset class="adminform">
	<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_CONDITIONS' ); ?></legend>
	
	    <?php
		$js = "
		function jSelectQuestion(id, title, catid, object) {
		 	aid = document.getElementById('mandatoryQns');
		 	if (aid.value !='') aid.value += ',';
			aid.value += id;
			SqueezeBox.close();
		}";
		/*
		 * CSS for article button
		 */
		$css = "
		}";
		$doc =& JFactory::getDocument();
		$doc->addScriptDeclaration($js);
		$doc->addStyleDeclaration($css);

		$link = 'administrator/index.php?option=com_bfquiz&task=listquestions&tmpl=component';
	    ?>
	    
		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="qnsPerQuiz">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_QNS_PER_QUIZ' ); ?>
				</label>
			</td>
			<td>
				<?php
				if(!isset($this->bfquiz->qnsPerQuiz)){
					$this->bfquiz->qnsPerQuiz=0;
				}
				?>
				<input class="text_area" type="text" name="qnsPerQuiz" id="qnsPerQuiz" size="3" maxlength="3" value="<?php echo $this->bfquiz->qnsPerQuiz;?>"/>
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label for="qnsPerPage">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_QNS_PER_PAGE' ); ?>
				</label>
			</td>
			<td>
				<?php
				if(!isset($this->bfquiz->qnsPerPage)){
					$this->bfquiz->qnsPerPage=0;
				}
				?>
				<input class="text_area" type="text" name="qnsPerPage" id="qnsPerPage" size="3" maxlength="3" value="<?php echo $this->bfquiz->qnsPerPage;?>"/>
			</td>
		</tr>

		<tr>
			<td width="300" class="key">
				<label for="article_ids">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_QN_IDS_IN_EVERY_QUIZ' ); ?>:
				</label>
			</td>
			<td>
				<?php
				if(!isset($this->bfquiz->mandatoryQns)){
					$this->bfquiz->mandatoryQns="";
				}
				?>
				<?php JHTML::_('behavior.modal'); ?>
				<input class="inputbox" type="text" id="mandatoryQns" name="mandatoryQns" value="<?php echo $this->bfquiz->mandatoryQns;?>" size="80">
<a class="modal" title="<?php echo JText::_("COM_BFQUIZ_TITLE_ADD_QUESTION");?>" href="<?php echo JUri::root().$link;?>" rel="{handler: 'iframe', size: {x: 770, y: 400}}"><img src="components/com_bfquiz/images/b_browse.png"/></a>			</td>
			</td>
		</tr>	

		<tr>
			<td width="100" align="right" class="key">
				<label for="mandatoryPos">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_POSITION_OF_QUESTIONS' ); ?>
				</label>
			</td>
			<td>
				<?php echo bfquizHelper::mandatoryPosition( $this->bfquiz->mandatoryPos ); ?>
			</td>
		</tr>

	</table>
	
	</fieldset>

</div>

<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="id" value="<?php echo $this->bfquiz->id; ?>" />
<input type="hidden" name="task" value="savepoolitem" />
<input type="hidden" name="controller" value="poolitem" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>