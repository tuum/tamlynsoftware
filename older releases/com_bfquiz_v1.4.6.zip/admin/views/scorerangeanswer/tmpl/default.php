<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.description.value == "") {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_ENTER_DESCRIPTION', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFQUIZ_VALIDATION_ALERT_SELECT_CATEGORY', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-45">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Category::This is the quiz category that your answer matrix applies to.">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_DESCRIPTION' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfquiz->description)){
			          $this->bfquiz->description="";
			       }
			    ?>
				<input class="text_area" type="text" name="description" id="description" size="60" maxlength="250" value="<?php echo $this->bfquiz->description;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFQUIZ_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfquiz->published)){
			          $this->bfquiz->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfquiz->published ); ?>
			</td>
		</tr>
	</table>

	<?php
		if(!isset($this->bfquiz->ordering)){
			$this->bfquiz->ordering=0;
		}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfquiz->ordering;?>" />

	</fieldset>

</div>
<div class="col width-45">
	<fieldset class="adminform">
	<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_CONDITIONS' ); ?></legend>
	<table class="admintable" align="center">
	   <tr>
	      <td><?php echo JText::_( 'COM_BFQUIZ_TITLE_SCORE_RANGE' ); ?> <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title='Score Range::Numeric values, eg 10 to 20'>
	      </td>
	      <td>
	      	<?php
			if(!isset($this->bfquiz->scoreStart)){
				$this->bfquiz->scoreStart=0;
			}
			?>
	      <input class="text_area" type="text" name="scoreStart" id="scoreStart" size="3" maxlength="10" value="<?php echo $this->bfquiz->scoreStart;?>" />
	      </td>
	      <td><?php echo JText::_( 'COM_BFQUIZ_TITLE_TO' ); ?>
	      </td>
	      <td>
	      	<?php
			if(!isset($this->bfquiz->scoreEnd)){
				$this->bfquiz->scoreEnd=0;
			}
			?>
	      <input class="text_area" type="text" name="scoreEnd" id="scoreEnd" size="3" maxlength="10" value="<?php echo $this->bfquiz->scoreEnd;?>" />
	      </td>
	   </tr>
	</table>

	</fieldset>

	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_RESULT' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
			    <img src="./components/com_bfquiz/images/con_info.png" class="hasTip" title="Redirect URL::This is the page that you will be redirected to if criteria match. Should be left blank if using Results Text below.">
			    &nbsp;
				<label for="title">
					<?php echo JText::_( 'COM_BFQUIZ_TITLE_REDIRECT_URL' ); ?>:
				</label>
			</td>
			<td>
	      		<?php
				if(!isset($this->bfquiz->redirectURL)){
					$this->bfquiz->redirectURL="";
				}
				?>			
				<input class="text_area" type="text" name="redirectURL" id="redirectURL" size="60" maxlength="250" value="<?php echo $this->bfquiz->redirectURL;?>"/>
			</td>
		</tr>
		</table>

	</fieldset>


</div>
<div class="clr"></div>

<?php $editor = JFactory::getEditor(); ?>
<fieldset class="adminform">
<legend><?php echo JText::_( 'COM_BFQUIZ_TITLE_RESULT_TEXT' ); ?></legend>
<center>
	<?php
	if(!isset($this->bfquiz->resultText)){
		$this->bfquiz->resultText="";
	}
	?>	
	<?php echo $editor->display( 'resultText',  $this->bfquiz->resultText, '800', '400', '60', '40', array()) ; ?>
</center>
</fieldset>

<?php
if(!isset($this->bfquiz->default)){
	$this->bfquiz->default="";
}
?>
<input type="hidden" name="default" value="<?php echo $this->bfquiz->default; ?>">

<input type="hidden" name="option" value="com_bfquiz" />
<input type="hidden" name="id" value="<?php echo $this->bfquiz->id; ?>" />
<input type="hidden" name="task" value="savescorerange" />
<input type="hidden" name="controller" value="scorerangeanswer" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>