-- <?php /* $Id: uninstall.sql 2 2011-11-15 04:37:51Z tuum $ */ defined('_JEXEC') or die() ?>;

DROP TABLE IF EXISTS `#__bfquiz`;
DROP TABLE IF EXISTS `#__bfquiz_matrix`;
DROP TABLE IF EXISTS `#__bfquiz_scorerange`;
DROP TABLE IF EXISTS `#__bfquiz_pool`;
DROP TABLE IF EXISTS `#__bfquiz_email`;
DELETE FROM `#__categories` WHERE section="com_bfquiz";
