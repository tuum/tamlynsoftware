-- <?php /* $Id: upgrade_1.3.1.sql 2 2011-11-15 04:37:51Z tuum $ */ defined('_JEXEC') or die() ?>;

SELECT @catid := max(id) from `#__categories` WHERE `section`='com_bfquiz';

ALTER TABLE `#__bfquiz` ADD `field_type` varchar(50) NOT NULL, 
	ADD `validation_type` varchar(50) NOT NULL;

CREATE TABLE `#__bfquiz_email` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL,  
  `subject` varchar(255) NOT NULL,
  `description` text,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `showQuestions` tinyint(1) NOT NULL,
  `showIncorrect` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
);

INSERT INTO `#__bfquiz_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`, `showQuestions`, `showIncorrect`) VALUES
(1, @catid, 'Admin', 'Automated BF Quiz Notification - {name}', '<p>{name} ({email}) has completed the {category} quiz with a score of {score}</p>', '2010-06-19 11:43:53', 0, '0000-00-00 00:00:00', 1, 0, 1, 1),
(2, @catid, 'Author', 'Automated BF Quiz Notification', '<p>Thank you {name} for completing the {category} quiz.</p>\r\n<p> </p>\r\n<p>Congratulations your score was {score}</p>', '2010-06-19 11:00:31', 0, '0000-00-00 00:00:00', 1, 2, 1, 1);
