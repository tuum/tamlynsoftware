<?php
/**
 * $Id: helper.php 2 2011-11-15 04:37:51Z tuum $
 * Helper for BF Quiz - to populate the question types
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

/**
 * @package		Joomla
 * @subpackage	Components
 */
class bfquizHelper
{

	/**
	* build the select list for question type
	*/
	function QuestionType( &$question_type )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZ_QUESTION_TYPE_TEXT' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZ_QUESTION_TYPE_RADIO' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZ_QUESTION_TYPE_CHECKBOX' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZ_QUESTION_TYPE_TEXTAREA' ) );

		if($question_type == null){
		   $question_type=1;
		}

		$target = JHTML::_('select.genericlist',   $click, 'question_type', 'class="inputbox" size="4" onchange="hideType()"', 'value', 'text',  intval( $question_type ) );

		return $target;
	}

	/**
	* Show question type
	*/
	function ShowQuestionType( &$question_type ) {
	   switch($question_type){
	      case 0:	echo JText::_( 'COM_BFQUIZ_QUESTION_TYPE_TEXT' );
	      			break;
	      case 1:   echo JText::_( 'COM_BFQUIZ_QUESTION_TYPE_RADIO' );
	      			break;
	      case 2:   echo JText::_( 'COM_BFQUIZ_QUESTION_TYPE_CHECKBOX' );
	      			break;
	      case 3:   echo JText::_( 'COM_BFQUIZ_QUESTION_TYPE_TEXTAREA' );
	      			break;
	      default:  echo JText::_( 'COM_BFQUIZ_QUESTION_TYPE_UNKNOWN' );
	   }
	}

	/**
	* build the select list for condition
	*/
	function ConditionType( &$condition, $i )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZ_IS_EQUAL_TO' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZ_IS_LESS_THAN' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZ_IS_GREATER_THAN' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZ_IS_NOT_EQUAL_TO' ) );

		if($condition == null){
		   $condition=0;
		}

		$target = JHTML::_('select.genericlist',   $click, 'condition'.$i.'', 'class="inputbox" size="1" onchange="hideType()"', 'value', 'text',  intval( $condition ) );

		return $target;
	}

	/**
	* build the select list for condition
	*/
	function OperatorType( &$operator_type, $i )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZ_OPERATOR_AND' ) );
		//$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZ_OPERATOR_OR' ) );

		if($operator_type == null){
		   $operator_type=0;
		}

		$target = JHTML::_('select.genericlist',   $click, 'operator'.$i.'', 'class="inputbox" size="1" onchange="hideType()"', 'value', 'text',  intval( $operator_type ) );

		return $target;
	}

    /**
	* build the select list for mandatory position
	*/
	function mandatoryPosition( &$mandatoryPos )
	{

		$click[] = JHTML::_('select.option',  'Start', JText::_( 'COM_BFQUIZ_POSITION_START' ) );
		$click[] = JHTML::_('select.option',  'End', JText::_( 'COM_BFQUIZ_POSITION_END' ) );
		$click[] = JHTML::_('select.option',  'Random', JText::_( 'COM_BFQUIZ_POSITION_RANDOM' ) );

		if($mandatoryPos == null){
		   $mandatoryPos="random";
		}

		$target = JHTML::_('select.genericlist',   $click, 'mandatoryPos', 'class="inputbox" size="3"', 'value', 'text',  $mandatoryPos );

		return $target;
	}

    /**
	 * Build the select list for parent question
	 */
	function Parent( &$row )
	{
		$db =& JFactory::getDBO();

		// If a not a new item, lets set the question item id
		if ( $row->id ) {
			$id = ' AND id != '.(int) $row->id;
		} else {
			$id = null;
		}

		// In case the parent was null
		if (!$row->parent) {
			$row->parent = 0;
		}

		// get a list of the question items
		// excluding the current question item and all child elements
		$query = 'SELECT m.*' .
				' FROM #__bfquiz m' .
				' WHERE m.parent=0 and m.id<>'.$row->id.'' .
				' ORDER BY parent, ordering';
		$db->setQuery( $query );
		$mitems = $db->loadObjectList();

		// establish the hierarchy of the menu
		$children = array();

		if ( $mitems )
		{
			// first pass - collect children
			foreach ( $mitems as $v )
			{
				$pt 	= $v->parent;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}else{
			$list = "";
		}

		// assemble menu items to the array
		$mitems 	= array();
		$mitems[] 	= JHTML::_('select.option',  '0', JText::_( 'Top' ) );

		if($list != ""){
			foreach ( $list as $item ) {
				$mitems[] = JHTML::_('select.option',  $item->id, '&nbsp;&nbsp;&nbsp;'. $item->question . ' ' . $item->id );
			}
		}

		$output = JHTML::_('select.genericlist',   $mitems, 'parent', 'class="inputbox" size="10"', 'value', 'text', $row->parent );

		return $output;
	}
	
/**
	* build the select list for field type
	*/
	function FieldType( &$field_type )
	{

		$click[] = JHTML::_('select.option',  'VARCHAR', JText::_( 'COM_BFQUIZ_FIELD_TYPE_VARCHAR' ) );
		$click[] = JHTML::_('select.option',  'TEXT', JText::_( 'COM_BFQUIZ_FIELD_TYPE_TEXT' ) );
		$click[] = JHTML::_('select.option',  'DATE', JText::_( 'COM_BFQUIZ_FIELD_TYPE_DATE' ) );
		$click[] = JHTML::_('select.option',  'INT', JText::_( 'COM_BFQUIZ_FIELD_TYPE_INT' ) );
		$click[] = JHTML::_('select.option',  'TINYINT', JText::_( 'COM_BFQUIZ_FIELD_TYPE_TINYINT' ) );
		$click[] = JHTML::_('select.option',  'FLOAT', JText::_( 'COM_BFQUIZ_FIELD_TYPE_FLOAT' ) );
		$click[] = JHTML::_('select.option',  'DOUBLE', JText::_( 'COM_BFQUIZ_FIELD_TYPE_DOUBLE' ) );

		if($field_type == null){
		   $field_type='TEXT';
		}

		$target = JHTML::_('select.genericlist',   $click, 'field_type', 'class="inputbox" size="1"', 'value', 'text',  $field_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationType( &$validation_type )
	{

		$click[] = JHTML::_('select.option',  'required', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED' ) );
		$click[] = JHTML::_('select.option',  'required validate-numeric', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_NUMERIC' ) );
		$click[] = JHTML::_('select.option',  'required validate-email', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_EMAIL' ) );

		if($validation_type == null){
		   $validation_type='required';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationTypeCheckbox( &$validation_type )
	{
		$click[] = JHTML::_('select.option',  'required validate-checkbox', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox2', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX2' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox3', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX3' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox4', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX4' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox5', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX5' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox6', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX6' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox7', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX7' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox8', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX8' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox9', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX9' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox10', JText::_( 'COM_BFQUIZ_VALIDATION_REQUIRED_VALIDATE_CHECKBOX10' ) );

		if($validation_type == null | strpos($validation_type,"checkbox")==FALSE){
		   $validation_type='required validate-checkbox';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}	
	
	/**
	* build the select list for email type
	*/
	function emailType( &$title )
	{
		$click[] = JHTML::_('select.option',  'Admin', JText::_( 'COM_BFQUIZ_EMAIL_TYPE_ADMIN' ) );
		$click[] = JHTML::_('select.option',  'Author', JText::_( 'COM_BFQUIZ_EMAIL_TYPE_AUTHOR' ) );
		
		if($title == null){
		   $title="Admin";
		}

		$target = JHTML::_('select.genericlist',   $click, 'title', 'class="inputbox" size="2"', 'value', 'text',  $title );

		return $target;
	}		

	function ScoreCategory( &$scorecatid )
	{
		//TODO, make these populate dynamically from a table.
		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZ_TITLE_PLEASE_SELECT' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZ_SCORECATEGORY_A' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZ_SCORECATEGORY_B' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZ_SCORECATEGORY_C' ) );
		$click[] = JHTML::_('select.option',  '4', JText::_( 'COM_BFQUIZ_SCORECATEGORY_D' ) );
		$click[] = JHTML::_('select.option',  '5', JText::_( 'COM_BFQUIZ_SCORECATEGORY_E' ) );
		$click[] = JHTML::_('select.option',  '6', JText::_( 'COM_BFQUIZ_SCORECATEGORY_F' ) );

		if($scorecatid == null){
		   $scorecatid=0;
		}

		$target = JHTML::_('select.genericlist',   $click, 'scorecatid', 'class="inputbox" size="1"', 'value', 'text',  intval( $scorecatid ) );

		return $target;
	}	

	function ShowScoreCategory( &$scorecatid ) {
	   switch($scorecatid){
	      case 0:	echo "";
	      			break;
	      case 1:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_A' );
	      			break;
	      case 2:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_B' );
	      			break;
	      case 3:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_C' );
	      			break;
	      case 4:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_D' );
	      			break;
	      case 5:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_E' );
	      			break;
	      case 6:   echo JText::_( 'COM_BFQUIZ_SCORECATEGORY_F' );
	      			break;
	      default:  echo "";
	   }
	}	
	
}