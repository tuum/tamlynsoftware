<?php
/**
 * $Id: install.bfquiz.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install()
{
?>

<div class="header"><strong>BF Quiz</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

		<img src="./components/com_bfquiz/images/bflogo.jpg"><br/>

        <br/>  Copyright &copy; 2010 - Tamlyn Creative Pty Ltd.
        <br />

                <br/>This Joomla! 1.5.x Component is released under the GNU GPL.
                <br/>
                <br/>Congratulations, you have successfully installed BF Quiz!
        </p>
    </td>
  </tr>
  <tr>
    <td>
    </td>
    <td>
            <strong><code>I N S T A L L :</code></strong>

                <br/>

                <br/>

                STEP 1 : <font color = "Green">Succesfull</font>
                <br>
                <br>
                STEP 2 : Navigate to Components, BF Quiz->Questions, and setup questions as required.
                <br>
                <br>
                STEP 3 : Add a "BF Quiz" menu item. (Optional) Make sure you configure email address in "Parameters - Component", and select Category in "Parameters - Basic".
				<br>
                <br>
                STEP 4 : (optional) If you wish to make radio or checkbox fields mandatory, you need to install <a href="http://www.tamlyncreative.com.au/software/downloads.html" target="_blank">BF Validate</a> plugin.
				<br>
                <br>
                STEP 5 : (optional) If you wish to use CAPTCHA, you need to install <a href="http://www.joomla.com.br/downloads/doc_details/50-bigo-captcha-12.html" target="_blank">Bigo CAPTCHA</a> plugin.
                <br>
                <br>
                STEP 6 : (optional) If you wish to use Video or audio, you need to install <a href="http://extensions.joomla.org/extensions/multimedia/video-players-&-gallery/812/details" target="_blank">AllVideos</a> plugin.
				<br>
                <br>

    </td>
  </tr>
    </table>
</center>

<?php
}
?>