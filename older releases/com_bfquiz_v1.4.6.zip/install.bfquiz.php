<?php
/**
 * $Id: install.bfquiz.php 2 2011-11-15 04:37:51Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install()
{
	$db	= &JFactory::getDBO();
	
	//check if upgrade required
	global $mainframe;
	$table=$mainframe->getCfg('dbprefix')."bfquiz";
	$fields =& $db->getTableFields( $table, true );
	if( sizeof( $fields[$table] ) ) {
		// We found some fields so let's create the HTML list
		$options = array();
		foreach( $fields[$table] as $field => $type ) {
			$options[] = JHTML::_( 'select.option', $field, $field );
		}
	}

	//CHECK FOR V1.4.4 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "scorecatid") {
			$found=1;
		}
	}	
	
	if($found == 0){
		$query="ALTER table `#__bfquiz` ADD `scorecatid` int(11) NOT NULL default '0'
  	  	    	   ;";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}
	
	//CHECK FOR V1.3.1 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "field_type") {
			$found=1;
		}
	}
	
	if($found == 0){
		$query="ALTER TABLE `#__bfquiz` ADD `field_type` varchar(50) NOT NULL, 
	ADD `validation_type` varchar(50) NOT NULL
  	  	    	   ;";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}
	
	//CHECK FOR V1.2.2 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "suppressQuestion") {
			$found=1;
		}
	}
	
	if($found == 0){
		$query="ALTER table `#__bfquiz` ADD `suppressQuestion` tinyint(1)
  	  	    	   ;";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}	
	
	//check for sample data
	$db->setQuery('SELECT `id` FROM `#__bfquiz`');
	$result=$db->loadResult();
	
	if($result){
		//no need for sample data
	}else{
		//install sample data
		$query = "INSERT INTO `#__categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES  
			('', 0, 'Example', '', 'example', '', 'com_bfquiz', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '')";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	      
		$query = "SELECT @catid := max(id) from `#__categories`";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
		
		$query = "INSERT INTO `#__bfquiz` (`id`, `catid`, `question`, `question_type`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`, `parent`, `option1`, `option2`, `option3`, `option4`, `option5`, `option6`, `option7`, `option8`, `option9`, `option10`, `option11`, `option12`, `option13`, `option14`, `option15`, `option16`, `option17`, `option18`, `option19`, `option20`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`, `answer6`, `answer7`, `answer8`, `answer9`, `answer10`, `answer11`, `answer12`, `answer13`, `answer14`, `answer15`, `answer16`, `answer17`, `answer18`, `answer19`, `answer20`, `score1`, `score2`, `score3`, `score4`, `score5`, `score6`, `score7`, `score8`, `score9`, `score10`, `score11`, `score12`, `score13`, `score14`, `score15`, `score16`, `score17`, `score18`, `score19`, `score20`, `next_question1`, `next_question2`, `next_question3`, `next_question4`, `next_question5`, `next_question6`, `next_question7`, `next_question8`, `next_question9`, `next_question10`, `next_question11`, `next_question12`, `next_question13`, `next_question14`, `next_question15`, `next_question16`, `next_question17`, `next_question18`, `next_question19`, `next_question20`, `prefix`, `suffix`, `field_name`, `fieldSize`, `mandatory`, `helpText`, `horizontal`, `solution`) VALUES 
(1, @catid, 'Which type of extinguisher should be used on a gas fire?', '1', '2009-04-08 03:28:21', 0, '0000-00-00 00:00:00', 1, 1, 0, 'Pressurised Water', 'Carbon Dioxide', 'Dry Chemical', 'Foam', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'extinguisher', 255, 1, 'It is important to use the <strong>correct</strong> extinguishing agent on a fire or you''ll make the situation worse.\r\n<br /><br />\r\n<table width=\"100%\" bgcolor=\"#ffffff\" border=\"1\">\r\n<tr>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz/images/Water.jpg\" WIDTH=\"30\" HEIGHT=\"77\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz/images/Co2.jpg\" WIDTH=\"29\" HEIGHT=\"78/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz/images/Dry-chem.jpg\" WIDTH=\"30\" HEIGHT=\"84/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz/images/Foam.jpg\" WIDTH=\"31\" HEIGHT=\"93/\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\">Water</td>\r\n<td align=\"center\">Co2</td>\r\n<td align=\"center\">Chemical</td>\r\n<td align=\"center\">Foam</td>\r\n\r\n</tr>\r\n</table>', 0, 'Dry Chemical extinguisher can be used for chemical, flammable liquid, electrical, gases.\r\n<br />\r\n<img src=\"./components/com_bfquiz/images/Dry-chem.jpg\" WIDTH=30\" HEIGHT=\"84\" />'),
(2, @catid, 'When lifting is required, you should:', '1', '2009-04-08 02:44:59', 0, '0000-00-00 00:00:00', 1, 2, 0, 'Bend your back and pick it up as quickly as possible', 'Find someone stronger to lift it for you', 'Bend at the knees and keep your back straight', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'manualH', 255, 1, '<img src=\"./components/com_bfquiz/images/manualHandling.jpg\" /><br />', 0, ''),
(3, @catid, 'Which shoe is most appropriate for an office environment?', '1', '2009-04-08 02:44:50', 0, '0000-00-00 00:00:00', 1, 3, 0, 'A', 'B', 'C', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'shoe', 255, 1, '<table>\r\n<tr>\r\n<td><img src=\"./components/com_bfquiz/images/shoe1.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz/images/shoe2.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz/images/shoe3.jpg\" /></td>\r\n</tr>\r\n</table>', 1, ''),
(4, @catid, 'What does the abbreviation IT stand for?', '0', '2009-04-08 02:59:24', 0, '0000-00-00 00:00:00', 1, 4, 0, 'Information Technology', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'abbreviation', 255, 1, '<i>Hint: It is the department that you would call if you had a problem with your computer.</i><br />', 0, ''),
(5, @catid, 'When you greet a visitor in your office, do you', '1', '2009-04-08 03:28:42', 0, '0000-00-00 00:00:00', 1, 5, 0, 'say nothing and let them sit wherever they wish', 'tell them where to sit', 'say Just sit anywhere', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'visitor', 255, 1, '', 0, 'You should indicate where your guest should sit to make them feel more comfortable.')";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}

	//check for email sample data
	$db->setQuery('SELECT `id` FROM `#__bfquiz_email`');
	$result=$db->loadResult();
	
	if($result){
		//no need for sample email data
	}else{		
		//install email data
		$query = "INSERT INTO `#__bfquiz_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`, `showQuestions`, `showIncorrect`) VALUES
(1, @catid, 'Admin', 'Automated BF Quiz Notification - {name}', '<p>{name} ({email}) has completed the {category} quiz with a score of {score}</p>', '2010-06-19 11:43:53', 0, '0000-00-00 00:00:00', 1, 0, 1, 1),
(2, @catid, 'Author', 'Automated BF Quiz Notification', '<p>Thank you {name} for completing the {category} quiz.</p>\r\n<p> </p>\r\n<p>Congratulations your score was {score}</p>', '2010-06-19 11:00:31', 0, '0000-00-00 00:00:00', 1, 2, 1, 1)";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}
	
?>

<div class="header"><strong>BF Quiz</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

		<img src="./components/com_bfquiz/images/bflogo.jpg"><br/>

        <br/>  Copyright &copy; 2010 - Tamlyn Creative Pty Ltd.
        <br />

                <br/>This Joomla! 1.5.x Component is released under the GNU GPL.
                <br/>
                <br/>Congratulations, you have successfully installed BF Quiz!
        </p>
    </td>
  </tr>
  <tr>
    <td>
    </td>
    <td>
            <strong><code>I N S T A L L :</code></strong>

                <br/>

                <br/>

                STEP 1 : <font color = "Green">Succesfull</font>
                <br>
                <br>
                STEP 2 : Navigate to Components, BF Quiz->Questions, and setup questions as required.
                <br>
                <br>
                STEP 3 : Add a "BF Quiz" menu item. (Optional) Make sure you configure email address in "Parameters - Component", and select Category in "Parameters - Basic".
				<br>
                <br>
                STEP 4 : (optional) If you wish to make radio or checkbox fields mandatory, you need to install <a href="http://www.tamlyncreative.com.au/software/downloads.html" target="_blank">BF Validate</a> plugin.
				<br>
                <br>
                STEP 5 : (optional) If you wish to use CAPTCHA, you need to install <a href="http://www.tamlyncreative.com.au/software/downloads.html" target="_blank">Bigo CAPTCHA</a> plugin.
                <br>
                <br>
                STEP 6 : (optional) If you wish to use Video or audio, you need to install <a href="http://extensions.joomla.org/extensions/multimedia/video-players-&-gallery/812/details" target="_blank">AllVideos</a> plugin.
				<br>
                <br>

    </td>
  </tr>
    </table>
</center>

<?php
}
?>