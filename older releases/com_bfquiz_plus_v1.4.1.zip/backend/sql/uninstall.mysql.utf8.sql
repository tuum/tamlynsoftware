-- <?php /* $Id: uninstall.mysql.utf8.sql 17 2012-01-08 11:25:43Z tuum $ */ defined('_JEXEC') or die() ?>;

DROP TABLE IF EXISTS `#__bfquiz_plus`;
DROP TABLE IF EXISTS `#__bfquiz_plus_matrix`;
DROP TABLE IF EXISTS `#__bfquiz_plus_scorerange`;
DROP TABLE IF EXISTS `#__bfquiz_plus_pool`;
DROP TABLE IF EXISTS `#__bfquiz_plus_email`;
DROP TABLE IF EXISTS `#__bfquiz_plus_scorecat`;
DELETE FROM `#__categories` WHERE extension="com_bfquiz_plus";
