window.addEvent('domready', function()
{
    document.formvalidator.setHandler('question', function(value)
    {
        regex = /^[^0-9]+$/;
        return regex.test(value);
    });
});

window.addEvent('domready', function() {
    document.formvalidator.setHandler('fieldname',
            function (value) {
                    regex=/^[a-zA-Z]\w{3,49}$/;
                    //The first character must be a letter,
                    //it must contain at least 4 characters and no more than 50 characters
                    //and no characters other than letters, numbers and the underscore may be used
                    return regex.test(value);
    });
});

function showOptions(){
	var i=0;
	for (i=1;i<21;i++){
		document.getElementById("jform_option"+i).style.display = '';
		document.getElementById("jform_option"+i+"-lbl").style.display = '';
		document.getElementById("jform_next_question"+i).style.display = '';
		document.getElementById("jform_score"+i).style.display = '';
		document.getElementById("jform_answer"+i).style.display = '';
	}
}

function hideAllOptions(){
	var i=0;
	for (i=1;i<21;i++){
		document.getElementById("jform_option"+i).style.display = 'none';
		document.getElementById("jform_option"+i+"-lbl").style.display = 'none';
		if(i>1){
			document.getElementById("jform_next_question"+i).style.display = 'none';
			document.getElementById("jform_score"+i).style.display = 'none';
			document.getElementById("jform_answer"+i).style.display = 'none';
		}
	}
}

function hideBranching(){
	var i=0;
	for (i=1;i<21;i++){
		if(i>1){
			document.getElementById("jform_next_question"+i).style.display = 'none';
			document.getElementById("jform_score"+i).style.display = 'none';
			document.getElementById("jform_answer"+i).style.display = 'none';
		}
	}
}

function hideType2(){
	if(document.getElementById("jform_question_type").value == 0){  //-lbl
		   hideAllOptions();
	}
}

function hideType(){
	updateValidation();
    document.getElementById("jform_next_question1").style.display = '';
    document.getElementById("jform_horizontal0").style.display = 'none';
    document.getElementById("jform_horizontal1").style.display = 'none';
    document.getElementById("bfhorizontal").style.display = 'none';
    document.getElementById("jform_horizontal-lbl").style.textDecoration = 'line-through';
	document.getElementById("jform_fieldSize-lbl").style.display = 'none';
	document.getElementById("jform_fieldSize").style.display = 'none';
    if(document.getElementById("jform_question_type").value == 0){  //text
	   hideAllOptions();
	   document.getElementById("jform_mandatory0").style.display = '';
       document.getElementById("jform_mandatory1").style.display = '';
	   document.getElementById("jform_mandatory-lbl").style.display = '';
	   document.getElementById("jform_fieldSize-lbl").style.display = '';
	   document.getElementById("jform_fieldSize").style.display = '';
	   document.getElementById("jform_option1").style.display = '';
	   document.getElementById("jform_option1-lbl").style.display = '';
    }else if(document.getElementById("jform_question_type").value == 1){  //radio
    	document.getElementById("jform_mandatory0").style.display = '';
	   document.getElementById("jform_mandatory1").style.display = '';
       document.getElementById("jform_mandatory-lbl").style.display = '';
       document.getElementById("jform_horizontal0").style.display = '';
       document.getElementById("jform_horizontal1").style.display = '';
	   document.getElementById("jform_horizontal-lbl").style.display = '';
	   document.getElementById("jform_horizontal-lbl").style.textDecoration = '';
	   document.getElementById("bfhorizontal").style.display = '';
	   showOptions();
    }else if(document.getElementById("jform_question_type").value == 2){  //checkbox
       showOptions();
       document.getElementById("jform_mandatory0").style.display = '';
	   document.getElementById("jform_mandatory1").style.display = '';
       document.getElementById("jform_mandatory-lbl").style.display = '';
       document.getElementById("jform_horizontal0").style.display = '';
       document.getElementById("jform_horizontal1").style.display = '';
	   document.getElementById("jform_horizontal-lbl").style.display = '';
	   document.getElementById("jform_horizontal-lbl").style.textDecoration = '';
	}else if(document.getElementById("jform_question_type").value == 3){  //textarea
	   hideAllOptions();
	   document.getElementById("jform_mandatory0").style.display = '';
	   document.getElementById("jform_mandatory1").style.display = '';
       document.getElementById("jform_mandatory-lbl").style.display = '';
	   document.getElementById("jform_fieldSize-lbl").style.display = '';
	   document.getElementById("jform_fieldSize").style.display = '';
	   document.getElementById("jform_option1").style.display = '';
	   document.getElementById("jform_option1-lbl").style.display = '';
    }
}

var checkbox_array = new Array('required validate-checkbox','required validate-checkbox2','required validate-checkbox3','required validate-checkbox4','required validate-checkbox5','required validate-checkbox6','required validate-checkbox7','required validate-checkbox8','required validate-checkbox9','required validate-checkbox10');
var text_array = new Array('required','required validate-numeric','required validate-email');

function updateValidation(){
   //get var from php
   var validation_type = "<?php echo isset($this->item->validation_type) ? $this->item->validation_type : ''; ?>";

   var sda = document.getElementById('jform_validation_type');
   var len = sda.length;
	   if(document.getElementById("jform_question_type").value == 2){  //checkbox
		  //remove all options first
		  sda.options.length=0;

	  var len2 = checkbox_array.length;
	  for(var i=0; i<len2; i++)
	  {
      	//now add validate-checkbox
	  	var y=document.createElement('option');
	  	y.text=checkbox_array[i];
		  	y.value=checkbox_array[i];
		  	if(checkbox_array[i] == validation_type){
		  	   y.selected = true;
		  	}
	  	try
	  	{
	  	  sda.add(y,null);}
	  	  catch(ex){
	  	  sda.add(y);
	  	}
	  }

	  sda.setAttribute("value", checkbox_array[0]);

   }else if(document.getElementById("jform_question_type").value == 0){  //text
	  //remove all options first
		  sda.options.length=0;

	  var len2 = text_array.length;
	  for(var i=0; i<len2; i++)
	  {
      	//now add validate options
	  	var y=document.createElement('option');
	  	y.text=text_array[i];
		  	y.value=text_array[i];
		  	if(text_array[i] == validation_type){
			   y.selected = true;
		  	}
	  	try
	  	{
	  	  sda.add(y,null);}
	  	  catch(ex){
	  	  sda.add(y);
	  	}
	  }

	  sda.setAttribute("value", text_array[0]);
   }else{
      //default validation types
	  //remove all options first
		  sda.options.length=0;

	  //now add validate options
	  var y=document.createElement('option');
	  y.text="default";
		  y.value="default";
	  try
	  {
	    sda.add(y,null);}
	    catch(ex){
	    sda.add(y);
	  }
   }
}