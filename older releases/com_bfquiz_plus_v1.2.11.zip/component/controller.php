<?php
/**
 * $Id: controller.php 63 2014-03-04 10:44:40Z tuum $
 * Bfquiz_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');
class Bfquiz_plusController extends JControllerLegacy
{
	/**
	 * Get the questions from #__bfquiz_plus for the current cateogry
	 *
	 * @return	array of questions
	 */
	public static function getQuestions()
	{
	    $catid	= JRequest::getVar( 'catid', 0, '', 'int' );

	   	$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from('#__bfquiz_plus AS a');
		$query->select('a.*,  cc.title AS category_name');
		$query->join('LEFT', '#__categories AS cc ON cc.id = a.catid');
		$query->where('a.state = 1');
		$query->where('a.catid = '.(int) $catid);
		$query->order('a.parent, a.ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		//establish the parent-child hierarchy
		$children = array();
		// first pass - collect children
		foreach ($rows as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$mylist = array();
		foreach ($rows as $v )
		{
			if ($v->parent==0)
			{
				array_push($mylist, $v);

				//now are there any children
				if (isset($children[$v->id]))
				{
					foreach ($children[$v->id] as $c )
					{
						array_push($mylist, $c);
					}
				}
			}
		}

		$myrows = $mylist;
		return $myrows;
	}

	/**
	 * Get questions from specified category
	 *
	 * @param int	$catid	Category id number
	 */
	public static function getQuestionsResponse($catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	    // get questions
		$query->from('#__bfquiz_plus AS a');
		$query->select('a.*');
		$query->where('a.catid = '.(int) $catid);
		$query->where('(a.state IN (0, 1))');
		$query->order('a.ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		return $rows;
	}

	/**
	 * Get all the responses for the specific category
	 *
	 * @param int $catid	Category id number
	 */
	public static function getAnswers($catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from('#__bfquizplus_'.(int)$catid.' AS a');
		$query->select('a.*');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		return $rows;
	}

	function getAnswers2($id, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from('#__bfquizplus_'.(int)$catid.' AS a');
		$query->select('a.*');
		$query->where('a.id = '.(int) $id);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		return $rows;
	}

	/**
	 * Get the next question based on conditional branching
	 *
	 * @param int $question		id number of the current question
	 * @param string $response	Answer selected for the current question
	 *
	 * @return	int	$next_question	id number of the next question
	 */
	public static function getNextQuestion($question, $response)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get questions
		$catid	= JRequest::getVar( 'catid', 0, '', 'int' );
		if ($catid == 0){
			$query->from('#__bfquiz_plus AS a');
			$query->select('a.*');
			$query->where('(a.state IN (0, 1))');
			$query->where('a.id = '.(int) $question);
		} else {
			$query->from('#__bfquiz_plus AS a');
			$query->select('a.*');
			$query->where('(a.state IN (0, 1))');
			$query->where('a.catid = '.(int) $catid);
			$query->where('a.id = '.(int) $question);
		}

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$next_question=0;

		if($rows[0]->question_type == 0){  // textbox
		   $next_question = $rows[0]->next_question1;
		}

		if($rows[0]->option1 == $response){
		   $next_question = $rows[0]->next_question1;
		}else if($rows[0]->option2 == $response){
		   $next_question = $rows[0]->next_question2;
		}else if($rows[0]->option3 == $response){
		   $next_question = $rows[0]->next_question3;
		}else if($rows[0]->option4 == $response){
		   $next_question = $rows[0]->next_question4;
		}else if($rows[0]->option5 == $response){
		   $next_question = $rows[0]->next_question5;
		}else if($rows[0]->option6 == $response){
		   $next_question = $rows[0]->next_question6;
		}else if($rows[0]->option7 == $response){
		   $next_question = $rows[0]->next_question7;
		}else if($rows[0]->option8 == $response){
		   $next_question = $rows[0]->next_question8;
		}else if($rows[0]->option9 == $response){
		   $next_question = $rows[0]->next_question9;
		}else if($rows[0]->option10 == $response){
		   $next_question = $rows[0]->next_question10;
		}else if($rows[0]->option11 == $response){
		   $next_question = $rows[0]->next_question11;
		}else if($rows[0]->option12 == $response){
		   $next_question = $rows[0]->next_question12;
		}else if($rows[0]->option13 == $response){
		   $next_question = $rows[0]->next_question13;
		}else if($rows[0]->option14 == $response){
		   $next_question = $rows[0]->next_question14;
		}else if($rows[0]->option15 == $response){
		   $next_question = $rows[0]->next_question15;
		}else if($rows[0]->option16 == $response){
		   $next_question = $rows[0]->next_question16;
		}else if($rows[0]->option17 == $response){
		   $next_question = $rows[0]->next_question17;
		}else if($rows[0]->option18 == $response){
		   $next_question = $rows[0]->next_question18;
		}else if($rows[0]->option19 == $response){
		   $next_question = $rows[0]->next_question19;
		}else if($rows[0]->option20 == $response){
		   $next_question = $rows[0]->next_question20;
		}

		//special case for checkbox
		//take the lowest next question id out of those selected
		$check_msg="";
		if ($rows[0]->question_type == 2 & $response != NULL)	// checkbox
		{
			foreach($response as $value)
         	{
               $check_msg .= "$value\n";
           	}
       		$response = $check_msg;

			for($i=0; $i < 20; $i++){
	             $myoption="option".($i+1);
	             $mynextquestion="next_question".($i+1);

	             if($rows[0]->$myoption){
	                //does answer contain this option
	                $response=" ".$response;
	                if(strpos(strtoupper($response), strtoupper($rows[0]->$myoption) )){
						//is next question id lower than current?
	                	if($rows[0]->$mynextquestion < $next_question | $next_question==0){
							$next_question=$rows[0]->$mynextquestion;
						}
			  	    }
			  	 }
	          }
		}

		return $next_question;
	}

	/**
	 * Get the question text for this question
	 *
	 * @param 	int		$question	id number of the current question
	 *
	 * @return	string	$result		Text of the question
	 */
	public static function getQuestion($question)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get question
		$query->from('#__bfquiz_plus AS a');
		$query->select('question');
		$query->where('a.id = '.(int) $question);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

	    return $result;
    }

    /**
     * Get all the details for the specified question
     *
     * @param 	int 	$question	id number of the question
     *
     * @return	array	$rows		All the fields for that question
     */
	public static function getQuestionDetails($question)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get question
		$query->from('#__bfquiz_plus AS a');
		$query->select('*');
		$query->where('a.id = '.(int) $question);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

	    return $rows;
    }

    /**
     * Save the default fields for this response
     *
     * @param string	$name	Name of the person completing the quiz
     * @param string	$email	Email address of the person completing the quiz
     * @param string	$table	Answer table name
     *
     * @return	int		id number of the row inserted in the answer table
     */
	public static function save($name,$email,$table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// todays date
		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$DateCompleted = $now->toSql();
		}else{
			$DateCompleted = $now->toMySQL();
		}

		$session = JFactory::getSession();
		if($session->has('dateReceived')){
   			$dateReceived=$session->get('dateReceived');
		}else{
			$dateReceived=$DateCompleted;
		}
		$ip = Bfquiz_plusController::getIP();

		// save data
		$query->clear();
		$query->insert($db->quoteName($table));
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->columns(array($db->quoteName('Name'), $db->quoteName('Email'), $db->quoteName('DateReceived'), $db->quoteName('ip'), $db->quoteName('state'), $db->quoteName('DateCompleted') ));
			$query->values($db->quote( $db->escape( $name ), false ).', '.$db->quote( $db->escape( $email ), false ).', '.$db->quote( $dateReceived, false).', '.$db->quote($ip, false).',1, '.$db->quote( $DateCompleted, false) );
		}else{
			//joomla 1.6 support
	        $query->set('`Name` = '.$db->quote( $db->escape( $name ), false ) );
	        $query->set('`Email` = '.$db->quote( $db->escape( $email ), false ) );
	        $query->set('`DateReceived` = '.$db->quote( $dateReceived, false) );
	        $query->set('`ip` = '.$db->quote($ip, false) );
	        $query->set('`state` = 1' );
	        $query->set('`DateCompleted` = '.$db->quote( $DateCompleted, false) );
		}
		$db->setQuery((string)$query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return $db->insertid();
	}

	/**
	 * Used to see if this IP address has already completed the quiz
	 *
	 * @param string $table		Name of the answer table
	 * @param string $ip		IP address of the person taking the quiz
	 *
	 * @return	int	Number of times this IP address appears in the answer table
	 */
	public static function checkIP($table,$ip)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	   	$query->from($db->quoteName($table).' AS a');
		$query->select('count(a.ip)');
		$query->where('a.ip = '. $db->quote($ip) );

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	/**
	 * Check to see if person with the email address has already completed the quiz
	 *
	 * @param string	$table		Answer table
	 * @param string	$myemail	Email address of person taking the quiz
	 *
	 * @return	int		Number of times this email address has taken the quiz
	 */
	public static function checkEmail($table, $myemail){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		if($myemail == ""){
			// don't check anonymous responses
			return 0;
		}else{
			$query->from($db->quoteName($table).' AS a');
			$query->select('count(a.Email)');
			$query->where('a.Email = '.$db->quote( $db->escape( $myemail ), false ) );

			$db->setQuery((string)$query);
			$result=$db->loadResult();

			return $result;
		}
	}

	/**
	 * Check to see if person with this user id (UNID) has completed the quiz
	 *
	 * @param string	$table	Answer table
	 * @param int		$myUID	User id number of the current user
	 *
	 * @return	int		Number of times this user has completed the quiz
	 */
	public static function checkUID($table, $myUID){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		if($myUID == "" | $myUID == 0){
			// don't check anonymous responses
			return 0;
		}else{
			$query->from($db->quoteName($table).' AS a');
			$query->select('count(a.uid)');
			$query->where('a.uid = '.(int)$myUID );

			$db->setQuery((string)$query);
			$result=$db->loadResult();

			return $result;
		}
	}

	/**
	 * Get the question data based on field name
	 *
	 * @param int 		$id			id number of the question
	 * @param string 	$field_name	name of the field to get data for
	 * @param string	$table		Name of the question table
	 *
	 * @return string	data in that field
	 */
	public static function getField($id,$field_name,$table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get answer
		$query->from($db->quoteName($table));
		$query->select($field_name);
		$query->where('id = '.(int)$id );

		$db->setQuery((string)$query);
		$result=$db->loadResult();

	    return $result;
	}

	/**
	 * Get the field name for a question
	 *
	 * @param 	int		$id		id number of the quesiton
	 *
	 * @return	string	field name
	 */
	function getFieldName($id){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('field_name');
		$query->where('id = '.(int)$id );

		$db->setQuery((string)$query);
		$result=$db->loadResult();

	    return $result;
	}

	/**
	 * Save the data for this question based on the field name
	 *
	 * @param int 		$id			id number of the answer row
	 * @param string 	$field_name	Name of the database field to save the answer in
	 * @param string 	$answer		Answer selected in the quiz
	 * @param string 	$table		Answer table name
	 *
	 * @return	boolean	True for success, false for failure
	 */
	public static function saveField($id,$field_name,$answer,$table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// save data
		$query->update($db->quoteName($table));
		$query->set($field_name.' = '.$db->quote( $db->escape( $answer ), false ) );
		$query->where('id = '.(int)$id );

		$db->setQuery((string)$query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

	/**
	 * This function processes the answers given for an all questions on one page quiz.
	 *
	 * @return null
	 */
	function updateOnePage()
	{
		JRequest::checkToken() or jexit( JText::_( 'COM_BFQUIZPLUS_ERROR_INVALID_TOKEN') );
		//get parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config =  $menu->getParams( $Itemid );

		$registeredUsers = $config->get( 'registeredUsers' );
		$preventMultipleEmail = $config->get( 'preventMultipleEmail' );
		$preventMultipleUID = $config->get( 'preventMultipleUID' );
		$scoringMethod = $config->get( 'scoringMethod' );
		$thankyouText = $config->get( 'thankyouText' );
		$allowAuthorEmail = $config->get( 'authorEmail' );

		$qntable="#__bfquiz_plus";
		$fullname = JRequest::getVar( 'fullname', "", 'post', 'string' );
		$email = JRequest::getVar( 'email', "", 'post', 'string' );
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		$table="#__bfquizplus_".(int)$catid;

		$emailcount = Bfquiz_plusController::checkEmail($table,$email);

		$user = JFactory::getUser();
		if($registeredUsers == "1"){
		   $uidcount = Bfquiz_plusController::checkUID($table,$user->id);
		}else{
		   $uidcount = 0;
		}

		if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed quiz

	    // save basic details to db, and generate id
		$id = Bfquiz_plusController::save($fullname,$email,$table);

		//save uid
		Bfquiz_plusController::saveField($id,"uid",$user->id,$table);

		$emailBody = "";
		$score=0;
		$answerSeq="";

		$items = Bfquiz_plusController::getQuestions();

		$total_qns=count( $items );

		for ($i=0; $i < $total_qns; $i++)
		{
		    $check_msg = "";
			$row = $items[$i];
			$fieldName = $row->field_name;

		    if($row->question_type == 1){ // radio
		      if(JRequest::getVar($fieldName) == "_OTHER_"){
		         $temp = $fieldName;
		         $temp .= '_OTHER_';
		         $answer = JRequest::getVar($temp);
		      }else{
		         $answer = JRequest::getVar($fieldName);
		      }
			}else if($row->question_type == "2"){  // Checkbox
		   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );
				if($name == ""){
				   //do nothing
				}else{
		   			foreach($name as $value) {
		    		   	if($value == "_OTHER_"){
		    		      	$temp = $fieldName;
		        	        $temp .= '_OTHER_';
					      	$value = JRequest::getVar($temp);
       				   	}
			 		   $check_msg .= "$value\n";
			 		}
		   		}
			    $answer = $check_msg;
			}else{
			   $answer = JRequest::getVar($fieldName);
			}

		   	if($answer == ""){
    			// do nothing
		   	}else if($row->question_type == 10){  //heading
		   		// do nothing
   			}else{
   				$question = Bfquiz_plusController::getQuestion($items[$i]->id);
    			$emailBody .= "<br>".$question.": <br>".JText::_("COM_BFQUIZPLUS_ANSWER").": ".$answer."<br>";
   			}

			if($fieldName == ""){
			   // do nothing
		   	}else if($row->question_type == 10){  //heading
		   		// do nothing
			}else{
  			   Bfquiz_plusController::saveField($id,$fieldName,$answer,$table);
  			   $score=$score+Bfquiz_plusController::getScore($fieldName,$qntable,$answer);
  		       if($scoringMethod == 1){
			      $answerSeq.=Bfquiz_plusController::getAnswerSeq($fieldName,$answer);
      		   }
  			}
		}

		//save score
		Bfquiz_plusController::saveField($id,"score",$score,$table);

		//save answer sequence
		Bfquiz_plusController::saveField($id,"answerseq",$answerSeq,$table);

		echo "<div class=\"Bfquiz_plusOptions\">";
		echo $thankyouText;
		echo "</div>";
		echo "<br>";
		Bfquiz_plusController::showResultsScoreCategory($id,$table,$catid);
		Bfquiz_plusController::showResults($score);
		echo "<br>";
		$myIncorrect=Bfquiz_plusController::showIncorrect($id,$table);

		//------------------------------------ email ------------------------------------------------------------
		$emailBodyIncorrect = "<br>".JText::_("COM_BFQUIZPLUS_INCORRECT_ANSWERS")."<br>".$myIncorrect."<br>";

		$adminEmail = Bfquiz_plusController::getEmailTemplate("Admin", $catid);

		$maxScore = Bfquiz_plusController::getMaxScore($catid);

		//repace fields with actual data
		$adminEmail[0]->description=preg_replace('/{score}/', $score , $adminEmail[0]->description); // insert score
		$adminEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $adminEmail[0]->description); // insert maximum score
		$adminEmail[0]->description=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->description); // insert category
		$adminEmail[0]->description=preg_replace('/{name}/', $fullname , $adminEmail[0]->description); // insert name
		$adminEmail[0]->description=preg_replace('/{email}/', $email , $adminEmail[0]->description); // insert email

		$adminEmail[0]->subject=preg_replace('/{score}/', $score , $adminEmail[0]->subject); // insert score
		$adminEmail[0]->subject=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->subject); // insert category
		$adminEmail[0]->subject=preg_replace('/{name}/', $fullname , $adminEmail[0]->subject); // insert name
		$adminEmail[0]->subject=preg_replace('/{email}/', $email , $adminEmail[0]->subject); // insert email

		$subject = $adminEmail[0]->subject;
		$body = $adminEmail[0]->description;
		if($adminEmail[0]->showQuestions == 1){
			$body .= $emailBody;
		}

		if($adminEmail[0]->showIncorrect == 1){
			$body .= $emailBodyIncorrect;
		}

		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

	   	$allowEmail = $config->get( 'allowEmail' );
	   	$sendEmailTo = $config->get( 'sendEmailTo' );

	   	if($allowEmail){
			Bfquiz_plusController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);
   		}

		$authorEmail = Bfquiz_plusController::getEmailTemplate("Author", $catid);

		//repace fields with actual data
		$authorEmail[0]->description=preg_replace('/{score}/', $score , $authorEmail[0]->description); // insert score
		$authorEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $authorEmail[0]->description); // insert maximum score
		$authorEmail[0]->description=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->description); // insert category
		$authorEmail[0]->description=preg_replace('/{name}/', $fullname , $authorEmail[0]->description); // insert name
		$authorEmail[0]->description=preg_replace('/{email}/', $email , $authorEmail[0]->description); // insert email

		$authorEmail[0]->subject=preg_replace('/{score}/', $score , $authorEmail[0]->subject); // insert score
		$authorEmail[0]->subject=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->subject); // insert category
		$authorEmail[0]->subject=preg_replace('/{name}/', $fullname , $authorEmail[0]->subject); // insert name
		$authorEmail[0]->subject=preg_replace('/{email}/', $email , $authorEmail[0]->subject); // insert email

		$subject = $authorEmail[0]->subject;
		$body = $authorEmail[0]->description;
		if($authorEmail[0]->showQuestions == 1){
			$body .= $emailBody;
		}

		if($authorEmail[0]->showIncorrect == 1){
			$body .= $emailBodyIncorrect;
		}

		if($allowAuthorEmail == "1" & $email!=""){
			Bfquiz_plusController::sendHTMLNotificationEmail($body, $email, $subject);
		}
		//------------------------------------ end email ------------------------------------------------------------

		if($scoringMethod == 1){
		   Bfquiz_plusController::checkABCD($fieldName,$answerSeq,$id,$table);
		}else if($scoringMethod == 2){
		   Bfquiz_plusController::checkscorerange($fieldName,$score,$id,$table);
		}

		}else{
		   echo JText::_( "COM_BFQUIZPLUS_EMAIL_ALREADY_COMPLETED");
      	}

      	//clear session data
      	$session = JFactory::getSession();
		$session->set('start_time'.$Itemid, null);
		$session->set('dateReceived', null);
	}

    function sendEmail($body){
    	$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

    	$allowEmail = $config->get( 'allowEmail' );
    	$sendEmailTo = $config->get( 'sendEmailTo' );
    	$emailSubject = $config->get( 'emailSubject' );
		$emailBody = $config->get( 'emailBody' );

	   if($allowEmail){
	       // Send email
		   Bfquiz_plusController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
		}else{
		   // do nothing
		}
    }

	function sendEmailAuthor($body,$author){
    	$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

    	$allowEmail = $config->get( 'allowEmail' );

      if($allowEmail){
          // Send email
         $sendEmailTo = $author;
    	 $emailSubject = $config->get( 'emailSubject' );
		 $emailBody = $config->get( 'emailBody' );
         Bfquiz_plusController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
      }else{
         // do nothing
      }
    }

    function sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody)
	{
	    $mailer = JFactory::getMailer();

	    $mailer->addRecipient($sendEmailTo);
		$mailer->setSubject($emailSubject);
		$mailer->setBody($emailBody.$body.'');

		if ($mailer->Send() !== true)
		{
		    // an error has occurred
		    // a notice will have been raised by $mailer
		}
	}

	public static function getIP() {

		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
			$ip=$_SERVER['REMOTE_ADDR'];
		return $ip;
	}

	public static function getStatsCheckbox($question, $response, $catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid));
		$query->select('*');
		$query->where($db->escape( $question ).' like '.$db->quote('%'.$db->escape( $response, true ).'%') );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStats($question, $response, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	  	$query->from($db->quoteName('#__bfquizplus_'.(int)$catid));
		$query->select('*');
		$query->where(trim($db->escape( $question )).' = '.$db->quote($db->escape( $response, true )) );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsPool($id, $response, $poolid, $qnsPerQuiz){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$total = 0;

		for($i=1; $i < $qnsPerQuiz+1; $i++){
			$tempqid = "qid".$i;
			$tempanswer = "answer".$i;

	  		$query->from($db->quoteName('#__bfquizplus_'.(int)$poolid.'_pool'));
			$query->select('*');
			$query->where($tempqid.'="'.(int)$id.'"');
			$query->where($tempanswer.'="'.$db->escape( $response, true ).'"');
			$query->where('(state IN (0, 1))');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$n = count($rows);

			$total = $total + $n;
		}

		return $total;
	}

	/***********************
	 *	Captcha functions!
	 ***********************/
	function displaycaptcha() {
		$app = JFactory::getApplication();

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 0, '', 'int');

		if ($use_captcha) {
			$Ok = null;
			$app->triggerEvent('onCaptcha_Display', array($Ok));
			if (!$Ok) {
				echo JText::_( "COM_BFQUIZPLUS_CAPTCHA_ERROR_DISPLAYING" );
			}
		}
	}

	/**
	@return boolean
	*/
	function _checkCaptcha() {
		$app = JFactory::getApplication();

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 1, '', 'int');


		// not using captcha!
		if (!$use_captcha) {
			return true;
		}
		$return = false;
		$word = JRequest::getVar('word', false, '', 'CMD');

		$app->triggerEvent('onCaptcha_confirm', array($word, &$return));
		if ($return) {
			return true;
		} else return false;
	}


	/**********************
	 * Scoring functions
	 **********************/
	 public static function showResults($score){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

		$showResults = $config->get( 'showResults' );

	    if($showResults){
	       ?>
		      <div class="Bfquiz_plusOptions"><strong><?php echo JText::_("COM_BFQUIZPLUS_CONGRATULATIONS"); ?> <?php echo $score; ?></strong></div>
		      <br>
		  <?php
	    }else{
	       // do nothing - show results menu parameter set to no
	    }
	 }

	public static function showResultsScoreCategory($id, $table, $catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	  	$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('*');
		$query->where('catid='.(int)$catid.' AND scorecatid>0');

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		$query->clear();
		$query->from($db->quoteName($table));
		$query->select('*');
		$query->where('id='.(int)$id);

		$db->setQuery((string)$query);
		$result2=$db->loadObjectList();

		$query->clear();
		$query->from($db->quoteName('#__bfquiz_plus_scorecat'));
		$query->select('*');
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$scorecats = $db->loadObjectList();

		if(count($scorecats)){
			foreach($scorecats as $row){
				$scorecategory[$row->id]=0;
				$count[$row->id]=0;
			}

			$qntable="#__bfquiz_plus";
			if(count($result)){
				foreach($result as $row){
					$fieldName = $row->field_name;

					$scorecategory[$row->scorecatid] = $scorecategory[$row->scorecatid] + Bfquiz_plusController::getScore($fieldName, $qntable, $result2[0]->$fieldName);
					$count[$row->scorecatid]++;
				}
				?>

				<?php foreach($scorecats as $row){ ?>
					<?php if($count[$row->id]){ ?>
						<div class="bfquizOptions"><strong><?php echo $row->congratulationsText; ?> <?php echo $scorecategory[$row->id]; ?></strong></div>
						<div class="bfquizScoreCategoryInfo"><?php echo $row->additionalInformationText; ?></div>
						<br>
					<?php } ?>
				<?php } ?>
			<?php
			}

		}
	}


	public static function getScore($field_name,$table,$answer)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName($table).' AS a');
		$query->select('a.id');
		$query->where('a.field_name = '.$db->quote($field_name));

		$db->setQuery((string)$query);
		$result=$db->loadResult();
		$id=$result;

		// get answer
		$query->clear();
		$query->from($db->quoteName($table).' AS a');
		$query->select('a.*');
		$query->where('a.id = '.(int)$id);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$myresult=&$rows[0];
		$score=0;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

		$scoringMethod = $config->get( 'scoringMethod' );

		$view=JRequest::getVar('view');
		if($view=="stats" & !(is_numeric($myresult->score1))){
			$scoringMethod =1;
		}

		if($scoringMethod == 1){
			$score=1;
		}else{
			if(is_numeric($myresult->score1)){
				$numanswers=0;
				//special case for checkbox question type
				if($myresult->question_type == 2){
					//how many correct answers?
					$numanswers=(int)($myresult->answer1)+(int)($myresult->answer2)+(int)($myresult->answer3)+(int)($myresult->answer4)+(int)($myresult->answer5)+(int)($myresult->answer6)+(int)($myresult->answer7)+(int)($myresult->answer8)+(int)($myresult->answer9)+(int)($myresult->answer10)+(int)($myresult->answer11)+(int)($myresult->answer12)+(int)($myresult->answer13)+(int)($myresult->answer14)+(int)($myresult->answer15)+(int)($myresult->answer16)+(int)($myresult->answer17)+(int)($myresult->answer18)+(int)($myresult->answer19)+(int)($myresult->answer20);
				}

				for ($z=0; $z < 20; $z++){
					$tempoption="option".($z+1);
					$tempscore="score".($z+1);
					if(trim(strtoupper($answer))==trim(strtoupper($myresult->$tempoption))){
						$score=$myresult->$tempscore;
						$z = 20;
					}
				}

				//special case for multiple answers
				if($numanswers>1){
					//get correct answer
					$correctanswer = "";
					for ($z=0; $z < 20; $z++){
						$tempvalue="answer".($z+1);
						$tempvalue2="option".($z+1);
						if($myresult->$tempvalue == 1){
							$correctanswer .= $myresult->$tempvalue2;
							$correctanswer.=" "; //add space between correct answers
						}
					}

					//remove all whitespace
					$myanswer=preg_replace('/\s+/','',$answer);
					$correctanswer=preg_replace('/\s+/','',$correctanswer);

					$score=0;
					for($i=0; $i < 20; $i++){
						$myoption="option".($i+1);
						$myscore="score".($i+1);

						if($myresult->$myoption){
							//does answer contain this option
							$answer=" ".$answer;
							if(strpos(strtoupper($answer), strtoupper($myresult->$myoption) )){
								//only assign score if all correct answers are selected
								if(trim(strtoupper($myanswer))==trim(strtoupper($correctanswer)) | $myresult->suppressQuestion == 1){
									$score=$score+(int)($myresult->$myscore);
								}
							}
						}
					}
				}
			}else{
				if($myresult->suppressQuestion == 1){
					$score=0;
				}else{
					echo JText::_("COM_BFQUIZPLUS_ERROR_SCORE_NUMERIC");
				}
			}

		} // end else

		return $score;
	}


	public static function showIncorrect($id,$table){
		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

		$showIncorrect = $config->get( 'showIncorrect' );
		$showCorrect = $config->get( 'showCorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){
	       //get questions
		   $items = Bfquiz_plusController::getQuestions();
		   $total_qns=count( $items );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $row = &$items[$i];
		      if($row->question_type == 10){
		      	//do nothing
		      }else{
			      $fieldName = $row->field_name;

				  $numanswers=0;
				  //special case for checkbox question type
				  if($row->question_type == 2){
				     //how many correct answers?
					 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
				  }

				  //get correct answer
				  $correctanswer = "";
				  for ($z=0; $z < 20; $z++){
				     $tempvalue="answer".($z+1);
				     $tempvalue2="option".($z+1);
				     if($row->$tempvalue == 1){
				        $correctanswer .= $row->$tempvalue2;
				        if($numanswers > 1){
				           $correctanswer.=" "; //add space between correct answers
				        }
				     }
				  }

			      //get answer
				  $answer=Bfquiz_plusController::getField($id,$fieldName,$table);

				  $answerWithSpaces=trim($answer);
				  $correctAnswerWithSpaces=trim($correctanswer);

			      if($row->question_type == 2){ //checkbox
			         //(remove whitespace)
			         $answer=preg_replace('/\s+/','',$answer);
			         $correctanswer=preg_replace('/\s+/','',$correctanswer);
			      }

				  //was answer correct?
			      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1 | $row->question_type == 10){
				     //answer was correct or question suppressed or heading
				     if( $row->suppressQuestion == 1 ){
				         //still do nothing as question is suppressed
				     }else{
						if( $showCorrect == 1 ){
				     	//show correct answer
				  	 	?>
						<tr>
			    			<th>
		    			   	<div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
		    				</th>
						</tr>
						<tr>
						    <th>
				      			<div class="Bfquiz_plusOptions">
				      			<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
				      			<?php echo $answerWithSpaces; ?>
				      			<?php echo JText::_("COM_BFQUIZPLUS_WAS_CORRECT"); ?>
								<br><br>
				      			<?php echo JHTML::_('content.prepare', $row->solution); ?>
				      	    	</div>
				      		</th>
			      		</tr>
			      		<tr>
			      	   	<td>&nbsp;</td>
			      		</tr>
						<?php
				     	}
				     }
				  }else{
					 //first one
					 if($i==0){
					    ?>
					    <div class="Bfquiz_plusOptions">
					    <?php echo JText::_( "COM_BFQUIZPLUS_INCORRECT_ANSWERS" ); ?></div>
					    <br>
					    <?php
					 }

		             //show solution
				  	 ?>
					<tr>
		    			<th>
		    			   <div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
		    			</th>
					</tr>
					<tr>
					    <th>
				      		<div class="Bfquiz_plusOptions">
				      		<div class="bfincorrect">
				      		<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
				      		<?php echo $answerWithSpaces; ?>
				      		<?php echo JText::_("COM_BFQUIZPLUS_WAS_INCORRECT"); ?>
				      		<br>
				      		<?php echo JText::_("COM_BFQUIZPLUS_CORRECT_ANSWER_IS"); ?>
				      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
				      		</div>
				      		<br><br>
				      		<?php echo JHTML::_('content.prepare', $row->solution); ?>
				      	    </div>
				      	</th>
			      	</tr>
			      	<tr>
			      	   <td>&nbsp;</td>
			      	</tr>
					<?php

					//now prepare above for email
					$myIncorrect.="<br>".JText::_( $row->question ).": <br>".JText::_('COM_BFQUIZPLUS_YOUR_ANSWER_OF')."".$answerWithSpaces."".JText::_('COM_BFQUIZPLUS_WAS_INCORRECT')."<br>".JText::_('COM_BFQUIZPLUS_CORRECT_ANSWER_IS')."".$correctAnswerWithSpaces."<br><br>";
		          }

		      }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }

	public static function showIncorrect2($answer,$fieldname,$qid){
		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

		$showIncorrect = $config->get( 'showIncorrect' );
		$showCorrect = $config->get( 'showCorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){
	       //get questions
		   $myitem = Bfquiz_plusController::getOneQuestion($qid);
		   $total_qns=count( $myitem );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $row = &$myitem[$i];
		      $fieldName = $row->field_name;

		   	  $numanswers=0;
			  //special case for checkbox question type
			  if($row->question_type == 2){
			     //how many correct answers?
				 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
			  }

			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($row->$tempvalue == 1){
			        $correctanswer .= $row->$tempvalue2;
			        if($numanswers > 1){
			           $correctanswer.=" "; //add space between correct answers
			        }
			     }
			  }

		   	  if( is_array($answer) ){
			     $answer = implode(" ",$answer);
			  }

			  $answerWithSpaces=trim($answer);
			  $correctAnswerWithSpaces=trim($correctanswer);

		      if($row->question_type == 2){ //checkbox
		         //(remove whitespace)
		         $answer=preg_replace('/\s+/','',$answer);
		         $correctanswer=preg_replace('/\s+/','',$correctanswer);
		      }

		      //was answer correct?
		      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1 | $row->question_type == 10){
				//answer was correct or question suppressed or heading
			     if( $row->suppressQuestion == 1 ){
			         //still do nothing as question is suppressed
			     }else{
					if( $showCorrect == 1 ){
			     	//show correct answer
			  	 	?>
					<tr>
		    			<th>
	    			   	<div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    				</th>
					</tr>
					<tr>
					    <th>
			      			<div class="Bfquiz_plusOptions">
			      			<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
			      			<?php echo $answerWithSpaces; ?>
			      			<?php echo JText::_("COM_BFQUIZPLUS_WAS_CORRECT"); ?>
			      			<br><br>
			      			<?php echo JHTML::_('content.prepare', $row->solution); ?>
			      	    	</div>
			      		</th>
		      		</tr>
		      		<tr>
		      	   	<td>&nbsp;</td>
		      		</tr>
					<?php
			     	}
			     }
			  }else{

	             //show solution
			  	?>
				<tr>
	    			<th>
	    			   <div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    			</th>
				</tr>
				<tr>
				    <th>
			      		<div class="Bfquiz_plusOptions">
			      		<div class="bfincorrect">
			      		<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
			      		<?php echo $answerWithSpaces; ?>
			      		<?php echo JText::_("COM_BFQUIZPLUS_WAS_INCORRECT"); ?>
			      		<br>
			      		<?php echo JText::_("COM_BFQUIZPLUS_CORRECT_ANSWER_IS"); ?>
			      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
			      		</div>
			      		<br><br>
			      		<?php echo JHTML::_('content.prepare', $row->solution); ?>
			      	    </div>
			      	</th>
		      	</tr>
		      	<tr>
		      	   <td>&nbsp;</td>
		      	</tr>
				<?php

				//now prepare above for email
				$myIncorrect.="\n".JText::_( $row->question ).": \n".JText::_('COM_BFQUIZPLUS_YOUR_ANSWER_OF')."".$answerWithSpaces."".JText::_('COM_BFQUIZPLUS_WAS_INCORRECT')."\n".JText::_('COM_BFQUIZPLUS_CORRECT_ANSWER_IS')."".$correctAnswerWithSpaces."\n\n";
	          }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }

	/**
	 * This is the show incorrect function used by the random question pool
	 *
	 * @param int	$id			id number of the row in the answer table
	 * @param int	$table		answer table
	 * @param array	$randompool	array of questions selected from the question pool for this quiz
	 *
	 * @return	string	details about the incorrect answers.
	 */
	function showIncorrectPool($id,$table,$randompool){
		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config = $menu->getParams( $Itemid );

		$showIncorrect = $config->get( 'showIncorrect' );
		$showCorrect = $config->get( 'showCorrect' );
		$myIncorrect = ""; //for email

	    if($showIncorrect){
		   $total_qns=count( $randompool );

		   echo '<table width="100%">';

		   for ($i=0; $i < $total_qns; $i++)
		   {
		      $qid = $randompool[$i];
		      $result = Bfquiz_plusController::getQuestionDetails($qid);
		      $row = &$result[0];
		      //$fieldName = $row->field_name;

			  $numanswers=0;
			  //special case for checkbox question type
			  if($row->question_type == 2){
			     //how many correct answers?
				 $numanswers=(int)($row->answer1)+(int)($row->answer2)+(int)($row->answer3)+(int)($row->answer4)+(int)($row->answer5)+(int)($row->answer6)+(int)($row->answer7)+(int)($row->answer8)+(int)($row->answer9)+(int)($row->answer10)+(int)($row->answer11)+(int)($row->answer12)+(int)($row->answer13)+(int)($row->answer14)+(int)($row->answer15)+(int)($row->answer16)+(int)($row->answer17)+(int)($row->answer18)+(int)($row->answer19)+(int)($row->answer20);
			  }

			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($row->$tempvalue == 1){
			        $correctanswer .= $row->$tempvalue2;
			        if($numanswers > 1){
			           $correctanswer.=" "; //add space between correct answers
			        }
			     }
			  }

			  $fieldName="answer".($i+1);
		      //get answer
			  $answer=Bfquiz_plusController::getField($id,$fieldName,$table);

			  $answerWithSpaces=trim($answer);
			  $correctAnswerWithSpaces=trim($correctanswer);

		      if($row->question_type == 2){ //checkbox
		         //(remove whitespace)
		         $answer=preg_replace('/\s+/','',$answer);
		         $correctanswer=preg_replace('/\s+/','',$correctanswer);
		      }

			  //was answer correct?
		      if(trim(strtoupper($answer))==trim(strtoupper($correctanswer)) | $row->suppressQuestion == 1  | $row->question_type == 10){
				 //answer was correct or question suppressed or heading
			     if( $row->suppressQuestion == 1 ){
			         //still do nothing as question is suppressed
			     }else{
					if( $showCorrect == 1 ){
			     	//show correct answer
			  	 	?>
					<tr>
		    			<th>
	    			   	<div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    				</th>
					</tr>
					<tr>
					    <th>
			      			<div class="Bfquiz_plusOptions">
			      			<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
			      			<?php echo $answerWithSpaces; ?>
			      			<?php echo JText::_("COM_BFQUIZPLUS_WAS_CORRECT"); ?>
			      			<br><br>
			      			<?php echo JHTML::_('content.prepare', $row->solution); ?>
			      	    	</div>
			      		</th>
		      		</tr>
		      		<tr>
		      	   	<td>&nbsp;</td>
		      		</tr>
					<?php
			     	}
			     }
			  }else{
				 //first one
				 if($i==0){
				    ?>
				    <div class="Bfquiz_plusOptions">
				    <?php echo JText::_( "COM_BFQUIZPLUS_INCORRECT_ANSWERS" ); ?></div>
				    <br>
				    <?php
				 }

	             //show solution
			  	 ?>
				<tr>
	    			<th>
	    			   <div class="Bfquiz_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    			</th>
				</tr>
				<tr>
				    <th>
			      		<div class="Bfquiz_plusOptions">
			      		<font color="red">
			      		<?php echo JText::_("COM_BFQUIZPLUS_YOUR_ANSWER_OF"); ?>
			      		<?php echo $answerWithSpaces; ?>
			      		<?php echo JText::_("COM_BFQUIZPLUS_WAS_INCORRECT"); ?>
			      		<br>
			      		<?php echo JText::_("COM_BFQUIZPLUS_CORRECT_ANSWER_IS"); ?>
			      		<strong><?php echo $correctAnswerWithSpaces; ?></strong>
			      		</font>
			      		<br><br>
			      		<?php echo JHTML::_('content.prepare', $row->solution); ?>
			      	    </div>
			      	</th>
		      	</tr>
		      	<tr>
		      	   <td>&nbsp;</td>
		      	</tr>
				<?php

				//now prepare above for email
				$myIncorrect.="<br>".JText::_( $row->question ).": <br>".JText::_('COM_BFQUIZPLUS_YOUR_ANSWER_OF')." ".$answerWithSpaces." ".JText::_('COM_BFQUIZPLUS_WAS_INCORRECT')."<br>".JText::_('COM_BFQUIZPLUS_CORRECT_ANSWER_IS')." ".$correctAnswerWithSpaces."<br><br>";
	          }
	       }
	    }else{
	       // do nothing - show incorrect menu parameter set to no
	    }

	    if($showIncorrect){
	       echo "</table>";
	    }

	    return $myIncorrect;
	 }

	/**
	 * get the fields for a particular question
	 *
	 * @param int $question	id number of question
	 */
	public static function getOneQuestion($question)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get question
		$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('*');
		$query->where('id = '.(int)$question);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

	    return $rows;
    }

    /**
     * Counts how many responses there are in the answer table
     *
     * @param 	int	$catid	id number of the category
     *
     * @return	int			number of responses
     */
	public static function getNumberResponses($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid).' AS a');
		$query->select('a.id');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		$n = count($rows);
		return $n;
	}

	/**
	 * Works out the maximum possible score if all correct answers are selected
	 *
	 * @param 	int $catid	category id number
	 *
	 * @return	int			maximum score
	 */
	public static function getMaxScore($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('*');
		$query->where('a.catid = '.(int)$catid);
		$query->where('(a.state IN (0, 1))');
		$query->order('a.ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		$n = count($rows);

		$maxScore=0;
		for($i=0; $i < $n; $i++){
			$tempMax=0;

			if(is_numeric($rows[$i]->score1)){
				for($z=1; $z < 21; $z++){
					$score = 'score'.$z;
					$tempScore=$rows[$i]->$score;
					if($tempScore > $tempMax){
						$tempMax = $tempScore;
					}
				}
				$maxScore = $maxScore + $tempMax;
			}else{
				$maxScore++; //for ABCD scoring.
			}
		}
		return $maxScore;
	}

	/**
	 * Works out the average score for this quiz so far.
	 *
	 * @param 	int 	$catid
	 *
	 * @return	int		average score
	 */
	public static function getAverageScore($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('*');
		$query->where('a.catid = '.(int)$catid);
		$query->where('(a.state IN (0, 1))');
		$query->order('a.ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$query->clear();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid).' AS a');
		$query->select('*');

		$db->setQuery((string)$query);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$n = count($rows);
		$n2 = count($rows2);

		$table="#__bfquiz_plus";
		$totalScore=0;
		for($i=0; $i < $n2; $i++){
			$totalTempScore=0;

			for($z=0; $z < $n; $z++){
				$fieldName = $rows[$z]->field_name;
				$tempScore = Bfquiz_plusController::getScore($fieldName,$table,$rows2[$i]->$fieldName);
				$totalTempScore = $totalTempScore + $tempScore;
			}
			$totalScore = $totalScore + $totalTempScore;
		}

		if($n2 >0){
			$average = round($totalScore / $n2,2);
		}else{
			$average = 0;
		}

		return $average;
	}

	/**
	 * Works out the highest score so far. Used by the stats view.
	 *
	 * @param 	int 	$catid	id number of the category
	 *
	 * @return	int		highest score
	 */
	public static function getHighestScore($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid).' AS a');
		$query->select('MAX(a.score) as score');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->score;
	}

	/**
	 * works out the lowest score so far
	 *
	 * @param	int	$catid	id number of the category
	 *
	 * @return	int			lowest score
	 */
	public static function getLowestScore($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid).' AS a');
		$query->select('MIN(a.score) as score');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->score;
	}

	/**
	 * See which ABCD answer matrix matches the conditions
	 *
	 * @param string 	$field_name		name of the field
	 * @param string 	$answerSeq		Sequence of answers, eg. BBAACDAB
	 * @param int 		$resultid		id of the row in the answer table
	 * @param string 	$resulttable	table name
	 */
	function checkABCD($field_name,$answerSeq, $resultid, $resulttable){
		//see which answer matrix matches
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get category id
		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('a.catid');
		$query->where('a.field_name = "'.$field_name.'"');

		$db->setQuery((string)$query);
		$result=$db->loadResult();
		$catid=$result;

		//get all ABCD answer matrix for this category
		$query->clear();
		$query->from($db->quoteName('#__bfquiz_plus_matrix').' AS a');
		$query->select('a.*');
		$query->where('a.catid = '.(int)$catid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		//now we need to see if any ABCD answer matrix match

		$n = count($rows);

		$match=0;
		for($z=0; $z < $n; $z++){
			$exactMatch = $rows[$z]->exactMatch;
			$redirectURL = $rows[$z]->redirectURL;
			$resultText = $rows[$z]->resultText;

			if($exactMatch!=""){
				if($answerSeq==$exactMatch){
					//we found a match

					//save matrixid
					Bfquiz_plusController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);

					if($redirectURL==""){
						//no redirect so show resultText
						echo $resultText;
					}else{
						//redirect to the url
						$msg="";
						$app = &JFactory::getApplication();
						$app->redirect( JRoute::_($redirectURL, false), $msg );
					}

					//don't bother looking at other matrix since we found match
					$match=1;
					$z = $n;
				}
			}else{  //no exactMatch set
				//need to see if other condtions match
				$score1 = $rows[$z]->score1;
				$score2 = $rows[$z]->score2;
				$score3 = $rows[$z]->score3;
				$score4 = $rows[$z]->score4;
				$score5 = $rows[$z]->score5;
				$condition1 = $rows[$z]->condition1;
				$condition2 = $rows[$z]->condition2;
				$condition3 = $rows[$z]->condition3;
				$condition4 = $rows[$z]->condition4;
				$condition5 = $rows[$z]->condition5;
				$qty1 = $rows[$z]->qty1;
				$qty2 = $rows[$z]->qty2;
				$qty3 = $rows[$z]->qty3;
				$qty4 = $rows[$z]->qty4;
				$qty5 = $rows[$z]->qty5;
				$operator1 = $rows[$z]->operator1;
				$operator2 = $rows[$z]->operator2;
				$operator3 = $rows[$z]->operator3;
				$operator4 = $rows[$z]->operator4;
				$operator5 = $rows[$z]->operator5;

				$line1=0;
				$line2=0;
				$line3=0;
				$line4=0;
				$line5=0;
				$numlines=0;

				for($i=1; $i < 6; $i++){
					$score="score".$i;
					$line="line".$i;
					$qty="qty".$i;
					$condition="condition".$i;

					if($$score != ""){
						$numlines++;
						//does it match the criteria?
						switch($$condition){
							case 0: if(Bfquiz_plusController::timesFound($answerSeq,$$score) == $$qty){    //is equal to
										$$line=1;
									}else{
										$$line=0;
									}
									break;
							case 1: if(Bfquiz_plusController::timesFound($answerSeq,$$score) < $$qty){    //is less than
										$$line=1;
									}else{
										$$line=0;
									}
									break;
							case 2: if(Bfquiz_plusController::timesFound($answerSeq,$$score) > $$qty){    //is greater than
										$$line=1;
									}else{
										$$line=0;
									}
									break;
							case 3: if(Bfquiz_plusController::timesFound($answerSeq,$$score) != $$qty){    //is not equal to
										$$line=1;
									}else{
										$$line=0;
									}
									break;
							default: $$line=0;
						} // end switch
					}else{
						$i=6; // don't bother checking other lines
					}//end if
				}

				//now need to use operator to combine conditions for each line
				switch($numlines){
					case 5: if($line1==1 & $line2==1 & $line3==1 & $line4==1 & $line5==1){
								$match=1;
							}
							break;
					case 4: if($line1==1 & $line2==1 & $line3==1 & $line4==1){
								$match=1;
							}
							break;
					case 3: if($line1==1 & $line2==1 & $line3==1){
								$match=1;
							}
							break;
					case 2: if($line1==1 & $line2==1){
								$match=1;
							}
							break;
					case 1: if($line1==1){
								$match=1;
							}
							break;
					default: $match=0;
				}

				if($match==1){
					//we found a match

					//save matrixid
					Bfquiz_plusController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);

					if($redirectURL==""){
						//no redirect so show resultText
						echo $resultText;
					}else{
						//redirect to the url
						$msg="";
						$app = &JFactory::getApplication();
						$app->redirect( JRoute::_($redirectURL, false), $msg );
					}
					//don't bother looking at other matrix since we found match
					$match=1;
					$z = $n;
				}
			}// end else exactMatch
		}

		if($match==0){  // no match found, so use default for that category
			//get default ABCD answer matrix for this category
			$query->from($db->quoteName('#__bfquiz_plus_matrix'),' AS a');
			$query->select('a.*');
			$query->where('a.catid = '.(int)$catid);
			$query->where('a.default = 1');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();

			$redirectURL = $rows[0]->redirectURL;
			$resultText = $rows[0]->resultText;

			//save matrixid
			Bfquiz_plusController::saveField($resultid,"matrixid",$rows[0]->id,$resulttable);

			if($redirectURL==""){
				//no redirect so show resultText
				echo $resultText;
			}else{
				//redirect to the url
				$msg="";
				$app = JFactory::getApplication();
				$app->redirect( JRoute::_($redirectURL, false), $msg );
			}
		}
	}

   /**
    * This function returns how many times a character appears in a string.
    *
    * @param string	$searchIn	string to search
    * @param char	$searchFor	character
    *
    * @return	int	number of times character appears
    */
	function timesFound($searchIn, $searchFor){
		$result = 0;

		for($i = 0; $i < strlen($searchIn); $i++)
		{
			if($searchIn[$i] == $searchFor){
				$result++;
			}
		}

		return $result;
	}

   /**
    * Gets the answer sequence, eg. ACBAD. Used for ABCD answer matrix
    *
    * @param 	string	$field_name	Field name selected
    * @param 	string	$answer		Answer selected
    *
    * @return	char	$score		A or B etc.
    */
   function getAnswerSeq($field_name,$answer)
   {
   		   //get answer sequence, eg ACBAD
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('a.id');
		$query->where('a.field_name = "'.$field_name.'"');

		$db->setQuery((string)$query);
		$result=$db->loadResult();
		$id=$result;

		// get answer
		$query->clear();
		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('a.*');
		$query->where('a.id = '.(int)$id);
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$myresult=&$rows[0];
		$score="";

		for ($z=0; $z < 20; $z++){
			$tempoption="option".($z+1);
			$tempscore="score".($z+1);
			if(trim(strtoupper($answer))==trim(strtoupper($myresult->$tempoption))){
				$score=$myresult->$tempscore;
				$z = 20;
			}
		}

		return $score;
	}

	/**
	 * See which score range matrix matches. Used for score range matrix
	 *
	 * @param 	string	$field_name		name of the field
	 * @param 	int		$score			score of the quiz
	 * @param 	int		$resultid		id number of the row in the answer table
	 * @param 	string	$resulttable	answer table name
	 */
	public static function checkscorerange($field_name,$score, $resultid, $resulttable){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get category id
		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('a.catid');
		$query->where('a.field_name = '.$db->quote($field_name));

		$db->setQuery((string)$query);
		$catid=$db->loadResult();

		//get all score ranges matrix for this category
		$query->clear();
		$query->from($db->quoteName('#__bfquiz_plus_scorerange').' AS a');
		//$query->select('a.*');
		$query->select('a.id, a.scoreStart, a.scoreEnd, a.redirectURL, a.resultText');
		$query->where('a.catid = '.(int)$catid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		//now we need to see if any score range matrix match

		$n = count($rows);

		$match=0;
		for($z=0; $z < $n; $z++){
			$scoreStart = $rows[$z]->scoreStart;
			$scoreEnd = $rows[$z]->scoreEnd;
			$redirectURL = $rows[$z]->redirectURL;
			$resultText = $rows[$z]->resultText;

			if($scoreStart == ""){  //no minimum score
				//is score less than max
				if($score <= $scoreEnd){
					//we found a match

					//save matrixid
					Bfquiz_plusController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
					$match=1;
					$z = $n;

					if($redirectURL==""){
						//no redirect so show resultText
						echo $resultText;
					}else{
						//redirect to the url
						$msg="";
						$app = JFactory::getApplication();
						$app->redirect( JRoute::_($redirectURL, false), $msg );
					}
				}
			}

			if($scoreEnd == ""){  //no maximum score
				//is score more than minimum
				if($score >= $scoreStart){
					//we found a match

					//save matrixid
					Bfquiz_plusController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
					$match=1;
					$z = $n;

					if($redirectURL==""){
						//no redirect so show resultText
						echo $resultText;
					}else{
						//redirect to the url
						$msg="";
						$app = JFactory::getApplication();
						$app->redirect( JRoute::_($redirectURL, false), $msg );
					}
				}
			}

			//is score between min & max
			if($score >= $scoreStart & $score <= $scoreEnd){
				//we found a match

				//save matrixid
				Bfquiz_plusController::saveField($resultid,"matrixid",$rows[$z]->id,$resulttable);
				$match=1;
				$z = $n;

				if($redirectURL==""){
					//no redirect so show resultText
					echo $resultText;
				}else{
					//redirect to the url
					$msg="";
					$app = JFactory::getApplication();
					$app->redirect( JRoute::_($redirectURL, false), $msg );
				}
			}
		} // end for

		if($match==0){  // no match found, so use default for that category
			$query->clear();
			//get default score range matrix for this category
			$query->from($db->quoteName('#__bfquiz_plus_scorerange').' AS a');
			//$query->select('a.*');
			$query->select('a.id, a.redirectURL, a.resultText');
			$query->where('a.catid='.(int)$catid);
			$query->where('a.default = 1');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();

			$redirectURL = $rows[0]->redirectURL;
			$resultText = $rows[0]->resultText;

			//save matrixid
			Bfquiz_plusController::saveField($resultid,"matrixid",$rows[0]->id,$resulttable);

			if($redirectURL==""){
				//no redirect so show resultText
				echo $resultText;
			}else{
				//redirect to the url
				$msg="";
				$app = JFactory::getApplication();
				$app->redirect( JRoute::_($redirectURL, false), $msg );
			}
		}
	}

	/**
	* Displays the results of completed quiz for currently logged in user
	*
	* @param	int	$uid	user id of the current user
	* @return	array
	*/
	public static function getmyquizzes($uid)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
   		$app = JFactory::getApplication();
   		$dbtype = $app->getCfg('dbtype');

		//get all quiz category id numbers
		$query->from($db->quoteName('#__categories'));
		$query->select('id,  title');
		$query->where('extension = "com_bfquiz_plus"');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$query->clear();

		$i=0;
		foreach($rows as $row){
			if($i==0){
				//$query->from($db->quoteName('#__bfquizplus_'.(int)$row->id));
				//if($dbtype == 'sqlsrv'){
				//	$query->select('id, uid, CONVERT(NVARCHAR(22), DateReceived, 103) as DateReceived, DateReceived as DateTimeReceived, score, DateCompleted, '.$db->quote( $db->escape( $row->title ), false ).' AS title, DATEDIFF(second, DateReceived, DateCompleted) as TimeTaken');
				//}else{
				//	$query->select('id, uid, DATE_FORMAT(DateReceived,\'%D %M %Y\') as DateReceived, DateReceived as DateTimeReceived, score, DateCompleted, '.$db->quote( $db->escape( $row->title ), false ).' AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken');
				//}
				//$query->where('uid='.(int)$uid );

				//$query->union doesn't work yet, so here's the old way instead
				//This isn't going to work for SQL Server
			    $query .= "SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y') as DateReceived, score, DateCompleted, ".$db->quote( $db->escape( $row->title ), false )." AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken, '".(int)$row->id."' AS catid FROM #__bfquizplus_".(int)$row->id." WHERE uid=".(int)$uid;
			}else{
				//$query->from($db->quoteName('#__bfquizplus_'.(int)$row->id));
		      	//if($dbtype == 'sqlsrv'){
				//	$query->union('id, uid, CONVERT(NVARCHAR(22), DateReceived, 103) as DateReceived, DateReceived as DateTimeReceived, score, DateCompleted, '.$db->quote( $db->escape( $row->title ), false ).' AS title, DATEDIFF(second, DateReceived, DateCompleted) as TimeTaken');
		      	//}else{
		      	//	$query->union('id, uid, DATE_FORMAT(DateReceived,\'%D %M %Y\') as DateReceived, DateReceived as DateTimeReceived, score, DateCompleted, '.$db->quote( $db->escape( $row->title ), false ).' AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken');
		      	//}
				//$query->where('uid='.(int)$uid );

				//$query->union doesn't work yet, so here's the old way instead
				//This isn't going to work for SQL Server
				$query .= " UNION SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y') as DateReceived, score, DateCompleted, ".$db->quote( $db->escape( $row->title ), false )." AS title, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken, '".(int)$row->id."' AS catid FROM #__bfquizplus_".(int)$row->id." WHERE uid=".(int)$uid;
			}
			$i++;
		}

		//$query->order(' DateCompleted DESC');
		$query .= " ORDER BY DateCompleted DESC";

		$db->setQuery((string)$query);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows2;
	}

	/**
	* displays the response of a completed quiz
	* @param	int	$catid	category id number
	* @param	int	$cid	id number of row we are interested in
	*
	* @return	array
	*/
	public static function response($catid,$cid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfquizplus_'.(int)$catid).' AS a');
		$query->select('a.*');
		$query->where('a.id = '.(int)$cid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
	}

	/**
	 * get the number of children questions associated with this parent question
	 *
	 * @param 	int 	$pid	parent id
	 * @return	int				number of children
	 */
	public static function getNumChildren($pid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get category
		$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('catid');
		$query->where('id = '.(int)$pid);

		$db->setQuery((string)$query);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		//find out how many children
		$query->clear();
		$query->from($db->quoteName('#__bfquiz_plus').' AS a');
		$query->select('COUNT(a.id) as count');
		$query->where('(a.state =1)');
		$query->where('a.parent = '.(int)$pid);
		$query->where('a.catid = '.(int)$rows2[0]->catid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->count;
	}

	/**
	 * Get the email template based on the name
	 *
	 * @param 	string 	$title	Name of the email template
	 *
	 * @return	array	Data for that email tempalte
	 */
	public static function getEmailTemplate($title, $catid)
    {
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	  	$query->from($db->quoteName('#__bfquiz_plus_email').' AS a');
		$query->select('a.*,  cc.title AS category_name');
		$query->join('LEFT', '#__categories AS cc ON cc.id = a.catid');
		$query->where('(a.state IN (0, 1))');
		$query->where('a.title = '.$db->quote($title));
		$query->where('a.catid = '.(int) $catid);
		$query->order('a.title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if(!isset($rows[0])){
			//no email for that category, so just pick the first one
			$query->clear();

			$query->from($db->quoteName('#__bfquiz_plus_email').' AS a');
			$query->select('a.*,  cc.title AS category_name');
			$query->join('LEFT', '#__categories AS cc ON cc.id = a.catid');
			$query->where('a.state');
			$query->where('a.title = '.$db->quote($title));
			$query->order('a.title');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
		}

		return $rows;
    }

    /**
     * Send the notification email at completion of quiz
     *
     * @param string	$body			contents of the email
     * @param string	$sendEmailTo	email address to send to
     * @param string	$emailSubject	subject of the email
     */
    static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
    	$conf	= JFactory::getConfig();

    	$mailfrom 	= $conf->get('config.mailfrom');
    	$fromname 	= $conf->get('config.fromname');

    	$emailBody = $body;
    	$mode = 1;

    	JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
    }

	public static function buildAnswerTables(){
		//Automatic Database Table Builder
		$database = JFactory::getDBO();
		$config = JFactory::getConfig();
		$app = JFactory::getApplication();
		$dbtype = $app->getCfg('dbtype');

		$mycategory = bfquiz_plusController::getCategory();

		$db = JFactory::getDBO();
		$app = JFactory::getApplication();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('*');
		$query->where('state = 1');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();
		$debug = "";

		if( sizeof( $mycategory ) ) {
			foreach( $mycategory as $mycat  ) {
				$myid = $mycat->id;
			    $table="#__bfquizplus_".$myid;

			    $result = $database->getTableList();
			    if (!in_array($app->getCfg('dbprefix')."bfquizplus_".$myid, $result)) {
			       //Table does not exist

		           $myFieldsMissing="";
				   for ($i=0, $n=count( $items ); $i < $n; $i++)
				   {
				    	$found=0;
				   		$row = &$items[$i];

						if($row->catid == $myid){
						   if($row->question_type == 10){ //heading
					        	// don't add field for heading question
					       }else{
			 		       		if($app->getCfg('dbtype') == 'sqlsrv'){
					       			$myFieldsMissing.= "[".$row->field_name."] [nvarchar](max),";
					       		}else{
			 			      		$myFieldsMissing.= "`".$row->field_name."` TEXT,";
					       		}
			 			   }
						}
		       		}

		       		if($app->getCfg('dbtype') == 'sqlsrv'){
				       $query="CREATE TABLE [".$table."](
			  			    [id] [bigint] IDENTITY(1,1) NOT NULL,
			      			[Name] [nvarchar](150) NOT NULL,
			      			[Email] [nvarchar](150) NOT NULL,
			      			[uid] [int],
			      			[DateReceived] [datetime] NOT NULL,
			      			[ip] [nvarchar](50) NOT NULL,
							[score] [int],
							[matrixid] [int],
							[answerseq] [nvarchar](255),
							[DateCompleted] [datetime] NOT NULL,
			      			[state] [smallint],
			  			    ".$myFieldsMissing."
							 CONSTRAINT [PK_".$table."_id] PRIMARY KEY CLUSTERED
							(
								[id] ASC
							)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
				    	);";
		       		}else{
				       $query="CREATE TABLE ".$table." (
			  			    `id` int(11) NOT NULL auto_increment,
			      			`Name` varchar(150) default NULL,
			      			`Email` varchar(150) default NULL,
			      			`uid` int(11) NOT NULL default 0,
			      			`DateReceived` datetime NOT NULL,
			      			`ip` varchar(50) default NULL,
			      			`score` int(11) NOT NULL default 0,
			      			`matrixid` int(11) NOT NULL default 0,
			      			`answerseq` varchar(255) default NULL,
			      			`DateCompleted` datetime NOT NULL,
			      			`state` tinyint(3) NOT NULL default '1',
			  			    ".$myFieldsMissing."
			      			PRIMARY KEY  (`id`)
				    	);";
		       		}

			       $db->setQuery( $query );
			       if (!$db->query())
			       {
			    	   return $db->getErrorMsg();
			       }
			       //Finished Table creation


			    }else{
			       //Table already exists
			       $debug .= "<br>Table already exists<br>";

				    $db = JFactory::getDBO();
				    // Grab the fields for the selected table
				    $fields = $db->getTableColumns( $table, true );
				    if( sizeof( $fields ) ) {
				       // We found some fields so let's create the HTML list
				       $options = array();
				       foreach( $fields as $field => $type ) {
					           $options[] = JHTML::_( 'select.option', $field, $field );
				       }

				       //what type of field, eg VARCHAR, INT, DATETIME etc.
					   $fieldType=array();
				       foreach( $fields as $field ) {
					      $fieldType[] = $field;
				       }
				    }

					$debug .= "<br>There are ".count( $items )." items<br>";
					for ($i=0, $n=count( $items ); $i < $n; $i++)
			 		{
		 		    	$found=0;
					    $row = $items[$i];
					    $debug .= "<br>DB Field Name=".$row->field_name."<br>";
					    $myindex=0;
					    if($row->field_name == ""){
					    	return	JText::_('COM_BFQUIZPLUS_BLANK_FIELDNAME');
					    }
					    foreach( $fields as $field => $type ){
				           if ($row->field_name == $field) {
					          $found=1;
					   	   }

					       if($found==0){
					   	      $myindex++;
					   	   }
					    }

			    	    if($found == 1){
					        if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type==""){
					           //do nothing
					        }else{
								if($app->getCfg('dbtype') == 'sqlsrv'){
									switch(strtoupper($row->field_type)){
										case "INT": 	$mytype = "[int]";
														break;
										case "DATE":	$mytype = "[datetime]";
														break;
										case "TINYINT": $mytype = "[smallint]";
														break;
										case "FLOAT":	$mytype = "[numeric](10, 2)";
														break;
										case "DOUBLE":	$mytype = "[numeric]";
														break;
										case "VARCHAR":	$mytype = "[nvarchar](".$row->fieldSize.")";
														break;
										case "TEXT" :	$mytype = "[nvarchar](max)";
														break;
										case "default":	$mytype = "[nvarchar](255)";
									}
						        }else{
						           $mytype = $row->field_type;
						           if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
						           	  if($row->fieldSize==0){
						           	  	$row->fieldSize=255;
						           	  }
						              $mytype = $row->field_type."(".$row->fieldSize.")";
						           }
								}

						        if($app->getCfg('dbtype') == 'sqlsrv'){
					           		$query="ALTER TABLE ".$db->quoteName($table)." ALTER COLUMN [".$row->field_name."] ".$mytype.";";
								}else{
									$query="ALTER TABLE ".$db->quoteName($table)." CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
								}

								$debug .= "<br>Query=".$query."<br>";
					  	    	$db->setQuery( $query );
					  	       	if (!$db->query())
					  	       	{
					  	    		return $db->getErrorMsg();
					  	       	}
						     }
					    }

					    if($row->question_type == 10){ //Heading
					        // don't add field for heading question
					        $found=1;
					    }

			 		    if($found == 0 & $row->catid == $myid){

							if($app->getCfg('dbtype') == 'sqlsrv'){
								$query="ALTER TABLE ".$db->quoteName($table)."
					    			    ADD [".$row->field_name."] [nvarchar](max)
			  					;";
							}else{
								$query="ALTER TABLE ".$db->quoteName($table)."
					    			    ADD `".$row->field_name."` TEXT
			  					;";
							}

						   $debug .= "<br>Query=".$query."<br>";
				  	       $db->setQuery( $query );
				  	       if (!$db->query())
				  	       {
				  	    	   return $db->getErrorMsg();
				  	       }
					    }
			    	}
			    }
			}
		}

		return "";
	}

	public static function getCategory()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, title');
		$query->from('#__categories');
		$query->where('published = 1');
		$query->where('extension = '.$db->quote('com_bfquiz_plus') );
		$query->order('title');
		$db->setQuery((string)$query);
		$options = $db->loadObjectList( );
		return $options;
	}
}
?>
