<?php
/**
 * $Id: controller.php 63 2014-03-04 10:44:40Z tuum $
 * bfquiz_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

/**
 * bfquiz_plus Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusController extends JControllerLegacy
{
	protected $default_view = 'questions';
	/**
	 * Method to display a view.
	 *
	 * @param	boolean			$cachable	If true, the view output will be cached
	 * @param	array			$urlparams	An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
	 *
	 * @return	JController		This object to support chaining.
	 * @since	1.5
	 */
	public function display($cachable = false, $urlparams = false)
	{
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';

		$view		= JRequest::getCmd('view', 'questions');
		$layout 	= JRequest::getCmd('layout', 'default');
		$id			= JRequest::getInt('id');

		// Check for edit form.
		if ($view == 'question' && $layout == 'edit' && !$this->checkEditId('com_bfquiz_plus.edit.question', $id)) {
			// Somehow the person just went to the form - we don't allow that.
			$this->setError(JText::sprintf('JLIB_APPLICATION_ERROR_UNHELD_ID', $id));
			$this->setMessage($this->getError(), 'error');
			$this->setRedirect(JRoute::_('index.php?option=com_bfquiz_plus&view=bfquiz_plus', false));

			return false;
		}

		parent::display();
		bfquiz_plusHelper::displayVersion();

		return $this;
	}

function saveOrder( )
{
	$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
	$app		= JFactory::getApplication();

	// Check for request forgeries
	JRequest::checkToken() or jexit( 'Invalid Token' );

	// Initialize variables
	$db			=& JFactory::getDBO();
	$total		= count( $cid );
	$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
	JArrayHelper::toInteger($order, array(0));

	$row =& JTable::getInstance('question', 'Table');
	$groupings = array();

	// update ordering values
	for( $i=0; $i < $total; $i++ ) {
		$row->load( (int) $cid[$i] );
		// track categories
		$groupings[] = $row->catid;

		if ($row->ordering != $order[$i]) {
			$row->ordering = $order[$i];
			if (!$row->store()) {
				JError::raiseError(500, $db->getErrorMsg() );
			}
		}
	}

	// execute updateOrder for each parent group
	$groupings = array_unique( $groupings );
	foreach ($groupings as $group){
		$row->reorder('catid = '.(int) $group);
	}

	$msg 	= 'New ordering saved';
	$app->redirect( 'index.php?option=com_bfquiz_plus', $msg );
}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('question');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFQUIZPLUS_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFQUIZPLUS_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_bfquiz_plus';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function removematrix()
	{
		$model = $this->getModel('matrixanswer');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFQUIZPLUS_ERROR_DELETING_ABCD' );
		} else {
			$msg = JText::_( 'COM_BFQUIZPLUS_ABCD_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfquiz_plus', $msg );
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function removescorerange()
	{
		$model = $this->getModel('scorerangeanswer');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFQUIZPLUS_ERROR_DELETING_SCORE_RANGE' );
		} else {
			$msg = JText::_( 'COM_BFQUIZPLUS_SCORE_RANGE_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfquiz_plus', $msg );
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('question');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFQUIZPLUS_ERROR_DELETING_QUESTION' );
		} else {
			$msg = JText::_( 'COM_BFQUIZPLUS_QUESTION_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfquiz_plus', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFQUIZPLUS_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfquiz_plus', $msg );
	}

	/**
	  Copies one or more questions
	 */
	function copy()
	{
		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_bfquiz_plus' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		= JFactory::getDBO();

		$table	= JTable::getInstance('question', 'Table');

		$user	= JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->question			= 'Copy of ' . $table->question;
					$table->state			= 0;

					$now = JFactory::getDate();
					$table->date			= $now->toMySQL();
					$table->field_name 			="";

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}else{
					return JError::raiseWarning( 500, $table->getError() );
			    }
			}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFQUIZPLUS_ITEMS_COPIED', $n ) );
	}


	/**
	 * view to allow user to select css file to edit
	 * @return void
	 */
	function chooseCSS()
	{
		JToolBarHelper::title(   JText::_( 'Choose CSS file' ), 'bfquiz_toolbar_title');
		JToolBarHelper::custom( 'edit_css', 'edit', 'edit', 'Edit', true );
		JToolBarHelper::cancel();

		// Initialize some variables
		$option     = JRequest::getCmd('option');
		$template    = JRequest::getVar('id', '', 'method', 'cmd');
		$client        = JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));

		// Determine CSS directory
		$dir = JPATH_SITE.'/components/com_bfquiz_plus/css';

		// List .css files
		jimport('joomla.filesystem.folder');
		$files = JFolder::files($dir, '\.css$', false, false);

		// Set FTP credentials, if given
		jimport('joomla.client.helper');
		JClientHelper::setCredentialsFromRequest('ftp');

		require_once  (JPATH_ADMINISTRATOR.'/components/com_templates/admin.templates.html.php');
        TemplatesView::chooseCSSFiles($template, $dir, $files, $option, $client);
	}

	/**
	 * form to allow user to edit css file
	 * @return void
	 */
	function editCSS()
	      {
	      	  JToolBarHelper::title(   JText::_( 'COM_BFQUIZPLUS_TOOLBAR_EDIT_CSS' ), 'bfquiz_toolbar_title');
	      	  JToolBarHelper::save( 'save_css' );
	      	  JToolBarHelper::cancel();

	          $app		= JFactory::getApplication();

	          // Initialize some variables
	          $option        = JRequest::getCmd('option');
	          $client        = JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfquiz_plus";
	          $filename    = JRequest::getVar('filename', '', 'method', 'cmd');

	          jimport('joomla.filesystem.file');

	          if (JFile::getExt($filename) !== 'css') {
	              $msg = JText::_('COM_BFQUIZPLUS_ERROR_NOT_CSS_FILE');
	              $app->redirect('index.php?option='.$option.'&client='.$client->id.'&task=choose_css&id='.$template, $msg, 'error');
	          }

	          $content = JFile::read($client->path.'/components/'.$template.'/css/'.$filename);

	          if ($content !== false)
	          {
	              // Set FTP credentials, if given
	              jimport('joomla.client.helper');
	              $ftp = JClientHelper::setCredentialsFromRequest('ftp');

	              $content = htmlspecialchars($content, ENT_COMPAT, 'UTF-8');

	              require_once  (JPATH_ADMINISTRATOR.'/components/com_templates/admin.templates.html.php');
	              TemplatesView::editCSSSource($template, $filename, $content, $option, $client, $ftp);
	          }
	          else
	          {
	              $msg = JText::sprintf('COM_BFQUIZPLUS_ERROR_COULD_NOT_OPEN', $client->path.$filename);
	              $app->redirect('index.php?option='.$option.'&client='.$client->id, $msg);
	          }
	      }

			/**
			* save css file changes
			* @return void
			*/
	      function saveCSS()
	      {
	          $app		= JFactory::getApplication();

	          // Check for request forgeries
	          JRequest::checkToken() or jexit( 'Invalid Token' );

	          // Initialize some variables
	          $option            = JRequest::getCmd('option');
	          $client            = JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfquiz_plus";
	          $filename        = JRequest::getVar('filename', '', 'post', 'cmd');
	          $filecontent    = JRequest::getVar('filecontent', '', 'post', 'string', JREQUEST_ALLOWRAW);

	          if (!$template) {
	              $app->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFQUIZPLUS_ERROR_OPERATION_FAILED').': '.JText::_('COM_BFQUIZPLUS_ERROR_NO_TEMPLATE_SPECIFIED'));
	          }

	          if (!$filecontent) {
	              $app->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFQUIZPLUS_ERROR_OPERATION_FAILED').': '.JText::_('COM_BFQUIZPLUS_ERROR_CONTENT_EMPTY'));
	          }

	          // Set FTP credentials, if given
	          jimport('joomla.client.helper');
	          JClientHelper::setCredentialsFromRequest('ftp');
	          $ftp = JClientHelper::getCredentials('ftp');

	          $file = $client->path.'/components/'.$template.'/css/'.$filename;

	          // Try to make the css file writeable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0755')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFQUIZPLUS_ERROR_CSS_NOT_WRITABLE'));
	          }

	          jimport('joomla.filesystem.file');
	          $return = JFile::write($file, $filecontent);

	          // Try to make the css file unwriteable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0555')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFQUIZPLUS_ERROR_CSS_NOT_UNWRITABLE'));
	          }

			  if ($return)
			  {
			      $msg = JText::_( 'COM_BFQUIZPLUS_FILE_SAVED' );
			  }else{
			  	  $msg = JText::_( 'COM_BFQUIZPLUS_ERROR_FAILED_OPEN_FILE' );
			  }


			  $this->setRedirect( JRoute::_('index.php?option=com_bfquiz_plus&task=complete', false), $msg );
      }

	public static function getCategory()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, title');
		$query->from('#__categories');
		$query->where('published = 1');
		$query->where('extension = '.$db->quote('com_bfquiz_plus') );
		$query->order('title');
		$db->setQuery((string)$query);
		$options = $db->loadObjectList( );
		return $options;
	}

	public static function getCategoryPool()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('DISTINCT a.id, b.title');
		$query->from('#__bfquiz_plus_pool AS a');
		$query->join('INNER', '#__categories AS b ON a.catid = b.id');
		$query->where('a.state = 1');
		$db->setQuery((string)$query);
		$options = $db->loadObjectList( );
		return $options;
	}

	public static function getQuestions($catid)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquiz_plus";

	    // get questions
	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where('catid = '.(int)$catid);
		$query->where('(state IN (0, 1))');
		$query->order('ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		return $rows;
	}

	public static function getAnswers($catid)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$catid;

		// get questions
	    $query->from($db->quoteName($table));
		$query->select('*');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		return $rows;
	}

	public static function getStats($fieldName, $response, $catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$catid;

	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where($db->escape( $fieldName ).' = '.$db->quote($db->escape( $response, true )) );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsCheckbox($question, $response, $catid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".$catid;

	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where($db->escape( $question ) .' like '.$db->quote('%'.$db->escape( $response, true ).'%') );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsPool($id, $response, $poolid, $qnsPerQuiz){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$poolid.'_pool';
		$total = 0;

		for($i=1; $i < $qnsPerQuiz+1; $i++){
			$tempqid = "qid".$i;
			$tempanswer = "answer".$i;

			$query->clear();
	    	$query->from($db->quoteName($table));
			$query->select('*');
			$query->where($db->quote($db->escape( $tempqid )).' = '.(int)$id  );
			$query->where($db->quote($tempanswer).' = '.$db->quote( $db->escape( $response ), false )  );

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
			$n = count($rows);

			$total = $total + $n;
		}

		return $total;
	}

	public static function getNumberResponses($catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$catid;

	    $query->from($db->quoteName($table));
		$query->select('id');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	/**
	 * Function to find out the total number of responses in the answer table for random question pool
	 *
	 * @param $poolid	int	id number of the random question pool
	 */
	public static function getNumberResponsesPool($poolid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$poolid.'_pool';

	    $query->from($db->quoteName($table));
		$query->select('id');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);
		return $n;
	}

	public static function getMaxScore($catid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
	    $table="#__bfquiz_plus";

	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where('catid = '.(int)$catid);
		$query->where('(state IN (0, 1))');
		$query->order('ordering');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$n = count($rows);

		$maxScore=0;
		for($i=0; $i < $n; $i++){
			$tempMax=0;
			for($z=0; $z < 20; $z++){
				$score = 'score'.$z;
				if(isset($rows[$i]->$score)){
					$tempScore=$rows[$i]->$score;
					if($tempScore > $tempMax){
						$tempMax = $tempScore;
					}
				}
			}
			$maxScore = $maxScore + $tempMax;
		}

		return $maxScore;
	}

	public static function getScore($field_name,$table,$answer)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	    $query->from($db->quoteName($table));
		$query->select('id');
		$query->where('field_name = '.$db->quote( $field_name));

		$db->setQuery((string)$query);
		$id=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		// get answer
		$query->clear();
	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where('id = '.(int)$id);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$myresult=&$rows[0];
		$score=0;

		// get menu parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');
		$config =  $menu->getParams( $Itemid );

		$scoringMethod = $config->get( 'scoringMethod' );

		$view=JRequest::getVar('view');
		if($view=="stats" & !(is_numeric($myresult->score1))){
			$scoringMethod =1;
		}

		if($scoringMethod == 1){
			$score=1;
		}else{
			if(is_numeric($myresult->score1)){

			$numanswers=0;
			//special case for checkbox question type
			if($myresult->question_type == 2){
				//how many correct answers?
				$numanswers=(int)($myresult->answer1)+(int)($myresult->answer2)+(int)($myresult->answer3)+(int)($myresult->answer4)+(int)($myresult->answer5)+(int)($myresult->answer6)+(int)($myresult->answer7)+(int)($myresult->answer8)+(int)($myresult->answer9)+(int)($myresult->answer10)+(int)($myresult->answer11)+(int)($myresult->answer12)+(int)($myresult->answer13)+(int)($myresult->answer14)+(int)($myresult->answer15)+(int)($myresult->answer16)+(int)($myresult->answer17)+(int)($myresult->answer18)+(int)($myresult->answer19)+(int)($myresult->answer20);
			}

			for ($z=0; $z < 20; $z++){
				$tempoption="option".($z+1);
				$tempscore="score".($z+1);
				if(trim(strtoupper($answer))==trim(strtoupper($myresult->$tempoption))){
					$score=$myresult->$tempscore;
					$z = 20;
				}
			}

	       	//special case for multiple answers
	       	if($numanswers>1){
			  //get correct answer
			  $correctanswer = "";
			  for ($z=0; $z < 20; $z++){
			     $tempvalue="answer".($z+1);
			     $tempvalue2="option".($z+1);
			     if($myresult->$tempvalue == 1){
			        $correctanswer .= $myresult->$tempvalue2;
			        $correctanswer.=" "; //add space between correct answers
			     }
			  }

			  //remove all whitespace
			  $myanswer=preg_replace('/\s+/','',$answer);
		      $correctanswer=preg_replace('/\s+/','',$correctanswer);

	          $score=0;
	          for($i=0; $i < 20; $i++){
	             $myoption="option".($i+1);
	             $myscore="score".($i+1);

	             if($myresult->$myoption){
	                //does answer contain this option
	                $answer=" ".$answer;
	                if(strpos(strtoupper($answer), strtoupper($myresult->$myoption) )){
	                   //only assign score if all correct answers are selected
	                   if(trim(strtoupper($myanswer))==trim(strtoupper($correctanswer)) | $myresult->suppressQuestion == 1){
			              $score=$score+(int)($myresult->$myscore);
			           }
			  	    }
			  	 }
	          }
	       }

		      }else{
		         if($myresult->suppressQuestion == 1){
		            $score=0;
		         }else{
		            echo JText::_("COM_BFQUIZPLUS_ERROR_SCORE_NUMERIC");
		         }
		      }

	       } // end else

		return $score;
	}

	public static function getAverageScore($catid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquiz_plus";
		$table2="#__bfquizplus_".(int)$catid;

	    $query->from($db->quoteName($table));
		$query->select('*');
		$query->where('catid = '.(int)$catid);
		$query->where('(state IN (0, 1))');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query->from($db->quoteName($table2));
		$query->select('*');

	   	$db->setQuery((string)$query);
	   	$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$n = count($rows);
		$n2 = count($rows2);

		$totalScore=0;
		for($i=0; $i < $n2; $i++){
			$totalTempScore=0;

			for($z=0; $z < $n; $z++){
				if($rows[$z]->question_type == 10){
					//do nothing
				}else{
					$fieldName = $rows[$z]->field_name;

					$tempScore = bfquiz_plusController::getScore($fieldName,$table,$rows2[$i]->$fieldName);

					$totalTempScore = $totalTempScore + $tempScore;
				}
			}
			$totalScore = $totalScore + $totalTempScore;
		}

		if($n2 > 0){
			$average = round($totalScore / $n2,2);
		}else{
			$average=0;
		}

		return $average;
	}

	/**
	 * Gets the average score for this random question pool
	 *
	 * @param 	int $poolid		The id of the random question pool
	 *
	 * @return	int	$average
	 */
	public static function getAverageScorePool($poolid){
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$poolid."_pool";

	    $query->from($db->quoteName($table));
		$query->select('*');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$totalScore=0;
		$n = count($rows);
		for($z=0; $z < $n; $z++){
			$tempScore = $rows[$z]->score;

			$totalScore = $totalScore + $tempScore;
		}

		if($n > 0){
			$average = round($totalScore / $n,2);
		}else{
			$average=0;
		}

		return $average;
	}


	public static function getHighestScore($catid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquiz_plus";
		$table2="#__bfquizplus_".(int)$catid;

		$query->from($db->quoteName($table));
		$query->select('*');
		$query->where('catid = '.(int)$catid);
		$query->where('(state IN (0, 1))');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query->from($db->quoteName($table2));
		$query->select('*');

	   	$db->setQuery((string)$query);
	   	$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$n = count($rows);
		$n2 = count($rows2);

		$highScore=0;
		for($i=0; $i < $n2; $i++){
			$totalTempScore=0;

			for($z=0; $z < $n; $z++){
				if($rows[$z]->question_type == 10){
					//do nothing
				}else{
					$fieldName = $rows[$z]->field_name;

					$tempScore = bfquiz_plusController::getScore($fieldName,$table,$rows2[$i]->$fieldName);

					$totalTempScore = $totalTempScore + $tempScore;
				}
			}
			if($totalTempScore > $highScore){
				$highScore = $totalTempScore;
			}
		}

		return $highScore;
	}

	/**
	 * Gets the maximum score so far in the question pool
	 *
	 * @param 	int $poolid		ID of the random question pool
	 * @return	int	$maxscore
	 */
	public static function getHighestScorePool($poolid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$poolid."_pool";

	    $query->from($db->quoteName($table));
		$query->select('MAX(score) AS maxscore');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

	   return $rows[0]->maxscore;
	}

	public static function getLowestScore($catid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquiz_plus";
		$table2="#__bfquizplus_".(int)$catid;

		$query->from($db->quoteName($table));
		$query->select('*');
		$query->where('catid = '.(int)$catid);
		$query->where('(state IN (0, 1))');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query->from($db->quoteName($table2));
		$query->select('*');

	   	$db->setQuery((string)$query);
	   	$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$n = count($rows);
		$n2 = count($rows2);

		$lowScore=0;
		for($i=0; $i < $n2; $i++){
			$totalTempScore=0;

			for($z=0; $z < $n; $z++){
				if($rows[$z]->question_type == 10){
					//do nothing
				}else{
					$fieldName = $rows[$z]->field_name;

					$tempScore = bfquiz_plusController::getScore($fieldName,$table,$rows2[$i]->$fieldName);

					$totalTempScore = $totalTempScore + $tempScore;
				}
			}

			if($i==0){
				$lowScore = $totalTempScore;
			}

			if($totalTempScore < $lowScore){
				$lowScore = $totalTempScore;
			}
		}

		return $lowScore;
	}

	/**
	 * Gets the lowest score so far in the question pool
	 *
	 * @param 	int $poolid		ID of the random question pool
	 * @return	int	$minscore
	 */
	public static function getLowestScorePool($poolid){
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquizplus_".(int)$poolid."_pool";

	    $query->from($db->quoteName($table));
		$query->select('MIN(score) AS minscore');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows[0]->minscore;
	}

/**
* Moves the record up one position
*/
function moveUpMatrix(  ) {
	bfquiz_plusController::orderMatrix( -1 );
}

/**
* Moves the record down one position
*/
function moveDownMatrix(  ) {
	bfquiz_plusController::orderMatrix( 1 );
}

/**
* Moves the order of a record
* @param integer The direction to reorder, +1 down, -1 up
*/
function orderMatrix( $inc )
{
	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfquiz_plus/tables');
	$row = JTable::getInstance('matrix', 'Table');

	$db		= JFactory::getDBO();
	$cid	= JRequest::getVar('cid', array(0), '', 'array');
	$option = JRequest::getCmd('option');
	JArrayHelper::toInteger($cid, array(0));

	$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
	$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
	$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

	$row = JTable::getInstance( 'matrix', 'Table' );
	$row->load( $cid[0] );
	$row->move( $inc, 'catid = '.(int) $row->catid.' AND state != 0' );

	$app->redirect( 'index.php?option='. $option. "&controller=matrix&task=matrix" );
}

/**
* Moves the record up one position
*/
function moveUpscorerange(  ) {
	bfquiz_plusController::orderscorerange( -1 );
}

/**
* Moves the record down one position
*/
function moveDownscorerange(  ) {
	bfquiz_plusController::orderscorerange( 1 );
}

/**
* Moves the order of a record
* @param integer The direction to reorder, +1 down, -1 up
*/
function orderscorerange( $inc )
{
	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfquiz_plus/tables');
	$row = JTable::getInstance('scorerange', 'Table');

	$db		= JFactory::getDBO();
	$cid	= JRequest::getVar('cid', array(0), '', 'array');
	$option = JRequest::getCmd('option');
	JArrayHelper::toInteger($cid, array(0));

	$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
	$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
	$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

	$row = JTable::getInstance( 'scorerange', 'Table' );
	$row->load( $cid[0] );
	$row->move( $inc, 'catid = '.(int) $row->catid.' AND state != 0' );

	$app->redirect( 'index.php?option='. $option. "&controller=scorerange&task=scorerange" );
}


 	/**********************************************************************************
    * This function will search through your answer table for fields that don't have
    * associated questions, and will automatically detele them.
    * Used by maintenance view.
    **********************************************************************************/
	function dbcleanup(){
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';
		bfquiz_plusHelper::addSubmenu('maintenance');

		JToolBarHelper::title( JText::_( 'COM_BFQUIZPLUS_TOOLBAR_MAINTENANCE' ), 'bfquiz_toolbar_title' );

	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfquiz_plus";

	   	//first get all the categories
		$query->select('DISTINCT catid');
	    $query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows1 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		// get field names and categories
		$query->clear();
		$query->select('field_name, catid, question_type');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

       for($n=0;$n < count($rows1); $n++){
          $row1 = &$rows1[$n];
          $table2="#__bfquizplus_".(int)$row1->catid;

          echo $table2."<br>";

          //now get the fields for the selected table
		  $fields = $db->getTableColumns( $table2, true );

		  if(!$fields){
	         global $mainframe;
		     JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_WARNING_TABLE').$table2.JText::_('COM_BFQUIZPLUS_WARNING_NO_FIELDS') );
		     JError::raiseNotice( 500, JText::_('COM_BFQUIZPLUS_WARNING_IGNORE_BELOW') );
		     return null;
	      }

   	      if( sizeof( $fields ) ) {
            // We found some fields so let's create the list
            $options = array();
            foreach( $fields as $field => $type ) {
            	$options[] = $field;

            	//now is there a question associated with this field?
            	$found=0;
            	for($i=0;$i < count($rows); $i++){
					$row = &$rows[$i];

				 	if($row->catid == $row1->catid){ // is this question in the same category
						if($row->field_name == $field | $field == "id" | $field == "Name" | $field == "Email" | $field == "DateReceived" | $field == "ip" | $field == "uid" | $field == "score" | $field == "matrixid" | $field == "answerseq" | $field == "DateCompleted" | $field == "state"){
						   $found=1;
						   $i=count($rows);
						}
					}
	      		}

	      		if($found==0){
	      		   echo JText::_( "COM_BFQUIZPLUS_ERROR_CANT_FIND_FIELD");
	      		   echo ' ';
	      		   echo $field;
	      		   $query="ALTER TABLE ".$db->quoteName($table2)." DROP ".$field;
	      		   $db->setQuery( $query );
				   if (!$db->query())
				   {
				   	   echo $db->getErrorMsg();
				   	   return false;
				   }
				   ?>
				   <br>
				   <?php
	               echo JText::_( "COM_BFQUIZPLUS_ERROR_FIELD");
	               echo $field;
	               echo JText::_( "COM_BFQUIZPLUS_ERROR_HAS_BEEN_DELETED");
	               echo $table2;
	               ?>
	               <br>
	               <?php
	      		}

      		}
   		  }

	   }

	   echo JText::_( "COM_BFQUIZPLUS_FINISHED_DB_CLEANUP");
	}

   /**********************************************************************************
    * This function will backup your BF Quiz Plus tables
    **********************************************************************************/
	function dbbackup(){
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';
		bfquiz_plusHelper::addSubmenu('maintenance');

		JToolBarHelper::title( JText::_( 'COM_BFQUIZPLUS_TOOLBAR_MAINTENANCE' ), 'bfquiz_toolbar_title' );

		$table="#__bfquiz_plus";

		$myExport = bfquiz_plusController::exportMyTable($table);

		$db = JFactory::getDBO();

		//get all quiz category id numbers
		$query = "SELECT id, title FROM `#__categories` WHERE `extension`='com_bfquiz_plus'";

		$db->setQuery( $query );
		$rows = $db->loadObjectList();

		if($rows){
			foreach($rows as $row){
				$table="#__bfquizplus_".(int)$row->id;
				$myExport .= "\n";
				$myExport .= bfquiz_plusController::exportMyTable($table);
			}
		}

		//get all random question pools
		$query = "SELECT id FROM `#__bfquiz_plus_pool`";

		$db->setQuery( $query );
		$rows2 = $db->loadObjectList();

		if($rows2){
			foreach($rows2 as $row){
				$table="#__bfquizplus_".(int)$row->id."_pool";
				$myExport .= "\n";
				$myExport .= bfquiz_plusController::exportMyTable($table);
			}
		}

		$table="#__bfquiz_plus_scorerange";
		$myExport .= "\n";
		$myExport .= bfquiz_plusController::exportMyTable($table);

		$table="#__bfquiz_plus_pool";
		$myExport .= "\n";
		$myExport .= bfquiz_plusController::exportMyTable($table);

		$table="#__bfquiz_plus_matrix";
		$myExport .= "\n";
		$myExport .= bfquiz_plusController::exportMyTable($table);

		$table="#__bfquiz_plus_email";
		$myExport .= "\n";
		$myExport .= bfquiz_plusController::exportMyTable($table);

		echo JText::_( 'COM_BFQUIZPLUS_BACKUP_PREPARED' );
		echo "<br>";

		// excel export
		print '<form id="mySQLExport" name="mySQLExport" method="POST" action="./components/com_bfquiz_plus/mysqlexport.php">';

		print '<DIV ID="myExport" style="display:none;"><textarea name="myExport">'.$myExport.'</textarea></div>';

		?>
		<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'Save backup to file' ); ?>" />
		<?php
		print "</form>";
	}

   function exportMyTable($table){
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
       // Get the structure of the question table
	   $mytable = $db->getTableCreate( $table );

	   if(!$mytable){
		  JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_WARNING_TABLE').$table.JText::_('COM_BFQUIZPLUS_WARNING_NO_FIELDS') );
		  JError::raiseNotice( 500, JText::_('COM_BFQUIZPLUS_WARNING_IGNORE_BELOW') );
		  return null;
	   }

	   // Grab the fields for the selected table
	   $fields = $db->getTableColumns( $table, true );

	   //now get the question data
		$query->select('*');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows = $db->loadRowList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

	   $myfields=array_values($fields);

	   $d=null;
	   foreach($rows as $cr){
	      $d .= "INSERT INTO " . $db->quoteName($table) . " VALUES (";
	      for($i=0; $i<sizeof($cr); $i++){
	         $myfield=$myfields[$i];
	         if($cr[$i] == ''){
	            if($myfield == "tinyint" | $myfield == "int"){
	               $d .= "0,";
	            }else{
	               $d .= "'',";
	            }
	         }else{
	            //add delimited before apostrophe
	            $d .= "'".addcslashes($cr[$i],"'")."',";
	         }
	      }

	      $d = substr($d, 0, strlen($d) - 1);
	      $d .= ");\n";
	   }

	   $myexport= $mytable[$table];
	   $myexport.=";\n\n";
	   $myexport .=$d;

	   return $myexport;
   }

	public static function exportMysqlToCsv($sql_query,$filename = 'export.csv')
	{
	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    $csv_enclosed = '"';
	    $csv_escaped = "\\";

		$app = JFactory::getApplication();
		$host = $app->getCfg('host');
		$db = $app->getCfg('db');
		$user = $app->getCfg('user');
		$password = $app->getCfg('password');
		$dbtype = $app->getCfg('dbtype');

	    // Gets the data from the database
		if($dbtype == 'mysqli'){
			$link = mysqli_connect($host, $user, $password, $db);
			@mysqli_query($link, 'set character set "utf8"');
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$result = mysqli_query($link, $sql_query);
		}else if($dbtype == 'sqlsrv'){
			$config = array(
				'Database' => $db,
				'uid' => $user,
				'pwd' => $password,
				'CharacterSet' => 'UTF-8',
				'ReturnDatesAsStrings' => true);

			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$link = sqlsrv_connect($host, $config);
			$result = sqlsrv_query($link, $sql_query);
			if( $result === false ) {
     			die( print_r( sqlsrv_errors(), true));
			}
			$fields_cnt = sqlsrv_num_fields($result);
		}else{
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
	    	$result = mysql_query($sql_query);
	    	$fields_cnt = mysql_num_fields($result);
		}

	    $schema_insert = '';

		if($dbtype == 'mysqli'){
			$fields = mysqli_fetch_fields($result);
			$i=0;
			foreach ($fields as $field) {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes($field->name)) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		        $i++;
			}
			$fields_cnt = $i;
		}else if($dbtype == 'sqlsrv'){
			//this bit just really doesnt work with SQL server.
			//todo - fix CSV export for SQLSRV

			if( sqlsrv_fetch( $result ) === false )
			{
			     echo "Error in retrieving row.\n";
			     die( print_r( sqlsrv_errors(), true));
			}
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(sqlsrv_get_field( $result, $i) )) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}else{
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}

	    $out = trim(substr($schema_insert, 0, -1));
	    $out .= $csv_terminated;

	    // Format the data
	    if($dbtype == 'sqlsrv'){
	    	$row = sqlsrv_fetch_array($result);
	    }else{
	    	$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
		}

	    while ($row)
	    {
	        $schema_insert = '';
	        for ($j = 0; $j < $fields_cnt; $j++)
	        {
	            if ($row[$j] == '0' || $row[$j] != '')
	            {

	                if ($csv_enclosed == '')
	                {
	                    $schema_insert .= $row[$j];
	                } else
	                {
	                    $schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
	                }
	            } else
	            {
	                $schema_insert .= '';
	            }

	            if ($j < $fields_cnt - 1)
	            {
	                $schema_insert .= $csv_separator;
	            }
	        } // end for

	        $out .= $schema_insert;
	        $out .= $csv_terminated;

			if($dbtype == 'sqlsrv'){
				$row = sqlsrv_fetch_array($result);
			}else{
				$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
			}
	    } // end while

	    header("Content-Length: " . strlen($out));
	    // Output to browser with appropriate mime type, you choose ;)
	    header('Content-Encoding: UTF-8');
		header('Content-type: text/csv; charset=UTF-8');
	   	header("Pragma: no-cache");
		header("Expires: 0");
	    header("Content-Disposition: attachment; filename=$filename");
	    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	    echo $out;
	    exit;

   }

	/*
	 * This funciton updates your database table from BF Quiz to BF Quiz Plus
	 */
	function importQuestions(){
		$db = JFactory::getDbo();

		$query = "RENAME TABLE `#__bfquiz_plus` TO `#__bfquiz_plus.old`";

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfquiz`

			ADD `archived` tinyint(1) NOT NULL DEFAULT '0',
			ADD `approved` tinyint(1) NOT NULL DEFAULT '1',
			ADD `access` int(11) NOT NULL DEFAULT '1',
			ADD `language` char(7) NOT NULL DEFAULT '',
			ADD `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `created_by` int(10) unsigned NOT NULL DEFAULT '0',
			ADD `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
			ADD `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			ADD `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfquiz` CHANGE `published` `state` tinyint(3) NOT NULL default '0';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "RENAME TABLE `#__bfquiz` TO `#__bfquiz_plus`;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$this->setRedirect(JRoute::_('index.php?option=com_bfquiz_plus&view=maintenance', false));
	}

	public static function buildAnswerTables(){
		//Automatic Database Table Builder
		$database = JFactory::getDBO();
		$config = JFactory::getConfig();
		$app = JFactory::getApplication();
		$dbtype = $app->getCfg('dbtype');

		$mycategory = bfquiz_plusController::getCategory();

		$db = JFactory::getDBO();
		$app = JFactory::getApplication();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfquiz_plus'));
		$query->select('*');
		$query->where('state = 1');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();
		$debug = "";

		if( sizeof( $mycategory ) ) {
			foreach( $mycategory as $mycat  ) {
				$myid = $mycat->id;
			    $table="#__bfquizplus_".$myid;

			    $result = $database->getTableList();
			    if (!in_array($app->getCfg('dbprefix')."bfquizplus_".$myid, $result)) {
			       //Table does not exist

		           $myFieldsMissing="";
				   for ($i=0, $n=count( $items ); $i < $n; $i++)
				   {
				    	$found=0;
				   		$row = &$items[$i];

						if($row->catid == $myid){
						   if($row->question_type == 10){ //heading
					        	// don't add field for heading question
					       }else{
			 		       		if($app->getCfg('dbtype') == 'sqlsrv'){
					       			$myFieldsMissing.= "[".$row->field_name."] [nvarchar](max),";
					       		}else{
			 			      		$myFieldsMissing.= "`".$row->field_name."` TEXT,";
					       		}
			 			   }
						}
		       		}

		       		if($app->getCfg('dbtype') == 'sqlsrv'){
				       $query="CREATE TABLE [".$table."](
			  			    [id] [bigint] IDENTITY(1,1) NOT NULL,
			      			[Name] [nvarchar](150) NOT NULL,
			      			[Email] [nvarchar](150) NOT NULL,
			      			[uid] [int],
			      			[DateReceived] [datetime] NOT NULL,
			      			[ip] [nvarchar](50) NOT NULL,
							[score] [int],
							[matrixid] [int],
							[answerseq] [nvarchar](255),
							[DateCompleted] [datetime] NOT NULL,
			      			[state] [smallint],
			  			    ".$myFieldsMissing."
							 CONSTRAINT [PK_".$table."_id] PRIMARY KEY CLUSTERED
							(
								[id] ASC
							)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
				    	);";
		       		}else{
				       $query="CREATE TABLE ".$table." (
			  			    `id` int(11) NOT NULL auto_increment,
			      			`Name` varchar(150) default NULL,
			      			`Email` varchar(150) default NULL,
			      			`uid` int(11) NOT NULL default 0,
			      			`DateReceived` datetime NOT NULL,
			      			`ip` varchar(50) default NULL,
			      			`score` int(11) NOT NULL default 0,
			      			`matrixid` int(11) NOT NULL default 0,
			      			`answerseq` varchar(255) default NULL,
			      			`DateCompleted` datetime NOT NULL,
			      			`state` tinyint(3) NOT NULL default '1',
			  			    ".$myFieldsMissing."
			      			PRIMARY KEY  (`id`)
				    	);";
		       		}

			       $db->setQuery( $query );
			       if (!$db->query())
			       {
			    	   return $db->getErrorMsg();
			       }
			       //Finished Table creation


			    }else{
			       //Table already exists
			       $debug .= "<br>Table already exists<br>";

				    $db = JFactory::getDBO();
				    // Grab the fields for the selected table
				    $fields = $db->getTableColumns( $table, true );
				    if( sizeof( $fields ) ) {
				       // We found some fields so let's create the HTML list
				       $options = array();
				       foreach( $fields as $field => $type ) {
					           $options[] = JHTML::_( 'select.option', $field, $field );
				       }

				       //what type of field, eg VARCHAR, INT, DATETIME etc.
					   $fieldType=array();
				       foreach( $fields as $field ) {
					      $fieldType[] = $field;
				       }
				    }

					$debug .= "<br>There are ".count( $items )." items<br>";
					for ($i=0, $n=count( $items ); $i < $n; $i++)
			 		{
		 		    	$found=0;
					    $row = $items[$i];
					    $debug .= "<br>DB Field Name=".$row->field_name."<br>";
					    $myindex=0;
					    if($row->field_name == ""){
					    	return	JText::_('COM_BFQUIZPLUS_BLANK_FIELDNAME');
					    }
					    foreach( $fields as $field => $type ){
				           if ($row->field_name == $field) {
					          $found=1;
					   	   }

					       if($found==0){
					   	      $myindex++;
					   	   }
					    }

			    	    if($found == 1){
					        if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type==""){
					           //do nothing
					        }else{
								if($app->getCfg('dbtype') == 'sqlsrv'){
									switch(strtoupper($row->field_type)){
										case "INT": 	$mytype = "[int]";
														break;
										case "DATE":	$mytype = "[datetime]";
														break;
										case "TINYINT": $mytype = "[smallint]";
														break;
										case "FLOAT":	$mytype = "[numeric](10, 2)";
														break;
										case "DOUBLE":	$mytype = "[numeric]";
														break;
										case "VARCHAR":	$mytype = "[nvarchar](".$row->fieldSize.")";
														break;
										case "TEXT" :	$mytype = "[nvarchar](max)";
														break;
										case "default":	$mytype = "[nvarchar](255)";
									}
						        }else{
						           $mytype = $row->field_type;
						           if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
						           	  if($row->fieldSize==0){
						           	  	$row->fieldSize=255;
						           	  }
						              $mytype = $row->field_type."(".$row->fieldSize.")";
						           }
								}

						        if($app->getCfg('dbtype') == 'sqlsrv'){
					           		$query="ALTER TABLE ".$db->quoteName($table)." ALTER COLUMN [".$row->field_name."] ".$mytype.";";
								}else{
									$query="ALTER TABLE ".$db->quoteName($table)." CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
								}

								$debug .= "<br>Query=".$query."<br>";
					  	    	$db->setQuery( $query );
					  	       	if (!$db->query())
					  	       	{
					  	    		return $db->getErrorMsg();
					  	       	}
						     }
					    }

					    if($row->question_type == 10){ //Heading
					        // don't add field for heading question
					        $found=1;
					    }

			 		    if($found == 0 & $row->catid == $myid){

							if($app->getCfg('dbtype') == 'sqlsrv'){
								$query="ALTER TABLE ".$db->quoteName($table)."
					    			    ADD [".$row->field_name."] [nvarchar](max)
			  					;";
							}else{
								$query="ALTER TABLE ".$db->quoteName($table)."
					    			    ADD `".$row->field_name."` TEXT
			  					;";
							}

						   $debug .= "<br>Query=".$query."<br>";
				  	       $db->setQuery( $query );
				  	       if (!$db->query())
				  	       {
				  	    	   return $db->getErrorMsg();
				  	       }
					    }
			    	}
			    }
			}
		}

		return "";
	}

	function importTrial(){

		echo "<br>This script will import BF Quiz Plus Trial questions to full version<br>";

		$db = JFactory::getDbo();

		$query = "RENAME TABLE `#__bfquiz_plus` TO `#__bfquiz_plus_old`";

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "RENAME TABLE `#__bfquiz_plustrial` TO `#__bfquiz_plus`;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "UPDATE test_categories set `extension` = 'com_bfquiz_plus' where `extension` = 'com_bfquiz_plustrial'";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		echo "<br>Import finished<br>";
	}

}
?>
