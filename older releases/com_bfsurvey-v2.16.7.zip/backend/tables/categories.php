<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyTableCategories extends F0FTable
{
	function __construct( $table, $key, &$db )
	{
		$this->key = 'bfsurvey_category_id';
		parent::__construct('#__bfsurvey_categories', $this->key, $db);
		$this->typeAlias = 'com_bfsurvey.category';
	}

	/**
	 * Copy (duplicate) one or more records
	 *
	 * @param   integer|array  $cid  The primary key value (or values) or the record(s) to copy
	 *
	 * @return  boolean  True on success
	 */
	public function copy($cid = null)
	{
		//We have to cast the id as array, or the helper function will return an empty set
		if($cid)
		{
			$cid = (array) $cid;
		}

		JArrayHelper::toInteger($cid);
		$k = $this->_tbl_key;

		if (count($cid) < 1)
		{
			if ($this->$k)
			{
				$cid = array($this->$k);
			}
			else
			{
				$this->setError("No items selected.");

				return false;
			}
		}

		$created_by  = $this->getColumnAlias('created_by');
		$created_on  = $this->getColumnAlias('created_on');
		$modified_by = $this->getColumnAlias('modified_by');
		$modified_on = $this->getColumnAlias('modified_on');

		$locked_byName = $this->getColumnAlias('locked_by');
		$checkin       = in_array($locked_byName, $this->getKnownFields());

		foreach ($cid as $item)
		{
			// Prevent load with id = 0

			if (!$item)
			{
				continue;
			}

			$this->load($item);

			// TODO Should we notify the user that we had a problem with this record?
			if (!$this->onBeforeCopy($item))
			{
				continue;
			}

			$this->$k           = null;
			$this->$created_by  = null;
			$this->$created_on  = null;
			$this->$modified_on = null;
			$this->$modified_by = null;

			$this->title = JText::_('COM_BFSURVEY_COPY_OF').' '. $this->title;
			//$this->enabled = 0;

			// Let's fire the event only if everything is ok
			// TODO Should we notify the user that we had a problem with this record?
			if ($this->store())
			{
				//get the maximum ordering
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__bfsurvey_questions');
				$max = $db->loadResult();

				//now lets copy all the questions for that category
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);
				$query->from($db->quoteName('#__bfsurvey_questions'));
				$query->select('*');
				$query->where('bfsurvey_category_id = '.(int)$item);

				$db->setQuery((string)$query);
				$myquestions = $db->loadObjectList();

				foreach($myquestions as $row){
					$query	= $db->getQuery(true);

					$query->insert('#__bfsurvey_questions');
					$query->columns(array($db->quoteName('bfsurvey_category_id'),
							$db->quoteName('title'),
							$db->quoteName('slug'),
							$db->quoteName('question_type'),
							$db->quoteName('parent'),
							$db->quoteName('option1'),
							$db->quoteName('option2'),
							$db->quoteName('option3'),
							$db->quoteName('option4'),
							$db->quoteName('option5'),
							$db->quoteName('option6'),
							$db->quoteName('option7'),
							$db->quoteName('option8'),
							$db->quoteName('option9'),
							$db->quoteName('option10'),
							$db->quoteName('option11'),
							$db->quoteName('option12'),
							$db->quoteName('option13'),
							$db->quoteName('option14'),
							$db->quoteName('option15'),
							$db->quoteName('option16'),
							$db->quoteName('option17'),
							$db->quoteName('option18'),
							$db->quoteName('option19'),
							$db->quoteName('option20'),
							$db->quoteName('prefix'),
							$db->quoteName('suffix'),
							$db->quoteName('field_name'),
							$db->quoteName('field_type'),
							$db->quoteName('fieldSize'),
							$db->quoteName('mandatory'),
							$db->quoteName('validation_rule'),
							$db->quoteName('helpText'),
							$db->quoteName('sql'),
							$db->quoteName('key_field'),
							$db->quoteName('value_field'),
							$db->quoteName('titles'),
							$db->quoteName('horizontal'),
							$db->quoteName('otherprefix'),
							$db->quoteName('othersuffix'),
							$db->quoteName('suppressQuestion'),
							$db->quoteName('image1'),
							$db->quoteName('image2'),
							$db->quoteName('image3'),
							$db->quoteName('image4'),
							$db->quoteName('image5'),
							$db->quoteName('image6'),
							$db->quoteName('image7'),
							$db->quoteName('image8'),
							$db->quoteName('image9'),
							$db->quoteName('image10'),
							$db->quoteName('image11'),
							$db->quoteName('image12'),
							$db->quoteName('image13'),
							$db->quoteName('image14'),
							$db->quoteName('image15'),
							$db->quoteName('image16'),
							$db->quoteName('image17'),
							$db->quoteName('image18'),
							$db->quoteName('image19'),
							$db->quoteName('image20'),
							$db->quoteName('hide_question'),
							$db->quoteName('hide_options'),
							$db->quoteName('show_question'),
							$db->quoteName('show_options'),
							$db->quoteName('terminate_options'),
							$db->quoteName('terminate_url'),
							$db->quoteName('default_value'),
							$db->quoteName('enabled'),
							$db->quoteName('ordering'),
							$db->quoteName('created_by'),
							$db->quoteName('created_on'),
							$db->quoteName('modified_by'),
							$db->quoteName('modified_on'),
							$db->quoteName('locked_by'),
							$db->quoteName('locked_on'),
							$db->quoteName('myclass')
					));

					$ordering = $row->ordering+$max;

					$query->values(array((int)$this->$k.',
							'.$db->quote( $db->escape($row->title), false ).',
							'.$db->quote( $db->escape($row->slug), false ).',
							'.$db->quote( $db->escape($row->question_type), false ).',
							'.(int)$row->parent.',
							'.$db->quote( $db->escape($row->option1), false ).',
							'.$db->quote( $db->escape($row->option2), false ).',
							'.$db->quote( $db->escape($row->option3), false ).',
							'.$db->quote( $db->escape($row->option4), false ).',
							'.$db->quote( $db->escape($row->option5), false ).',
							'.$db->quote( $db->escape($row->option6), false ).',
							'.$db->quote( $db->escape($row->option7), false ).',
							'.$db->quote( $db->escape($row->option8), false ).',
							'.$db->quote( $db->escape($row->option9), false ).',
							'.$db->quote( $db->escape($row->option10), false ).',
							'.$db->quote( $db->escape($row->option11), false ).',
							'.$db->quote( $db->escape($row->option12), false ).',
							'.$db->quote( $db->escape($row->option13), false ).',
							'.$db->quote( $db->escape($row->option14), false ).',
							'.$db->quote( $db->escape($row->option15), false ).',
							'.$db->quote( $db->escape($row->option16), false ).',
							'.$db->quote( $db->escape($row->option17), false ).',
							'.$db->quote( $db->escape($row->option18), false ).',
							'.$db->quote( $db->escape($row->option19), false ).',
							'.$db->quote( $db->escape($row->option20), false ).',
							'.$db->quote( $db->escape($row->prefix), false ).',
							'.$db->quote( $db->escape($row->suffix), false ).',
							'.$db->quote( $db->escape($row->field_name), false ).',
							'.$db->quote( $db->escape($row->field_type), false ).',
							'.(int)$row->fieldSize.',
							'.(int)$row->mandatory.',
							'.$db->quote( $db->escape($row->validation_rule), false ).',
							'.$db->quote( $db->escape($row->helpText), false ).',
							'.$db->quote( $db->escape($row->sql), false ).',
							'.$db->quote( $db->escape($row->key_field), false ).',
							'.$db->quote( $db->escape($row->value_field), false ).',
							'.$db->quote( $db->escape($row->titles), false ).',
							'.(int)$row->horizontal.',
							'.$db->quote( $db->escape($row->otherprefix), false ).',
							'.$db->quote( $db->escape($row->othersuffix), false ).',
							'.(int)$row->suppressQuestion.',
							'.$db->quote( $db->escape($row->image1), false ).',
							'.$db->quote( $db->escape($row->image2), false ).',
							'.$db->quote( $db->escape($row->image3), false ).',
							'.$db->quote( $db->escape($row->image4), false ).',
							'.$db->quote( $db->escape($row->image5), false ).',
							'.$db->quote( $db->escape($row->image6), false ).',
							'.$db->quote( $db->escape($row->image7), false ).',
							'.$db->quote( $db->escape($row->image8), false ).',
							'.$db->quote( $db->escape($row->image9), false ).',
							'.$db->quote( $db->escape($row->image10), false ).',
							'.$db->quote( $db->escape($row->image11), false ).',
							'.$db->quote( $db->escape($row->image12), false ).',
							'.$db->quote( $db->escape($row->image13), false ).',
							'.$db->quote( $db->escape($row->image14), false ).',
							'.$db->quote( $db->escape($row->image15), false ).',
							'.$db->quote( $db->escape($row->image16), false ).',
							'.$db->quote( $db->escape($row->image17), false ).',
							'.$db->quote( $db->escape($row->image18), false ).',
							'.$db->quote( $db->escape($row->image19), false ).',
							'.$db->quote( $db->escape($row->image20), false ).',
							'.(int)$row->hide_question.',
							'.$db->quote( $db->escape($row->hide_options), false ).',
							'.(int)$row->show_question.',
							'.$db->quote( $db->escape($row->show_options), false ).',
							'.$db->quote( $db->escape($row->terminate_options), false ).',
							'.$db->quote( $db->escape($row->terminate_url), false ).',
							'.$db->quote( $db->escape($row->default_value), false ).',
							'.(int)$row->enabled.',
							'.(int)$ordering.',
							'.$db->quote( $db->escape($row->created_by), false ).',
							'.$db->quote( $db->escape($row->created_on), false ).',
							'.$db->quote( $db->escape($row->modified_by), false ).',
							'.$db->quote( $db->escape($row->modified_on), false ).',
							'.(int)$row->locked_by.',
							'.$db->quote( $db->escape($row->locked_on), false ).',
							'.$db->quote( $db->escape($row->myclass), false )
					));

					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}
				}


				//now lets update the parent item
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);
				$query->from($db->quoteName('#__bfsurvey_questions'));
				$query->select('*');
				$query->where('bfsurvey_category_id = '.(int)$this->$k);

				$db->setQuery((string)$query);
				$myquestionscopy = $db->loadObjectList();

				foreach($myquestionscopy as $row){
					if($row->parent > 0){
						//get the field name of the original parent
						$db = JFactory::getDbo();
						$query	= $db->getQuery(true);
						$query->from($db->quoteName('#__bfsurvey_questions'));
						$query->select('*');
						$query->where('bfsurvey_question_id = '.(int)$row->parent);

						$db->setQuery((string)$query);
						$myquestion = $db->loadObjectList();

						//now get the id of the copy of this parent question
						$db = JFactory::getDbo();
						$query	= $db->getQuery(true);
						$query->from($db->quoteName('#__bfsurvey_questions'));
						$query->select('*');
						$query->where('field_name = '.$db->quote($myquestion[0]->field_name));
						$query->where('bfsurvey_category_id = '.(int)$this->$k);

						$db->setQuery((string)$query);
						$myparentquestion = $db->loadObjectList();

						//now update the parent id for this item
						$db = JFactory::getDbo();
						$query	= $db->getQuery(true);
						$query->update('#__bfsurvey_questions');
						$query->set('parent='.$myparentquestion[0]->bfsurvey_question_id);
						$query->where('bfsurvey_question_id = '.$row->bfsurvey_question_id);

						$db->setQuery((string)$query);
						$db->query();
						if ($db->getErrorNum())
						{
							echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
							return;
						}
					}
				}
			}

			$this->reset();
		}

		return true;
	}
}