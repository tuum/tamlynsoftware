ALTER TABLE [#__bfsurvey_categories] ADD [showEmailConfirm] [smallint] NOT NULL;
ALTER TABLE [#__bfsurvey_categories] ADD [emailConfirmText] [nvarchar](255) NOT NULL;