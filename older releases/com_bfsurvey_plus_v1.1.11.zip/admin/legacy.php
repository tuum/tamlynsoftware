<?php
/**
 * $Id: legacy.php 35 2012-09-09 13:04:43Z tuum $
 * Legacy functions to make software work for Joomla 2.5.4 or less
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * Alias to JController for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  Controller
 * @since       2.5.5
 */
class JControllerLegacy extends JController
{
}

jimport('joomla.application.component.view');

/**
 * Alias to JView for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  View
 * @since       2.5.5
 */
class JViewLegacy extends JView
{
}

jimport('joomla.application.component.model');

/**
 * Alias to JModel for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  Model
 * @since       2.5.5
 */
class JModelLegacy extends JModel
{
	/**
	 * Add a directory where JModel should search for models. You may
	 * either pass a string or an array of directories.
	 *
	 * @param   mixed   $path    A path or array[sting] of paths to search.
	 * @param   string  $prefix  A prefix for models.
	 *
	 * @return  array  An array with directory elements. If prefix is equal to '', all directories are returned.
	 *
	 * @since   2.5.5
	 */
	public static function addIncludePath($path = '', $prefix = '')
	{
		return parent::addIncludePath($path, $prefix);
	}
}