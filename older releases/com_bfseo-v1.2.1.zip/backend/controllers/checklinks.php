<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerChecklinks extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'checklinks';
	}

	public function execute($task)
	{
		if (!in_array($task, array('check','results'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function check()
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$url = $input->getString('url');

		//see if there is a url passed from meta view
		$urltocheck = $input->getString('urltocheck');
		if(isset($urltocheck))
		{
			//check token in URL
			JSession::checkToken( 'get' ) or jexit(JText::_('JINVALID_TOKEN'));
			$url = base64_decode($urltocheck);
		}
		else
		{
			//check token in form submission
			JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
		}



		$model = $this->getThisModel();

		$results = $model->check($url);

		if ($results === false) {
			$this->setMessage(JText::sprintf( 'COM_BFSEO_FETCH_URL_FAILED', $url), 'error');
			$this->setRedirect('index.php?option=com_bfseo&view=checklinks');
			return;
		}

		$session = JFactory::getSession();
		$session->set('results', $results);

		$this->setRedirect('index.php?option=com_bfseo&view=checklinks');

	}
}
