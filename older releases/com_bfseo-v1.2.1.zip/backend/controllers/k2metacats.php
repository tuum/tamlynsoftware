<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoControllerK2metacats extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'k2metacats';
	}

	public function execute($task) {

		if(!in_array($task, array('save', ))) $task = 'add';
		parent::execute($task);
	}


	public function save()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		$model = $this->getThisModel();

		$app = JFactory::getApplication();
		$input = $app->input;

		$data = $input->getArray();
		$ids = $data['id'];

		foreach ($ids as $id) {

			$params = $model->getParams($id);

			$desc = $data['desc'][$id];


			$params["catMetaDesc"] = $desc;

			$param = json_encode($params);
			$param = str_replace("'", "''", $param);
			$param = str_replace("\\", "\\\\", $param);

			$result = $model->updateMeta($param, $id);
		}

		$this->setMessage( JText::_( 'COM_BFSEO_METADATA_SAVED' ) );

		$this->setRedirect( 'index.php?option=com_bfseo&view=k2metacats' );
		return true;
	}


}
