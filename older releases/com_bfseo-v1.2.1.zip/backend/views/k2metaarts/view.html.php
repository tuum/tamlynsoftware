<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoViewK2MetaArts extends F0FViewHtml
{
	protected function onAdd($tpl = null)
	{
		$this->menuItems = BfseoModelK2MetaArts::getMenuItems();
		return true;
	}
}

