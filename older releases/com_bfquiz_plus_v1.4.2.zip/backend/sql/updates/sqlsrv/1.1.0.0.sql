ALTER TABLE [#__bfquiz_plus] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfquiz_plus_email] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfquiz_plus_matrix] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfquiz_plus_scorerange] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfquiz_plus_pool] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfquiz_plus_scorecat] ADD [alias] [nvarchar](255) NOT NULL;