<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

$params = JFactory::getApplication()->getParams();
$slug=$params->get('slug');
$showThisWeekNextWeek=$params->get('showThisWeekNextWeek');

$app		= JFactory::getApplication();
$menus		= $app->getMenu();
$menu = $menus->getActive();

if ($menu)
{
	JFactory::getDocument()->setTitle( $params->get('page_title', $menu->title) );
}
else
{
	JFactory::getDocument()->setTitle( JText::_('COM_BFSURVEY_DEFAULT_PAGE_TITLE') );
}

//check if user has permission
$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
$statsAccess = BfsurveyModelSurvey::getStatsAccess($slug);

if (!in_array($statsAccess, $accessLevels))
{
	// User trying to view questions that he does not have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_NO_ACCESS_STATS') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfsurvey&view=stats&Itemid=".(int)$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
	$finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFSURVEY_LOG_IN')."</a><br>";
	return;
}

include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
AkeebaStrapper::jQueryUI();

require_once JPATH_ADMINISTRATOR.'/components/com_bfsurvey/views/stats/tmpl/form.php';