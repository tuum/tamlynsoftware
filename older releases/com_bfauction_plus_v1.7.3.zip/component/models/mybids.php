<?php
/**
 * $Id: mybids.php 88 2014-02-02 11:55:57Z tuum $
 * My Bids Model for bfauction_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * My Bids Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusModelmybids extends JModelLegacy
{
	/**
	 * Item data array
	 *
	 * @var array
	 */
	var $_data;

	 /**
	  * Items total
	  * @var integer
	  */
	 var $_total = null;

	 /**
	  * Pagination object
	  * @var object
	  */
	 var $_pagination = null;

	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
	    $db = JFactory::getDBO();
	    $user = JFactory::getUser();

		$query = 'SELECT b.*'
						. ' FROM #__bfauction_plus AS b'
						. ' RIGHT JOIN (SELECT DISTINCT itemid FROM #__bfauction_plus_bid WHERE uid='.(int)$user->id.') AS dd on dd.itemid=b.id'
						. ' WHERE b.state=1'
						. ' ORDER BY b.endDate'
		;

		return $query;
	}

	/**
	 * Retrieves the data
	 * @return array Array of objects containing the data from the database
	 */
	function getData()
	{
		// if data hasn't already been obtained, load it
		if (empty($this->_data)) {
		    $query = $this->_buildQuery();
		    $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_data;

	}


	function __construct()
	  {
	 	parent::__construct();

		$app = JFactory::getApplication();

		// Get pagination request variables
		$limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart = $app->getUserStateFromRequest('.limitstart', 'limitstart', 0, 'int');

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);

	    $filter_ord = $app->getUserStateFromRequest('filter_order', 'filter_order', 'orderdate');
		$filter_ord_Dir = strtoupper($app->getUserStateFromRequest('filter_order_Dir', 'filter_order_Dir', 'DESC' ));
	  }

      function getTotal()
	    {
	   	// Load the content if it doesn't already exist
	   	if (empty($this->_total)) {
	   	    $query = $this->_buildQuery();
	   	    $this->_total = $this->_getListCount($query);
	   	}
	   	return $this->_total;
	  }

      function getPagination()
	    {
	   	// Load the content if it doesn't already exist
	   	if (empty($this->_pagination)) {
	   	    jimport('joomla.html.pagination');
	   	    $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
	   	}
	   	return $this->_pagination;
	  }

}
