<?php
/**
 * $Id: default.php 94 2014-11-25 04:32:56Z tuum $
 * BF Auction view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	require_once( JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfauction_plus.php' );

	JHtml::_('script', 'system/core.js', false, true);

	JHtml::_('behavior.modal', 'a.modal');
	//JHtml::script('lytebox.js', 'components/com_bfauction_plus/lib/lytebox/');
	//JHtml::script('../../components/com_bfauction_plus/lib/lytebox/lytebox.js', false, true);
	JHtml::script(JUri::base() . 'components/com_bfauction_plus/lib/lytebox/lytebox.js', false, true);

	JHtml::_('behavior.multiselect');

	$document = JFactory::getDocument();
	$cssFile = './components/com_bfauction_plus/lib/lytebox/lytebox.css';
	$document->addStyleSheet($cssFile, 'text/css', null, array());

    $app = JFactory::getApplication();
    $user = JFactory::getUser();

	$bfcurrency = $this->params->get('bfcurrency', '$');
	$dateFormat = $this->params->get( 'dateFormat' );
	$rowColour = $this->params->get('rowColour');
	$alternateColour = $this->params->get('alternateColour');
	$currencySymbolAfter= $this->params->get('currencySymbolAfter', 0);
	$showSeller= $this->params->get('showSeller', 0);

	$items = 0;
	$limitstart = 0;
	$limit = 0;

	$context="";
	$filter_catid		= $app->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_sort		= $app->getUserStateFromRequest( $context.'filter_sort',		'filter_sort',		'',			'int' );
	$filter_filter		= $app->getUserStateFromRequest( $context.'filter_filter',		'filter_filter',	'',			'int' );
	$search				= $app->getUserStateFromRequest( $context.'search',				'search',			'',			'string' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm2.submit();"';

	// state filter
	$lists['order'] = bfauction_plusHelper::orderList($filter_sort);
	$lists['filter'] = bfauction_plusHelper::filterList($filter_filter);

	$session = JFactory::getSession();
	$catid = $session->get('catid');
	$showAllCategories = $session->get('showAllCategories');

	// search filter
	$lists['search']= $search;

	$itemid = JRequest::getVar( 'Itemid');
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=bfauction_plus'); ?>" name="adminForm2" id="adminForm2" method="post">
<table>
	<tr>
		<td align="left" width="100%">
			<?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_FILTER' ); ?>:
			<input type="text" name="search" id="search2" value="<?php echo htmlspecialchars($lists['search']);?>" class="text_area" onchange="document.adminForm2.submit();" />
			<button onclick="this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_BUTTON_GO' ); ?></button>
			<button onclick="document.getElementById('search2').value='';this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_BUTTON_RESET' ); ?></button>
		</td>
		<td nowrap="nowrap">
			<?php
			echo $lists['order'];
			if($showAllCategories){
				?>
			<select name="filter_catid" class="inputbox" onchange="document.adminForm2.submit();">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_bfauction_plus'), 'value', 'text', (int)$filter_catid);?>
			</select>
				<?php
			}

			echo $lists['filter'];
			?>
		</td>
	</tr>
</table>
<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>
<input type="hidden" name="option" value="com_bfauction_plus" />
<input type="hidden" name="task" value="listItems" />
<input type="hidden" name="boxchecked" value="0" />
</form>

<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr class="bfauction_plusReportHeader">
			<th width="5" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ID' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CATEGORY' ); ?>
			</th>
			<?php if($showSeller){ ?>
			<th width="10%" nowrap="nowrap" align="center">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_SELLER' ); ?>
			</th>
			<?php } ?>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CURRENT_BID' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_HIGH_BIDDER' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_END_DATE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_NOW' ); ?>
			</th>
			<th width="90" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_IMAGE' ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$link 		= JRoute::_( 'index.php?option=com_bfauction_plus&view=bid&cid='. $row->id.'&Itemid='.(int)$itemid );

		?>

		<tr class="bfauction_plusReportBody" style="background-color:<?php echo $i & 1 ? $alternateColour : $rowColour; ?>">
			<td align="center">
				<?php if($row->productId){ ?>
					<?php echo $row->productId; ?>
				<?php }else{ ?>
			   		<?php echo $row->id; ?>
			   	<?php } ?>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<?php if($showSeller){ ?>
			<td align="center">
				<?php echo $row->seller;?>
			</td>
			<?php } ?>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo number_format($row->currentBid,2); ?>
				<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
			<td align="center">
				<?php
				if($row->highBidder <> '0'){
					if($row->highBidder == $user->username){
						echo $row->highBidder;
					}else{
						echo substr($row->highBidder, 0, 1);
						echo "******";
						echo substr($row->highBidder, -1);
					}
				}
				?>
			</td>
			<td align="center">
				<?php echo JHTML::_('date',  $row->endDate, $dateFormat ); ?>
			</td>
			<td>
				<?php if(!$row->winEmailSent){ ?>
				<form method="post" name="adminForm">
					<input type="hidden" name="option" value="com_bfauction_plus" />
					<input type="hidden" name="task" value="bid" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="cid" value="<?php echo $row->id; ?>" />

					<input name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_BID_NOW' ); ?>" />
				</form>
				<?php } ?>
			</td>
			<td>
				<?php
				$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$row->id."img1.jpg";
				if (file_exists($a_pic)){
					echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$row->id.'img1.jpg?time='.time().'"  rel="lytebox[myimages'.$i.']"><img src="'.JUri::base().'images/com_bfauction_plus/'.$row->id.'img1_t.jpg?time='.time().'"/></a>';
				}elseif($row->imageShared > 0){
					$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$row->imageShared."img1.jpg";
					if (file_exists($a_pic)){
						echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$row->imageShared.'img1.jpg?time='.time().'"  rel="lytebox[myimages'.$i.']"><img src="'.JUri::base().'images/com_bfauction_plus/'.$row->imageShared.'img1_t.jpg?time='.time().'"/></a>';
					}
				?>
				<?php }elseif($row->image != ""){ ?>
    				<a href="<?php echo $row->image;?>"  rel="lytebox[myimages<?php echo $i; ?>]"><img src="<?php echo $row->image;?>" width="90" border=0></a>
    			<?php } ?>
			</td>
		</tr>

		<?php
		$k = 1 - $k;
	}
	?>

	  <tfoot>
	    <tr>
	      <form method="post" name="adminForm" action="index.php?option=com_bfauction_plus">
	      	<td colspan="8"><?php echo $this->pagination->getListFooter(); ?></td>
	      	<input type="hidden" name="option" value="com_bfauction_plus" />
		  	<input type="hidden" name="task" value="bfauctionplus" />
		  	<input type="hidden" name="boxchecked" value="0" />
		  	<input type="hidden" name="cid" value="<?php if(isset($row)){ echo $row->id; } ?>" />
		  	<input type="hidden" name="view" value="bfauction_plus" />
		  </form>
	    </tr>
	  </tfoot>

	</table>
</div>

<?php bfauction_plusController::triggerBFAuctionEmail(); ?>

