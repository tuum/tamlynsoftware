<?php
/**
 * $Id: default.php 88 2014-02-02 11:55:57Z tuum $
 * Disclaimer view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<?php
$showDisclaimer = $this->params->get('showDisclaimer');
$disclaimerText = $this->params->get('disclaimerText');
$catid = JRequest::getVar( 'catid', 0, '', 'int' );
$showAllCategories = JRequest::getVar( 'showAllCategories', 0, '', 'int' );

$session = JFactory::getSession();
$session->set('catid', $catid );
$session->set('showAllCategories', $showAllCategories );

$limitstart = JRequest::getVar('limitstart', 0, '', 'int');

$app		= JFactory::getApplication();
$menus	= $app->getMenu();
$menu	= $menus->getActive();

$itemId	= JRequest::getInt('Itemid');
if(!$itemId){
	$itemId = $menu->id;
}

if($showDisclaimer & $limitstart==0){
   echo $disclaimerText;
}else{
	$redirectURL = "index.php?option=com_bfauction_plus&view=bfauction_plus&limitstart=".$limitstart."&Itemid=".$itemId;
	$msg = "";
	$app = JFactory::getApplication();
	$app->redirect( JRoute::_($redirectURL, false), $msg );
}

?>
<form method="post" action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=bfauction_plus&limitstart='.$limitstart.'&Itemid='.$itemId); ?>" name="adminForm">
<input type="hidden" name="option" value="com_bfauction_plus" />
<input type="hidden" name="task" value="listItems" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_GO_TO_AUCTION' ); ?>" />
</form>
