<?php
/**
 * $Id: default.php 88 2014-02-02 11:55:57Z tuum $
 * Sales Report view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');

$user = JFactory::getUser();

$listOrder	= $this->state->get('list.ordering');
$listDirn	= $this->state->get('list.direction');
$ordering 	= ($listOrder == 'a.ordering');
$canOrder	= $user->authorise('core.edit.state',	'com_bfauction_plus');
$saveOrder 	= ($listOrder == 'a.ordering');

$params = JComponentHelper::getParams('com_bfauction_plus');
$dateFormat = $params->get('dateFormat');
$bfcurrency = $params->get('bfcurrency', '$');

$app = JFactory::getApplication();
$filter_date_from		= $app->getUserStateFromRequest( 'filter.date_from',		'filter_date_from',	'',		'string' );
$filter_date_to			= $app->getUserStateFromRequest( 'filter.date_to',			'filter_date_to',	'',		'string' );
$showAllBidders			= $app->getUserStateFromRequest( 'filter.show_all_bidders',	'filter_show_all_bidders',	'',		'string' );

$header=""; // excel export
$data="";

$version = new JVersion();
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=rptsales'); ?>" method="post" name="adminForm" id="adminForm">
	<?php if(floatval($version->RELEASE) >= 3) { ?>
	<div id="filter-bar" class="btn-toolbar">
		<div class="filter-search btn-group pull-left">
			<div class="btn-group pull-left">
				<button type="submit" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				<button type="button" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
			</div>
			<div class="btn-group pull-right">
				<?php echo JHTML::calendar( $filter_date_to, "filter_date_to", "filter_date_to", '%Y-%m-%d %H:%M:%S', 'placeholder='.JText::_("COM_BFAUCTIONPLUS_FILTER_TO").': onclick=this.form.submit();' ); ?>
			</div>
			<div class="btn-group pull-right">
				<?php echo JHTML::calendar( $filter_date_from, "filter_date_from", "filter_date_from", '%Y-%m-%d %H:%M:%S', 'placeholder='.JText::_("COM_BFAUCTIONPLUS_FILTER_FROM").': onclick=this.form.submit();' ); ?>
			</div>

		</div>
	</div>
	<?php } //end 3 ?>
	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
	<fieldset id="filter-bar">
		<div class="filter-select fltrt">
				<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
				<button type="button" onclick="document.id('filter_date_from').value='';document.id('filter_date_to').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>

				<label class="filter-search-lbl" for="filter_date_from"><?php echo JText::_("COM_BFAUCTIONPLUS_FILTER_FROM"); ?>:</label>
				<?php echo JHTML::calendar( $filter_date_from, "filter_date_from", "filter_date_from", '%Y-%m-%d %H:%M:%S' ); ?>

				<label class="filter-search-lbl" for="filter_date_to"><?php echo JText::_("COM_BFAUCTIONPLUS_FILTER_TO"); ?>:</label>
				<?php echo JHTML::calendar( $filter_date_to, "filter_date_to", "filter_date_to", '%Y-%m-%d %H:%M:%S' ); ?>

				<select name="filter_show_all_bidders" class="inputbox" onchange="this.form.submit()">
					<option value=""><?php echo JText::_('COM_BFAUCTIONPLUS_SELECT_SHOW_ALL_BIDDERS');?></option>
					<?php echo JHtml::_('select.options', JFormFieldAuctionBidders::getOptions(), 'value', 'text', $this->state->get('filter.show_all_bidders'), true);?>
				</select>
		</div>
	</fieldset>
	<?php } //end 2.5 ?>

	<div class="clr"> </div>

	<table class="adminlist">
	<thead>
		<tr>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CUSTOMER' ); ?>
				<?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_CUSTOMER' ) . "\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_CUSTOMER_PURCHASES' ); ?>
				<?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_CUSTOMER_PURCHASES' ) . "\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_BIDS_PER_CUSTOMER' ); ?>
				<?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_BIDS_PER_CUSTOMER' ) . "\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_LOGINS_PER_CUSTOMER' ); ?>
				<?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_LOGINS_PER_CUSTOMER' ) . "\t"; ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="14">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$originalOrders = array();
	$totalLogins = 0;
	foreach ($this->items as $i => $item) :
	?>
		<?php $totalCustomerPurchases = bfauction_plusModelrptsales::getTotalCustomerPurchases($item->username, $filter_date_from, $filter_date_to); ?>
		<?php $totalCustomerBids = bfauction_plusModelrptsales::getTotalCustomerBids($item->id, $filter_date_from, $filter_date_to); ?>
		<?php $totalCustomerLogins = bfauction_plusModelrptsales::getTotalCustomerLogins($item->id, $filter_date_from, $filter_date_to); ?>
		<?php if( ($totalCustomerPurchases!=0 & $totalCustomerBids!=0 & $totalCustomerLogins!=0) | $showAllBidders=="ShowAll" ){ ?>
		<tr class="row<?php echo $i % 2; ?>">
			<td class="center">
				<?php echo $item->name; ?>
				<?php echo " - "; ?>
				<?php echo $item->username; ?>
				<?php $data .= $item->name." - ".$item->username."\t"; ?>
			</td>
			<td class="center">
				<?php
					echo $bfcurrency.($totalCustomerPurchases == 0 ? 0 : $totalCustomerPurchases);
				?>
				<?php $data .= $bfcurrency.($totalCustomerPurchases == 0 ? 0 : $totalCustomerPurchases)."\t"; ?>
			</td>
			<td class="center">
				<?php echo $totalCustomerBids; ?>
				<?php $data .= $totalCustomerBids."\t"; ?>
			</td>
			<td class="center">
				<?php echo $totalCustomerLogins; ?>
				<?php $data .= $totalCustomerLogins."\t"; ?>
				<?php $totalLogins = $totalLogins + $totalCustomerLogins; ?>
			</td>
		</tr>
		<?php $data .= "\n"; ?>
		<?php }else{ ?>
		<?php //skip rows with no purchase ?>
		<?php } ?>
	<?php endforeach; ?>
	 </tbody>
	</table>

	<table class="adminlist">
	<thead>
		<tr>
			<th width="25%" nowrap="nowrap">
			<?php $data .= "\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_SALES' ); ?>:
				<?php echo $bfcurrency.($this->salesTotal==0 ? 0 : $this->salesTotal); ?>
				<?php $data .= $bfcurrency.($this->salesTotal==0 ? 0 : $this->salesTotal)."\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_BIDS' ); ?>:
				<?php echo $this->bidsTotal; ?>
				<?php $data .= $this->bidsTotal."\t"; ?>
			</th>
			<th width="25%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_LOGINS' ); ?>:
				<?php echo $totalLogins; ?>
				<?php $data .= $totalLogins."\t"; ?>

			</th>
		</tr>
	</thead>
	</table>
	<?php $data .= "\n"; ?>

	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

<?php
//dodgy way but it will do for now
   // excel export
   print '<form id="ExcelExport" name="ExcelExport" method="POST" action="./components/com_bfauction_plus/excelexport.php">';

   print '<input type=hidden name="myheader"  value="'.$header.'">';

   print '<DIV ID="ExcelDate" style="display:none;"><textarea name="mydata">'.$data.'</textarea></div>';

   ?>
   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_EXPORT_TO_EXCEL' ); ?>" />
   <?php jimport('joomla.html.html'); ?>
   <?php echo JHTML::_( 'form.token' ); ?>
   <?php
   print "</form>";
		?>