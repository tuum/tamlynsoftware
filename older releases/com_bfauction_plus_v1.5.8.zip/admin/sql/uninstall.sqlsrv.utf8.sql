-- <?php /* $Id: uninstall.sqlsrv.utf8.sql 43 2012-03-29 12:32:38Z tuum $ */ defined('_JEXEC') or die() ?>;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfauction_plus]
END;	
	
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus_bid]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfauction_plus_bid]
END;	
	
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus_email]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfauction_plus_email]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus_payment_plugins]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfauction_plus_payment_plugins]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauctionplus_watchlist]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfauctionplus_watchlist]		
END;

DELETE FROM [#__categories] WHERE extension='com_bfauction_plus';
