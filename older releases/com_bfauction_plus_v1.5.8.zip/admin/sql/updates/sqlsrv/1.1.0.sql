ALTER TABLE [#__bfauction_plus] ADD [saleType] [smallint] NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [address1] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [address2] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [city] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [region] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [postcode] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [country] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [phone] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [imageShared] [int] NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [relistid] [int] NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [quantity] [int] NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [quantityPurchased] [int] NOT NULL;
ALTER TABLE [#__bfauction_plus] ADD [deliveryOption] [nvarchar](255) NOT NULL;

ALTER TABLE [#__bfauction_plus_bid] ADD [quantity] [int] NOT NULL;
ALTER TABLE [#__bfauction_plus_bid] ADD [deliveryOption] [nvarchar](255) NOT NULL;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfuserlog]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfuserlog](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [int],
	[site] [smallint] NOT NULL,	
	[visitDate] [datetime] NOT NULL,
	[login] [smallint] NOT NULL,
	[published] [smallint] NOT NULL,
	[archived] [smallint] NOT NULL,	
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,  	
 CONSTRAINT [PK_#__bfuserlog_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;