ALTER TABLE `#__bfauction_plus` ADD `saleType` tinyint(1) NOT NULL default '0'; 
ALTER TABLE `#__bfauction_plus` ADD `address1` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `address2` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `city` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `region` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `postcode` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `country` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `phone` varchar(255) NOT NULL default '';
ALTER TABLE `#__bfauction_plus` ADD `imageShared` int(11) NOT NULL default '0';
ALTER TABLE `#__bfauction_plus` ADD `relistid` int(11) NOT NULL default '0';
ALTER TABLE `#__bfauction_plus` ADD `quantity` int(11) NOT NULL default '1';
ALTER TABLE `#__bfauction_plus` ADD `quantityPurchased` int(11) NOT NULL default '0';
ALTER TABLE `#__bfauction_plus` ADD `deliveryOption` varchar(255) NOT NULL;

ALTER TABLE `#__bfauction_plus_bid` ADD `quantity` int(11) NOT NULL default '1';
ALTER TABLE `#__bfauction_plus_bid` ADD `deliveryOption` varchar(255) NOT NULL;

 CREATE TABLE IF NOT EXISTS `#__bfuserlog` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`uid` int(11) NOT NULL,
	`site` tinyint(4) NOT NULL DEFAULT '0',
	`visitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`login` tinyint(4) NOT NULL DEFAULT '0',
	`published` tinyint(3) NOT NULL default '0',
	`archived` tinyint(1) NOT NULL DEFAULT '0',
	`publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`id`)
);