<?php
/**
 * $Id: view.html.php 40 2012-09-23 04:17:28Z tuum $
 * BFQuiz_Plus StatsPool View for BFQuiz_Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * BFQuiz_Plus StatsPool View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusViewStatsPool extends JViewLegacy
{
    /**
     * Hellos view display method
     * @return void
     **/
    function display($tpl = null)
    {
        JToolBarHelper::title( JText::_( 'COM_BFQUIZPLUS_TOOLBAR_STATS' ), 'bfquiz_toolbar_title' );

		bfquiz_plusHelper::addSubmenu('stats');

		$catid	= JRequest::getVar( 'cid', 0, '', 'int' );
		$poolid	= JRequest::getVar( 'poolid', 0, '', 'int' );

		$params = JComponentHelper::getParams('com_bfquiz_plus');

        // Get data
		$items2 = bfquiz_plusController::getQuestions($catid);

        $items = $this->get('DataPool');
		$items3 = $this->get('Data');

	    if(!$items3){
	      JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_ERROR_NO_RESULTS') );
	    }

	    $this->assignRef( 'items', $items );
		$this->assignRef( 'items2', $items2 );
        $this->assignRef( 'items3', $items3 );
        $this->assignRef( 'catid', $catid );
        $this->assignRef( 'params', $params );

		$totalResponses = bfquiz_plusController::getNumberResponsesPool($poolid);
		$this->assignRef( 'totalResponses', $totalResponses );

		$averageScore = bfquiz_plusController::getAverageScorePool($poolid);
		$this->assignRef( 'averageScore', $averageScore );

		$highScore = bfquiz_plusController::getHighestScorePool($poolid);
		$this->assignRef( 'highScore', $highScore );

		$lowScore = bfquiz_plusController::getLowestScorePool($poolid);
		$this->assignRef( 'lowScore', $lowScore );

		$this->assignRef( 'poolid', $poolid );

        parent::display($tpl);
    }
}