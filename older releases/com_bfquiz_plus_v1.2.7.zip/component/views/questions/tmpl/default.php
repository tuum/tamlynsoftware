<?php
/**
 * $Id: default.php 47 2013-02-20 11:45:27Z tuum $
 * Questions View for Bfquiz_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
$version = new JVersion();

$params = JComponentHelper::getParams('com_bfquiz_plus');

?>

<?php
//check if user has permission
require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';
$canDo	= Bfquiz_plusHelper::getActions(0);

$user = JFactory::getUser();
if($user->id == 0){
	JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ERROR_YOU_MUST_LOG_IN_VIEW') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfquiz_plus&view=questions&Itemid=".$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".$finalUrl."'>".JText::_( 'COM_BFQUIZPLUS_LOG_IN')."</a><br>";
}elseif ($canDo->get('core.create')) {
?>

<?php if(floatval($version->RELEASE) <= '2.5') { ?>
<form action="<?php echo JRoute::_( 'index.php'); ?>" method="post" id="adminForm2" name="adminForm2">
	<?php echo $this->getToolbar(); ?>
	<input type = "hidden" name = "task" value = "" />
	<input type = "hidden" name = "view" value = "questions" />
	<input type = "hidden" name = "option" value = "com_bfquiz_plus" />
</form>
<div class="clr"></div>
<?php } ?>

<?php
require_once(JPATH_COMPONENT_ADMINISTRATOR . '/views/questions/tmpl/default.php');

}else{
	JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ACCESS_DENIED') );
}
?>