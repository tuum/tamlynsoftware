<?php
/**
 * $Id: default.php 47 2013-02-20 11:45:27Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

 // Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;

$app		= JFactory::getApplication();
$menus		= $app->getMenu();
$menu = $menus->getActive();
$Itemid = (int) $menu->id;

$session = JFactory::getSession();

//answers
$row2 = &$this->items2[0];

/*********************** TIMED QUIZ ******************************/
$timedQuiz = $this->params->get( 'timedQuiz' );
$timeLimit = $this->params->get( 'timeLimit' );
$timerText = $this->params->get( 'timerText' );
$timerCompleteText = $this->params->get( 'timerCompleteText' );

// $minutes and $seconds are added together to get total time.
$minutes = $timeLimit; // Enter minutes
$seconds = 0; // Enter seconds
$time_limit = ($minutes * 60) + $seconds; // Convert total time into seconds
// Add $time_limit (total time) to start time. And store into session variable.
if(!$session->has('start_time'.$Itemid)){
	$session->set('start_time'.$Itemid, mktime(date('G'),date('i'),date('s'),date('m'),date('d'),date('Y')) + $time_limit);
}

$targetDate = $session->get('start_time'.$Itemid);
$actualDate = time();

// Define date format
$dateFormat = "Y-m-d H:i:s";

$secondsDiff = $targetDate - $actualDate;

$remainingDay     = floor($secondsDiff/60/60/24);
$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

$targetDateDisplay = date($dateFormat,$targetDate);
$actualDateDisplay = date($dateFormat,$actualDate);
?>
<script language="Javascript">
<!--
  // get variable from php
  var days = <?php echo $remainingDay; ?>;
  var hours = <?php echo $remainingHour; ?>;
  var minutes = <?php echo $remainingMinutes; ?>;
  var seconds = <?php echo $remainingSeconds; ?>;
  var timerCompleteText = "<?php echo $timerCompleteText ?>";
  var timedQuiz = "<?php echo $timedQuiz ?>";

function setCountDown ()
{
  seconds--;
  if (seconds < 0){
      minutes--;
      seconds = 59
  }
  if (minutes < 0){
      hours--;
      minutes = 59
  }
  if (hours < 0){
      days--;
      hours = 23
  }
  //document.getElementById("txt").innerHTML = hours+" hours, "+minutes+" minutes, "+seconds+" seconds";
  if(seconds < 10){
	  seconds = "0"+seconds;
  }
  document.getElementById("txt").value = minutes+":"+seconds;

  if(days < 0){
     clearInterval(ct);
     document.getElementById("txt").value = "0:00";
  	 document.myquiz.submit();
     alert(timerCompleteText);
  }

  //setTimeout ( "setCountDown()", 1000 );
}

if(timedQuiz=="1"){
    var ct = setInterval("setCountDown()",1000); // Start clock.
 }

//-->
</script>
<?php

if($remainingSeconds < 10){
	$remainingSecs = "0".$remainingSeconds;
}else{
    $remainingSecs = $remainingSeconds;
}

$timerinit="".$remainingMinutes.":".$remainingSecs;
/*****************************************************************/

if(!$session->has('dateReceived')){
	$now = JFactory::getDate();
	if(is_callable(array('JDate', 'toSql'))){
		$session->set('dateReceived', $now->toSql());
	}else{
		$session->set('dateReceived', $now->toMySQL());
	}
}

$introText = $this->params->get( 'introText' );
$quizTitle = $this->params->get( 'quizTitle' );
$emailText = $this->params->get( 'emailText' );
$nameText = $this->params->get( 'nameText' );
$allowEmail = $this->params->get( 'allowEmail' );

$submitText = $this->params->get( 'submitText' );

$anonymous = $this->params->get( 'anonymous' );
$anonymousText = $this->params->get( 'anonymousText' );
$anonymousYes = $this->params->get( 'anonymousYes' );
$anonymousNo = $this->params->get( 'anonymousNo' );
$nameText = $this->params->get( 'nameText' );
$emailText = $this->params->get( 'emailText' );

$showName = $this->params->get( 'showName' );
$showEmail = $this->params->get( 'showEmail' );

$errorText = $this->params->get( 'errorText' );
$use_captcha = $this->params->get( 'use_captcha' );

$registeredUsers = $this->params->get( 'registeredUsers' );
$preventMultiple = $this->params->get( 'preventMultiple' );
$preventMultipleEmail = $this->params->get( 'preventMultipleEmail' );
$preventMultipleUID = $this->params->get( 'preventMultipleUID' );

$scoringMethod = $this->params->get( 'scoringMethod' );
$randomOptions = $this->params->get( 'randomOptions' );
$questionColour = $this->params->get( 'questionColour', '#abc' );
$optionColour = $this->params->get( 'optionColour', '#eee' );

//initialise some variables
$user="";
$emailcount=0;
$uidcount=0;


if($anonymous == ""){
   $anonymous = "1";
}

if($showName == ""){
   $showName = "1";
}

if($showEmail == ""){
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );
$Itemid = JRequest::getVar( 'Itemid', 0, '', 'int' );

if($catid == 0){
	$app = JFactory::getApplication();
	JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_ERROR_SELECT_CATEGORY') );
	$app->redirect( 'index.php' );
}

$table="#__bfquizplus_".(int)$catid;

$ip = Bfquiz_plusController::getIP();
$ipcount = Bfquiz_plusController::checkIP($table,$ip);

$total_qns=count( $this->items );
?>

<script language="Javascript">
<!--
	// get variable from php
	var showName = "<?php echo $showName ?>";
	var showEmail = "<?php echo $showEmail ?>";
	var toggle = 1;
	var total_qns = "<?php echo $total_qns ?>";

	function ToggleDetails(){
   		if(toggle == 1){
   		   // hide details
   		   if(showName=="1"){
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		   }

           if(showEmail=="1"){
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1"){
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		   }

		   if(showEmail=="1"){
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
           }
		   toggle=1;
        }
   }

//-->
</script>



<?php
// Check that the class exists before trying to use it
if (class_exists('plgBFValidatePlus'))
{
   plgBFValidatePlus::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f)) {
	    f.check='';
		f.check.value='<?php echo JSession::getFormToken(); ?>';//send token
		return true;
	}
	else {
		alert( '<?php echo addslashes($errorText) ?>' );
	}
	return false;
}
function imposeMaxLength(Object, MaxLen)
{
  return (Object.value.length < MaxLen);
}
</script>

<?php
$user = JFactory::getUser();
 if($registeredUsers == "1"){
    $emailcount = Bfquiz_plusController::checkEmail($table,$user->email);
    $uidcount = Bfquiz_plusController::checkUID($table,$user->id);
 }

 if (($user->id) | $registeredUsers != "1") {  // test if registerd users only

 	if($ipcount < 1 | $preventMultiple != "1"){  // check if IP address has already completed quiz

       if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed quiz

			if($uidcount < 1 | $preventMultipleUID != "1"){  // check if UID has already completed quiz

?>

<form  method="POST" name="myquiz" id="myquiz" class="form-validate" class="form-validate" onSubmit="return myValidate(this);">

<table >
	<thead>
		<tr>
			<th>
				<div class="Bfquiz_plusTitle"><?php echo JText::_( $quizTitle ); ?></div>
			</th>
		</tr>
	</thead>
<tr>
    <td>
    <div class="Bfquiz_plusIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="Bfquiz_plusQuestionFooter">
	</div>
    </td>
</tr>

<?php if($timedQuiz == "1"){ ?>
<tr>
   <td>
		<div class="timeremaining"><?php echo JText::_($timerText); ?> <input id="txt" name="txt" readonly value="<?php echo $timerinit; ?>"></div>
   </td>
</tr>
<?php } ?>

<div class="Bfquiz_plusIntro">
<?php if($showName == "1"){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table align="left">
       <tr>
           <td>
               <div class="Bfquiz_plusCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="Bfquiz_plusCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table align="left">
        <tr>
            <td width="70">
                <div class="Bfquiz_plusCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="Bfquiz_plusCustomerOptions">
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $user->name; ?>' >
                </div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="fullname" id="fullname" value='<?php echo $user->name; ?>' >
<?php
      }
?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table align="left">
		       <tr>
		           <td width="70">
		               <div class="Bfquiz_plusCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="Bfquiz_plusCustomerOptions">
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $user->email; ?>' >
		               </div>
		           </td>
		       </tr>
       </table>
       <br><br>
       </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="email" id="email" value='<?php  echo $user->email; ?>' >
<?php
      }
?>
</div>

<?php
$k = 0;

for ($i=0; $i < $total_qns; $i++)
{
	$row = &$this->items[$i];
	$fieldName = $row->field_name;

    if($fieldName != NULL){
    	if(isset($row2->$fieldName)){
   			$tempanswer = $row2->$fieldName;
    	}else{
    		$tempanswer = "";
    	}
?>
    <input id="field_name" name="field_name" type="hidden" value="<?php echo $row->field_name; ?>">

    <?php if($row->suppressQuestion != "1"){ ?>
	<tr>
	    <th>
	       <div class="Bfquiz_plusQuestion" style="background-color:<?php echo $questionColour; ?>"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<?php } ?>

	<tr>
	    <th>
	      <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="Bfquiz_plusOptions" style="background-color:<?php echo $optionColour; ?>">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == ""){
	          // do nothing
	       }else{
	          echo JHTML::_('content.prepare', $row->helpText);
	          echo "<br>";
	       }

	       if(!isset($row->prefix)){
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix)){
	          $row->suffix = "";
	       }

	       $sequence = $row->id;

	       if($row->question_type == "0"){  //text
	           $mylength="65";
	           if($row->fieldSize < 65){
	              $mylength=$row->fieldSize;
	           }
	           if($row->mandatory){
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='".$fieldName."' name='".$fieldName."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\" value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
				  }else{
	              ?>
		             <div class="Bfquiz_plusSuppressQuestion">
	                 <?php echo JText::_($row->prefix); ?>
	                 </div>
	                 <div class="Bfquiz_plusSuppressOptions">
	                 <?php
	                    echo "<INPUT id='".$fieldName."' name='".$fieldName."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\" value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	                 ?>
	                 </div>
       			  <?php
       			  }
	           }else{
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='".$fieldName."' name='".$fieldName."' size=".$mylength." MAXLENGTH=".$row->fieldSize." value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	              }else{
	              ?>
	                <div class="Bfquiz_plusSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="Bfquiz_plusSuppressOptions">
	                <?php
	                   echo "<INPUT id='".$fieldName."' name='".$fieldName."' size=".$mylength." MAXLENGTH=".$row->fieldSize." value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	                ?>
	                </div>
       			  <?php
       			  }
	           }
	       }else if($row->question_type == "1"){  // Radio
		       if($randomOptions != "1"){

	       	      for($z=0; $z < 20; $z++)
   	       	      {
	       		    $tempvalue="option".($z+1);
	       		    $tempnext="next_question".($z+1);

	       		    if($row->$tempvalue != ""){

 	  			       if($row->horizontal == "1"){
 	  			          $myclass="bfradiohorizontal";
 	  			       }else{
 	  			          $myclass="bfradio";
 	  			       }

				       if($row->mandatory & class_exists('plgBFValidatePlus')){
 	  			          ?>
				     	   <label for="<?php echo $fieldName; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?> ><?php echo JText::_($row->prefix); ?><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				     	   <?php
				     	}else{
				     	   ?>
				     	   <label for="<?php echo $fieldName; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?> ><?php echo JText::_($row->prefix); ?><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				     	   <?php
			     		}

				      	if($row->horizontal == "1"){
 				     	   //echo "&nbsp;&nbsp;&nbsp;";
 				     	   echo "&nbsp;";
				      	}else{
				      	   echo "<br>";
			     	 	}
	       	       }
	             }

	          }else{
	             //-------------------------------random options--------------------------------------------------

				$numofoptions=0;
                $myoptions = array();
                //how many options are there?
                for($x=0; $x < 20; $x++)
                {
                   $numofoptions = $x;
                   $tempvalue="option".($x+1);

                   if($row->$tempvalue == ""){
                      $x=20;
                   }else{
                      $myoptions[$x]= $x;
                   }
                }

                //randomly reorder questions
                shuffle($myoptions);

                for($y=0; $y < 20; $y++)
                {
                    if($y+1 > $numofoptions){
                       $z = $y;
                    }else{
                       $z = $myoptions[$y];
                    }

                    $tempvalue="option".($z+1);
                    $tempnext="next_question".($z+1);

                    if($row->$tempvalue != ""){
                       if($row->mandatory & class_exists('plgBFValidatePlus')){
                          ?>

                          <?php if($row->horizontal == "1"){
                             $myclass="bfradiohorizontal";
                          }else{
                             $myclass="bfradio";
                          } ?>

                          <?php echo JText::_($row->prefix); ?>
                          <label for="<?php echo $fieldName; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?> ><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }else{
                          ?>
                          <?php echo JText::_($row->prefix); ?>
                          <label for="<?php echo $fieldName; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?> ><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }

                       if($row->horizontal == "1"){
                          echo "&nbsp;&nbsp;&nbsp;";
                       }else{
                          echo "<br>";
                       }
                     }
                  }
	              //-------------------------------end random options--------------------------------------------------
	          }
			}else if($row->question_type == "2"){  // Checkbox

				if($row->horizontal == "1"){
				   $myclass="bfradiohorizontal";
				}else{
				   $myclass="bfradio";
				}

			    for($z=0; $z < 20; $z++)
			   {
			       $tempvalue="option".($z+1);
	   	           if($row->$tempvalue != ""){
	   	              if($row->$tempvalue == "_OTHER_"){
	   	                 if($row->mandatory & class_exists('plgBFValidatePlus')){
		                      ?>
				   	          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="<?php echo $row->validation_type; ?>" onchange="MakeOtherMandatory('<?php echo $fieldName; ?>','<?php echo $z; ?>')" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> ><?php echo JText::_($row->otherprefix); ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>_other" name="<?php echo $fieldName; ?>_OTHER_" value="<?php echo JText::_($tempanswer); ?>" ><?php echo JText::_($row->othersuffix); ?><?php echo JText::_($row->suffix); ?>
				   	          <?php
	       	             }else{
				   	          ?>
				   	          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> ><?php echo JText::_($row->otherprefix); ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>_OTHER_" value="<?php echo JText::_($tempanswer); ?>" ><?php echo JText::_($row->othersuffix); ?><?php echo JText::_($row->suffix); ?>
				   	          <?php
	       	             }
	       	          }else{
			             if($row->mandatory & class_exists('plgBFValidatePlus')){
			   	              ?>
   	                          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" class="<?php echo $row->validation_type; ?>" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
   	                          <?php
				         }else{
			   		          ?>
   	                          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
   	                          <?php
	   	                 }
				   	  }
			  		  if($row->horizontal == "1"){
					      echo "&nbsp;&nbsp;&nbsp;";
		   		   	  }else{
		   		   	      echo "<br>";
		   		   	  }
	   	           }
	   	        }
		   }else if($row->question_type == "3"){  // Textarea
	           if($row->mandatory){
		          echo ''.JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" class="required" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');">'.JText::_($tempanswer).'</textarea> '.JText::_($row->suffix);
		       }else{
		          echo ''.JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');">'.JText::_($tempanswer).'</textarea> '.JText::_($row->suffix);
		       }
	       }

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
	       ?>
	       </div>
	       <div class="Bfquiz_plusQuestionFooter">

	       </div>
	    </th>
	</tr>
	<?php


	} // end field is not NULL

	$k = 1 - $k;
}
?>
</table>

<?php
$num=count( $this->items );
?>

<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfquiz_plus" />
<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="Itemid" value="<?php echo $Itemid ?>" />
<input type="hidden" name="task" value="updateOnePage" />
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
<?php echo JHtml::_('form.token'); ?>
</form>

<?php
	      }else{
	  	     echo JText::_( "COM_BFQUIZPLUS_UID_ALREADY_COMPLETED");
	      }

      }else{
  	     echo JText::_( "COM_BFQUIZPLUS_EMAIL_ALREADY_COMPLETED");
      }

   }else{
      echo JText::_( "COM_BFQUIZPLUS_IP_ALREADY_COMPLETED");
   }

}else{
   echo JText::_( "COM_BFQUIZPLUS_MUST_LOGIN");
}
?>