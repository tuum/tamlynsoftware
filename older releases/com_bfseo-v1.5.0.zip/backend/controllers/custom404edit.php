<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoControllerCustom404Edit extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'custom404edit';
	}

	public function execute($task)
	{
		if (!in_array($task, array('save'))) {
			$task = 'browse';
		}
		parent::execute($task);
	}

	public function save()
	{
		$input = JFactory::getApplication()->input;

		$data = array(
			'id' 	=> $input->get('id'),
			'title' => $input->getString('title'),
			'lang'  => $input->getString('lang'),
			'html'  => $input->get('html', '<b>404</b>', 'raw')
		);

		$model = $this->getThisModel();
		$model->save($data);

		$this->setMessage(JText::_('COM_BFSEO_HTML_SAVED'));
		$this->setRedirect('index.php?option=com_bfseo&view=custom404');

		return true;
	}

}

