<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerSitemap extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'sitemap';
	}

	public function execute($task)
	{
		if (!in_array($task, array('createsitemap','deletesitemap'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function createsitemap()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		$model = $this->getThisModel();

		$app = JFactory::getApplication();
		$input = $app->input;

		$sitemap_menus = $input->get('sitemap_menus', array(), 'ARRAY');
		$sitemap_menus = implode(",", $sitemap_menus);

		$sitemap_categories = $input->get('sitemap_categories', array(), 'ARRAY');
		$sitemap_categories = implode(",", $sitemap_categories);

		$result = $model->createsitemap($sitemap_menus, $sitemap_categories);

		$url = 'index.php?option=com_bfseo&view=sitemap';
		if($result !== true) {
			$this->setRedirect($url, JText::_('COM_BFSEO_ERROR_CANT_CREATE_SITEMAP'),'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSEO_CREATED_SITEMAP'));
		}

		$this->redirect();
	}

	function deletesitemap()
	{
		$model = $this->getThisModel();

		$result = $model->deletesitemap();

		$url = 'index.php?option=com_bfseo&view=sitemap';
		if($result !== true) {
			$this->setRedirect($url, JText::_('COM_BFSEO_ERROR_CANT_DELETE_SITEMAP'),'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSEO_DELETED_SITEMAP'));
		}

		$this->redirect();
	}
}