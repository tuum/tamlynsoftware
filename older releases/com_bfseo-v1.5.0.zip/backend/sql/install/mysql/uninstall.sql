DROP TABLE IF EXISTS `#__bfseo_xmlsitemap`;
DROP TABLE IF EXISTS `#__bfseo_404s`;