<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoViewK2MetaArts extends F0FViewHtml
{
	protected function onAdd($tpl = null)
	{
		$input = JFactory::getApplication()->input;

		$session = JFactory::getSession();

		$limitstart = $input->get('limitstart', 0);

		$this->listlimit  = $input->get('listlimit', $session->get('listlimit', 20));
		$session->set('listlimit', $this->listlimit);

		list($this->menuItems, $this->pagination) = BfseoModelK2MetaArts::getMenuItems($limitstart, $this->listlimit);

		return true;
	}
}

