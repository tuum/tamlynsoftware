<?php
/*
 * @package BF SEO
* @copyright Copyright (c)2016 Tamlyn Software
* @license GNU General Public License version 2 or later
*/
defined('_JEXEC') or die();

class BfseoViewPagecheck extends F0FViewHtml
{
	protected function onBrowse($tpl = null)
	{
		$model = $this->getModel();

		return true;
	}
}