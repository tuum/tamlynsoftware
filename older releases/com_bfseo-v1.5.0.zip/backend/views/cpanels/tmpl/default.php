<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$params = JComponentHelper::getParams('com_bfseo');
$downloadid = $params->get('downloadid');

$lang = JFactory::getLanguage();
$icons_root = JURI::base().'media/com_bfseo/images/';

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');
?>
<div id="cpanel" class="row-fluid">
	<div class="span10">

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=metatags">
				<div class="bfseo-icon-metamenu"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_META_MENU'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=metatagarts">
				<div class="bfseo-icon-metaarticle"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_META_ARTICLE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=metatagcats">
				<div class="bfseo-icon-metacategory"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_META_CATEGORY'); ?></span>
			</a>
		</div>

		<?php if (bfseoHelper::isK2installed()): ?>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=k2metaarts">
				<div class="bfseo-icon-metaarticle"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_K2_META_ARTICLE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=k2metacats">
				<div class="bfseo-icon-metacategory"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_K2_META_CATEGORY'); ?></span>
			</a>
		</div>

		<?php endif ?>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=configcheck">
				<div class="bfseo-icon-configcheck"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_CONFIGCHECK'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=pagecheck">
				<div class="bfseo-icon-pagecheck"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_PAGECHECK'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=checklinks">
				<div class="bfseo-icon-linkcheck"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_CHECKLINKS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=robots">
				<div class="bfseo-icon-robots"> </div>
				<i class="fa fa-android"></i>
				<span><?php echo JText::_('COM_BFSEO_TITLE_ROBOTS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=htaccess">
				<div class="bfseo-icon-htaccess"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_HTACCESS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=sitemap">
				<div class="bfseo-icon-sitemap"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_SITEMAP'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfseo&view=custom404">
				<div class="bfseo-icon-page404"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_PAGE_404'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://www.tamlynsoftware.com/products/bf-seo/bf-seo-user-guide.html" target="_blank">
				<div class="bfseo-icon-documentation"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_USERGUIDE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/contact-us/support-tickets.html" target="_blank">
				<div class="bfseo-icon-support"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_SUPPORT_TICKETS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://extensions.joomla.org/extensions/extension/site-management/seo-a-metadata/bf-seo" target="_blank">
				<div class="bfseo-icon-rate"> </div>
				<span><?php echo JText::_('COM_BFSEO_TITLE_RATE_AND_REVIEW'); ?></span>
			</a>
		</div>

		<?php if(version_compare(PHP_VERSION, '5.3.0', 'ge') && $downloadid){ ?>
		<div align="center">
		<?php //echo LiveUpdate::getIcon(); ?>
		</div>
		<?php } ?>
	</div>
</div>

<div class="ak_clr"></div>

<div class="row-fluid footer">
<div class="span12">
	<?php global $bfseo_version; ?>
	<p style="font-size: small" class="well">Copyright &copy;<?php echo date('Y');?> Tamlyn Software. All Rights Reserved.
		<?php echo JText::_( 'COM_BFSEO_VERSION'); ?>
		<?php echo $bfseo_version; ?>
	</p>
</div>
</div>