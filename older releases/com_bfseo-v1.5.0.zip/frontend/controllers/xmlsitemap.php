<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerXmlsitemap extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'xmlsitemap';

	}
}