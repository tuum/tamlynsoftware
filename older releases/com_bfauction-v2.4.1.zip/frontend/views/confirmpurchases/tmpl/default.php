<?php

/**
 * $Id: default.php 90 2014-05-11 12:54:57Z tuum $
 * Buy now view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

jimport ('joomla.html.html.bootstrap');

//check form is submitted from our site
JRequest::checkToken() or die( 'Invalid Token' );

$user = JFactory::getUser();

$item = bfauctionHelper::getItemFromId($this->input->get('cid'));

// Overrides
if ($item->commissionAmount > 0){
	$this->cparams->commissionAmount = $item->commissionAmount;
}
if ($item->taxAmount > 0){
	$this->cparams->taxAmount = $item->taxAmount;
}
if ($item->shipping > 0){
	$this->cparams->shipping = $item->shipping;
}

$totalAmount = (float) ($item->buyNowPrice + $this->cparams->taxAmount + $this->cparams->commissionAmount);
$quantity = $item->quantity;
$quantityPurchased = $item->quantityPurchased ? $item->quantityPurchased : 1;
$nextBid = $item->buyNowPrice;

$bfcurrency 		 = $this->cparams->bfcurrency;
$currencySymbolAfter = $this->cparams->currencySymbolAfter;
$currencyLeft 		 = $currencySymbolAfter ? '' : $bfcurrency;
$currencyRight		 = $currencySymbolAfter ? $bfcurrency : '';

require_once( JPATH_COMPONENT.'/assets/confirm.php' );

?>

<div class="row-fluid">
	<div class="bfauction_Introtext">
		<?php echo JText::_( 'COM_BFAUCTION_TITLE_ARE_YOU_SURE' ); ?>&nbsp;<?php echo $item->title; ?>&nbsp;(<?php if($item->productId){ echo $item->productId; }else{ echo $item->bfauction_item_id; } ?>)?
	</div>
</div>

<div class="row-fluid">
	<div class="span7 form-horizontal">
	<fieldset>
		<form action="<?php echo JRoute::_('index.php?option=com_bfauction&view=auctions&task=commitBuyNow'); ?>" method="post" name="adminForm" id="adminForm">

				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label><?php echo JText::_( 'COM_BFAUCTION_TITLE_BUY_NOW' ); ?>:</label>
					</div>

					<div class="controls bfauction_Details">
						<?php echo bfauctionHelper::toCurrency($item->buyNowPrice) ?>
						<input type="hidden" name="option" value="com_bfauction" />
						<input type="hidden" name="task" value="commitBuyNow" />
						<input type="hidden" name="boxchecked" value="0" />
						<input type="hidden" name="buyNowPrice" value="<?php echo $item->buyNowPrice; ?>" />
						<input type="hidden" name="cid" value="<?php echo $item->bfauction_item_id; ?>" />
						<input type="hidden" name="tax" id="tax">
						<input type="hidden" name="commission" id="commission">
						<?php echo JHTML::_( 'form.token' ); ?>
					</div>
				</div>

				<?php if ($item->shipping > 0){ ?>
					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="shipping"><?php echo JText::_( 'COM_BFAUCTION_TITLE_SHIPPING' ); ?>:</label>
						</div>
						<div class="controls bfauction_Details">
							<?php echo $currencyLeft ?><?php echo $item->shipping ?>&nbsp;<?php echo $currencyRight ?>
						</div>
					</div>
				<?php } ?>

				<?php if($quantity > 1){ ?>
					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_QUANTITY' ); ?>:</label>
						</div>
						<div class="controls bfauction_Details">
							<?php echo $quantity; ?>
						</div>
					</div>

					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_QUANTITY_PURCHASED' ); ?>:</label>
						</div>
						<div class="controls">
							<input class="inputbox" type="text" name="quantityPurchased" id="quantityPurchased" size="1" value="<?php echo $quantityPurchased; ?>" onblur="process()" />
						</div>
					</div>

				<?php }else{ ?>
						<input class="inputbox" type="hidden" name="quantityPurchased" id="quantityPurchased" size="1" value="<?php echo $quantityPurchased; ?>" />
				<?php } ?>

				<?php if($this->cparams->includeCommission){ ?>
					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_COMMISSION' ); ?>:</label>
						</div>
						<div class="controls bfauction_Details">
							<div id="currencyCommission"><?php echo $currencyLeft ?></div><div id="divCommission"></div><?php echo $currencyRight ?>
						</div>
					</div>
				<?php } ?>

				<?php if($this->cparams->includeTax){ ?>
					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_TAX' ); ?>:</label>
						</div>
						<div class="controls bfauction_Details">
							<div id="currencyTax"><?php echo $currencyLeft ?></div><div id="divTax"></div><?php echo $currencyRight ?>
						</div>
					</div>
				<?php } ?>

				<?php if($this->cparams->showTotalPrice){ ?>
					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="Bid"><?php echo JText::_( 'COM_BFAUCTION_TITLE_TOTAL_PRICE' ); ?>:</label>
						</div>
						<div class="controls bfauction_Details">
							<strong><div id="currencyTax"><?php echo $currencyLeft ?></div><div id="divTotalPrice" ></div></strong><?php echo $currencyRight ?>
						</div>
					</div>
				<?php } ?>

				<div class="control-group">
					<div class="controls bfauction_Details">
						<input class="btn btn-small btn-success" name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_BUY_NOW_COMMIT' ); ?>" />
						<input type="button" class="btn btn-small btn-danger" onclick="window.location='<?php echo JRoute::_('index.php?option=com_bfauction&view=auction&id='.$this->input->get('cid')); ?>';return false;" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_CANCEL'); ?>">
					</div>
				</div>

		</fieldset>
	</div>
	</form>
</div>

<script language="javascript" type="text/javascript">
<!--
process();
//-->
</script>


