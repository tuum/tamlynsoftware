<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2015 Tim Plummer
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

    $cid = JRequest::getVar('cid');
	$user = JFactory::getUser();

	$params = JComponentHelper::getParams('com_bfauction');

	$bfcurrency = $params->get('bfcurrency');
	if($bfcurrency == ""){
		$bfcurrency = "$";
	}

	$dateFormat = $params->get( 'dateFormat' );

?>

<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_HISTORY' ); ?></legend>

	<table class="adminlist">
	<thead>
		<tr class="bfauction_plusReportHeader">
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTION_TITLE_USERNAME' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTION_TITLE_EMAIL' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID' ); ?>:
		</th>

		<th width="150">
			<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_DATE' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTION_TITLE_RETRACT_BID' ); ?>:
		</th>
		</tr>
		</thead>

		<?php
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row = $this->items[$i];
			?>
			<tr class="bfauctionReportBody">
			<td>
			   <?php echo $row->username; ?>
			</td>
			<td>
			   <?php echo $row->email; ?>
			</td>
			<td>
			   <?php echo $bfcurrency; ?><?php echo $row->bid; ?>
			</td>
			<td>
			    <strong><?php echo JHTML::_('date',  $row->bid_time, $dateFormat ); ?></strong>
			</td>
			<td>
				<form method="post" name="adminForm">
					<input type="hidden" name="option" value="com_bfauction" />
					<input type="hidden" name="task" value="retractBid" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="cid" value="<?php echo $row->bfauction_bid_id; ?>" />
					<input type="hidden" name="itemid" value="<?php echo $row->itemid; ?>" />

					<input name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo JText::_( 'COM_BFAUCTION_TITLE_RETRACT_BID' ); ?>" />
				</form>
			</td>
			</tr>
		<?php
		} //end for$row
		?>

	</table>


	</fieldset>
</div>
<div class="col width-35">
	&nbsp;
</div>
<div class="clr"></div>
