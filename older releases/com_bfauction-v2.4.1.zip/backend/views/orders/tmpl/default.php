<?php
/**
 * $Id$
 * Sales Report view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

$items = $this->items;
$status = array(
	'P' => 'Pending',
);
$gateway = array(
	'cod' => 'Cash On Delivery',
);
?>
<div class="row">
<form method="post" name="adminForm">
	<div class="row offset1">
		<div class='span12'>
			<table class='table orders'>
				<tr>
					<th>Item</th>
					<th>Highest Bidder</th>
					<th>Order Date</th>
					<th>Payment</th>
					<th>Amount</th>
					<th>Status</th>
					<th></th>
				</tr>
				<?php foreach($items as $item): ?>
					<tr>
						<td width='20%'><?php echo $item->title ?> </td>
						<td width='10%'><?php echo $item->highBidder ?> </td>
						<td width='10%'><?php echo $item->orderDate ?> </td>
						<td width='10%'><?php echo $gateway[$item->processor] ?> </td>
						<td width='10%'><?php echo bfauctionHelper::toCurrency($item->totalAmount) ?> </td>
						<td width='10%'><?php echo $status[$item->orderStatus] ?> </td>
						<td width='10%'><button class='btn btn-success btn-small' type='submit' name="orderId" value='<?php echo $item->orderId ?>'>Complete</button></td>
					</tr>
				<?php endforeach ?>
			</table>

			<?php if (!$items): ?>
				<p><b>No pending orders.</b></p>
			<?php endif ?>

			<div>
				<input type="hidden" name="task" value="complete" />
				<?php echo JHtml::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>
</div>

