<?php
/**
 *  @package BF SEO
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelRobots extends F0FModel
{
	public function createrobots()
	{
		if(file_exists(JPATH_ROOT. "/robots.txt")){
			//robots file already exists, so exit
			return false;
		}

		//first lets see if we can copy the robots.txt.dist file that comes with Joomla
		if(file_exists(JPATH_ROOT. "/robots.txt.dist")){
			JFile::copy(JPATH_ROOT. "/robots.txt.dist", JPATH_ROOT. "/robots.txt");
		};

		if(file_exists(JPATH_ROOT. "/robots.txt")){
			//robots file has been created successfully
			return true;
		}

		//There doesn't seem to be a robots.txt.dist file, so let's create a basic Robots.txt file

		$contents = '# If the Joomla site is installed within a folder such as at
# e.g. www.example.com/joomla/ the robots.txt file MUST be
# moved to the site root at e.g. www.example.com/robots.txt
# AND the joomla folder name MUST be prefixed to the disallowed
# path, e.g. the Disallow rule for the /administrator/ folder
# MUST be changed to read Disallow: /joomla/administrator/
#
# For more information about the robots.txt standard, see:
# http://www.robotstxt.org/orig.html
#
# For syntax checking, see:
# http://tool.motoricerca.info/robots-checker.phtml

User-agent: *
Disallow: /administrator/
Disallow: /bin/
Disallow: /cache/
Disallow: /cli/
Disallow: /components/
Disallow: /includes/
Disallow: /installation/
Disallow: /language/
Disallow: /layouts/
Disallow: /libraries/
Disallow: /logs/
Disallow: /modules/
Disallow: /plugins/
Disallow: /tmp/';

		JFile::write(JPATH_ROOT. "/robots.txt", $contents);

		if(file_exists(JPATH_ROOT. "/robots.txt")){
			//robots file has been created successfully
			return true;
		}
		else
		{
			return false;
		}
	}

	public function updaterobots()
	{
		$jinput = JFactory::getApplication()->input;
		$contents=$jinput->get('robotsnew','','RAW');

		$result = JFile::write(JPATH_ROOT. "/robots.txt", $contents);

		return $result;
	}
}