<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelK2MetaArts extends F0FModel
{
	public function __construct($config = array())
	{
		$config['table'] = 'k2_items';
		parent::__construct($config);
	}

	static function getMenuItems($limitstart, $listlimit)
	{
		jimport('joomla.html.pagination');

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('COUNT(*)');
		$query->from('#__k2_items');
		$db->setQuery($query);
		$count = $db->loadResult();

		$query = $db->getQuery(true);
		$query->select('id,  title, metadesc');
		$query->from('#__k2_items');
		$query->where('published = 1');
		$query->order('id');
		$db->setQuery($query);
		$db->query();
		$db->setQuery($query, $limitstart, $listlimit);
		if ($db->getErrorNum()) {
			JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1000'), JText::_('COM_BFSEO_DATABASE_ERROR'));
		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1001'), JText::_('COM_BFSEO_DATABASE_ERROR'));
			}
		}
		$pageNav = new JPagination($count, $limitstart, $listlimit);

		return array($rows, $pageNav->getListFooter());
	}

	static function updateMeta($metadesc, $id)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$metadesc = $db->quote($metadesc);

		$query->clear();
		$query->update('#__k2_items');
		$query->set("metadesc=$metadesc");
		$query->where('id=' . (int)$id);
		$db->setQuery($query);
		if (!$db->query()) {
			return false;
		}

		return true;
	}
}

