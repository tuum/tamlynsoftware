ALTER TABLE `#__bfsurvey_categories` ADD `showEmailConfirm` tinyint(1) NOT NULL;
ALTER TABLE `#__bfsurvey_categories` ADD `emailConfirmText` varchar(255) NOT NULL DEFAULT '';