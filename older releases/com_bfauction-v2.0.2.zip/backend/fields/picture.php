<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// Protect from unauthorized access
defined('F0F_INCLUDED') or die;

JFormHelper::loadFieldClass('media');

/**
 * Form Field class for the F0F framework
 * Media selection field.
 *
 * @package  FrameworkOnFramework
 * @since    2.0
 */
class F0FFormFieldPicture extends JFormFieldMedia implements F0FFormField
{
	protected $static;

	protected $repeatable;

	/** @var   F0FTable  The item being rendered in a repeatable form field */
	public $item;

	/** @var int A monotonically increasing number, denoting the row number in a repeatable view */
	public $rowid;

	/**
	 * Method to get certain otherwise inaccessible properties from the form field object.
	 *
	 * @param   string  $name  The property name for which to the the value.
	 *
	 * @return  mixed  The property value or null.
	 *
	 * @since   2.0
	 */
	public function __get($name)
	{
		switch ($name)
		{
			case 'static':
				if (empty($this->static))
				{
					$this->static = $this->getStatic();
				}

				return $this->static;
				break;

			case 'repeatable':
				if (empty($this->repeatable))
				{
					$this->repeatable = $this->getRepeatable();
				}

				return $this->static;
				break;

			default:
				return parent::__get($name);
		}
	}

	/**
	 * Get the rendering of this field type for static display, e.g. in a single
	 * item view (typically a "read" task).
	 *
	 * @since 2.0
	 *
	 * @return  string  The field HTML
	 */
	public function getStatic()
	{
		$imgattr = array(
			'id' => $this->id
		);

		if ($this->element['class'])
		{
			$imgattr['class'] = (string) $this->element['class'];
		}

		if ($this->element['style'])
		{
			$imgattr['style'] = (string) $this->element['style'];
		}

		if ($this->element['width'])
		{
			$imgattr['width'] = (string) $this->element['width'];
		}

		if ($this->element['height'])
		{
			$imgattr['height'] = (string) $this->element['height'];
		}

		if ($this->element['align'])
		{
			$imgattr['align'] = (string) $this->element['align'];
		}

		if ($this->element['rel'])
		{
			$imgattr['rel'] = (string) $this->element['rel'];
		}

		if ($this->element['alt'])
		{
			$alt = JText::_((string) $this->element['alt']);
		}
		else
		{
			$alt = null;
		}

		if ($this->element['title'])
		{
			$imgattr['title'] = JText::_((string) $this->element['title']);
		}

		if ($this->element['src'])
		{
			$src = JText::_((string) $this->element['src']);

			$replace  = $this->item->image;
			$src = str_replace('[IMAGE:ID]', $replace, $src);
		}
		else
		{
			$src = null;
		}

		if ($this->element['url'])
		{
			$url = JText::_((string) $this->element['url']);

			$keyfield = $this->item->getKeyName();
			$replace  = $this->item->$keyfield;
			$url = str_replace('[ITEM:ID]', $replace, $url);
		}
		else
		{
			$url = null;
		}

		$output="";
		if($url)
		{
			$output = '<a href="'.$url.'">'.JHtml::image($src, $alt, $imgattr).'</a>';
			$fullimage  = $this->item->image2;

			$temp_pic = JPATH_SITE.'/'.$fullimage;
			$fullimage = JUri::base().$fullimage;
			if (file_exists($temp_pic))
			{
				$output = '<a href="'. $fullimage . '?time=' . time() . '"  class="lytebox">'.JHtml::image($src, $alt, $imgattr).'</a>';
			}
			else
			{
				$output = '<a href="'.$url.'">'.JHtml::image($src, $alt, $imgattr).'</a>';
			}
		}
		else
		{
			$output = JHtml::image($src, $alt, $imgattr);
		}

		return $output;
	}

	/**
	 * Get the rendering of this field type for a repeatable (grid) display,
	 * e.g. in a view listing many item (typically a "browse" task)
	 *
	 * @since 2.0
	 *
	 * @return  string  The field HTML
	 */
	public function getRepeatable()
	{
		return $this->getStatic();
	}
}
