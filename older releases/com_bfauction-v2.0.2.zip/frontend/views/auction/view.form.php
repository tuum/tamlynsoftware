<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die();

class BfauctionViewAuction extends F0FViewForm
{
	public function display($tpl = null)
	{
		$id = $this->input->get('id');
		$this->cparams  = bfauctionHelper::getOptions($id);

		$model = $this->getModel();
		$this->lastbid	= $model->getLastBidData();

		$user = JFactory::getUser();
		$this->profile	= $model->getUserProfile($user->id);

		parent::display($tpl);
	}
}