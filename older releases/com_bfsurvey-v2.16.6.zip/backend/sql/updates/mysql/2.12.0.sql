ALTER TABLE `#__bfsurvey_emailitems`
ADD `replyTo` text,
ADD `replyToName` text;