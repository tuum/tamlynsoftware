<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

class BFSurveyDispatcher extends F0FDispatcher
{
	public function onBeforeDispatch() {
		$result = parent::onBeforeDispatch();

		if($result) {
			// Load Akeeba Strapper
			include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
			AkeebaStrapper::bootstrap();
			AkeebaStrapper::jQueryUI();
		}

		return $result;
	}

	static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject, $filename, $attachments=null, $mailfrom, $fromname)
	{
		$conf	= JFactory::getConfig();

		if($mailfrom == '')
		{
			$mailfrom 	= $conf->get('mailfrom', $conf->get('config.mailfrom'));
		}

		if($fromname == '')
		{
			$fromname 	= $conf->get('fromname', $conf->get('config.fromname'));
		}

		$emailBody = $body;
		$mode = 1;

		$mysendEmailTo = 	explode( ',', $sendEmailTo );
		foreach($mysendEmailTo AS $sendEmailTo)
		{
			$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';

			if(empty($attachments)){
				$attachments = array();
			}
			if (!is_array($attachments)){
				$attachments = array($attachments);
			}
			if (!empty($filename) && JFile::exists($path . $filename)){
				$PDFattachment = $path . $filename;
				array_push($attachments, $PDFattachment);
			}

			$cc = null;
			$bcc = null;

			if(empty($attachments))
			{
				//no attachment
				$attachments = null;
			}

			JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode, $cc, $bcc, $attachments, $mailfrom, $fromname);
		}
	}

	static function getEmailTemplate($title,$category)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfsurvey_emailitems');
		$query->where('enabled = 1 AND title='.$db->quote( $db->escape($title), false ));
		$query->where('bfsurvey_category_id = '.(int)$category);
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	static function getEmailType($id, $contentType, $status, $catid)
	{
		$emailType="";

		//which event is triggering the email?

		//let's get all the email templates for this category
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('title, condition_trigger, condition_field1, condition_criteria1, condition_value1');
		$query->from($db->quoteName('#__bfsurvey_emailitems'));
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->where('enabled');
		$db->setQuery((string)$query);
		$myemailitems = $db->loadObjectList();

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			// has status (or any other field) changed since last save?
			// look at history table
			$table1 = JTable::getInstance('Contenthistory');
			$table2 = JTable::getInstance('Contenthistory');

			$query->clear();
			$query->from($db->quoteName('#__ucm_history'));
			$query->select('version_id');
			$query->where('ucm_type_id = '.(int)$contentType);
			$query->where('ucm_item_id = '.(int)$id);
			$query->order('save_date DESC');
			$db->setQuery((string)$query);
			$myids = $db->loadObjectList();

			if(isset($myids[0])){
				$id1 = $myids[0]->version_id;
				$id2 = isset($myids[1]->version_id) ? $myids[1]->version_id : $myids[0]->version_id;
			}else{
				$id1 = null;
				$id2 = null;
			}

			$myresult = array();
		}

		foreach($myemailitems as $i => $emailitem):
		//what is the email trigger?

		if($emailitem->condition_trigger=="0")
		{
			if(count($myids)==1 || count($myids)==0)
			{
				//initial save or content history turned off
				$emailType[$i]=$emailitem->title;
			}
			else
			{
				//not first save as this item has content history
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==1)
		{
			//content history feature was added in Joomla 3.2
			if (version_compare(JVERSION, '3.1.6', 'gt'))
			{
				JLoader::register('ContenthistoryHelper', JPATH_ADMINISTRATOR . '/components/com_contenthistory/helpers/contenthistory.php');

				//field changes
				$condition_field1 = $emailitem->condition_field1;
				$condition_criteria1 = $emailitem->condition_criteria1;
				$condition_value1 = $emailitem->condition_value1;

				if($condition_criteria1 == -1 || $condition_value1 == '')
				{
					// only care if this field has changed or not
					if ($table1->load($id1) && $table2->load($id2))
					{
						foreach (array($table1, $table2) as $mytable)
						{
							$object = new stdClass;
							$object->data = ContenthistoryHelper::prepareData($mytable);
							$object->version_note = $mytable->version_note;
							$object->save_date = $mytable->save_date;
							$myresult[] = $object;
						}

						if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
							//field is the same, so this email is not triggered
							$emailType[$i]="";
						}else{
							//field has changed, so use this email template
							$emailType[$i]=$emailitem->title;
						}
					}
				}
				else
				{
					// we want this field to change, but also have a specific value
					// basically we only want one email triggered for this status, regardless of whether there are multiple changes
					if ($table1->load($id1) && $table2->load($id2))
					{
						foreach (array($table1, $table2) as $mytable)
						{
							$object = new stdClass;
							$object->data = ContenthistoryHelper::prepareData($mytable);
							$object->version_note = $mytable->version_note;
							$object->save_date = $mytable->save_date;
							$myresult[] = $object;
						}

						if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
							//field is the same, so this email is not triggered
							$emailType[$i]="";
						}else{
							//field has changed, so now check if it has specific value
							if ($condition_criteria1<>"-1")
							{
								foreach (array($table1, $table2) as $mytable)
								{
									$object = new stdClass;
									$object->data = ContenthistoryHelper::prepareData($mytable);
									$object->version_note = $mytable->version_note;
									$object->save_date = $mytable->save_date;
									$myresult[] = $object;
								}

								if($condition_criteria1 == 1)
								{
									if($status == $condition_value1){
										//field is the same, so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 0)
								{
									if($status < $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 2)
								{
									if($status > $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 3)
								{
									if($status <> $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
							}
						}
					}
				}
			}else{
				//content history not supported, don't send any email
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==2)
		{
			//content history feature was added in Joomla 3.2
			if (version_compare(JVERSION, '3.1.6', 'gt'))
			{
				JLoader::register('ContenthistoryHelper', JPATH_ADMINISTRATOR . '/components/com_contenthistory/helpers/contenthistory.php');

				//field has specific value
				$condition_field1 = $emailitem->condition_field1;
				$condition_criteria1 = $emailitem->condition_criteria1;
				$condition_value1 = $emailitem->condition_value1;

				//we only care about the updated value on the form
				if ($table1->load($id1) && $condition_criteria1<>"-1" && $id1>0)
				{
					foreach ($table1 as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($condition_criteria1 == 1)
					{
						if($status == $condition_value1){
							//field is the same, so this email is triggered
							$emailType[$i]=$emailitem->title;
						}
						else
						{
							//don't use this template
							$emailType[$i]="";
						}
					}
					else if($condition_criteria1 == 0)
					{
						if($status < $condition_value1){
							//this matches so this email is triggered
							$emailType[$i]=$emailitem->title;
						}
						else
						{
							//don't use this template
							$emailType[$i]="";
						}
					}
					else if($condition_criteria1 == 2)
					{
						if($status > $condition_value1){
							//this matches so this email is triggered
							$emailType[$i]=$emailitem->title;
						}
						else
						{
							//don't use this template
							$emailType[$i]="";
						}
					}
					else if($condition_criteria1 == 3)
					{
						if($status <> $condition_value1){
							//this matches so this email is triggered
							$emailType[$i]=$emailitem->title;
						}
						else
						{
							//don't use this template
							$emailType[$i]="";
						}
					}
				}
			}else{
				//content history not supported, don't send any email
				$emailType[$i]="";
			}
		}
		else
		{
			$emailType[$i]="";
		}
		endforeach;

		return $emailType;
	}

	static function sendEmail($myemail, $table, $catid)
	{
		$menuId = BFSurveyDispatcher::getMenuId($catid);

		$id = 'bfsurvey_'.$catid.'result_id';
		$url = '<a href="'.JUri::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&id='.$table->$id.'&Itemid='.$menuId.'">'.$table->$id.'</a>';

		if($myemail[0]->pdfEmail)
		{
			// do stuff to generate PDF

			// see if PDF flie already exists
			JLoader::import('joomla.filesystem.file');
			$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';
			$filename = 'email_' . $catid . '_' . $table->$id.'.pdf';

			$reportDetails = BFSurveyDispatcher::getReport($catid);
			$report = BFSurveyDispatcher::createReport($catid, $table->$id);
			$filename = BFSurveyDispatcher::createPDF($reportDetails[0], $report, $reportDetails['fields'], $catid, $table->$id, $reportDetails['question_types']);
		}

		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{Name}/', $table->Name , $myemail[0]->description); // insert Name
		$myemail[0]->description=preg_replace('/{name}/', $table->Name , $myemail[0]->description); // insert Name
		$myemail[0]->description=preg_replace('/{Company}/', $table->Company , $myemail[0]->description); // insert Company
		$myemail[0]->description=preg_replace('/{company}/', $table->Company , $myemail[0]->description); // insert Company
		$myemail[0]->description=preg_replace('/{Email}/', $table->Email , $myemail[0]->description); // insert Email
		$myemail[0]->description=preg_replace('/{email}/', $table->Email , $myemail[0]->description); // insert Email
		$myemail[0]->description=preg_replace('/{uid}/', $table->created_by , $myemail[0]->description); // insert uid

		$myemail[0]->subject=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->subject); // insert id
		$myemail[0]->description=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->description); // insert description

		$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
		$myemail[0]->subject=preg_replace('/{Name}/', $table->Name , $myemail[0]->subject); // insert Name
		$myemail[0]->subject=preg_replace('/{name}/', $table->Name , $myemail[0]->subject); // insert Name
		$myemail[0]->subject=preg_replace('/{Company}/', $table->Company , $myemail[0]->subject); // insert Company
		$myemail[0]->subject=preg_replace('/{company}/', $table->Company , $myemail[0]->subject); // insert Company
		$myemail[0]->subject=preg_replace('/{Email}/', $table->Email , $myemail[0]->subject); // insert Email
		$myemail[0]->subject=preg_replace('/{email}/', $table->Email , $myemail[0]->subject); // insert Email
		$myemail[0]->subject=preg_replace('/{uid}/', $table->created_by , $myemail[0]->subject); // insert uid

		if (strpos($myemail[0]->description,'{allfields}') !== false)
		{
			$fieldChanges = BFSurveyDispatcher::getAllFieldsData($table->$id, $catid);
			$myemail[0]->description=preg_replace('/{allfields}/', $fieldChanges , $myemail[0]->description);
			$myemail[0]->description=preg_replace('/_OTHER_/', '' , $myemail[0]->description);
		}

		$mailfrom = preg_replace('/{Email}/', $table->Email , $myemail[0]->replyTo); // insert Email
		$fromname = preg_replace('/{Name}/', $table->Name , $myemail[0]->replyToName); // insert Name

		//now get the field names of all the fields except the attachment fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->where('question_type != 4'); // not the attachment fields
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		//get list of all fields in the database
		foreach($myFields AS $field)
		{
			$fieldname=$field->field_name;
			if(is_array($table->$fieldname)){
				$table->$fieldname = implode(",", $table->$fieldname);
			}
			$myemail[0]->description=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->description);
			$myemail[0]->subject=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->subject);

			$mailfrom = preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $mailfrom);
			$fromname = preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $fromname);
		}

		//attachments?
		$attachments = self::findAttachments($myemail,$table,$id,$query,$db);

		$emailSubject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		//is there a send to group set?
		if($myemail[0]->sendToGroup)
		{
			$sendToGroup = BFSurveyDispatcher::getSendToGroup($myemail[0]->sendToGroup);

			foreach($sendToGroup as $sendEmailTo)
			{
				$myurl = '<a href="'.JUri::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&uuid='.$sendEmailTo->uuid.'&Itemid='.$menuId.'">'.$myemail[0]->title.'</a>';
				$mybody=preg_replace('/{uurl}/', $myurl , $body); // insert unique user url (uurl)

				BFSurveyDispatcher::sendHTMLNotificationEmail($mybody, $sendEmailTo->email, $emailSubject, $filename, $attachments, $mailfrom, $fromname);
			}
		}

		$myemail[0]->sendTo=preg_replace('/{Email}/', $table->Email , $myemail[0]->sendTo); // insert Email
		if($myemail[0]->sendTo != '')
		{
			$sendEmailTo = $myemail[0]->sendTo;

			$mysendEmailTo = 	explode( ',', $sendEmailTo );
			foreach($mysendEmailTo AS $sendEmailTo)
			{
				$mybody = $body;

				$uuid = BFSurveyDispatcher::getUuid($sendEmailTo);
				if($uuid != '' && $uuid != null)
				{
					$myurl = '<a href="'.JUri::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&uuid='.$uuid.'&Itemid='.$menuId.'">'.$myemail[0]->title.'</a>';
					$mybody=preg_replace('/{uurl}/', $myurl , $body); // insert unique user url (uurl)
				}

				BFSurveyDispatcher::sendHTMLNotificationEmail($mybody, $sendEmailTo, $emailSubject, $filename, $attachments, $mailfrom, $fromname);
			}
		}
	}

	static function findAttachments($myemail,$table,$id,$query,$db){
		// get the field names of all the files fields
		$query->clear();
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name');
		$query->where('bfsurvey_category_id = 1');
		$query->where('question_type = 4');  //attachment
		$db->setQuery((string)$query);
		$filesFields = $db->loadObjectList();
		$attachments = array();
		foreach($filesFields as $fileField){
			$pattern = JPATH_SITE.'/images/com_bfsurvey/'.$table->$id.$fileField->field_name.'_original.*';
			$attachments = array_merge($attachments, glob($pattern));
			$myemail[0]->description=preg_replace('/{'.$fileField->field_name.'}/', 'attached' , $myemail[0]->description);
		}
		return $attachments;
	}

	static function getAllFieldsData($id, $catid)
	{
		$fieldData = '';

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//need to find out id in #__content_types table
		$query->select('*');
		$query->from('#__bfsurvey_'.$catid.'results');
		$query->where('bfsurvey_'.$catid.'result_id = '.(int)$id);
		$db->setQuery((string)$query);
		$myresult=$db->loadObjectList();

		//get all field names
		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name, parent, bfsurvey_question_id');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->order('ordering');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();

		// establish the hierarchy of the questions
		$children = array();
		// first pass - collect children
		foreach ($items as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$myFields = array();
		foreach ($items as $v )
		{
			if($v->parent==0){
				array_push($myFields, $v);

				//now are there any children
				if(isset($children[$v->bfsurvey_question_id])){
					foreach ($children[$v->bfsurvey_question_id] as $c ){
						array_push($myFields, $c);
					}
				}
			}
		}

		//loop through all the fields
		foreach($myFields as $field)
		{
			$fieldname=$field->field_name;
			$flag=0;

			if(isset($myresult[0]->$fieldname))
			{
				if($myresult[0]->$fieldname != "" && $myresult[0]->$fieldname != NULL){
					if(is_array($myresult[0]->$fieldname)){
						$value = implode(",", $myresult[0]->$fieldname);
					}else{
						$value = $myresult[0]->$fieldname;
					}
					$question = BFSurveyDispatcher::getQuestion($fieldname, $catid);
					$fieldData.=$question.': '.$value."<br>";
				}
			}
		}

		return $fieldData;
	}

	static function getQuestion($fieldname, $catid)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('title');
		$query->from('#__bfsurvey_questions');
		$query->where('field_name = '.$db->quote($fieldname));
		$query->where('bfsurvey_category_id = '.$db->quote($catid));
		$db->setQuery((string)$query);
		$question=$db->loadResult();

		return $question;
	}

	/*
	 * Used for rating question on PDF
	 */
	static function getOption($fieldname, $catid, $i)
	{
		if($i > 20 || $i < 1)
		{
			return null;
		}
		$option = "option".$i;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select($option);
		$query->from('#__bfsurvey_questions');
		$query->where('field_name = '.$db->quote($fieldname));
		$query->where('bfsurvey_category_id = '.$db->quote($catid));
		$db->setQuery((string)$query);
		$myoption=$db->loadResult();

		return $myoption;
	}

	/*
	 * Get the field from the categories table
	 */
	static function getCategory($fieldname, $catid)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select($fieldname);
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.$db->quote($catid));
		$db->setQuery((string)$query);
		$question=$db->loadResult();

		return $question;
	}

	static function getSendToGroup($sendToGroup)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('a.email, md5(concat('.$db->quoteName('a.id').','.$db->quoteName('a.username').','.$db->quoteName('a.password').')) AS uuid');
		$query->from($db->quoteName('#__user_usergroup_map') . ' AS map');
		$query->join('LEFT', $db->quoteName('#__users').' AS a ON map.user_id = a.id');
		$query->where('map.group_id = '.$sendToGroup);

		$db->setQuery((string)$query);
		$sendToGroup = $db->loadObjectList();

		return $sendToGroup;
	}

	static function getUuid($sendEmailTo)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('md5(concat('.$db->quoteName('a.id').','.$db->quoteName('a.username').','.$db->quoteName('a.password').')) AS uuid');
		$query->from($db->quoteName('#__users').' AS a');
		$query->where('a.email = '.$db->quote(trim($db->escape($sendEmailTo))));

		$db->setQuery((string)$query);
		$uuid = $db->loadResult();

		return $uuid;
	}


	// From here down is for PDF email attachments
	static function getReport($catid)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('bfsurvey_emailitem_id, subject, description, '
				.'pdfEmail, template, templateCoverpage, templateHeader, templateFooter');
		$query->from('#__bfsurvey_emailitems');
		$query->where('bfsurvey_category_id='.(int)$catid);
		$query->where('pdfEmail=1');
		$db->setQuery((string)$query);
		$result = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		//get all field names
		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name, parent, bfsurvey_question_id, question_type');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->order('ordering');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();

		// establish the hierarchy of the questions
		$children = array();
		// first pass - collect children
		foreach ($items as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$myFields = array();
		foreach ($items as $v )
		{
			if($v->parent==0){
				array_push($myFields, $v);

				//now are there any children
				if(isset($children[$v->bfsurvey_question_id])){
					foreach ($children[$v->bfsurvey_question_id] as $c ){
						array_push($myFields, $c);
					}
				}
			}
		}

		//loop through all the fields
		$mfields="";
		$qnfields="";
		$counter=0;
		foreach($myFields as $field)
		{
			if($counter > 0)
			{
				$mfields.=",".$field->field_name;
				$qnfields.=",".$field->question_type;
			}
			else
			{
				$mfields.=$field->field_name;
				$qnfields.=$field->question_type;
			}
			$counter++;
		}

		$result['fields'] = $mfields;
		$result['question_types'] = $qnfields;

		return $result;
	}


	static function after ($this, $inthat)
	{
		if (!is_bool(strpos($inthat, $this)))
			return substr($inthat, strpos($inthat,$this)+strlen($this));
	}

	static function before ($this, $inthat)
	{
		return substr($inthat, 0, strpos($inthat, $this));
	}

	static function createReport($catid, $id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfsurvey_'.$catid.'results');
		$query->where('bfsurvey_'.$catid.'result_id='.$id);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		return $result;
	}

	static function createPDF($reportDetails, $report, $fields, $catid, $tableid, $question_types)
	{
		$html = "";

		if($reportDetails->templateCoverpage != '')
		{
			$templateCoverpage = $reportDetails->templateCoverpage;
			foreach ($report as $i => $item) :
				foreach (explode(',',$fields) as $field) :
					$template = preg_replace('/\['.$field.'\]/', htmlspecialchars($item->$field), $template);
				endforeach;
			endforeach;
			$now = JFactory::getDate();
			$date=$now->format('d M Y');
			$templateCoverpage = preg_replace('/\{date\}/', $date, $templateCoverpage);
			$html.= $templateCoverpage;
			$html .= $reportDetails->templateFooter;
			//add page break
			$html.= '<div style="page-break-after: always"></div>';
			if($reportDetails->templateHeader != '' && $reportDetails->rowsAsSeparatePages==0)
			{
				$html.= $reportDetails->templateHeader;
			}
		}

		if($reportDetails->template != '')
		{
			foreach ($report as $i => $item) :
				$template = "";
				if($reportDetails->rowsAsSeparatePages)
				{
					if($reportDetails->templateHeader != '')
					{
						$template .= $reportDetails->templateHeader;
						$template .= '<div class="clearfix"> </div>';
					}
				}
				$template .= $reportDetails->template;

				foreach (explode(',',$fields) as $field) :
					$template = preg_replace('/\['.$field.'\]/', htmlspecialchars($item->$field), $template);
					if($i % 2)
					{
						$template = preg_replace('/\<tr\>/', '<tr style="background-color:#DDDDDD;">', $template);
					}
				endforeach;
				$html.= $template;

			endforeach;
		}else{
			//default layout for PDF email
			$surveyTitle = BFSurveyDispatcher::getCategory('surveyTitle', $catid);
			$html.='<h1>'.$surveyTitle.'</h1>';

			$html.='
				<style type="text/css">
				.question{
					font-size: 28px;
					font-weight: bold;
    				color: #424F9A;
					font-family: "ITCFranklinGothicW01-Md 812698";
				}
				.answer{
    				font-family: "ITCFranklinGothicW01-Md 812698";
				}
				</style>
';

			$html.='
				<div id="j-main-container" class="span10">

					<div class="clearfix"> </div>
					<table class="table table-striped" id="reportList">
						<thead>';

			$html.='
						</thead>
						<tbody>';

			//display standard fields
			$showName = BFSurveyDispatcher::getCategory('showName', $catid);
			if($showName){
				$html.='<tr class="row"><td class="question">Name</td></tr>
						<tr class="rowanswer"><td class="answer">
						'.$report[0]->Name.'
						</td></tr><br>
						';
			}

			$showCompany = BFSurveyDispatcher::getCategory('showCompany', $catid);
			if($showCompany){
				$html.='<tr class="row"><td class="question">Company</td></tr>
						<tr class="rowanswer"><td class="answer">
						'.$report[0]->Company.'
						</td></tr><br>
						';
			}

			$showEmail = BFSurveyDispatcher::getCategory('showEmail', $catid);
			if($showEmail){
				$html.='<tr class="row"><td class="question">Email</td></tr>
						<tr class="rowanswer"><td class="answer">
						'.$report[0]->Email.'
						</td></tr><br>
						';
			}

			//loop through all the fields
			$counter=0;
			$question_type = explode(',',$question_types);
			foreach(explode(',',$fields) as $fieldname)
			{
				if($question_type[$counter] == 9){  //rating
					$fieldnameBefore = $fieldname;

					$question = BFSurveyDispatcher::getQuestion($fieldnameBefore, $catid);
					$html.='<tr class="row'.($counter % 2).'"><td class="question">'.$question.'</td></tr>';

					for($i = 1; $i < 21; $i++){
						$fieldname = $fieldnameBefore.'_'.$i;
						if(isset($report[0]->$fieldname))
						{
							if($report[0]->$fieldname != "" && $report[0]->$fieldname != NULL){
								if(is_array($report[0]->$fieldname)){
									$value = implode(",", $report[0]->$fieldname);
								}else{
									$value = $report[0]->$fieldname;
								}

								$option = BFSurveyDispatcher::getOption($fieldnameBefore, $catid, $i);
								$html.='<tr class="row'.($counter % 2).'"><td class="question">'.$option.'</td></tr><tr class="rowanswer'.($counter % 2).'"><td class="answer">'.$value.'</td></tr>';
							}
						}
					}

					$html.='<div class="clearfix"> </div>';
				}

				if(isset($report[0]->$fieldname))
				{
					// everything else that is not rating quesiton type
					if($report[0]->$fieldname != "" && $report[0]->$fieldname != NULL){
						if(is_array($report[0]->$fieldname)){
							$value = implode(",", $report[0]->$fieldname);
						}else{
							$value = $report[0]->$fieldname;
						}
						$question = BFSurveyDispatcher::getQuestion($fieldname, $catid);
						$html.='<tr class="row'.($counter % 2).'"><td class="question">'.$question.'</td></tr><tr class="rowanswer'.($counter % 2).'"><td class="answer">'.$value.'</td></tr><div class="clearfix"> </div>';
					}
				}

				$counter++;
			}

			$html.='
						</tbody>
					</table>
				</div>';
		}

		// Repair the input HTML
		if (function_exists('tidy_repair_string'))
		{
			$tidyConfig = array(
					'bare'							=> 'yes',
					'clean'							=> 'yes',
					'drop-proprietary-attributes'	=> 'yes',
					'clean'							=> 'yes',
					'output-html'					=> 'yes',
					'show-warnings'					=> 'no',
					'ascii-chars'					=> 'no',
					'char-encoding'					=> 'utf8',
					'input-encoding'				=> 'utf8',
					'output-bom'					=> 'no',
					'output-encoding'				=> 'utf8',
					'force-output'					=> 'yes',
					'tidy-mark'						=> 'no',
					'wrap'							=> 0,
			);
			$repaired = tidy_repair_string($html, $tidyConfig, 'utf8');
			if ($repaired !== false)
			{
				$html = $repaired;
			}
		}

		if($reportDetails->templateHeader != '' && $reportDetails->templateCoverpage == '')
		{
			$template = $reportDetails->templateHeader;
			$template .= $html;
			$html = $template;
		}

		$html .= $reportDetails->templateFooter;

		//echo "<pre>" . htmlentities($html) . "</pre>"; die();

		// Create the PDF
		$pdf = BFSurveyDispatcher::getTCPDF();
		$pdf->AddPage();
		$pdf->writeHTML($html, true, false, true, false, '');
		$pdf->lastPage();
		$pdfData = $pdf->Output('', 'S');

		unset($pdf);

		// Write the PDF data to disk using JFile::write();
		JLoader::import('joomla.filesystem.file');
		if (function_exists('openssl_random_pseudo_bytes'))
		{
			$rand = openssl_random_pseudo_bytes(16);
			if ($rand === false)
			{
				// Broken or old system
				$rand = mt_rand();
			}
		}
		else
		{
			$rand = mt_rand();
		}
		$hashThis = serialize($reportDetails) . microtime() . $rand;
		if (function_exists('hash'))
		{
			$hash = hash('sha256', $hashThis);
		}
		if (function_exists('sha1'))
		{
			$hash = sha1($hashThis);
		}
		else
		{
			$hash = md5($hashThis);
		}

		$categoryTitle = BFSurveyDispatcher::getCategory('surveyTitle', $catid);

		$name = preg_replace('/\s+/', '', $categoryTitle) . '_' . $tableid.'.pdf';

		$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';

		$ret = JFile::write($path . $name, $pdfData);
		if ($ret)
		{
			// return the name of the file
			return $name;
		}
		else
		{
			return false;
		}
	}

	static function &getTCPDF()
	{
		// Set up TCPDF
		$jreg = JFactory::getConfig();
		$tmpdir = $jreg->get('tmp_path');
		$tmpdir = rtrim($tmpdir, '/' . DIRECTORY_SEPARATOR) . '/';
		$siteName = $jreg->get('sitename');

		$baseurl = JURI::base();
		$baseurl = rtrim($baseurl, '/');

		define('K_TCPDF_EXTERNAL_CONFIG', 1);

		define ('K_PATH_MAIN', JPATH_BASE . '/');
		define ('K_PATH_URL', $baseurl);
		define ('K_PATH_FONTS', JPATH_ROOT.'/media/com_bfsurvey/tcpdf/fonts/');
		define ('K_PATH_CACHE', $tmpdir);
		define ('K_PATH_URL_CACHE', $tmpdir);
		define ('K_PATH_IMAGES', JPATH_ROOT.'/media/com_bfsurvey/tcpdf/images/');
		define ('K_BLANK_IMAGE', K_PATH_IMAGES.'_blank.png');
		define ('PDF_PAGE_FORMAT', 'A4');
		define ('PDF_PAGE_ORIENTATION', 'P');
		define ('PDF_CREATOR', 'BFSurvey Applicaiton');
		define ('PDF_AUTHOR', $siteName);
		define ('PDF_UNIT', 'mm');
		define ('PDF_MARGIN_HEADER', 5);
		define ('PDF_MARGIN_FOOTER', 10);
		define ('PDF_MARGIN_TOP', 27);
		define ('PDF_MARGIN_BOTTOM', 25);
		define ('PDF_MARGIN_LEFT', 15);
		define ('PDF_MARGIN_RIGHT', 15);
		define ('PDF_FONT_NAME_MAIN', 'dejavusans');
		define ('PDF_FONT_SIZE_MAIN', 8);
		define ('PDF_FONT_NAME_DATA', 'dejavusans');
		define ('PDF_FONT_SIZE_DATA', 8);
		define ('PDF_FONT_MONOSPACED', 'dejavusansmono');
		define ('PDF_IMAGE_SCALE_RATIO', 1.25);
		define('HEAD_MAGNIFICATION', 1.1);
		define('K_CELL_HEIGHT_RATIO', 1.25);
		define('K_TITLE_MAGNIFICATION', 1.3);
		define('K_SMALL_RATIO', 2/3);
		define('K_THAI_TOPCHARS', true);
		define('K_TCPDF_CALLS_IN_HTML', false);

		require_once JPATH_ADMINISTRATOR . '/components/com_bfsurvey/assets/tcpdf/tcpdf.php';

		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor(PDF_AUTHOR);
		$pdf->SetTitle('Report');
		$pdf->SetSubject('Report');

		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

		$pdf->setHeaderFont(array('dejavusans', '', 8, '', false));
		$pdf->setFooterFont(array('dejavusans', '', 8, '', false));
		$pdf->SetFont('dejavusans', '', 8, '', false);

		return $pdf;
	}

	public static function getMenuId($catid)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, params');
		$query->from('#__menu');
		$query->where('link = "index.php?option=com_bfsurvey&view=survey"');
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$menuId = 0;
		foreach ($rows as $row) {
			$json = json_decode($row->params);
			if ($catid == $json->slug) {
				$menuId = $row->id;
				break;
			}
		}
		return $menuId;
	}

}