<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Showoptions Form Field class
 */
class JFormFieldTerminateoptions extends JFormFieldList
{
	/**
     * The field type.
     *
     * @var         string
     */
    protected $type = 'terminateoptions';

    /**
     * Method to get a list of options for a list input.
     *
     * @return      array           An array of JHtml options.
     */
    protected function getOptions()
    {
    	$values = (array) $this->value;

	    // Initialize variables.
		$options = array();
		$show_options = "";
		$noresult=0;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//if we are loading existing question, get that terminate option
		$id = JRequest::getVar( 'id', 0, '', 'int' );
		if($id>0)
		{
			$query->from('#__bfsurvey_questions');
			$query->select('option1, option2, option3, option4, option5, option6, option7, option8, option9, option10, option11, option12, option13, option14, option15, option16, option17, option18, option19, option20');
			$query->where('bfsurvey_question_id='.(int) $id);
			$db->setQuery((string)$query);
			$result = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return false;
			}

			$options = array();
			$options[] = JHtml::_('select.option',  '0', JText::_('COM_BFSURVEY_SELECT_PLEASE_SELECT'));
			for($i=1; $i < 21; $i++){
				$myoption="option".$i;
				$options[] = JHtml::_('select.option', $result[0]->$myoption, $result[0]->$myoption);
			}
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		reset($options);

		return $options;
	}

	protected function getInput()
	{
		$html = array();
		$attr = '';

		if (!is_array($this->value) && !empty($this->value))
		{
			// String in format 2,5,4
			if (is_string($this->value))
			{
				$this->value = explode(',', $this->value);

				//work around to allow commas in options
				$this->value = str_replace('^',',', $this->value);
			}
		}

		// Get the field options.
		$options = (array) $this->getOptions();

		$input = parent::getInput();

		return $input;
	}

}