<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// Load FOF if not already loaded
if (!defined('F0F_INCLUDED'))
{
	$paths = array(
			(defined('JPATH_LIBRARIES') ? JPATH_LIBRARIES : JPATH_ROOT . '/libraries') . '/f0f/include.php',
			__DIR__ . '/fof/include.php',
	);

	foreach ($paths as $filePath)
	{
		if (!defined('F0F_INCLUDED') && file_exists($filePath))
		{
			@include_once $filePath;
		}
	}
}

// Pre-load the installer script class from our own copy of FOF
if (!class_exists('F0FUtilsInstallscript', false))
{
	@include_once __DIR__ . '/fof/utils/installscript/installscript.php';
}

// Pre-load the database schema installer class from our own copy of FOF
if (!class_exists('F0FDatabaseInstaller', false))
{
	@include_once __DIR__ . '/fof/database/installer.php';
}

// Pre-load the update utility class from our own copy of FOF
if (!class_exists('F0FUtilsUpdate', false))
{
	@include_once __DIR__ . '/fof/utils/update/update.php';
}

class Com_BFSurveyInstallerScript extends F0FUtilsInstallscript
{
	/**
	 * The title of the component (printed on installation and uninstallation messages)
	 *
	 * @var string
	 */
	protected $componentTitle = 'BF Survey';

	/**
	 * The component's name
	 *
	 * @var   string
	 */
	protected $componentName = 'com_bfsurvey';

	/**
	 * The list of extra modules and plugins to install on component installation / update and remove on component
	 * uninstallation.
	 *
	 * @var   array
	 */
	protected $installation_queue = array
	(
			// modules => { (folder) => { (module) => { (position), (published) } }* }*
			'modules' => array(
					'site' => array(
							'bfsurvey' => array('left', 0)
					)
			),
			// plugins => { (folder) => { (element) => (published) }* }*
			'plugins' => array(
					'installer' => array(
				   'bfsurvey' => 1,
					),
			)
	);

	/**
	 * Runs after install, update or discover_update
	 * @param string $type install, update or discover_update
	 * @param JInstaller $parent
	 */
	function postflight($type, $parent)
	{
		parent::postflight($type, $parent);

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			$table = JTable::getInstance('Contenttype', 'JTable');
			if(!$table->load(array('type_alias' => 'com_bfsurvey.question')))
			{
				$common = new stdClass;
				$common->core_content_item_id = 'bfsurvey_question_id';
				$common->core_title = 'title';
				$common->core_state = 'enabled';
				$common->core_alias = 'slug';
				$common->core_created_time = 'created_on';
				$common->core_modified_time = 'modified_on';
				//$common->core_access = 'access';
				$common->core_ordering = 'ordering';
				$common->core_catid = 'bfsurvey_category_id';
				$common->asset_id = null;
				$field_mappings = new stdClass;
				$field_mappings->common[] = $common;
				$field_mappings->special = array();
				$special = new stdClass;
				$special->dbtable = '#__bfsurvey_questions';
				$special->key = 'bfsurvey_question_id';
				$special->type = 'MyQuestion';
				$special->prefix = 'BFSurveyTable';
				$special->config = 'array()';
				$table_object = new stdClass;
				$table_object->special = $special;
				$contenttype['type_title'] = 'BFSurvey';
				$contenttype['type_alias'] = 'com_bfsurvey.question';
				$contenttype['table'] = json_encode($table_object);
				$contenttype['rules'] = '';
				$contenttype['router'] = 'BFSurveyHelperRoute::getBFSurveyRoute';
				$contenttype['field_mappings'] = json_encode($field_mappings);
				$contenttype['formFile'] = 'administrator\\/components\\/com_bfsurvey\\/views\\/question\\/tmpl\\/form.form.xml';
				$contenttype['hideFields'] = '["locked_by","locked_on"]';
				$contenttype['ignoreChanges'] = '["modified_by", "modified_on", "locked_by","locked_on"]';
				$contenttype['convertToInt'] = '["ordering"]';
				$contenttype['displayLookup'] = '[{"sourceColumn":"bfsurvey_category_id","targetTable":"#__bfsurvey_categories","targetColumn":"bfsurvey_category_id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]';

				$table->save($contenttype);
			}
		}
	}

	/**
	 * Renders the post-installation message
	 */
	private function _renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent)
	{
		?>
		<img src="../media/com_bfsurvey/images/bfsurvey-48.png" width="48" height="48" alt="BF Survey" align="right"/>

		<h2>Welcome to BF Survey!</h2>

		<?php
		parent::renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent);
		?>

		<?php
	}
}