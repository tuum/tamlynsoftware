DROP TABLE IF EXISTS `#__bfsurvey_questions`;
DROP TABLE IF EXISTS `#__bfsurvey_categories`;
DROP TABLE IF EXISTS `#__bfsurvey_emailitems`;
DROP TABLE IF EXISTS `#__bfsurvey_reports`;