 ALTER TABLE [#__bfsurvey_categories] ADD [theme] [nvarchar](50) NOT NULL DEFAULT '';
 ALTER TABLE [#__bfsurvey_questions] ADD [terminate_options] [nvarchar](max) NOT NULL DEFAULT '';
 ALTER TABLE [#__bfsurvey_questions] ADD [terminate_url] [nvarchar](255) NOT NULL DEFAULT '';