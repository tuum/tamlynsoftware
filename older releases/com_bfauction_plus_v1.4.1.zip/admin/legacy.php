<?php
/**
 * $Id: legacy.php 62 2012-09-25 12:22:53Z tuum $
 * Legacy functions to make software work for Joomla 2.5.4 or less
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * Alias to JController for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  Controller
 * @since       2.5.5
 */
class JControllerLegacy extends JController
{
}

jimport('joomla.application.component.view');

/**
 * Alias to JView for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  View
 * @since       2.5.5
 */
class JViewLegacy extends JView
{
}

jimport('joomla.application.component.model');

/**
 * Alias to JModel for forward compatability.
 *
 * @package     Joomla.Libraries
 * @subpackage  Model
 * @since       2.5.5
 */
class JModelLegacy extends JModel
{
	/**
	 * Add a directory where JModel should search for models. You may
	 * either pass a string or an array of directories.
	 *
	 * @param   mixed   $path    A path or array[sting] of paths to search.
	 * @param   string  $prefix  A prefix for models.
	 *
	 * @return  array  An array with directory elements. If prefix is equal to '', all directories are returned.
	 *
	 * @since   2.5.5
	 */
	public static function addIncludePath($path = '', $prefix = '')
	{
		return parent::addIncludePath($path, $prefix);
	}
}