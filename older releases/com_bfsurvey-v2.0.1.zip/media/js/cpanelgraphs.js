/**
 * @package		bfsurvey
 * @copyright	Copyright (c)2014 Tamlyn Software
 * @license		GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 */

/**
 * Setup (required for Joomla! 3)
 */
if(typeof(akeeba) == 'undefined') {
	var akeeba = {};
}
if(typeof(akeeba.jQuery) == 'undefined') {
	akeeba.jQuery = jQuery.noConflict();
}

var bfsurvey_cpanel_graph_from = "";
var bfsurvey_cpanel_graph_to = "";

var bfsurvey_cpanel_graph_salesPoints = [];
var bfsurvey_cpanel_graph_subsPoints = [];
var bfsurvey_cpanel_graph_levelsPoints = [];

var bfsurvey_cpanel_graph_plot1 = null;
var bfsurvey_cpanel_graph_plot2 = null;

function bfsurvey_cpanel_graphs_load()
{
	// Get the From date
	bfsurvey_cpanel_graph_from = document.getElementById('bfsurvey_graph_datepicker').value;

	// Calculate the To date
	var thatDay = new Date(bfsurvey_cpanel_graph_from);
	thatDay = new Date(thatDay.getTime() + 30*86400000);
	bfsurvey_cpanel_graph_to = thatDay.getUTCFullYear()+'-'+(thatDay.getUTCMonth()+1)+'-'+thatDay.getUTCDate();

	// Clear the data arrays
	bfsurvey_cpanel_graph_salesPoints = [];
	bfsurvey_cpanel_graph_subsPoints = [];
	bfsurvey_cpanel_graph_levelsPoints = [];

	// Remove the charts and show the spinners
	(function($) {
		$('#aklevelschart').empty();
		$('#aklevelschart').hide();
		bfsurvey_cpanel_graph_plot2 = null;
		$('#aksaleschart').empty();
		$('#aksaleschart').hide();
		bfsurvey_cpanel_graph_plot1 = null;

		$('#akthrobber').show();
		$('#akthrobber2').show();
	})(akeeba.jQuery);

	bfsurvey_load_sales();
}

function bfsurvey_load_sales()
{
	(function($) {
		var url = "index.php?option=com_bfsurvey&view=1results&since="+bfsurvey_cpanel_graph_from+"&until="+bfsurvey_cpanel_graph_to+"&cid=1&format=json";
		//DEBUG
		//alert(url);
		//END DEBUG
		$.getJSON(url, function(data){
			$.each(data, function(index, item){
				bfsurvey_cpanel_graph_salesPoints.push([item.created_on, parseInt(item.projectSize * 100) * 1 / 100]);
				bfsurvey_cpanel_graph_subsPoints.push([item.created_on, item.status * 1]);
			});
			$('#akthrobber').hide();
			$('#aksaleschart').show();
			if(bfsurvey_cpanel_graph_salesPoints.length == 0) {
				$('#aksaleschart-nodata').show();
				return;
			}
			bfsurvey_render_sales();
		});
	})(akeeba.jQuery);
}

function bfsurvey_render_sales()
{
	(function($) {
		$.jqplot.config.enablePlugins = true;
		bfsurvey_cpanel_graph_plot1 = $.jqplot('aksaleschart', [bfsurvey_cpanel_graph_subsPoints, bfsurvey_cpanel_graph_salesPoints], {
			show: true,
			axes:{
				xaxis:{renderer:$.jqplot.DateAxisRenderer,tickInterval:'1 week'},
				yaxis:{min: 0,tickOptions:{formatString:'%.2f'}},
				y2axis:{min: 0,tickOptions:{formatString:'%u'}}
			},
			series:[
				{
					yaxis: 'y2axis',
					lineWidth:1,
					renderer:$.jqplot.BarRenderer,
					rendererOptions:{barPadding: 0, barMargin: 0, barWidth: 5, shadowDepth: 0, varyBarColor: 0},
					markerOptions: {
						style:'none'
					},
					color: '#aae0aa'
				},
				{
					lineWidth:3,
					markerOptions:{
						style:'filledCircle',
						size:8
					},
					renderer: $.jqplot.hermiteSplineRenderer,
					rendererOptions:{steps: 60, tension: 0.6}
				}
			],
			highlighter: {
				show: true,
				sizeAdjust: 7.5
			},
			axesDefaults:{useSeriesColor: true}
		}).replot();
	})(akeeba.jQuery);
}