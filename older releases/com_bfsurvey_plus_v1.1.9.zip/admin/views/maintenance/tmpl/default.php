<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 36 2012-09-17 13:40:10Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

   $app = JFactory::getApplication();
   $dbtype = $app->getCfg('dbtype');
   if($dbtype == 'sqlsrv'){
   		//do nothing as backup button doesnt work for SQLSRV yet
   }else{
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey_plus&view=maintenance'); ?>" method="post" name="adminForm" id="adminForm">
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo JHtml::_('form.token'); ?>
</form>

		<form method="post" name="adminForm">

		<div class="adminlist">
		<?php echo JText::_( 'COM_BFSURVEYPLUS_CLICK_BUTTON_BACKUP'); ?>
		<br><br>
		</div>

		<input type="hidden" name="option" value="com_bfsurvey_plus" />
		<input type="hidden" name="task" value="dbbackup" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="controller" value="" />

		<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPLUS_BACKUP_DATABASE' ); ?>" />

		</form>

		<br><br>

<?php } ?>

<form method="post" name="adminForm">

<div class="adminlist">
<?php echo JText::_( 'COM_BFSURVEYPLUS_DATABASE_CLEANUP'); ?>
<?php echo JText::_( 'COM_BFSURVEYPLUS_DATABASE_CLEANUP_DETAIL'); ?>
<br>
<?php echo JText::_( 'COM_BFSURVEYPLUS_DATABASE_CLEANUP_WARNING1'); ?>
<?php echo JText::_( 'COM_BFSURVEYPLUS_DATABASE_CLEANUP_WARNING2'); ?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_plus" />
<input type="hidden" name="task" value="dbcleanup" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPLUS_AUTO_DATABASE_CLEANUP' ); ?>" />

</form>

<br><br>

<?php
	//does jos_bfsurvey_plustrial table exist?
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);

	//check for sample data
	$app = JFactory::getApplication();

	$mytables = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfsurvey_plustrial", $mytables)) {
?>
<form method="post" name="adminForm">
<div class="adminlist">
<?php
	echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_DETAILS1');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_DETAILS2');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_DETAILS3');
?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_plus" />
<input type="hidden" name="task" value="importquestions" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_ALL_QUESTIONS' ); ?>" />

</form>

<?php } //end if ?>

<?php
	//does jos_bfsurvey_pro table exist?
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);

	//check for sample data
	$app = JFactory::getApplication();

	$mytables = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfsurvey_pro", $mytables)) {
?>
	<form method="post" name="adminForm">
		<div class="adminlist">
		<?php
		echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_PRO');
		?>
		<br><br>
		</div>

		<input type="hidden" name="option" value="com_bfsurvey_plus" />
		<input type="hidden" name="task" value="importQuestionsPro" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="controller" value="" />
		<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPLUS_IMPORT_PRO_QUESTIONS' ); ?>" />
	</form>

<?php } //end if ?>