<?php
/**
 * $Id: edit.php 41 2012-09-29 11:03:45Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

 defined('_JEXEC') or die;

//JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'question.cancel' || document.formvalidator.isValid(document.id('question-form'))) {
			Joomla.submitform(task, document.getElementById('question-form'));
		}
		else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey_plus&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="question-form" class="form-validate">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFSURVEYPLUS_TITLE_DETAILS') : JText::sprintf('COM_BFSURVEYPLUS_EDIT_QUESTION', $this->item->id); ?></a></li>
			<li><a href="#options" data-toggle="tab"><?php echo JText::_('COM_BFSURVEYPLUS_TITLE_OPTIONS');?></a></li>
			<li><a href="#advanced" data-toggle="tab"><?php echo JText::_('COM_BFSURVEYPLUS_SLIDER_ADVANCED');?></a></li>
		</ul>
		<div class="tab-content">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<div class="width-60 fltlft">
		<fieldset class="adminform">
<?php } ?>
			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('catid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('catid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('question'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('question'); ?></div>
				</div>

				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('helpText'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('helpText'); ?></div>
				</div>
				<?php } ?>

				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('helpText'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('helpText'); ?>
				<?php } ?>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_name'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_name'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('question_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('question_type'); ?></div>
				</div>

				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
				</div>
				<?php } ?>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('mandatory'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('mandatory'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('parent'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('parent'); ?></div>
				</div>
			</div>

			<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
	</div>
	<div class="width-40 fltrt">
		<?php echo JHtml::_('sliders.start', 'option-slider'); ?>

		<?php echo JHtml::_('sliders.panel',JText::_('COM_BFSURVEYPLUS_SLIDER_OPTIONS'), 'options-details'); ?>

		<fieldset class="panelform">
			<?php } ?>
			<div class="tab-pane" id="options">
				<div class="control-group">
					<div class="optionLabelHeading">&nbsp;</div>
					<?php if( floatval($version->RELEASE) >= 3 ) { ?>
					<div class="fltlft300_j3">
					<?php }else{ ?>
					<div class="fltlft300">
					<?php } ?>
						<?php echo JText::_('COM_BFSURVEYPLUS_FIELD_NEXT_QUESTION_LABEL'); ?>
					</div>
				</div>
				<div class="clr"></div>

				<div class="control-group">
					<?php for ($i=1, $n=21; $i < $n; $i++ ) { ?>
						<?php $tempvalue='option'.$i; ?>
						<?php $tempvalue2='next_question'.$i; ?>
						<div class="control-label"><?php echo $this->form->getLabel($tempvalue); ?></div>
						<div class="controls"><?php echo $this->form->getInput($tempvalue); ?><?php echo $this->form->getInput($tempvalue2); ?></div>
					<?php } ?>
				</div>
			</div>
		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>

		<?php echo JHtml::_('sliders.panel',JText::_('COM_BFSURVEYPLUS_SLIDER_ADVANCED'), 'advanced-details'); ?>
		<fieldset class="panelform">
		<?php } ?>
			<div class="tab-pane" id="advanced">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suppressQuestion'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suppressQuestion'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_type'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('fieldSize'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('fieldSize'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('validation_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('validation_type'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('titles'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('titles'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sql'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sql'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sqlfield'); ?><?php echo $this->form->getLabel('total'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sqlfield'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('horizontal'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('horizontal'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('prefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('prefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suffix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('otherprefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('otherprefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('othersuffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('othersuffix'); ?></div>
				</div>
			</div>
		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
		<?php echo JHtml::_('sliders.end'); ?>
		<?php } ?>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('state'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('state'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
	<?php } ?>
	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</div>
	</div>
	<?php } ?>
</form>

<script language="javascript" type="text/javascript">
<!--

hideType();

//-->
</script>