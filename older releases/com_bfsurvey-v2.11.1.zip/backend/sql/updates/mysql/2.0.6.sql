ALTER TABLE `#__bfsurvey_reports` ADD `customQuery` text;
ALTER TABLE `#__bfsurvey_categories` ADD `customCSS` text;