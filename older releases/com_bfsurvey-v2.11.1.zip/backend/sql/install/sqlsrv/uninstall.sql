-- <?php /* $Id$ */ defined('_JEXEC') or die() ?>;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_questions]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurvey_questions]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_categories]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurvey_categories]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_emailitems]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurvey_emailitems]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_reports]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurvey_reports]
END;