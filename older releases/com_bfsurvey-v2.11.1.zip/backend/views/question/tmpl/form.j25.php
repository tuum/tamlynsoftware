<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');


JHTML::_('behavior.mootools');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/chosen.jquery.min.js');
F0FTemplateUtils::addCSS('media://com_bfsurvey/css/chosen.css');

// Default settings
$options['disable_search_threshold']  = isset($options['disable_search_threshold']) ? $options['disable_search_threshold'] : 10;
$options['allow_single_deselect']     = isset($options['allow_single_deselect']) ? $options['allow_single_deselect'] : true;
$options['placeholder_text_multiple'] = isset($options['placeholder_text_multiple']) ? $options['placeholder_text_multiple']: JText::_('JGLOBAL_SELECT_SOME_OPTIONS');
$options['placeholder_text_single']   = isset($options['placeholder_text_single']) ? $options['placeholder_text_single'] : JText::_('JGLOBAL_SELECT_AN_OPTION');
$options['no_results_text']           = isset($options['no_results_text']) ? $options['no_results_text'] : JText::_('JGLOBAL_SELECT_NO_RESULTS_MATCH');

// Options array to json options string
$options_str = json_encode($options, (false));

JFactory::getDocument()->addScriptDeclaration("
		jQuery(document).ready(function (){
			jQuery('select').chosen(" . $options_str . ");
		});
	"
);
F0FTemplateUtils::addCSS('media://com_bfsurvey/css/j25.css');
F0FTemplateUtils::addCSS('media://com_bfsurvey/css/backend.css');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/question.js');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/mobile.js');
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey&layout=question&id='.(int) $this->item->bfsurvey_question_id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
	<input type="hidden" name="bfsurvey_question_id" id="bfsurvey_question_id" value="<?php echo $this->item->bfsurvey_question_id ?>" />
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="question" />

	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFSURVEY_TITLE_DETAILS') : JText::sprintf('COM_BFSURVEY_EDIT_QUESTION', $this->item->id); ?></a></li>
			<li><a href="#options" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_OPTIONS');?></a></li>
			<li><a href="#visibility" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_VISIBILITY');?></a></li>
			<li><a href="#advanced" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_ADVANCED');?></a></li>
		</ul>
		<div class="tab-content">

			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bfsurvey_category_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bfsurvey_category_id'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_name'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_name'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('question_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('question_type'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('mandatory'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('mandatory'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('validation_rule'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('validation_rule'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('parent'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('parent'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('helpText'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('helpText'); ?></div>
				</div>
			</div>

			<div class="tab-pane" id="options">
				<div class="control-group">
					<?php for ($i=1, $n=21; $i < $n; $i++ ) { ?>
						<?php $tempvalue='option'.$i; ?>
						<div class="control-label"><?php echo $this->form->getLabel($tempvalue); ?><?php if($i == 1){ echo $this->form->getLabel('placeholder'); } ?></div>
						<div class="controls"><?php echo $this->form->getInput($tempvalue); ?></div>
					<?php } ?>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('default_value'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('default_value'); ?></div>
				</div>
			</div>

			<div class="tab-pane" id="visibility">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('hide_question'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('hide_question'); ?> = <?php echo $this->form->getInput('hide_options'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('show_question'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('show_question'); ?> = <?php echo $this->form->getInput('show_options'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('terminate_options'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('terminate_options'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('terminate_url'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('terminate_url'); ?></div>
				</div>
				<br>
				<br>
				<br>
				<br>
				<br>
			</div>

			<div class="tab-pane" id="advanced">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suppressQuestion'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suppressQuestion'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('myclass'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('myclass'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_type'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('fieldSize'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('fieldSize'); ?></div>
				</div>

				<!--
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('validation_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('validation_type'); ?></div>
				</div>
				-->
				<input type="hidden" name="validation_type" value="" />

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('titles'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('titles'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sql'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sql'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('key_field'); ?><?php echo $this->form->getLabel('total'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('key_field'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('value_field'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('value_field'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('horizontal'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('horizontal'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('prefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('prefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suffix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('otherprefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('otherprefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('othersuffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('othersuffix'); ?></div>
				</div>
			</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('enabled'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('enabled'); ?>
				</div>
			</div>

			<?php if(version_compare(JVERSION, '3.2', 'ge')) { ?>
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('version_note'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('version_note'); ?>
				</div>
			</div>
			<?php } ?>
		</fieldset>
	</div>
	<!-- End Sidebar -->
</form>

<script language="javascript" type="text/javascript">
<!--
hideType();
//-->
</script>