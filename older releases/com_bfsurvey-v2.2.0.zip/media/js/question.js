window.addEvent('domready', function()
{
    document.formvalidator.setHandler('question', function(value)
    {
        //regex = /^[^0-9]+$/;
    	//first character must be alphabetic
    	regex = /^[a-zA-Z][a-zA-Z0-9]+$/;
        return regex.test(value);
    });
});

window.addEvent('domready', function() {
    document.formvalidator.setHandler('fieldname',
            function (value) {
					reservedWords='ADD, ALL, ALTER, ANALYZE, AND, AS, ASC, ASENSITIVE, BEFORE, BETWEEN, BIGINT, BINARY, BLOB, BOTH, BY, CALL, CASCADE, CASE, CHANGE, CHAR, CHARACTER, CHECK, \
						COLLATE, COLUMN, CONDITION, CONSTRAINT, CONTINUE, CONVERT, CREATE, CROSS, CURRENT_DATE, CURRENT_TIME, CURRENT_TIMESTAMP, CURRENT_USER, CURSOR, DATABASE, DATABASES, \
						DAY_HOUR, DAY_MICROSECOND, DAY_MINUTE, DAY_SECOND, DEC, DECIMAL, DECLARE, DEFAULT, DELAYED, DELETE, DESC, DESCRIBE, DETERMINISTIC, DISTINCT, DISTINCTROW, DIV, DOUBLE, \
						DROP, DUAL, EACH, ELSE, ELSEIF, ENCLOSED, ESCAPED, EXISTS, EXIT, EXPLAIN, FALSE, FETCH, FLOAT, FLOAT4, FLOAT8, FOR, FORCE, FOREIGN, FROM, FULLTEXT, GRANT, GROUP, \
						HAVING, HIGH_PRIORITY, HOUR_MICROSECOND, HOUR_MINUTE, HOUR_SECOND, IF, IGNORE, IN, INDEX, INFILE, INNER, INOUT, INSENSITIVE, INSERT, INT, INT1, INT2, INT3, INT4, \
						INT8, INTEGER, INTERVAL, INTO, IS, ITERATE, JOIN, KEY, KEYS, KILL, LEADING, LEAVE, LEFT, LIKE, LIMIT, LINES, LOAD, LOCALTIME, LOCALTIMESTAMP, LOCK, LONG, LONGBLOB, \
						LONGTEXT, LOOP, LOW_PRIORITY, MATCH, MEDIUMBLOB, MEDIUMINT, MEDIUMTEXT, MIDDLEINT, MINUTE_MICROSECOND, MINUTE_SECOND, MOD, MODIFIES, NATURAL, NOT, NO_WRITE_TO_BINLOG, \
						NULL, NUMERIC, ON, OPTIMIZE, OPTION, OPTIONALLY, OR, ORDER, OUT, OUTER, OUTFILE, PRECISION, PRIMARY, PROCEDURE, PURGE, READ, READS, REAL, REFERENCES, REGEXP, RELEASE, \
						RENAME, REPEAT, REPLACE, REQUIRE, RESTRICT, RETURN, REVOKE, RIGHT, RLIKE,	SCHEMA, SCHEMAS, SECOND_MICROSECOND, SELECT, SENSITIVE, SEPARATOR, SET, SHOW, SMALLINT, \
						SONAME, SPATIAL, SPECIFIC, SQL, SQLEXCEPTION, SQLSTATE, SQLWARNING, SQL_BIG_RESULT, SQL_CALC_FOUND_ROWS, SQL_SMALL_RESULT, SSL, STARTING, STRAIGHT_JOIN, TABLE, \
						TERMINATED, THEN, TINYBLOB, TINYINT, TINYTEXT, TO, TRAILING, TRIGGER, TRUE, UNDO, UNION, UNIQUE, UNLOCK, UNSIGNED, UPDATE, USAGE, USE, USING, UTC_DATE, UTC_TIME, \
						UTC_TIMESTAMP, VALUES, VARBINARY, VARCHAR, VARCHARACTER, VARYING, WHEN, WHERE, WHILE, WITH, WRITE, XOR, YEAR_MONTH, ZEROFILL, ASENSITIVE, CALL, CONDITION, CONNECTION, \
						CONTINUE, CURSOR, DECLARE, DETERMINISTIC, EACH, ELSEIF, EXIT, FETCH, GOTO, INOUT, INSENSITIVE, ITERATE, LABEL, LEAVE, LOOP, MODIFIES, OUT, READS, RELEASE, REPEAT, \
						RETURN, SCHEMA, SCHEMAS, SENSITIVE, SPECIFIC, SQL, SQLEXCEPTION, SQLSTATE, SQLWARNING, TRIGGER, UNDO, UPGRADE, WHILE';
					if(reservedWords.indexOf(value.toUpperCase()) != -1)
					{
						//cannot use any mySQL keywords for field name
						return false;
					}
                    regex=/^[a-zA-Z]\w{3,49}$/;
                    //The first character must be a letter,
                    //it must contain at least 4 characters and no more than 50 characters
                    //and no characters other than letters, numbers and the underscore may be used
                    return regex.test(value);
    });
});

function showOptions(){
   if(document.getElementById("sql").value == ""){  //show
	  var i=0;
	  for (i=1;i<21;i++){
         document.getElementById("option"+i).style.display = '';
         document.getElementById("option"+i+"-lbl").style.display = '';
      }
   }else{ //hide
      var i=0;
	  for (i=2;i<21;i++){
         document.getElementById("option"+i).style.display = 'none';
         document.getElementById("option"+i+"-lbl").style.display = 'none';
      }
   }
}

function hideAllOptions(){
	var i=0;
	for (i=1;i<21;i++){
		document.getElementById("option"+i).style.display = 'none';
		document.getElementById("option"+i+"-lbl").style.display = 'none';
	}
}

function hideType(){
	if(document.getElementById("question_type").value == 0){  //-lbl
		   hideAllOptions();
	}
}

function hideType(){
	/* updateValidation(); */
    document.getElementById("sql").style.display = '';
    document.getElementById("sql-lbl").style.display = '';
    document.getElementById("key_field").style.display = '';
    document.getElementById("key_field-lbl").style.display = '';
    document.getElementById("value_field").style.display = '';
    document.getElementById("value_field-lbl").style.display = '';
    document.getElementById("horizontal0").style.display = 'none';
    document.getElementById("horizontal1").style.display = 'none';
    document.getElementById("horizontal-lbl").style.textDecoration = 'line-through';
	document.getElementById("fieldSize-lbl").style.display = 'none';
	document.getElementById("fieldSize").style.display = 'none';
    document.getElementById("total-lbl").style.display = 'none';

    if(document.getElementById("question_type").value == 0){  //text
	   hideAllOptions();
	   document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
	   document.getElementById("mandatory0").style.display = '';
       document.getElementById("mandatory1").style.display = '';
	   document.getElementById("mandatory-lbl").style.display = '';
	   document.getElementById("sql").style.display = 'none';
       document.getElementById("sql-lbl").style.display = 'none';
       document.getElementById("key_field").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
       document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
       document.getElementById("fieldSize-lbl").style.display = '';
	   document.getElementById("fieldSize").style.display = '';
    }else if(document.getElementById("question_type").value == 1){  //radio
    	document.getElementById("horizontal").style.display = '';
    	document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
       document.getElementById("mandatory-lbl").style.display = '';
       document.getElementById("horizontal0").style.display = '';
       document.getElementById("horizontal1").style.display = '';
	   document.getElementById("horizontal-lbl").style.display = '';
	   document.getElementById("horizontal-lbl").style.textDecoration = '';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
       showOptions();
    }else if(document.getElementById("question_type").value == 2){  //checkbox
       showOptions();
       document.getElementById("horizontal").style.display = '';
       document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
       document.getElementById("mandatory-lbl").style.display = '';
       document.getElementById("horizontal0").style.display = '';
       document.getElementById("horizontal1").style.display = '';
	   document.getElementById("horizontal-lbl").style.display = '';
	   document.getElementById("horizontal-lbl").style.textDecoration = '';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
    }else if(document.getElementById("question_type").value == 3){  //textarea
	   hideAllOptions();
	   document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
	   document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
       document.getElementById("mandatory-lbl").style.display = '';
	   document.getElementById("sql").style.display = 'none';
       document.getElementById("sql-lbl").style.display = 'none';
       document.getElementById("key_field").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
       document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
       document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
	   document.getElementById("fieldSize-lbl").style.display = '';
	   document.getElementById("fieldSize").style.display = '';
    }else if(document.getElementById("question_type").value == 4){  //attachment
    	document.getElementById("horizontal").style.display = 'none';
 	   document.getElementById("horizontal-lbl").style.display = 'none';
       document.getElementById("sql").style.display = 'none';
	   document.getElementById("sql-lbl").style.display = 'none';
	   document.getElementById("key_field").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
	   document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
       document.getElementById("mandatory0").style.display = 'none';
	   document.getElementById("mandatory1").style.display = 'none';
	   document.getElementById("mandatory-lbl").style.display = 'none';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
	   hideAllOptions();
    }else if(document.getElementById("question_type").value == 5){  //date
    	document.getElementById("horizontal").style.display = 'none';
 	   document.getElementById("horizontal-lbl").style.display = 'none';
       document.getElementById("sql").style.display = 'none';
       document.getElementById("sql-lbl").style.display = 'none';
	   document.getElementById("key_field").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
	   document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
       document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
	   document.getElementById("mandatory-lbl").style.display = '';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
	   hideAllOptions();
    }else if(document.getElementById("question_type").value == 6){  //drop down
       showOptions();
       document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
       document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
	   document.getElementById("mandatory-lbl").style.display = '';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
    }else if(document.getElementById("question_type").value == 7){  //list
       hideAllOptions();
       document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
       document.getElementById("mandatory0").style.display = 'none';
	   document.getElementById("mandatory1").style.display = 'none';
	   document.getElementById("mandatory-lbl").style.display = 'none';
       document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
    }else if(document.getElementById("question_type").value == 8){  //summation
       showOptions();
       document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
       document.getElementById("mandatory0").style.display = '';
	   document.getElementById("mandatory1").style.display = '';
	   document.getElementById("mandatory-lbl").style.display = '';
       document.getElementById("sql").style.display = 'none';
       document.getElementById("sql-lbl").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
	   document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
	   document.getElementById("titles-lbl").style.display = 'none';
       document.getElementById("titles").style.display = 'none';
       document.getElementById("total-lbl").style.display = '';
	}else if(document.getElementById("question_type").value == 9){  //Rating
       showOptions();
	   document.getElementById("horizontal").style.display = 'none';
	   document.getElementById("horizontal-lbl").style.display = 'none';
	   document.getElementById("sql").style.display = 'none';
       document.getElementById("sql-lbl").style.display = 'none';
       document.getElementById("key_field-lbl").style.display = 'none';
	   document.getElementById("value_field").style.display = 'none';
       document.getElementById("value_field-lbl").style.display = 'none';
       document.getElementById("total-lbl").style.display = '';
       document.getElementById("titles-lbl").style.display = '';
       document.getElementById("titles").style.display = '';
    }
}

/* - Turned of for now
var checkbox_array = new Array('required validate-checkbox','required validate-checkbox2','required validate-checkbox3','required validate-checkbox4','required validate-checkbox5','required validate-checkbox6','required validate-checkbox7','required validate-checkbox8','required validate-checkbox9','required validate-checkbox10');
var text_array = new Array('required','required validate-numeric','required validate-email');

function updateValidation(){
   //get var from php
   var validation_type = "<?php echo isset($this->item->validation_type) ? $this->item->validation_type : ''; ?>";

   var sda = document.getElementById('validation_type');
   var len = sda.length;
   	   if(document.getElementById("question_type").value == 2){  //checkbox
		  //remove all options first
		  sda.options.length=0;

	  var len2 = checkbox_array.length;
	  for(var i=0; i<len2; i++)
	  {
      	//now add validate-checkbox
	  	var y=document.createElement('option');
	  	y.text=checkbox_array[i];
		  	y.value=checkbox_array[i];
		  	if(checkbox_array[i] == validation_type){
		  	   y.selected = true;
		  	}
	  	try
	  	{
	  	  sda.add(y,null);}
	  	  catch(ex){
	  	  sda.add(y);
	  	}
	  }

	  sda.setAttribute("value", checkbox_array[0]);

   }else if(document.getElementById("question_type").value == 0){  //text
	  //remove all options first
		  sda.options.length=0;

	  var len2 = text_array.length;
	  for(var i=0; i<len2; i++)
	  {
      	//now add validate options
	  	var y=document.createElement('option');
	  	y.text=text_array[i];
		  	y.value=text_array[i];
		  	if(text_array[i] == validation_type){
			   y.selected = true;
		  	}
	  	try
	  	{
	  	  sda.add(y,null);}
	  	  catch(ex){
	  	  sda.add(y);
	  	}
	  }

	  sda.setAttribute("value", text_array[0]);
   }else{
      //default validation types
	  //remove all options first
		  sda.options.length=0;

	  //now add validate options
	  var y=document.createElement('option');
	  y.text="default";
		  y.value="default";
	  try
	  {
	    sda.add(y,null);}
	    catch(ex){
	    sda.add(y);
	  }
   }
}
*/

(function($)
{
	//ajax to update the parent list based on category selection
	$(document).ready(function(){
		$("#bfsurvey_category_id").change(function() {
			var value = $(this).val();
			var id = document.getElementById("bfsurvey_question_id");

		    $.ajax({
		    	type: "GET",
		        url: "index.php?option=com_bfsurvey&view=questions&layout=form&format=json",
				data: {
					'catid'					: value,
					'enabled'				: '1',
					'bfsurvey_question_id'	: id.value
				},
		        dataType: 'json',
		        error: function (xhr, status, error) {
		        	if(value>0){
		        		alert(error);
		                alert(status);
		                alert(xhr.responseText);
		            }else{
		            	//reset all the options in the parent drop down
		               	var select = document.getElementById("parent");
		               	select.options.length = 0;
		            }
		        },
		        success: function(data){
		            //reset all the options in the parent drop down
		            var select = document.getElementById("parent");
		            select.options.length = 0;

		            select.options.add(new Option("Top", "0"));
		            //now populate the new options
		      	  	var len = data.length;
		      	  	for(var i=0; i<len; i++){
		      	  		select.options.add(new Option(data[i]['title'], data[i]['bfsurvey_question_id']));
		        	}

		      		$("#parent").val('').trigger("liszt:updated");
		        }
		    });

		    $.ajax({
		    	type: "GET",
		        url: "index.php?option=com_bfsurvey&view=questions&layout=form&format=json",
				data: {
					'catid'					: value,
					'showhide'				: '1',
					'enabled'				: '1',
					'bfsurvey_question_id'	: id.value
				},
		        dataType: 'json',
		        error: function (xhr, status, error) {
		        	if(value>0){
		        		alert(error);
		                alert(status);
		                alert(xhr.responseText);
		            }else{
			            //reset all the options in the hide question
			            var select2 = document.getElementById("hide_question");
			            select2.options.length = 0;

			            //reset all the options in the show question
			            var select3 = document.getElementById("show_question");
			            select3.options.length = 0;
		            }
		        },
		        success: function(data){
		            //reset all the options in the hide question
		            var select2 = document.getElementById("hide_question");
		            select2.options.length = 0;

		            //reset all the options in the show question
		            var select3 = document.getElementById("show_question");
		            select3.options.length = 0;

		            select2.options.add(new Option("PLEASE SELECT", 0));
	      	  		select3.options.add(new Option("PLEASE SELECT", 0));

		            //now populate the new options
		      	  	var len = data.length;
		      	  	for(var i=0; i<len; i++){
		      	  		select2.options.add(new Option(data[i]['title'], data[i]['bfsurvey_question_id']));
		      	  		select3.options.add(new Option(data[i]['title'], data[i]['bfsurvey_question_id']));
		        	}

		      		$("#hide_question").val('').trigger("liszt:updated");
		      		$("#show_question").val('').trigger("liszt:updated");
		        }
		    });
		});

		//ajax to update the options in hide question list based on question selection
		$("#hide_question").change(function() {
			var value = $(this).val();
			var catid = document.getElementById("bfsurvey_category_id");

		    $.ajax({
		    	type: "GET",
		        url: "index.php?option=com_bfsurvey&view=questions&layout=form&format=json",
				data: {
					'catid'					: catid.value,
					'showhide'				: '2',
					'bfsurvey_question_id'	: value
				},
		        dataType: 'json',
		        error: function (xhr, status, error) {
		        	if(value>0){
		        		alert(error);
		                alert(status);
		                alert(xhr.responseText);
		            }else{
		            	//reset all the options in the hide_options drop down
		               	var select = document.getElementById("hide_options");
		               	select.options.length = 0;
		            }
		        },
		        success: function(data){
		            //reset all the options in the hide_options drop down
		            var select = document.getElementById("hide_options");
		            select.options.length = 0;

		            //select.options.add(new Option("Please Select", "0"));
		            //now populate the new options
		      	  	var len = data.length;
		      	  	for(var i=0; i<len; i++){
		      	  		if(data[i]['bfsurvey_question_id']==value){
			      	  		if(data[i]['option1']!=''){
			      	  			select.options.add(new Option(data[i]['option1'], data[i]['option1']));
			      	  		}
			      	  		if(data[i]['option2']!=''){
			      	  			select.options.add(new Option(data[i]['option2'], data[i]['option2']));
			      	  		}
			      	  		if(data[i]['option3']!=''){
			      	  			select.options.add(new Option(data[i]['option3'], data[i]['option3']));
			      	  		}
			      	  		if(data[i]['option4']!=''){
			      	  			select.options.add(new Option(data[i]['option4'], data[i]['option4']));
			      	  		}
			      	  		if(data[i]['option5']!=''){
			      	  			select.options.add(new Option(data[i]['option5'], data[i]['option5']));
			      	  		}
			      	  		if(data[i]['option6']!=''){
			      	  			select.options.add(new Option(data[i]['option6'], data[i]['option6']));
			      	  		}
			      	  		if(data[i]['option7']!=''){
			      	  			select.options.add(new Option(data[i]['option7'], data[i]['option7']));
			      	  		}
			      	  		if(data[i]['option8']!=''){
			      	  			select.options.add(new Option(data[i]['option8'], data[i]['option8']));
			      	  		}
			      	  		if(data[i]['option9']!=''){
			      	  			select.options.add(new Option(data[i]['option9'], data[i]['option9']));
			      	  		}
			      	  		if(data[i]['option10']!=''){
			      	  			select.options.add(new Option(data[i]['option10'], data[i]['option10']));
			      	  		}
			      	  		if(data[i]['option11']!=''){
			      	  			select.options.add(new Option(data[i]['option11'], data[i]['option11']));
			      	  		}
			      	  		if(data[i]['option12']!=''){
			      	  			select.options.add(new Option(data[i]['option12'], data[i]['option12']));
			      	  		}
			      	  		if(data[i]['option13']!=''){
			      	  			select.options.add(new Option(data[i]['option13'], data[i]['option13']));
			      	  		}
			      	  		if(data[i]['option14']!=''){
			      	  			select.options.add(new Option(data[i]['option14'], data[i]['option14']));
			      	  		}
			      	  		if(data[i]['option15']!=''){
			      	  			select.options.add(new Option(data[i]['option15'], data[i]['option15']));
			      	  		}
			      	  		if(data[i]['option16']!=''){
			      	  			select.options.add(new Option(data[i]['option16'], data[i]['option16']));
			      	  		}
			      	  		if(data[i]['option17']!=''){
			      	  			select.options.add(new Option(data[i]['option17'], data[i]['option17']));
			      	  		}
			      	  		if(data[i]['option18']!=''){
			      	  			select.options.add(new Option(data[i]['option18'], data[i]['option18']));
			      	  		}
			      	  		if(data[i]['option19']!=''){
			      	  			select.options.add(new Option(data[i]['option19'], data[i]['option19']));
			      	  		}
			      	  		if(data[i]['option20']!=''){
			      	  			select.options.add(new Option(data[i]['option20'], data[i]['option20']));
			      	  		}
		      	  		}
		        	}

		      	  	$("#hide_options").val('').trigger("liszt:updated");
		        }
		    });
		});

		//ajax to update the options in show question list based on question selection
		$("#show_question").change(function() {
			var value = $(this).val();
			var catid = document.getElementById("bfsurvey_category_id");

		    $.ajax({
		    	type: "GET",
		        url: "index.php?option=com_bfsurvey&view=questions&layout=form&format=json",
				data: {
					'catid'					: catid.value,
					'showhide'				: '2',
					'bfsurvey_question_id'	: value
				},
		        dataType: 'json',
		        error: function (xhr, status, error) {
		        	if(value>0){
		        		alert(error);
		                alert(status);
		                alert(xhr.responseText);
		            }else{
		            	//reset all the options in the show_options drop down
		               	var select = document.getElementById("show_options");
		               	select.options.length = 0;
		            }
		        },
		        success: function(data){
		            //reset all the options in the show_options drop down
		            var select = document.getElementById("show_options");
		            select.options.length = 0;

		            //select.options.add(new Option("Please Select", "0"));
		            //now populate the new options
		      	  	var len = data.length;
		      	  	for(var i=0; i<len; i++){
		      	  		if(data[i]['bfsurvey_question_id']==value){
			      	  		if(data[i]['option1']!=''){
			      	  			select.options.add(new Option(data[i]['option1'], data[i]['option1']));
			      	  		}
			      	  		if(data[i]['option2']!=''){
			      	  			select.options.add(new Option(data[i]['option2'], data[i]['option2']));
			      	  		}
			      	  		if(data[i]['option3']!=''){
			      	  			select.options.add(new Option(data[i]['option3'], data[i]['option3']));
			      	  		}
			      	  		if(data[i]['option4']!=''){
			      	  			select.options.add(new Option(data[i]['option4'], data[i]['option4']));
			      	  		}
			      	  		if(data[i]['option5']!=''){
			      	  			select.options.add(new Option(data[i]['option5'], data[i]['option5']));
			      	  		}
			      	  		if(data[i]['option6']!=''){
			      	  			select.options.add(new Option(data[i]['option6'], data[i]['option6']));
			      	  		}
			      	  		if(data[i]['option7']!=''){
			      	  			select.options.add(new Option(data[i]['option7'], data[i]['option7']));
			      	  		}
			      	  		if(data[i]['option8']!=''){
			      	  			select.options.add(new Option(data[i]['option8'], data[i]['option8']));
			      	  		}
			      	  		if(data[i]['option9']!=''){
			      	  			select.options.add(new Option(data[i]['option9'], data[i]['option9']));
			      	  		}
			      	  		if(data[i]['option10']!=''){
			      	  			select.options.add(new Option(data[i]['option10'], data[i]['option10']));
			      	  		}
			      	  		if(data[i]['option11']!=''){
			      	  			select.options.add(new Option(data[i]['option11'], data[i]['option11']));
			      	  		}
			      	  		if(data[i]['option12']!=''){
			      	  			select.options.add(new Option(data[i]['option12'], data[i]['option12']));
			      	  		}
			      	  		if(data[i]['option13']!=''){
			      	  			select.options.add(new Option(data[i]['option13'], data[i]['option13']));
			      	  		}
			      	  		if(data[i]['option14']!=''){
			      	  			select.options.add(new Option(data[i]['option14'], data[i]['option14']));
			      	  		}
			      	  		if(data[i]['option15']!=''){
			      	  			select.options.add(new Option(data[i]['option15'], data[i]['option15']));
			      	  		}
			      	  		if(data[i]['option16']!=''){
			      	  			select.options.add(new Option(data[i]['option16'], data[i]['option16']));
			      	  		}
			      	  		if(data[i]['option17']!=''){
			      	  			select.options.add(new Option(data[i]['option17'], data[i]['option17']));
			      	  		}
			      	  		if(data[i]['option18']!=''){
			      	  			select.options.add(new Option(data[i]['option18'], data[i]['option18']));
			      	  		}
			      	  		if(data[i]['option19']!=''){
			      	  			select.options.add(new Option(data[i]['option19'], data[i]['option19']));
			      	  		}
			      	  		if(data[i]['option20']!=''){
			      	  			select.options.add(new Option(data[i]['option20'], data[i]['option20']));
			      	  		}
		      	  		}
		        	}

		      	  	$("#show_options").val('').trigger("liszt:updated");
		        }
		    });
		});

		//populate the terminate options field
		$("#option1").add("#option2").add("#option3").add("#option4").add("#option5").add("#option6").add("#option7").add("#option8").add("#option9").add("#option10").add("#option11").add("#option12").add("#option13").add("#option14").add("#option15").add("#option16").add("#option17").add("#option18").add("#option19").add("#option20").change(function() {
			//reset all the options in the terminate_options drop down
			var select = document.getElementById("terminate_options");
			//var value = $('#terminate_options :selected').text();
			var value = $('#terminate_options').val();
			select.options.length = 0;

			if($("#option1").val()!=''){
				select.options.add(new Option($("#option1").val(), $("#option1").val()));
			}
			if($("#option2").val()!=''){
				select.options.add(new Option($("#option2").val(), $("#option2").val()));
			}
			if($("#option3").val()!=''){
				select.options.add(new Option($("#option3").val(), $("#option3").val()));
			}
			if($("#option4").val()!=''){
				select.options.add(new Option($("#option4").val(), $("#option4").val()));
			}
			if($("#option5").val()!=''){
				select.options.add(new Option($("#option5").val(), $("#option5").val()));
			}
			if($("#option6").val()!=''){
				select.options.add(new Option($("#option6").val(), $("#option6").val()));
			}
			if($("#option7").val()!=''){
				select.options.add(new Option($("#option7").val(), $("#option7").val()));
			}
			if($("#option8").val()!=''){
				select.options.add(new Option($("#option8").val(), $("#option8").val()));
			}
			if($("#option9").val()!=''){
				select.options.add(new Option($("#option9").val(), $("#option9").val()));
			}
			if($("#option10").val()!=''){
				select.options.add(new Option($("#option10").val(), $("#option10").val()));
			}
			if($("#option11").val()!=''){
				select.options.add(new Option($("#option11").val(), $("#option11").val()));
			}
			if($("#option12").val()!=''){
				select.options.add(new Option($("#option12").val(), $("#option12").val()));
			}
			if($("#option13").val()!=''){
				select.options.add(new Option($("#option13").val(), $("#option13").val()));
			}
			if($("#option14").val()!=''){
				select.options.add(new Option($("#option14").val(), $("#option14").val()));
			}
			if($("#option15").val()!=''){
				select.options.add(new Option($("#option15").val(), $("#option15").val()));
			}
			if($("#option16").val()!=''){
				select.options.add(new Option($("#option16").val(), $("#option16").val()));
			}
			if($("#option17").val()!=''){
				select.options.add(new Option($("#option17").val(), $("#option17").val()));
			}
			if($("#option18").val()!=''){
				select.options.add(new Option($("#option18").val(), $("#option18").val()));
			}
			if($("#option19").val()!=''){
				select.options.add(new Option($("#option19").val(), $("#option19").val()));
			}
			if($("#option20").val()!=''){
				select.options.add(new Option($("#option20").val(), $("#option20").val()));
			}

			$("#terminate_options").val(value).trigger("liszt:updated");
		});

		//genereate initial field name
		$("#title").change(function() {
			var value = $(this).val();

			if(document.getElementById("field_name").value == '')
			{
				len = value.length;
				if(len > 12)
				{
					len = 12;
				}

				//change spaces and any non alphanumeric characters to underscore & make lowercase
				field_name = value.replace(/\W+/g, "_")
				field_name = field_name.toLowerCase();
				document.getElementById("field_name").value = field_name.substr(0,len);
			}
		});
	});

	window.addEventListener('load', function (){
		//if hide_question and show_question are not set, trigger AJAX to refresh the list and make it look nicer
		if(document.getElementById("hide_question").value == 0 && document.getElementById("show_question").value == 0){
			$("#bfsurvey_category_id").change();
		}
		$("#option1").change();
	});

})(jQuery);