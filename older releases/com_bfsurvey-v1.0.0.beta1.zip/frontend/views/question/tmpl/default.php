<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
$canDo	= BfsurveyModelSurvey::getActions();

if (!$canDo->get('core.create')) {
	// User trying to view questions that he does not have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_NO_ACCESS_QUESTIONS') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfsurvey&view=questions&Itemid=".(int)$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
	$finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFSURVEY_LOG_IN')."</a><br>";
	return;
}
?>
<?php echo $this->loadAnyTemplate('site:com_bfsurvey/question/form'); ?>

<?php echo $this->form ?>