<?php
defined('_JEXEC') or die();

class bfsurveyViewMaintenance extends FOFViewHtml
{
	protected function onBrowse($tpl = null)
	{
		$model = $this->getModel();

		return true;
	}
}