<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyViewReport extends FOFViewHtml
{
	public function onRead($tpl = null) {
		$id = JRequest::getVar( 'id', 0, '', 'int' );

		$model = $this->getModel();
		$this->reportDetails = $model->getReport($id);
		$this->items = $model->createReport($this->reportDetails);

		return parent::onRead($tpl);
	}
}