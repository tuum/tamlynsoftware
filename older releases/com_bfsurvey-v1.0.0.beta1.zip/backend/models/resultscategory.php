<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelResultscategory extends FOFModel
{
	public function buildQuery($overrideLimits = false)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('a.bfsurvey_category_id AS id, a.title');
		$query->from('#__bfsurvey_categories AS a');
		$query->where('a.enabled = 1');
		$query->order('a.title');
		//left join so we only show categories that have questions in them
		$query->join('INNER', '#__bfsurvey_questions AS c ON c.bfsurvey_question_id = a.bfsurvey_category_id');

		return $query;
	}
}