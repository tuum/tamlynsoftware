<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelMaintenance extends FOFModel
{
	/**********************************************************************************
	 * This function will search through your answer table for fields that don't have
	* associated questions, and will automatically detele them.
	* Used by maintenance view.
	**********************************************************************************/
	public function performChanges()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$table="#__bfsurvey_questions";

		//first get all the categories
		$query->select('DISTINCT bfsurvey_category_id');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows1 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}


		// get field names and categories
		$query->clear();
		$query->select('field_name, bfsurvey_category_id, question_type');
		$query->from($db->quoteName($table));
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		for($n=0;$n < count($rows1); $n++){
			$row1 = &$rows1[$n];
			$table2="#__bfsurvey_".$row1->bfsurvey_category_id."results";

			echo $table2."<br>";

			//now get the fields for the selected table
			$fields = $db->getTableColumns( $table2, true );

			if(!$fields){
				global $mainframe;
				JError::raiseWarning( 100, JText::_('COM_BFSURVEY_ERROR_MYSQL_TABLE').' '.$table2.' '.JText::_('COM_BFSURVEY_ERROR_MYSQL_DOES_NOT_EXIST') );
				JError::raiseNotice( 100, JText::_('COM_BFSURVEY_ERROR_MYSQL_IGNORE_WARNING') );
				return false;
			}

			if( sizeof( $fields ) ) {
				// We found some fields so let's create the list
				$options = array();
				foreach( $fields as $field => $type ) {
					$options[] = $field;

					//now is there a question associated with this field?
					$found=0;
					for($i=0;$i < count($rows); $i++){
						$row = &$rows[$i];
						$id_field="bfsurvey_".$row1->bfsurvey_category_id."result_id";

						if($row->bfsurvey_category_id == $row1->bfsurvey_category_id){ // is this question in the same category
							if($row->field_name == $field | $field == $id_field | $field == "Name" | $field == "Email" | $field == "state" | $field == "enabled" | $field == "ordering" | $field == "uid" | $field == "DateCreated" | $field == "created_by" | $field == "created_on" | $field == "uidModified" | $field == "DateModified" | $field == "modified_by" | $field == "modified_on" | $field == "locked_by" | $field == "locked_on" | $field == "ip" | substr($field,0,7) == "bfsurvey_" | $field == "status" | $field == "designer" | $field == "servicesProcessed" | $field == "Billable" ){
								$found=1;
								$i=count($rows);
							}
						}

						//rating question
						if($row->question_type == 9){
							if(strlen($row->field_name) > strlen($field)){
								$mylen=strlen($field);
							}else{
								$mylen=strlen($row->field_name);
							}

							if($row->field_name == substr($field, 0, $mylen)){
								$found=1;
							}
						}
					}

					if($found==0){
						echo JText::_( "COM_BFSURVEY_ERROR_CANT_FIND_FIELD");
						echo " ";
						echo $field;
						$query="ALTER TABLE ".$db->quoteName($table2)." DROP ".$field;
						$db->setQuery( $query );
						if (!$db->query())
						{
							echo $db->getErrorMsg();
							return false;
						}

						echo "<br>";
						echo JText::_( "COM_BFSURVEY_ERROR_FIELD");
						echo " ";
						echo $field;
						echo " ";
						echo JText::_( "COM_BFSURVEY_ERROR_HAS_BEEN_DELETED");
						echo " ";
						echo $table2;
						echo "<br>";
			      	}
		    	}
			}
		}

		return true;
	}

	function dbbackup(){
		$table="#__bfsurvey_questions";
		$myExport = bfsurveyModelMaintenance::exportMyTable($table);

		$table="#__bfsurvey_categories";
		$myExport .= bfsurveyModelMaintenance::exportMyTable($table);

		$table="#__bfsurvey_emailitems";
		$myExport .= bfsurveyModelMaintenance::exportMyTable($table);

		$table="#__bfsurvey_reports";
		$myExport .= bfsurveyModelMaintenance::exportMyTable($table);

		//get all survey category id numbers
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('bfsurvey_category_id');
		$query->from('#__bfsurvey_categories');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		foreach($rows as $row){
			$table="#__bfsurvey_".$row->bfsurvey_category_id."results";
			$myExport .= "\n";
			$myExport .= bfsurveyModelMaintenance::exportMyTable($table);
		}

		$myExport = stripcslashes($myExport);

		$file_name = "MySQL_Database_Backup.sql";
		Header("Content-type: application/octet-stream");
		Header("Content-Disposition: attachment; filename=$file_name");
		echo $myExport;
	}

	function exportMyTable($table){
	   	$db = JFactory::getDbo();
	   	$query	= $db->getQuery(true);

	   	// Get the structure of the question table
	   	$mytable = $db->getTableCreate( $table );

	   	if(!$mytable){
	   		JError::raiseWarning( 500, JText::_('COM_BFSURVEY_ERROR_MYSQL_TABLE').' '.$table.' '.JText::_('COM_BFSURVEY_ERROR_MYSQL_CANNOT_BE_FOUND') );
	   		JError::raiseNotice( 500, JText::_('COM_BFSURVEY_ERROR_MYSQL_IGNORE_WARNING') );
	   		return null;
	   	}

	   	// Grab the fields for the selected table
	   	$fields = $db->getTableColumns( $table, true );

	   	//now get the question data
	   	$query->select('*');
	   	$query->from($db->quoteName($table));
	   	$db->setQuery((string)$query);
	   	$rows = $db->loadRowList();
	   	if ($db->getErrorNum())
	   	{
	   		echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
	   		return;
	   	}

	   	$myfields=array_values($fields);

	   	$d=null;
	   	foreach($rows as $cr){
	   		$d .= "INSERT INTO " . $db->quoteName($table) . " VALUES (";
	   		for($i=0; $i<sizeof($cr); $i++){
	   			$myfield=$myfields[$i];
	   			if($cr[$i] == ''){
	   				if($myfield == "tinyint" | $myfield == "int"){
	   					$d .= "0,";
	   				}else{
	   					$d .= "'',";
	   				}
	   			}else{
	   				//add delimited before apostrophe
	   				$d .= "'".addcslashes($cr[$i],"'")."',";
	   			}
	   		}

	   		$d = substr($d, 0, strlen($d) - 1);
	   		$d .= ");\n";
	   	}

	   	$myexport= $mytable[$table];
	   	$myexport.=";\n\n";
	   	$myexport .=$d;

	   	//Insert database prefix
	   	$db = JFactory::getDbo();
	   	$myexport=preg_replace('/#__/', $db->getPrefix() , $myexport);

	   	//delimit speech marks
	   	$myexport=preg_replace('/"/', '\"' , $myexport);

	   	return $myexport;
	}

	function import()
	{
		$db = JFactory::getDbo();

		$query = "RENAME TABLE `#__bfsurvey_questions` TO `#__bfsurvey_questions.old`";

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus`
  				ADD  `value_field` varchar(25) NOT NULL,
  				ADD  `hide_question` int(11) NOT NULL,
    			ADD  `hide_options` text,
  				ADD  `show_question` int(11) NOT NULL,
  				ADD  `show_options` text,
  				ADD  `default_value` varchar(255) NOT NULL,
  				ADD  `locked_by` bigint(20) NOT NULL DEFAULT '0',
  				ADD  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  				ADD  `myclass` varchar(255) NOT NULL";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `id` `bfsurvey_question_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `catid` `bfsurvey_category_id` bigint(20) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `state` `enabled` tinyint(3) NOT NULL DEFAULT '1';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `question` `title` varchar(255) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `alias` `slug` varchar(50) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `sqlfield` `key_field` varchar(25) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `created` `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_plus` CHANGE `modified` `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "UPDATE #__bfsurvey_plus SET value_field=key_field;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "RENAME TABLE `#__bfsurvey_plus` TO `#__bfsurvey_questions`;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		//now get all the existing categories
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, title, alias');
		$query->from('#__categories');
		$query->where('published = 1');
		$query->where('extension = '.$db->quote('com_bfsurvey_plus') );

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		foreach($rows as $row)
		{
			$query->clear();
			$query->insert('#__bfsurvey_categories');
			$query->columns(array($db->quoteName('bfsurvey_category_id'), $db->quoteName('title'), $db->quoteName('slug') ));
			$query->values( (int)$row->id.', '.$db->quote( $db->escape($row->title), false ).', '.$db->quote( $db->escape($row->alias), false ) );

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$id=$db->insertid();

			$query->clear();
			$query->update('#__bfsurvey_questions');
			$query->set('bfsurvey_category_id = '.(int)$id);
			$query->where('bfsurvey_category_id = '.(int)$row->id);

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//need to rename and alter answer tables, and adjust a few fields
			$db = JFactory::getDbo();
			$query = "RENAME TABLE `#__bfsurveyplus_".(int)$row->id."` TO `#__bfsurvey_".(int)$id."results`;";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$db = JFactory::getDbo();
			$query = "ALTER TABLE `#__bfsurvey_".(int)$id."results` CHANGE `id` `bfsurvey_".(int)$id."result_id`  int(11) NOT NULL AUTO_INCREMENT;";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$db = JFactory::getDbo();
			$query = "ALTER TABLE `#__bfsurvey_".(int)$id."results` CHANGE `state` `enabled` tinyint(3) NOT NULL DEFAULT '1';";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$db = JFactory::getDbo();
			$query = "ALTER TABLE `#__bfsurvey_".(int)$id."results` CHANGE `uid` `created_by` bigint(20) NOT NULL DEFAULT '0';";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$db = JFactory::getDbo();
			$query = "ALTER TABLE `#__bfsurvey_".(int)$id."results` CHANGE `DateReceived` `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$db = JFactory::getDbo();
			$query = "ALTER TABLE `#__bfsurvey_".(int)$id."results`
						ADD `modified_by` bigint(20) NOT NULL DEFAULT '0',
						ADD `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
						ADD `locked_by` bigint(20) NOT NULL DEFAULT '0',
						ADD `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
						ADD `status` varchar(150) DEFAULT NULL;";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$query->clear();
			$query->update('#__bfsurveyplus_email');
			$query->set('catid = '.(int)$id);
			$query->where('catid = '.(int)$row->id);

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//now add to content history for this category
			//content history feature was added in Joomla 3.2
			if (version_compare(JVERSION, '3.1.6', 'gt'))
			{
				//does content_type record exist for this category?
				$catid = (int)$id;

				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);

				$query->select('type_id');
				$query->from('#__content_types');
				$query->where('type_alias = '.$db->quote('com_bfsurvey.'.$catid.'result'));

				$db->setQuery((string)$query);
				$type_id=$db->loadResult();

				if($type_id > 0)
				{
					//do nothing
				}
				else
				{
					//need to add record to content type table
					$table = JTable::getInstance('Contenttype', 'JTable');
					if(!$table->load(array('type_alias' => 'com_bfsurvey.'.$catid.'result')))
					{
						$common = new stdClass;
						$common->core_content_item_id = 'bfsurvey_'.$catid.'result_id';
						$common->core_title = 'title';
						$common->core_state = 'enabled';
						//$common->core_alias = 'slug';
						$common->core_created_time = 'created_on';
						$common->core_modified_time = 'modified_on';
						$common->core_ordering = 'ordering';
						//$common->core_catid = 'bfsurvey_category_id';
						$common->asset_id = null;
						$field_mappings = new stdClass;
						$field_mappings->common[] = $common;
						$field_mappings->special = array();
						$special = new stdClass;
						$special->dbtable = '#__bfsurvey_'.$catid.'results';
						$special->key = 'bfsurvey_'.$catid.'result_id';
						$special->type = 'My'.$catid.'result';
						$special->prefix = 'BFSurveyTable';
						$special->config = 'array()';
						$table_object = new stdClass;
						$table_object->special = $special;
						$contenttype['type_title'] = 'BFSurvey '.$catid.'result';
						$contenttype['type_alias'] = 'com_bfsurvey.'.$catid.'result';
						$contenttype['table'] = json_encode($table_object);
						$contenttype['rules'] = '';
						$contenttype['router'] = 'BFSurveyHelperRoute::getBFSurveyRoute';
						$contenttype['field_mappings'] = json_encode($field_mappings);
						$contenttype['formFile'] = 'components\\/com_bfsurvey\\/views\\/'.$catid.'result\\/tmpl\\/form.form.xml';
						$contenttype['hideFields'] = '["locked_by","locked_on"]';
						$contenttype['ignoreChanges'] = '["modified_by", "modified_on", "locked_by","locked_on","recaptcha_challenge_field","recaptcha_response_field","id","Itemid"]';
						$contenttype['convertToInt'] = '["ordering"]';
						$contenttype['displayLookup'] = '[{"sourceColumn":"bfsurvey_category_id","targetTable":"#__bfsurvey_categories","targetColumn":"bfsurvey_category_id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]';

						$table->save($contenttype);
					}
				}
			}
		}

		//now import import template
		$query->clear();
		$query = "RENAME TABLE `#__bfsurveyplus_email` TO `#__bfsurvey_emailitems`";

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query = "ALTER TABLE `#__bfsurvey_emailitems` CHANGE `state` `enabled` tinyint(3) NOT NULL DEFAULT '1';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query = "ALTER TABLE `#__bfsurvey_emailitems` CHANGE `id` `bfsurvey_emailitem_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query = "ALTER TABLE `#__bfsurvey_emailitems` CHANGE `catid` `bfsurvey_category_id` bigint(20) NOT NULL;";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query = "ALTER TABLE `#__bfsurvey_emailitems` CHANGE `created` `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query = "ALTER TABLE `#__bfsurvey_emailitems` CHANGE `modified` `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00';";
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$db = JFactory::getDbo();
		$query = "ALTER TABLE `#__bfsurvey_emailitems`
					ADD `sendTo` varchar(255) NOT NULL,
					ADD `condition_trigger` varchar(255) NOT NULL DEFAULT '',
					ADD `condition_field1` varchar(255) NOT NULL DEFAULT '',
					ADD `condition_criteria1` varchar(255) NOT NULL DEFAULT '',
					ADD `condition_value1` varchar(255) NOT NULL DEFAULT '',
					ADD `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
					ADD `locked_by` bigint(20) unsigned NOT NULL DEFAULT '0'";
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

		$app = JFactory::getApplication();
		$app->redirect(JRoute::_('index.php?option=com_bfsurvey&view=maintenance', false));
	}
}