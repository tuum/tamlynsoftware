<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

/**
 * Renders the price of a subscription level and its optional sign-up fee
 */
class FOFFormFieldBFSurveyreportsactions extends FOFFormFieldText
{
	/**
	 * Get the rendering of this field type for a repeatable (grid) display,
	 * e.g. in a view listing many item (typically a "browse" task)
	 *
	 * @return  string  The field HTML
	 */
	public function getRepeatable()
	{
		$html = '';

		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=read&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8') .
			'&tmpl=component" class="btn btn-info modal" rel="{handler: \'iframe\', size: {x: 800, y: 500}}" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_PREVIEW') . '"><span class="icon icon-file icon-white"></span></a>' .
			"\n";
		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=download&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8') .
			'" class="btn btn-primary" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_DOWNLOAD')
			. '"><span class="icon icon-download-alt icon-white"></span></a>' . "\n";
		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=read&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8').'&format=csv' .
			'" class="btn btn-success" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_EXPORT') .
			'"><span class="icon icon-file icon-white"></span></a>'
			. "\n";

		return $html;
	}
}
