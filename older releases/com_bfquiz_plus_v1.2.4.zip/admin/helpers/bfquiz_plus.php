<?php
/**
 * $Id: bfquiz_plus.php 52 2013-05-23 23:00:15Z tuum $
 * Helper for BF Quiz Plus - to populate the question types
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

/**
 * @package		Joomla
 * @subpackage	Components
 */
class bfquiz_plusHelper
{

	/**
	* build the select list for question type
	*/
	function QuestionType( &$question_type )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXT' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_RADIO' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_CHECKBOX' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXTAREA' ) );
		$click[] = JHTML::_('select.option',  '10', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_HEADING' ) );

		if($question_type == null){
		   $question_type=1;
		}

		$target = JHTML::_('select.genericlist',   $click, 'question_type', 'class="inputbox" size="5" onchange="hideType()"', 'value', 'text',  intval( $question_type ) );

		return $target;
	}

	/**
	* Show question type
	*/
	public static function ShowQuestionType( &$question_type ) {
	   switch($question_type){
	      case 0:	echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXT' );
	      			break;
	      case 1:   echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_RADIO' );
	      			break;
	      case 2:   echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_CHECKBOX' );
	      			break;
	      case 3:   echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXTAREA' );
	      			break;
	      case 10:   echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_HEADING' );
	      			break;
	      default:  echo JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_UNKNOWN' );
	   }
	}

	/**
	* build the select list for condition
	*/
	function ConditionType( &$condition, $i )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZPLUS_IS_EQUAL_TO' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZPLUS_IS_LESS_THAN' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZPLUS_IS_GREATER_THAN' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZPLUS_IS_NOT_EQUAL_TO' ) );

		if($condition == null){
		   $condition=0;
		}

		$target = JHTML::_('select.genericlist',   $click, 'condition'.$i.'', 'class="inputbox" size="1" onchange="hideType()"', 'value', 'text',  intval( $condition ) );

		return $target;
	}

	/**
	* build the select list for condition
	*/
	function OperatorType( &$operator_type, $i )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZPLUS_OPERATOR_AND' ) );
		//$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZPLUS_OPERATOR_OR' ) );

		if($operator_type == null){
		   $operator_type=0;
		}

		$target = JHTML::_('select.genericlist',   $click, 'operator'.$i.'', 'class="inputbox" size="1" onchange="hideType()"', 'value', 'text',  intval( $operator_type ) );

		return $target;
	}

    /**
	* build the select list for mandatory position
	*/
	function mandatoryPosition( &$mandatoryPos )
	{

		$click[] = JHTML::_('select.option',  'Start', JText::_( 'COM_BFQUIZPLUS_POSITION_START' ) );
		$click[] = JHTML::_('select.option',  'End', JText::_( 'COM_BFQUIZPLUS_POSITION_END' ) );
		$click[] = JHTML::_('select.option',  'Random', JText::_( 'COM_BFQUIZPLUS_POSITION_RANDOM' ) );

		if($mandatoryPos == null){
		   $mandatoryPos="random";
		}

		$target = JHTML::_('select.genericlist',   $click, 'mandatoryPos', 'class="inputbox" size="3"', 'value', 'text',  $mandatoryPos );

		return $target;
	}

    /**
	 * Build the select list for parent question
	 */
	function Parent( &$row )
	{
		$db = JFactory::getDBO();

		// If a not a new item, lets set the question item id
		if ( $row->id ) {
			$id = ' AND id != '.(int) $row->id;
		} else {
			$id = null;
		}

		// In case the parent was null
		if (!$row->parent) {
			$row->parent = 0;
		}

		// get a list of the question items
		// excluding the current question item and all child elements
		$query = 'SELECT m.*' .
				' FROM #__bfquiz_plus m' .
				' WHERE m.parent=0 and m.id<>'.$row->id.'' .
				' ORDER BY parent, ordering';
		$db->setQuery( $query );
		$mitems = $db->loadObjectList();

		// establish the hierarchy of the menu
		$children = array();

		if ( $mitems )
		{
			// first pass - collect children
			foreach ( $mitems as $v )
			{
				$pt 	= $v->parent;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}else{
			$list = "";
		}

		// assemble menu items to the array
		$mitems 	= array();
		$mitems[] 	= JHTML::_('select.option',  '0', JText::_( 'Top' ) );

		if($list != ""){
			foreach ( $list as $item ) {
				$mitems[] = JHTML::_('select.option',  $item->id, '&nbsp;&nbsp;&nbsp;'. $item->question . ' ' . $item->id );
			}
		}

		$output = JHTML::_('select.genericlist',   $mitems, 'parent', 'class="inputbox" size="10"', 'value', 'text', $row->parent );

		return $output;
	}

/**
	* build the select list for field type
	*/
	function FieldType( &$field_type )
	{

		$click[] = JHTML::_('select.option',  'VARCHAR', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_VARCHAR' ) );
		$click[] = JHTML::_('select.option',  'TEXT', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_TEXT' ) );
		$click[] = JHTML::_('select.option',  'DATE', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_DATE' ) );
		$click[] = JHTML::_('select.option',  'INT', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_INT' ) );
		$click[] = JHTML::_('select.option',  'TINYINT', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_TINYINT' ) );
		$click[] = JHTML::_('select.option',  'FLOAT', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_FLOAT' ) );
		$click[] = JHTML::_('select.option',  'DOUBLE', JText::_( 'COM_BFQUIZPLUS_FIELD_TYPE_DOUBLE' ) );

		if($field_type == null){
		   $field_type='TEXT';
		}

		$target = JHTML::_('select.genericlist',   $click, 'field_type', 'class="inputbox" size="1"', 'value', 'text',  $field_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationType( &$validation_type )
	{

		$click[] = JHTML::_('select.option',  'required', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED' ) );
		$click[] = JHTML::_('select.option',  'required validate-numeric', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_NUMERIC' ) );
		$click[] = JHTML::_('select.option',  'required validate-email', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_EMAIL' ) );

		if($validation_type == null){
		   $validation_type='required';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationTypeCheckbox( &$validation_type )
	{
		$click[] = JHTML::_('select.option',  'required validate-checkbox', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox2', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX2' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox3', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX3' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox4', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX4' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox5', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX5' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox6', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX6' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox7', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX7' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox8', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX8' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox9', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX9' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox10', JText::_( 'COM_BFQUIZPLUS_VALIDATION_REQUIRED_VALIDATE_CHECKBOX10' ) );

		if($validation_type == null | strpos($validation_type,"checkbox")==FALSE){
		   $validation_type='required validate-checkbox';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}

	/**
	* build the select list for email type
	*/
	function emailType( &$title )
	{
		$click[] = JHTML::_('select.option',  'Admin', JText::_( 'COM_BFQUIZPLUS_EMAIL_TYPE_ADMIN' ) );
		$click[] = JHTML::_('select.option',  'Author', JText::_( 'COM_BFQUIZPLUS_EMAIL_TYPE_AUTHOR' ) );

		if($title == null){
		   $title="Admin";
		}

		$target = JHTML::_('select.genericlist',   $click, 'title', 'class="inputbox" size="2"', 'value', 'text',  $title );

		return $target;
	}

	/**
	 * Configure the Linkbar.
	 *
	 * @param	string	The name of the active view.
	 * @since	1.6
	 */
	public static function addSubmenu($vName = 'bfquiz_plus')
	{
		JSubMenuHelper::addEntry(
			JText::_('COM_BFQUIZPLUS_TITLE_QUESTIONS'),
			'index.php?option=com_bfquiz_plus',
			$vName == 'bfquiz_plus'
		);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_CATEGORIES'),
    		'index.php?option=com_categories&extension=com_bfquiz_plus',
    		$vName == 'categories'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_REPORT'),
    		'index.php?option=com_bfquiz_plus&view=category',
    		$vName == 'report'
    	);

   		JSubMenuHelper::addEntry(
   			JText::_('COM_BFQUIZPLUS_TITLE_STATS'),
   			'index.php?option=com_bfquiz_plus&view=statscategory',
   			$vName == 'stats'
   		);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_RESULTS'),
    		'index.php?option=com_bfquiz_plus&view=resultscategory',
    		$vName == 'results'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_ABCD_ANSWER_MATRIX'),
    		'index.php?option=com_bfquiz_plus&view=matrixanswers',
    		$vName == 'matrixanswers'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_SCORE_RANGE_MATRIX'),
    		'index.php?option=com_bfquiz_plus&view=scoreranges',
    		$vName == 'scoreranges'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_QUESTION_POOL'),
    		'index.php?option=com_bfquiz_plus&view=poolitems',
    		$vName == 'poolitems'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_EMAIL_TEMPLATE'),
    		'index.php?option=com_bfquiz_plus&view=emailitems',
    		$vName == 'emailitems'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_SCORE_CAT'),
    		'index.php?option=com_bfquiz_plus&view=scorecats',
    		$vName == 'scorecats'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_MAINTENANCE'),
    		'index.php?option=com_bfquiz_plus&view=maintenance',
    		$vName == 'maintenance'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFQUIZPLUS_TITLE_HELP'),
    		'index.php?option=com_bfquiz_plus&view=help',
    		$vName == 'help'
    	);

	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @param	int		The category ID.
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_bfquiz_plus';
		} else {
			$assetName = 'com_bfquiz_plus.category.'.(int) $categoryId;
		}

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}

	/**
	 * Display Copyright information
	 *
	 */
	public static function displayVersion() {
		global $bfquizplus_version ;
		echo '<div class="clr"> </div>';
		echo '<div class="copyright" style="text-align:center;margin-top: 5px; display:block; width:100%; float:left;">'.JText::_( 'COM_BFQUIZPLUS_VERSION').' <strong>'.$bfquizplus_version.'</strong></div>' ;
	}

	static function getDataQuestion($id)
	{
	    $db = JFactory::getDBO();

		$query = 'SELECT *'
						. ' FROM #__bfquiz_plus'
						. ' WHERE state IN (0, 1) AND id = '.(int)$id
		;

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
	}

}