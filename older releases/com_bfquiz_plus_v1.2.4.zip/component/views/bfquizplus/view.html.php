<?php
/**
 * $Id: view.html.php 47 2013-02-20 11:45:27Z tuum $
 * BF Quiz Plus View for BF Quiz Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * Bfquiz_plusViewBfquiz_plus View
 *
 * @package    Joomla
 * @subpackage Components
 */
class Bfquiz_plusViewBfquizplus extends JViewLegacy
{
	protected $state;
	protected $item;

    function display($tpl = null)
    {
		$app		= JFactory::getApplication();
		$params		= $app->getParams();

		// Get data from the model
		$items		= $this->get('Item');

		$this->assignRef( 'items', $items );
		$this->assignRef( 'params', $params );

		$catid=JRequest::getInt('catid', 0);
	    if($catid){
        	parent::display($tpl);
	    }else{
	    	echo JText::_( "COM_BFQUIZPLUS_ERROR_MUST_SELECT_CATEGORY");
	    }
    }
}