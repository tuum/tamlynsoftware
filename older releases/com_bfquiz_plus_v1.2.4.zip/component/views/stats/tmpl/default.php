<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 47 2013-02-20 11:45:27Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php

if($this->catid != 0){  // make sure category is selected

$config = JComponentHelper::getParams( 'com_bfquiz_plus' );
$scoringMethod = $config->get( 'scoringMethod' );

?>

<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_OVERALL_STATS' ); ?>
            </th>
        </tr>
    </thead>

    <tr class="<?php echo "row"; ?>">
    <td>
    <?php
       echo JText::_( 'COM_BFQUIZPLUS_STATS_SO_FAR' );
       echo "&nbsp;";
       echo $this->totalResponses;
       echo "&nbsp;";
       echo JText::_('COM_BFQUIZPLUS_STATS_PEOPLE_HAVE_COMPLETED');
    ?>
    </td>
    </tr>

    <?php if($scoringMethod == 1){
       // do nothing.
    }else{
    ?>

    <tr class="<?php echo "row"; ?>">
    <td>
    <?php
       echo JText::_( 'COM_BFQUIZPLUS_STATS_MAX_SCORE' );
       echo "&nbsp;";
       echo $this->maxScore;
    ?>
    </td>
    </tr>
	</tr>
    <tr class="<?php echo "row"; ?>">
    <td>
    <?php
       echo JText::_( 'COM_BFQUIZPLUS_STATS_AVG_SCORE' );
       echo "&nbsp;";
       echo $this->averageScore;
       echo "&nbsp;";
       echo JText::_( 'COM_BFQUIZPLUS_STATS_OUT_OF' );
       echo "&nbsp;";
       echo $this->maxScore;
       echo "&nbsp;";
       echo JText::_( 'COM_BFQUIZPLUS_STATS_OR' );
       echo "&nbsp;";
       echo round((($this->averageScore/$this->maxScore)*100),2);
       echo JText::_( '%' );
    ?>
    </td>
    </tr>
    <tr class="<?php echo "row"; ?>">
    <td>
    <?php
       echo JText::_( 'COM_BFQUIZPLUS_STATS_HIGH_SCORE' );
       echo "&nbsp;";
       echo $this->highScore;
    ?>
    </td>
    </tr>
    </tr>
    <tr class="<?php echo "row"; ?>">
    <td>
    <?php
       echo JText::_( 'COM_BFQUIZPLUS_STATS_LOW_SCORE' );
       echo "&nbsp;";
       echo $this->lowScore;
    ?>
    </td>
    </tr>

    <?php
    } // end ABCD
    ?>

	</table>
</div>
<br>



<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'ID' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'Question' ); ?>
            </th>
        </tr>
    </thead>

    <?php
    $k = 0;
    for ($i=0, $n=count( $this->items2 ); $i < $n; $i++)
    {
		$row =& $this->items2[$i];

		if($row->question_type == 10){
			//do nothing
		}else{
        ?>
  		<tr class="<?php echo "row$k"; ?>">
  		    <td>
  		       <?php echo $row->id; ?>
  		    </td>
  		    <td>
  		       <?php echo JText::_($row->question); ?>
  		    </td>
  		</tr>

  		<tr>
  		<td colspan=2>
		<?php
		$question_type = $row->question_type;
		$total = 0;
		$myOption = array();
		$myAnswer = array();
		?>
  		Question type = <?php

  		echo Bfquiz_plusHelper::ShowQuestionType( $row->question_type );

		for ($i3=1; $i3 < 21; $i3++)
		{
			$fieldName=$row->field_name;
			$name = 'option'.$i3;
			$response=$row->$name;

			if($response==""){
			    // do nothing
			}else{
				if($question_type == 2){ //checkbox
				   $answer = bfquizplusController::getStatsCheckbox($fieldName, $response, $this->catid);
				}else{
				   $answer = bfquizplusController::getStats($fieldName, $response, $this->catid);
				}
				$myAnswer[$i3]=$answer;
				$myOption[$i3]=$response;

				if($answer > 0){
			       $total=$total + $answer;
		    	}
			}
		}

		if($question_type == 0){ //text
			$fieldName=$row->field_name;
			$response=$row->option1;
			$myAnswer[2]=0;

			for($x=0; $x < count($this->items3); $x++){
				$row2 =& $this->items3[$x];

				$tempanswer=$row2->$fieldName;

				if(strtoupper($tempanswer) == strtoupper($response)){
				   // do nothing
				}else if($tempanswer==""){
				   // do nothing
				}else{
					$myOption[2]='Incorrect';
					$myAnswer[2]=$myAnswer[2]+1;

					if($answer > 0){
					   $total=$total + 1;
		    	    }
				}
			}
		}

		?>

		<table>
		<tr>
		   <th width="400">Option</th>
		   <th width="50">Count</th>
		   <th width="100">Percent</th>
		   <th width="100">Graph</th>
		</tr>
		<?php
			$colourCount=0;
			for ($z=1; $z < count($myOption)+1; $z++){
			    $colourCount++;
			    if($colourCount > 5){
			       $colourCount = 1;
			    }
			    echo "<tr>";
			    echo "<td>".JText::_($myOption[$z])."</td>";
			    echo "<td>".$myAnswer[$z]."</td>";
			    if($total > 0){
			       echo "<td>".number_format((($myAnswer[$z]/$total)*100),2)."%</td>";
				}else{
				   echo "<td>0.00%</td>";
				}


			    $myclass = 'polls_color_'.$colourCount;
			?>
			    <td width=300 >
			    <?php
			    if($total > 0){
			    ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:<?php echo (($myAnswer[$z]/$total)*100) ?>%"></div>
		        <?php
		        }else{
		        ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:1%"></div>
		        <?php
		        }
		        ?>
		        </td>
			    </tr>
			<?php

			}

		?>
		</table>
		<?php
		echo JText::_( 'Total: ');
		echo $total;
		?>
        </td>
        </tr>

        <?php
        $k = 1 - $k;
		}
    }
    ?>
    </table>
</div>

<?php

}else{

   echo "You must select a category in Parameters Basic.";

}

?>