<?php
/**
 *  @package	Slick Slider
 *  @copyright	Copyright (c)2015 Tim Plummer / TamlynSoftware.com
 *  @license	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Slick Slider is a third party JQuery library developed by Ken Wheeler
 *  http://kenwheeler.github.io/slick/
 *  Copyright (c) 2014 Ken Wheeler
 *  Licensed under the MIT license.
 */

// no direct access
defined('_JEXEC') or die('');

JHtml::_('jquery.framework');

$document = JFactory::getDocument();
$cssFile = JURI::base().'media/mod_slick/css/slick-theme.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/slick.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/slicknav.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/style.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());


$document->addScript(JURI::base().'media/mod_slick/js/slick.min.js' );

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

$image1 = htmlspecialchars($params->get('image1', ''));
$image1url = htmlspecialchars($params->get('image1url', ''));
$image1title = htmlspecialchars($params->get('image1title', ''));

$image2 = htmlspecialchars($params->get('image2', ''));
$image2url = htmlspecialchars($params->get('image2url', ''));
$image2title = htmlspecialchars($params->get('image2title', ''));

$image3 = htmlspecialchars($params->get('image3', ''));
$image3url = htmlspecialchars($params->get('image3url', ''));
$image3title = htmlspecialchars($params->get('image3title', ''));

$image4 = htmlspecialchars($params->get('image4', ''));
$image4url = htmlspecialchars($params->get('image4url', ''));
$image4title = htmlspecialchars($params->get('image4title', ''));

$image5 = htmlspecialchars($params->get('image5', ''));
$image5url = htmlspecialchars($params->get('image5url', ''));
$image5title = htmlspecialchars($params->get('image5title', ''));

$image6 = htmlspecialchars($params->get('image6', ''));
$image6url = htmlspecialchars($params->get('image6url', ''));
$image6title = htmlspecialchars($params->get('image6title', ''));

$image7 = htmlspecialchars($params->get('image7', ''));
$image7url = htmlspecialchars($params->get('image7url', ''));
$image7title = htmlspecialchars($params->get('image7title', ''));

$image8 = htmlspecialchars($params->get('image8', ''));
$image8url = htmlspecialchars($params->get('image8url', ''));
$image8title = htmlspecialchars($params->get('image8title', ''));

$image9 = htmlspecialchars($params->get('image9', ''));
$image9url = htmlspecialchars($params->get('image9url', ''));
$image9title = htmlspecialchars($params->get('image9title', ''));

$image10 = htmlspecialchars($params->get('image10', ''));
$image10url = htmlspecialchars($params->get('image10url', ''));
$image10title = htmlspecialchars($params->get('image10title', ''));

$autoplay = htmlspecialchars($params->get('autoplay', ''));
$autoplaySpeed = htmlspecialchars($params->get('autoplaySpeed', '2000'));
$pauseOnHover = htmlspecialchars($params->get('pauseOnHover', '0'));
$pauseOnHover = $pauseOnHover==1 ? 'true' : 'false';

if($autoplay){
	$auto = 'autoplay: true,
  			autoplaySpeed: '.$autoplaySpeed.',
			pauseOnHover: '.$pauseOnHover.',';
}else{
	$auto = '';
}

$infinite = htmlspecialchars($params->get('infinite', '1'));
$infinite = $infinite==1 ? 'infinite: true,' : 'infinite: false,';

$touchMove = htmlspecialchars($params->get('touchMove', '0'));
$touchMove = $touchMove==1 ? 'touchMove: true,' : 'touchMove: false,';

$showArrows = htmlspecialchars($params->get('arrows', '1'));
$arrows = $showArrows==1 ? 'arrows: true,' : 'arrows: false,';

$document->addScriptDeclaration('
(function($)
{
	$(document).ready(function()
	{
		$(\'.slick-list\').slick({
			prevArrow: false,
			nextArrow: false,
			dots: false,
			speed: 300,
			slidesToShow: 1,
			centerMode: true,
			initialSlide: 1,
			variableWidth: true,
			'.$auto.'
			'.$infinite.'
			'.$touchMove.'
			'.$arrows.'
		});

			$(\'.slick-next\').click(function(){
				$("#carousel").slick(\'slickNext\');
			});

				$(\'.slick-prev\').click(function(){
					$("#carousel").slick(\'slickPrev\');
				});

	});
})(jQuery);
');

if(isset($image1))
{
	//get image height of first image
	$imginfo = getimagesize($image1);
	//$src_w = $imginfo[0];
	$src_h = $imginfo[1] + 40;
}
else
{
	$src_h = 250;
}

// Add styles
$style = '.slick-control {    
	top: -' . $src_h/2 . 'px !important;    
}';
$document->addStyleDeclaration($style);

?>
<div class="slick<?php echo $moduleclass_sfx ?>">

<div class="variable-width">
	<div class="slick-list filmstrip draggable" aria-live="polite" tabindex="0" id="carousel">

		<?php if(isset($image1) && $image1 != ''){ ?>
		<div>
			<?php if(isset($image1url) && $image1url != ''){ ?>
			<a href="<?php echo $image1url; ?>">
			<?php } ?>
				<img src="<?php echo $image1; ?>" alt="<?php echo $image1title; ?>">
			<?php if(isset($image1url) && $image1url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image1url) && $image1url != ''){ ?>
			<a href="<?php echo $image1url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image1title) && $image1title != ''){ ?>
				<span><?php echo $image1title; ?></span>
				<?php } ?>
			<?php if(isset($image1url) && $image1url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image2) && $image2 != ''){ ?>
		<div>
			<?php if(isset($image2url) && $image2url != ''){ ?>
			<a href="<?php echo $image2url; ?>">
			<?php } ?>
				<img src="<?php echo $image2; ?>" alt="<?php echo $image2title; ?>">
			<?php if(isset($image2url) && $image2url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image2url) && $image2url != ''){ ?>
			<a href="<?php echo $image2url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image2title) && $image2title != ''){ ?>
				<span><?php echo $image2title; ?></span>
				<?php } ?>
			<?php if(isset($image2url) && $image2url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image3) && $image3 != ''){ ?>
		<div>
			<?php if(isset($image3url) && $image3url != ''){ ?>
			<a href="<?php echo $image3url; ?>">
			<?php } ?>
				<img src="<?php echo $image3; ?>" alt="<?php echo $image3title; ?>">
			<?php if(isset($image3url) && $image3url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image3url) && $image3url != ''){ ?>
			<a href="<?php echo $image3url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image3title) && $image3title != ''){ ?>
				<span><?php echo $image3title; ?></span>
				<?php } ?>
			<?php if(isset($image3url) && $image3url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image4) && $image4 != ''){ ?>
		<div>
			<?php if(isset($image4url) && $image4url != ''){ ?>
			<a href="<?php echo $image4url; ?>">
			<?php } ?>
				<img src="<?php echo $image4; ?>" alt="<?php echo $image4title; ?>">
			<?php if(isset($image4url) && $image4url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image4url) && $image4url != ''){ ?>
			<a href="<?php echo $image4url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image4title) && $image4title != ''){ ?>
				<span><?php echo $image4title; ?></span>
				<?php } ?>
			<?php if(isset($image4url) && $image4url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image5) && $image5 != ''){ ?>
		<div>
			<?php if(isset($image5url) && $image5url != ''){ ?>
			<a href="<?php echo $image5url; ?>">
			<?php } ?>
				<img src="<?php echo $image5; ?>" alt="<?php echo $image5title; ?>">
			<?php if(isset($image5url) && $image5url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image5url) && $image5url != ''){ ?>
			<a href="<?php echo $image5url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image5title) && $image5title != ''){ ?>
				<span><?php echo $image5title; ?></span>
				<?php } ?>
			<?php if(isset($image5url) && $image5url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image6) && $image6 != ''){ ?>
		<div>
			<?php if(isset($image6url) && $image6url != ''){ ?>
			<a href="<?php echo $image6url; ?>">
			<?php } ?>
				<img src="<?php echo $image6; ?>" alt="<?php echo $image6title; ?>">
			<?php if(isset($image6url) && $image6url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image6url) && $image6url != ''){ ?>
			<a href="<?php echo $image6url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image6title) && $image6title != ''){ ?>
				<span><?php echo $image6title; ?></span>
				<?php } ?>
			<?php if(isset($image6url) && $image6url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image7) && $image7 != ''){ ?>
		<div>
			<?php if(isset($image7url) && $image7url != ''){ ?>
			<a href="<?php echo $image7url; ?>">
			<?php } ?>
				<img src="<?php echo $image7; ?>" alt="<?php echo $image7title; ?>">
			<?php if(isset($image7url) && $image7url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image7url) && $image7url != ''){ ?>
			<a href="<?php echo $image7url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image7title) && $image7title != ''){ ?>
				<span><?php echo $image7title; ?></span>
				<?php } ?>
			<?php if(isset($image7url) && $image7url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image8) && $image8 != ''){ ?>
		<div>
			<?php if(isset($image8url) && $image8url != ''){ ?>
			<a href="<?php echo $image8url; ?>">
			<?php } ?>
				<img src="<?php echo $image8; ?>" alt="<?php echo $image8title; ?>">
			<?php if(isset($image8url) && $image8url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image8url) && $image8url != ''){ ?>
			<a href="<?php echo $image8url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image8title) && $image8title != ''){ ?>
				<span><?php echo $image8title; ?></span>
				<?php } ?>
			<?php if(isset($image8url) && $image8url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image9) && $image9 != ''){ ?>
		<div>
			<?php if(isset($image9url) && $image9url != ''){ ?>
			<a href="<?php echo $image9url; ?>">
			<?php } ?>
				<img src="<?php echo $image9; ?>" alt="<?php echo $image9title; ?>">
			<?php if(isset($image9url) && $image9url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image9url) && $image9url != ''){ ?>
			<a href="<?php echo $image9url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image9title) && $image9title != ''){ ?>
				<span><?php echo $image9title; ?></span>
				<?php } ?>
			<?php if(isset($image9url) && $image9url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if(isset($image10) && $image10 != ''){ ?>
		<div>
			<?php if(isset($image10url) && $image10url != ''){ ?>
			<a href="<?php echo $image10url; ?>">
			<?php } ?>
				<img src="<?php echo $image10; ?>" alt="<?php echo $image10title; ?>">
			<?php if(isset($image10url) && $image10url != ''){ ?>
			</a>
			<?php } ?>
			<?php if(isset($image10url) && $image10url != ''){ ?>
			<a href="<?php echo $image10url; ?>" class="caption">
			<?php } ?>
				<?php if(isset($image10title) && $image10title != ''){ ?>
				<span><?php echo $image10title; ?></span>
				<?php } ?>
			<?php if(isset($image10url) && $image10url != ''){ ?>
			</a>
			<?php } ?>
		</div>
		<?php } ?>

	</div>

	<?php if($showArrows==1){ ?>
		<div class="slick-control slick-prev" style="display: block;"></div>
		<div class="slick-control slick-next" style="display: block;"></div>
	<?php } ?>
</div>

</div>