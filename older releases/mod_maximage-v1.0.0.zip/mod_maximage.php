<?php
/**
 *  @package	Maximage Background Slider
 *  @copyright	Copyright (c)2015 Tim Plummer / TamlynSoftware.com
 *  @license	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Maximage Background Slider is a third party JQuery library developed by Aaron Vanderzwan
 *  http://blog.aaronvanderzwan.com/2012/07/maximage-2-0/
 *  Copyright (c) 2007-2012 Aaron Vanderzwan
 *  Dual licensed under the MIT and GPL licenses.
 */

// no direct access
defined('_JEXEC') or die('');

JHtml::_('jquery.framework');

$document = JFactory::getDocument();
$cssFile = JURI::base().'media/mod_maximage/css/maximage.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$document->addScript(JURI::base().'media/mod_maximage/js/jquery.cycle.all.min.js' );
$document->addScript(JURI::base().'media/mod_maximage/js/jquery.maximage.min.js' );

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

$image1 = htmlspecialchars($params->get('image1', ''));
$image2 = htmlspecialchars($params->get('image2', ''));
$image3 = htmlspecialchars($params->get('image3', ''));
$image4 = htmlspecialchars($params->get('image4', ''));
$image5 = htmlspecialchars($params->get('image5', ''));
$image6 = htmlspecialchars($params->get('image6', ''));
$image7 = htmlspecialchars($params->get('image7', ''));
$image8 = htmlspecialchars($params->get('image8', ''));
$image9 = htmlspecialchars($params->get('image9', ''));
$image10 = htmlspecialchars($params->get('image10', ''));

$autoplaySpeed = htmlspecialchars($params->get('autoplaySpeed', '3000'));

$document->addScriptDeclaration('
(function($)
{
	$(document).ready(function()
	{
		$(function() {
		    var imgs = $(\'#maximage img\');
		    imgs.sort(function() { return 0.5 - Math.random() });
		    $(\'#maximage\').html( imgs );

		    $(\'#maximage\').maximage({
		        cycleOptions: {
		            speed: '.$autoplaySpeed.'
		        }
		    });
		});
	});
})(jQuery);
');


?>
<div class="maximage<?php echo $moduleclass_sfx ?>">

	<div id="maximage">

		<?php if(isset($image1) && $image1 != ''){ ?>
		<img src="<?php echo $image1; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image2) && $image2 != ''){ ?>
		<img src="<?php echo $image2; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image3) && $image3 != ''){ ?>
		<img src="<?php echo $image3; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image4) && $image4 != ''){ ?>
		<img src="<?php echo $image4; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image5) && $image5 != ''){ ?>
		<img src="<?php echo $image5; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image6) && $image6 != ''){ ?>
		<img src="<?php echo $image6; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image7) && $image7 != ''){ ?>
		<img src="<?php echo $image7; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image8) && $image8 != ''){ ?>
		<img src="<?php echo $image8; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image9) && $image9 != ''){ ?>
		<img src="<?php echo $image9; ?>" alt="image01" />
		<?php } ?>

		<?php if(isset($image10) && $image10 != ''){ ?>
		<img src="<?php echo $image10; ?>" alt="image01" />
		<?php } ?>
	</div>

</div>