<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

$model = $this->getModel();
$this->menuItems = $model->getMenuItems();
$this->categoryItems = $model->getCategoryItems();

header('Content-type: text/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>'.PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

<?php foreach ($this->menuItems as $menu): ?>
<?php $link = JRoute::_($menu->link, true, @$node->secure == 0 ? (JFactory::getURI()->isSSL() ? 1 : -1) : $node->secure); ?>
<?php if(!empty($link)){ ?>
	<url>
		<loc><?php echo $link; ?></loc>
	<?php if(isset($menu->modified)){ ?>
		<lastmod><?php echo $menu->modified; ?></lastmod>
	<?php } ?>
		<changefreq>weekly</changefreq>
		<priority>0.5</priority>
	</url>
<?php } ?>
<?php endforeach; ?>

<?php foreach ($this->categoryItems as $item): ?>
<?php $Itemid = $item->Itemid==0 ? '' : '&amp;Itemid='.$item->Itemid; ?>
<?php if($item->Itemid != -1){ ?>
<?php $link = JRoute::_('index.php?option=com_content&amp;view=article&amp;id='.$item->id.'&amp;catid='.$item->catid.$Itemid, false, 2) ?>
	<url>
		<loc><?php echo $link ?></loc>
		<?php if(isset($item->modified)){ ?>
			<lastmod><?php echo $item->modified; ?></lastmod>
		<?php } ?>
		<changefreq>weekly</changefreq>
		<priority>0.5</priority>
	</url>
<?php } ?>
<?php endforeach; ?>

</urlset>
