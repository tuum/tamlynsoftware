<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelMetatagcats extends F0FModel
{
	public function __construct($config = array()) {
		$config['table'] = 'categories';
		parent::__construct($config);
	}

	static function getMenuItems()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('id,  title, metadesc');
		$query->from('#__categories');
		$query->where('published = 1');
		$query->where('extension = "com_content"');
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		return $rows;
	}

	static function updateMeta($metadesc, $id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->clear();
		$query->update('#__categories');
		$query->set("`metadesc`='{$metadesc}'");
		$query->where('id='.(int)$id);
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}

		return true;
	}
}
