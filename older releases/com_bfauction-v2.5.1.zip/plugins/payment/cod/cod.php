<?php

defined('_JEXEC') or die('Restricted access');

$lang = JFactory::getLanguage();
$lang->load('plg_payment_cod', JPATH_ADMINISTRATOR);

require_once(dirname(__FILE__) . '/cod/helper.php');

class plgpaymentcod extends JPlugin
{
	var $_payment_gateway = 'payment_cod';
	var $_log = null;

	function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);

		$this->responseStatus = array(
			'Completed' => 'C',
			'Pending' => 'P',
			'Failed' => 'E',
			'Denied' => 'D',
			'Refunded' => 'RF',
			'Canceled_Reversal' => 'CRV',
			'Reversed' => 'RV',
			'ERROR' => 'E');
	}

	function onTP_GetInfo($config)
	{
		if (!in_array($this->_name, $config)) {
			return null;
		}
		$obj = new stdClass;
		$obj->name = $this->params->get('plugin_name');
		$obj->id = $this->_name;
		return $obj;
	}

	function onTP_GetHTML($vars)
	{
		$html = $this->buildLayout($vars);
		return $html;
	}

	function onTP_Processpayment($data, $vars = null)
	{
		$user = JFactory::getUser();
		$user_name = $user->username;
		$now = JFactory::getDate()->toSql();
		
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__bfauction_items');
		$query->where('orderId=' . $data['orderId']);
		$query->where("highBidder='$user_name'");
		$query->set('orderStatus="P"');
		$query->set("orderDate='$now'");
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum()) {
			return JError::raiseWarning(500, 'COM_BFAUCTION_DATABASE_ERROR');
		}

		$result = array(
			'order_id' => $data['orderId'],
			'status' => 'P',
		);

		return $result;
	}

	function buildLayout($vars, $layout = 'default')
	{
		ob_start();
		$layout = $this->buildLayoutPath($layout);
		include($layout);
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

	function buildLayoutPath($layout)
	{
		$app = JFactory::getApplication();
		$core_file = dirname(__FILE__) . '/' . $this->_name . '/tmpl/default.php';
		$override = JPATH_BASE . '/' . 'templates' . '/' . $app->getTemplate() . '/html/plugins/' . $this->_type . '/' . $this->_name . '/' . $layout . '.php';
		if (JFile::exists($override)) {
			return $override;
		} else {
			return $core_file;
		}
	}
}


