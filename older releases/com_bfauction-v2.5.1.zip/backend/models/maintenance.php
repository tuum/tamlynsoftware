<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 3, or later
 * @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionModelMaintenance extends F0FModel
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->table = 'categories';
	}

	function import($includeEmail = null)
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__categories');
		$query->where('extension = ' . "'com_bfauction_plus'");
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {
			return $this->dbErrorMessage($db);
		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				return $this->dbErrorMessage($db);
			}
			return true;
		}

		$ids = array();

		foreach ($rows as $row) {
			$query = $db->getQuery(true);
			$query->insert('#__bfauction_categories');
			$query->set("title = '{$row->title}'");
			$query->set("slug = '" . JFilterOutput::stringURLSafe($row->title) . "'");
			$query->set("created_on = '{$row->created_time}'");
			$query->set("created_by = '{$row->created_user_id}'");
			$query->set("modified_on = '{$row->modified_time}'");
			$query->set("modified_by = '{$row->modified_user_id}'");
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				return $this->dbErrorMessage($db);
			}
			$ids[$row->id] = $db->insertid();
		}

		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__bfauction_plus');
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {
			return $this->dbErrorMessage($db);
		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				return $this->dbErrorMessage($db);
			}
			return true;
		}

		foreach ($rows as $row) {
			$query = $db->getQuery(true);
			$query->insert('#__bfauction_items');
			$query->set("bfauction_category_id = {$ids[$row->catid]}");
			$query->set("title = '{$row->title}'");
			$query->set("slug = '" . JFilterOutput::stringURLSafe($row->title) . "'");
			$query->set("description = '{$row->description}'");
			$query->set("currentBid = '{$row->currentBid}'");
			$query->set("highBidder = '{$row->highBidder}'");
			$query->set("date = '{$row->date}'");
			$query->set("endDate = '{$row->endDate}'");
			$query->set("checked_out = '{$row->checked_out}'");
			$query->set("checked_out_time = '{$row->checked_out_time}'");
			$query->set("created = '{$row->created}'");
			$query->set("created_by = '{$row->created_by}'");
			$query->set("modified = '{$row->modified}'");
			$query->set("modified_by = '{$row->modified_by}'");
			$query->set("parent = '{$row->parent}'");
			$query->set("publish_up = '{$row->publish_up}'");
			$query->set("publish_down = '{$row->publish_down}'");
			$query->set("itemLocation = '{$row->itemLocation}'");
			$query->set("deliveryMethod = '{$row->deliveryMethod}'");
			$query->set("imageShared = '{$row->imageShared}'");
			$query->set("productId = '{$row->productId}'");
			$query->set("onlineStore = '{$row->onlineStore}'");
			$query->set("bidIncrement = '{$row->bidIncrement}'");
			$query->set("shipping = '{$row->shipping}'");
			$query->set("buyNowPrice = '{$row->buyNowPrice}'");
			$query->set("winEmailSent = '{$row->winEmailSent}'");
			$query->set("winEmailDate = '{$row->winEmailDate}'");
			$query->set("reservePrice = '{$row->reservePrice}'");
			$query->set("commission = '{$row->commission}'");
			$query->set("tax = '{$row->tax}'");
			$query->set("taxableItem = '{$row->taxableItem}'");
			$query->set("commissionAmount = '{$row->commissionAmount}'");
			$query->set("taxAmount = '{$row->taxAmount}'");
			$query->set("priceEstimate = '{$row->priceEstimate}'");
			$query->set("qtyAvailable = '{$row->qtyAvailable}'");
			$query->set("itemCondition = '{$row->condition}'");        // 'condition' is a reserved word in MySql 5
			$query->set("buyersPremium = '{$row->buyersPremium}'");
			$query->set("saleType = '{$row->saleType}'");
			$query->set("address1 = '{$row->address1}'");
			$query->set("address2 = '{$row->address2}'");
			$query->set("city = '{$row->city}'");
			$query->set("region = '{$row->region}'");
			$query->set("postcode = '{$row->postcode}'");
			$query->set("country = '{$row->country}'");
			$query->set("phone = '{$row->phone}'");
			$query->set("relistid = '{$row->relistid}'");
			$query->set("quantity = '{$row->quantity}'");
			$query->set("quantityPurchased = '{$row->quantityPurchased}'");
			$query->set("deliveryOption = '{$row->deliveryOption}'");
			$query->set("supplier = '{$row->supplier}'");
			$query->set("costPrice = '{$row->costPrice}'");
			$query->set("featured = '{$row->featured}'");
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				return $this->dbErrorMessage($db);
			}

			for ($i = 1; $i < 21; $i++) {
				$src  = JPATH_BASE . "/../images/com_bfauction_plus/{$row->id}img{$i}.jpg";
				if (file_exists($src)) {
					$dest  = JPATH_BASE . "/../images/com_bfauction/{$db->insertid()}img{$i}.jpg";
					@copy($src, $dest);
					$src  = JPATH_BASE . "/../images/com_bfauction_plus/{$row->id}img{$i}_t.jpg";
					$dest  = JPATH_BASE . "/../images/com_bfauction/{$db->insertid()}img{$i}_t.jpg";
					@copy($src, $dest);
				}
			}
		}

		if ($includeEmail) {

			$query = $db->getQuery(true);
			$query->select('*');
			$query->from('#__bfauction_plus_email');
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				return $this->dbErrorMessage($db);
			}
			$rows = $db->loadObjectList();
			if (empty($rows)) {
				if ($db->getErrorNum()) {
					return $this->dbErrorMessage($db);
				}
				return true;
			}

			foreach ($rows as $row) {
				$query = $db->getQuery(true);
				$query->insert('#__bfauction_emailitems');
				$query->set("bfauction_category_id = {$ids[$row->catid]}");
				$query->set("title = '{$row->title}'");
				$query->set("subject = '{$row->subject}'");
				$query->set("description = '{$row->description}'");
				$query->set("access = '{$row->access}'");
				$query->set("language = '{$row->language}'");
				$query->set("ordering = '{$row->ordering}'");
				$query->set("created_on = '{$row->created}'");
				$query->set("created_by = '{$row->created_by}'");
				$query->set("modified_on = '{$row->modified}'");
				$query->set("modified_by = '{$row->modified_by}'");
				$db->setQuery($query);
				$db->query();
				if ($db->getErrorNum()) {
					return $this->dbErrorMessage($db);
				}
			}

		}


		return true;
	}

	function dbErrorMessage($db)
	{
		return JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg());
	}

}
