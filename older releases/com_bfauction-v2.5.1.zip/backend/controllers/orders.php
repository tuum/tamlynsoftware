<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2015 Tim Plummer
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionControllerOrder extends F0FController
{
	public function complete()
	{
		//JSession::checkToken( 'get' ) or jexit(JText::_('JINVALID_TOKEN'));

		$input = JFactory::getApplication()->input;

		//$now = JFactory::getDate()->toSql();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__bfauction_items');
		$query->set('orderStatus="C"');
		$query->where('orderId=' . (int) $input->get('orderId'));
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum()) {
			$this->setMessage('Error');
		} else {
			$this->setMessage('Order has been completed.');
		}

		$this->setRedirect('index.php?option=com_bfauction&view=orders');

	}
}