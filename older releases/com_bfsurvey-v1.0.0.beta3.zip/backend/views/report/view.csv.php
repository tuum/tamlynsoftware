<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyViewReport extends FOFViewCsv
{
	public function onRead($tpl = null) {
		$id = JRequest::getVar( 'id', 0, '', 'int' );

		$model = $this->getModel();
		$this->reportDetails = $model->getReport($id);
		$items = $model->createReport($this->reportDetails);

		$document = FOFPlatform::getInstance()->getDocument();

		if ($document instanceof JDocument)
		{
			$document->setMimeEncoding('text/csv');
		}

		JResponse::setHeader('Pragma', 'public');
		JResponse::setHeader('Expires', '0');
		JResponse::setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0');
		JResponse::setHeader('Cache-Control', 'public', false);
		JResponse::setHeader('Content-Description', 'File Transfer');
		JResponse::setHeader('Content-Disposition', 'attachment; filename="' . $this->csvFilename . '.csv"');

		if (is_null($tpl))
		{
			$tpl = 'csv';
		}

		if (FOFPlatform::getInstance()->checkVersion(JVERSION, '3.0', 'lt'))
		{
			FOFPlatform::getInstance()->setErrorHandling(E_ALL, 'ignore');
		}

		$hasFailed = false;

		try
		{
			$result = $this->loadTemplate($tpl, true);

			if ($result instanceof Exception)
			{
				$hasFailed = true;
			}
		}
		catch (Exception $e)
		{
			$hasFailed = true;
		}

		if (FOFPlatform::getInstance()->checkVersion(JVERSION, '3.0', 'lt'))
		{
			if ($result instanceof Exception)
			{
				$hasFailed = true;
			}
		}

		if (!$hasFailed)
		{
			echo $result;
		}
		else
		{
			// Default CSV behaviour in case the template isn't there!

			if (empty($items))
			{
				return;
			}

			$item    = array_pop($items);
			$keys    = get_object_vars($item);
			$keys    = array_keys($keys);
			$items[] = $item;
			reset($items);

			if (!empty($this->csvFields))
			{
				$temp = array();

				foreach ($this->csvFields as $f)
				{
					if (in_array($f, $keys))
					{
						$temp[] = $f;
					}
				}

				$keys = $temp;
			}

			if ($this->csvHeader)
			{
				$csv = array();

				foreach ($keys as $k)
				{
					$csv[] = '"' . str_replace('"', '""', $k) . '"';
				}

				echo implode(",", $csv) . "\r\n";
			}

			foreach ($items as $item)
			{
				$csv  = array();
				$item = (array) $item;

				foreach ($keys as $k)
				{
					if (!isset($item[$k]))
					{
						$v = '';
					}
					else
					{
						$v = $item[$k];
					}

					if (is_array($v))
					{
						$v = 'Array';
					}
					elseif (is_object($v))
					{
						$v = 'Object';
					}

					$csv[] = '"' . str_replace('"', '""', $v) . '"';
				}

				echo implode(",", $csv) . "\r\n";
			}
		}

		return false;
	}
}