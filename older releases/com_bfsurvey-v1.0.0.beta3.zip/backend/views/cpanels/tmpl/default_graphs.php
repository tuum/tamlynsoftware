<?php

// Protect from unauthorized access
defined('_JEXEC') or die();

//FOFTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.jqplot.min.css');
//
//FO/FTemplateUtils::parsePath('media://com_bfsurvey/js/excanvas.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jquery.jqplot.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jqplot.highlighter.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jqplot.dateAxisRenderer.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jqplot.barRenderer.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jqplot.pieRenderer.min.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/jqplot.hermite.js');
//FOFTemplateUtils::parsePath('media://com_bfsurvey/js/cpanelgraphs.js');

FOFTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.jqplot.min.css');

AkeebaStrapper::addJSfile('media://com_bfsurvey/js/excanvas.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jquery.jqplot.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.highlighter.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.dateAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.barRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pieRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.hermite.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/cpanelgraphs.js');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$graphDayFrom = gmdate('Y-m-d', time() - 30 * 24 * 3600);
?>
<h3><?php echo JText::_('COM_BFSURVEY_DASHBOARD_EXCEPTIONS') ?></h3>
<p>
	<?php echo JText::_('COM_BFSURVEY_DASHBOARD_FROMDATE') ?>
	<?php echo JHTML::_('calendar', $graphDayFrom, 'bfsurvey_graph_datepicker', 'bfsurvey_graph_datepicker'); ?>
	&nbsp;
	<button class="btn btn-mini" id="bfsurvey_graph_reload" onclick="return false">
		<?php echo JText::_('COM_BFSURVEY_DASHBOARD_RELOADGRAPHS') ?>
	</button>
</p>
<div id="aksaleschart">
	<img src="<?php echo FOFTemplateUtils::parsePath('media://com_bfsurvey/images/throbber.gif')?>" id="akthrobber" />
	<p id="aksaleschart-nodata" style="display:none">
		<?php echo JText::_('COM_BFSURVEY_DASHBOARD_STATS_NODATA')?>
	</p>
</div>

<div style="clear: both;">&nbsp;</div>

<h3><?php echo JText::_('COM_BFSURVEY_DASHBOARD_EXCEPTSTATS') ?></h3>
<div id="aklevelschart">
	<img src="<?php echo FOFTemplateUtils::parsePath('media://com_bfsurvey/images/throbber.gif')?>" id="akthrobber2" />
	<p id="aklevelschart-nodata" style="display:none">
		<?php echo JText::_('COM_BFSURVEY_DASHBOARD_STATS_NODATA')?>
	</p>
</div>

<script type="text/javascript">

bfsurvey_cpanel_graph_from = "<?php echo $graphDayFrom ?>";

(function($) {
	$(document).ready(function(){
		bfsurvey_cpanel_graphs_load();

		$('#bfsurvey_graph_reload').click(function(e){
			bfsurvey_cpanel_graphs_load();
		})
	});
})(akeeba.jQuery);
</script>