<?php
defined('_JEXEC') or die();

JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

?>


<?php echo $this->getRenderedForm(); ?>