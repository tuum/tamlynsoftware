<?php
defined('_JEXEC') or die();

class bfsurveyViewStats extends FOFViewHtml
{

}