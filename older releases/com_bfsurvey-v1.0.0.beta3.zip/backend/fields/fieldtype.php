<?php
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class
 */
class JFormFieldfieldtype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'fieldtype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

				$options[] = JHTML::_('select.option',  'VARCHAR', JText::_( 'VARCHAR' ) );
				$options[] = JHTML::_('select.option',  'TEXT', JText::_( 'TEXT' ) );
				$options[] = JHTML::_('select.option',  'DATE', JText::_( 'DATE' ) );
				$options[] = JHTML::_('select.option',  'INT', JText::_( 'INT' ) );
				$options[] = JHTML::_('select.option',  'TINYINT', JText::_( 'TINYINT' ) );
				$options[] = JHTML::_('select.option',  'FLOAT', JText::_( 'FLOAT' ) );
				$options[] = JHTML::_('select.option',  'DOUBLE', JText::_( 'DOUBLE' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
