<?php
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Email Type Form Field class
 */
class JFormFieldemailtype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'emailtype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

				$options[] = JHTML::_('select.option',  'Admin', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_ADMIN' ) );
				$options[] = JHTML::_('select.option',  'Author', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_AUTHOR' ) );
				$options[] = JHTML::_('select.option',  'Invite', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_INVITE' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
