<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyControllerEmailitem extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'emailitem';
	}

	function sendnow()
	{
		$result = parent::save();

		$myresult=$this->input->getdata();

		$catid = $myresult["bfsurvey_category_id"];
		$emailType = $myresult["title"];
		$emailTemplate = BFSurveyDispatcher::getEmailTemplate($emailType,(int)$catid);

		if($emailTemplate)
		{
			BFSurveyDispatcher::sendEmail($emailTemplate, null, (int)$catid);
		}
	}
}