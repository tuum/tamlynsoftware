<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelReport extends FOFModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'reports';
	}

	public function save($data)
	{
		if(is_array($data['fields'])){
			$data['fields'] = implode(",", $data['fields']);
		}

		parent::save($data);

		return true;
	}
}