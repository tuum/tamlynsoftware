<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelQuestions extends FOFModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'questions';
	}

	public function save($data)
	{
		if(is_array($data['hide_options'])){
			$data['hide_options'] = implode(",", $data['hide_options']);
		}

		if(is_array($data['show_options'])){
			$data['show_options'] = implode(",", $data['show_options']);
		}

		parent::save($data);

		return true;
	}

	public function buildQuery($overrideLimits = false)
	{
		$table = $this->getTable();
		$tableName = $table->getTableName();
		$tableKey = $table->getKeyName();
		$db = $this->getDbo();

		$query = $db->getQuery(true);

		// Call the behaviors
		$this->modelDispatcher->trigger('onBeforeBuildQuery', array(&$this, &$query));

		$alias = $this->getTableAlias();

		if ($alias)
		{
			$alias = ' AS ' . $db->qn($alias);
		}
		else
		{
			$alias = '';
		}

		$select = $this->getTableAlias() ? $db->qn($this->getTableAlias()) . '.*' : $db->qn($tableName) . '.*';

		$query->select($select)->from($db->qn($tableName) . $alias);

		if (!$overrideLimits)
		{
			$order = $this->getState('filter_order', null, 'cmd');

			if (!in_array($order, array_keys($table->getData())))
			{
				$order = 'ordering';
			}

			if ($alias)
			{
				$order = $db->qn($this->getTableAlias()) . '.' . $order;
			}

			$dir = $this->getState('filter_order_Dir', 'ASC', 'cmd');
			$query->order($order . ' ' . $dir);
		}

		//this is used by parent drop down on question form
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		if($catid){
			$bfsurvey_question_id = JRequest::getVar( 'bfsurvey_question_id', 0, '', 'int' );

			$query->where('bfsurvey_category_id = '.$catid);
			$query->where('parent = 0');
			$query->where('bfsurvey_question_id<>'.(int) $bfsurvey_question_id);
		}

		// Call the behaviors
		$this->modelDispatcher->trigger('onAfterBuildQuery', array(&$this, &$query));

		return $query;
	}

	/**
	 * Method to get a list of questions.
	 * Overridden to cater for parent-child grouping.
	 */
	public function &getItemList($overrideLimits = false, $group = '')
	{
		$items	= parent::getItemList();

		// establish the hierarchy of the questions
		$children = array();
		// first pass - collect children
		foreach ($items as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$mylist = array();
		foreach ($items as $v )
		{
			if($v->parent==0){
				array_push($mylist, $v);

				//now are there any children
				if(isset($children[$v->bfsurvey_question_id])){
					foreach ($children[$v->bfsurvey_question_id] as $c ){
						$c->title = ' -- '.$c->title;
						array_push($mylist, $c);
					}
				}
			}
		}

		//if there are no parent items, just show original list with everything indented
		if(count($mylist)==0 & count($items)>0){
			foreach ($items as $v )
			{
				$v->title = ' -- '.$v->title;
				array_push($mylist, $v);
			}
		}

		return $mylist;
	}
}