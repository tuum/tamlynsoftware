<?php
/**
 *  @package BFSurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 *
 *  This file is required because the content history (version control) assumes we are using JTable
 *  The class name is mentioned in the content_types record
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyTableMyQuestion extends JTable
{
	public function __construct(&$db)
	{
		parent::__construct('#__bfsurvey_questions', 'bfsurvey_question_id', $db);
	}

}