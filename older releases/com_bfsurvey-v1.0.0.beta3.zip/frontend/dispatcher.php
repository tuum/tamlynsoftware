<?php
defined('_JEXEC') or die();

class BFSurveyDispatcher extends FOFDispatcher
{
	static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
	{
		$conf	= JFactory::getConfig();

		$mailfrom 	= $conf->get('config.mailfrom');
		$fromname 	= $conf->get('config.fromname');

		$emailBody = $body;
		$mode = 1;

		$mysendEmailTo = 	explode( ',', $sendEmailTo );
		foreach($mysendEmailTo AS $sendEmailTo)
		{
			JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
		}
	}

	static function getEmailTemplate($title,$category)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfsurvey_emailitems');
		$query->where('enabled = 1 AND title='.$db->quote( $db->escape($title), false ));
		$query->where('bfsurvey_category_id = '.(int)$category);
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	static function getEmailType($id, $contentType, $status, $catid)
	{
		$emailType="";

		//which event is triggering the email?

		//let's get all the email templates for this category
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('title, condition_trigger, condition_field1, condition_criteria1, condition_value1');
		$query->from($db->quoteName('#__bfsurvey_emailitems'));
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->where('enabled');
		$db->setQuery((string)$query);
		$myemailitems = $db->loadObjectList();

		// has status (or any other field) changed since last save?
		// look at history table
		$table1 = JTable::getInstance('Contenthistory');
		$table2 = JTable::getInstance('Contenthistory');

		$query->clear();
		$query->from($db->quoteName('#__ucm_history'));
		$query->select('version_id');
		$query->where('ucm_type_id = '.(int)$contentType);
		$query->where('ucm_item_id = '.(int)$id);
		$query->order('save_date DESC');
		$db->setQuery((string)$query);
		$myids = $db->loadObjectList();

		$id1 = $myids[0]->version_id;
		$id2 = isset($myids[1]->version_id) ? $myids[1]->version_id : $myids[0]->version_id;

		$myresult = array();

		foreach($myemailitems as $i => $emailitem):
		//what is the email trigger?

		if($emailitem->condition_trigger=="0")
		{
			if(count($myids)==1 || count($myids)==0)
			{
				//initial save or content history turned off
				$emailType[$i]=$emailitem->title;
			}
			else
			{
				//not first save as this item has content history
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==1)
		{
			//field changes
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			if($condition_criteria1 == -1 || $condition_value1 == '')
			{
				// only care if this field has changed or not
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so use this email template
						$emailType[$i]=$emailitem->title;
					}
				}
			}
			else
			{
				// we want this field to change, but also have a specific value
				// basically we only want one email triggered for this status, regardless of whether there are multiple changes
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so now check if it has specific value
						if ($condition_criteria1<>"-1")
						{
							foreach (array($table1, $table2) as $mytable)
							{
								$object = new stdClass;
								$object->data = ContenthistoryHelper::prepareData($mytable);
								$object->version_note = $mytable->version_note;
								$object->save_date = $mytable->save_date;
								$myresult[] = $object;
							}

							if($condition_criteria1 == 1)
							{
								if($status == $condition_value1){
									//field is the same, so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 0)
							{
								if($status < $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 2)
							{
								if($status > $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 3)
							{
								if($status <> $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
						}
					}
				}
			}
		}
		else if($emailitem->condition_trigger==2)
		{
			//field has specific value
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			//we only care about the updated value on the form
			if ($table1->load($id1) && $condition_criteria1<>"-1")
			{
				foreach ($table1 as $mytable)
				{
					$object = new stdClass;
					$object->data = ContenthistoryHelper::prepareData($mytable);
					$object->version_note = $mytable->version_note;
					$object->save_date = $mytable->save_date;
					$myresult[] = $object;
				}

				if($condition_criteria1 == 1)
				{
					if($status == $condition_value1){
						//field is the same, so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 0)
				{
					if($status < $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 2)
				{
					if($status > $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 3)
				{
					if($status <> $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
			}
		}
		else
		{
			$emailType[$i]="";
		}
		endforeach;

		return $emailType;
	}

	static function sendEmail($myemail, $table, $catid)
	{
		$id = 'bfsurvey_'.$catid.'result_id';
		$url = '<a href="'.JURI::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&id='. $table->$id.'">'.$table->$id.'</a>';

		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{Name}/', $table->Name , $myemail[0]->description); // insert Name
		$myemail[0]->description=preg_replace('/{Company}/', $table->Company , $myemail[0]->description); // insert Company
		$myemail[0]->description=preg_replace('/{Email}/', $table->Email , $myemail[0]->description); // insert Email
		$myemail[0]->description=preg_replace('/{uid}/', $table->created_by , $myemail[0]->description); // insert uid

		$myemail[0]->subject=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->subject); // insert id
		$myemail[0]->description=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->description); // insert description

		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		//get list of all fields in the database
		foreach($myFields AS $field)
		{
			$fieldname=$field->field_name;
			if(is_array($table->$fieldname)){
				$table->$fieldname = implode(",", $table->$fieldname);
			}
			$myemail[0]->description=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->description);
			$myemail[0]->subject=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->subject);
		}

		$emailSubject = $myemail[0]->subject;
		$body = $myemail[0]->description;
		$sendEmailTo = $myemail[0]->sendTo;

		BFSurveyDispatcher::sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject);
	}
}