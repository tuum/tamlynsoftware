<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

$params = JFactory::getApplication()->getParams();
$slug=$params->get('slug');

//check if user has permission
$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
$statsAccess = BfsurveyModelSurvey::getStatsAccess($slug);

if (!in_array($statsAccess, $accessLevels))
{
	// User trying to view questions that he does not have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_NO_ACCESS_STATS') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfsurvey&view=stats&Itemid=".(int)$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
	$finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFSURVEY_LOG_IN')."</a><br>";
	return;
}

include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
AkeebaStrapper::jQueryUI();

require_once JPATH_ADMINISTRATOR.'/components/com_bfsurvey/views/stats/tmpl/form.php';