<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

//check if user has permission
require_once JPATH_ADMINISTRATOR.'/components/com_bfsurvey/models/questions.php';