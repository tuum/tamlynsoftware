<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

// Load FOF
include_once JPATH_LIBRARIES.'/fof/include.php';
if(!defined('FOF_INCLUDED')) {
	JError::raiseError ('500', 'FOF is not installed');
}

FOFTemplateUtils::addCSS('media://com_bfsurvey/css/frontend.css');

//make sure jQuery loads before our javascript files - dodgy fix for 3.3+
JHtml::_('jquery.framework');
FOFDispatcher::getTmpInstance('com_bfsurvey')->dispatch();