<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();
?>

<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSURVEY_RESULTS_SELECT_CATEGORY'); ?></p>
</div>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="table table-striped" id="emailList">
    <thead>
        <tr>
            <th width="1%" class="nowrap center">
		        <?php echo JText::_( 'COM_BFSURVEY_TITLE_ID' ); ?>
            </th>
            <th class="title">
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_CATEGORY' ); ?>
            </th>
        </tr>
    </thead>

    <?php
    $k = 0;
    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row =& $this->items[$i];
        $link 		= JRoute::_( 'index.php?option=com_bfsurvey&view='.(int)$row->id.'results' );
        $checked 	= JHTML::_('grid.id',   $i, $row->id );
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td class="center nowrap">
                <a href="<?php echo $link; ?>"><?php echo $row->id; ?></a>
            </td>
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<input type="hidden" name="option" value="com_bfsurvey" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

</form>