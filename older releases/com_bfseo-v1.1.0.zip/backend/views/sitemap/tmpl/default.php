<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

jimport( 'joomla.filesystem.file' );

if(!file_exists(JPATH_ROOT. "/sitemap.xml")){
?>
	<div class="alert alert-error">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSEO_SITEMAP_FILE_MISSING'); ?></p>
	</div>

	<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
		<input type="hidden" name="option" value="com_bfseo"/>
		<input type="hidden" name="view" value="sitemap"/>
		<input type="hidden" name="task" value="createsitemap"/>
		<?php echo JHtml::_( 'form.token' ); ?>

		<div class="control-group">
			<?php echo JText::_( 'COM_BFSEO_MENUS_TO_SELECT'); ?>
		</div>

		<?php foreach ($this->menuItems as $menu): ?>
		  <input type="checkbox" name="sitemap_menus[]" value="<?php echo $menu->id; ?>" checked="checked"><?php echo $menu->title; ?> (<?php echo $menu->description; ?>)<br>
		<?php endforeach; ?>

		<div class="form-actions">
			<input type="submit" class="btn btn-warning btn-large" value="<?php echo JText::_('COM_BFSEO_CREATE_SITEMAP') ?>"/>
		</div>
	</form>
<?php
}
else
{
?>
	<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSEO_SITEMAP_FILE_FOUND'); ?></p>
	</div>
<?php

	$contents = JFile::read(JPATH_ROOT. "/sitemap.xml");

?>
	<div class="span12">
		<textarea class="large-text code" rows="8" cols="70" name="sitemapnew" readonly><?php echo $contents; ?></textarea>
	</div>
<?php
	// show preview of sitemap xml file
	if (strpos($contents, 'com_bfseo') !== false){

		$source = file_get_contents(JURI::root()."index.php?option=com_bfseo&view=xmlsitemap&format=raw");
		?>
		<div class="span12">
			<p><b><?php echo JText::_('COM_BFSEO_SITEMAP_FILE_SOURCE'); ?></b></p>
			<textarea class="large-text code" rows="30" cols="70" name="sitemapxml" readonly><?php echo $source; ?></textarea>
		</div>

		<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
			<input type="hidden" name="option" value="com_bfseo"/>
			<input type="hidden" name="view" value="sitemap"/>
			<input type="hidden" name="task" value="deletesitemap"/>

			<div class="control-group">
				<?php echo JText::_( 'COM_BFSEO_DELETE_SITEMAP_INFORMATION'); ?>
			</div>

			<div class="form-actions">
				<input type="submit" class="btn btn-warning btn-large" value="<?php echo JText::_('COM_BFSEO_DELETE_SITEMAP') ?>"/>
			</div>
		</form>

		<?php
	}
}
?>