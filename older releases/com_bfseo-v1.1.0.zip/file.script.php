<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF SEO is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF SEO is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF SEO.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF SEO from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// Load FOF if not already loaded
if (!defined('F0F_INCLUDED'))
{
	$paths = array(
			(defined('JPATH_LIBRARIES') ? JPATH_LIBRARIES : JPATH_ROOT . '/libraries') . '/f0f/include.php',
			__DIR__ . '/fof/include.php',
	);

	foreach ($paths as $filePath)
	{
		if (!defined('F0F_INCLUDED') && file_exists($filePath))
		{
			@include_once $filePath;
		}
	}
}

// Pre-load the installer script class from our own copy of FOF
if (!class_exists('F0FUtilsInstallscript', false))
{
	@include_once __DIR__ . '/fof/utils/installscript/installscript.php';
}

// Pre-load the database schema installer class from our own copy of FOF
if (!class_exists('F0FDatabaseInstaller', false))
{
	@include_once __DIR__ . '/fof/database/installer.php';
}

// Pre-load the update utility class from our own copy of FOF
if (!class_exists('F0FUtilsUpdate', false))
{
	@include_once __DIR__ . '/fof/utils/update/update.php';
}

class Com_BfseoInstallerScript extends F0FUtilsInstallscript
{
	/**
	 * The title of the component (printed on installation and uninstallation messages)
	 *
	 * @var string
	 */
	protected $componentTitle = 'BF SEO';

	/**
	 * The component's name
	 *
	 * @var   string
	 */
	protected $componentName = 'com_bfseo';

	/**
	 * Runs after install, update or discover_update
	 * @param string $type install, update or discover_update
	 * @param JInstaller $parent
	 */
	function postflight($type, $parent)
	{
		parent::postflight($type, $parent);

		jimport( 'joomla.filesystem.file' );

		// define the following parameters only if it is an original install
        if ( $type == 'install' ) {
        
			$names = array(
				'minTitleLength',
				'maxTitleLength',
				'minDescLength',
				'maxDescLength',
				'minWarningText',
				'maxWarningText',
				'skipWords',
				'skipTags',
				'metaKeywordLocation',
			);
			$params = array();
			$config_xml = JPATH_ADMINISTRATOR.'/components/com_bfseo/config.xml';
			if (file_exists($config_xml)) {			
				$config = file_get_contents($config_xml);
				$p = xml_parser_create();
				xml_parse_into_struct($p, $config, $vals, $index);
				xml_parser_free($p);

				$fields = $index['FIELD'];
				foreach ($fields as $k => $v) {
					$field = $vals[$v];
					if (isset($field['attributes'])) {
						$attribs = $field['attributes'];
						if (in_array($attribs['NAME'], $names)) {
							$params[$attribs['NAME']] = $attribs['DEFAULT'];
						}
					}
				}
			}
			$this->setParams( $params );
        }

		if(!file_exists(JPATH_SITE . "/images/com_bfseo/")){
			JFolder::create(JPATH_SITE. "/images/com_bfseo/");
		};
	}

	function setParams($param_array) {
            if ( count($param_array) > 0 ) {
                    // read the existing component value(s)
                    $db = JFactory::getDbo();
                    $db->setQuery('SELECT params FROM #__extensions WHERE name = "com_bfseo"');
                    $params = json_decode( $db->loadResult(), true );
                    // add the new variable(s) to the existing one(s)
                    foreach ( $param_array as $name => $value ) {
                            $params[ (string) $name ] = (string) $value;
                    }
                    // store the combined new and existing values back as a JSON string
                    $paramsString = json_encode( $params );
                    $db->setQuery('UPDATE #__extensions SET params = ' .
                            $db->quote( $paramsString ) .
                            ' WHERE name = "com_bfseo"' );
                            $db->query();
            }
    }

	/**
	 * Renders the post-installation message
	 */
	private function _renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent)
	{
		?>
		<h2>Welcome to BF SEO!</h2>

		<?php
		parent::renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent);
		?>

		<?php
	}
}