<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

class BFSurveyDispatcher extends F0FDispatcher
{
	public function onBeforeDispatch() {
		$result = parent::onBeforeDispatch();

		if($result) {
			// Load Akeeba Strapper
			include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
			AkeebaStrapper::bootstrap();
			AkeebaStrapper::jQueryUI();
			AkeebaStrapper::addCSSfile('media://com_bfsurvey/css/backend.css');
		}

		return $result;
	}

	public function dispatch() {
		// Handle Live Update requests
		if(!class_exists('LiveUpdate')) {
			require_once JPATH_COMPONENT_ADMINISTRATOR.'/liveupdate/liveupdate.php';
			//if(JRequest::getCmd('view','') == 'liveupdate') {
			if(($this->input->get('view','', 'cmd') == 'liveupdate')) {
				LiveUpdate::handleRequest();
				return true;
			}
		}
		parent::dispatch();
	}

	static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
	{
		$conf	= JFactory::getConfig();

		if($mailfrom == '')
		{
			$mailfrom 	= $conf->get('mailfrom', $conf->get('config.mailfrom'));
		}

		if($fromname == '')
		{
			$fromname 	= $conf->get('fromname', $conf->get('config.fromname'));
		}

		$emailBody = $body;
		$mode = 1;

		$mysendEmailTo = 	explode( ',', $sendEmailTo );
		foreach($mysendEmailTo AS $sendEmailTo)
		{
			//JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
			$cc = null;
			$bcc = null;

			if(empty($attachments))
			{
				//no attachment
				$attachments = null;
			}

			JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode, $cc, $bcc, $attachments, $mailfrom, $fromname);
		}
	}

	static function getEmailTemplate($title,$category)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfsurvey_emailitems');
		$query->where('enabled = 1 AND title='.$db->quote( $db->escape($title), false ));
		$query->where('bfsurvey_category_id = '.(int)$category);
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	static function getEmailType($id, $contentType, $status, $catid)
	{
		$emailType="";

		//which event is triggering the email?

		//let's get all the email templates for this category
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('title, condition_trigger, condition_field1, condition_criteria1, condition_value1');
		$query->from($db->quoteName('#__bfsurvey_emailitems'));
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->where('enabled');
		$db->setQuery((string)$query);
		$myemailitems = $db->loadObjectList();

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			// has status (or any other field) changed since last save?
			// look at history table
			$table1 = JTable::getInstance('Contenthistory');
			$table2 = JTable::getInstance('Contenthistory');

			$query->clear();
			$query->from($db->quoteName('#__ucm_history'));
			$query->select('version_id');
			$query->where('ucm_type_id = '.(int)$contentType);
			$query->where('ucm_item_id = '.(int)$id);
			$query->order('save_date DESC');
			$db->setQuery((string)$query);
			$myids = $db->loadObjectList();

			$id1 = $myids[0]->version_id;
			$id2 = isset($myids[1]->version_id) ? $myids[1]->version_id : $myids[0]->version_id;

			$myresult = array();
		}

		foreach($myemailitems as $i => $emailitem):
		//what is the email trigger?

		if($emailitem->condition_trigger=="0")
		{
			if(count($myids)==1)
			{
				//initial save
				$emailType[$i]=$emailitem->title;
			}
			else
			{
				//not first save as this item has content history
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==1)
		{
			//content history feature was added in Joomla 3.2
			if (version_compare(JVERSION, '3.1.6', 'gt'))
			{
				//field changes
				$condition_field1 = $emailitem->condition_field1;
				$condition_criteria1 = $emailitem->condition_criteria1;
				$condition_value1 = $emailitem->condition_value1;

				if($condition_criteria1 == -1 || $condition_value1 == '')
				{
					// only care if this field has changed or not
					if ($table1->load($id1) && $table2->load($id2))
					{
						foreach (array($table1, $table2) as $mytable)
						{
							$object = new stdClass;
							$object->data = ContenthistoryHelper::prepareData($mytable);
							$object->version_note = $mytable->version_note;
							$object->save_date = $mytable->save_date;
							$myresult[] = $object;
						}

						if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
							//field is the same, so this email is not triggered
							$emailType[$i]="";
						}else{
							//field has changed, so use this email template
							$emailType[$i]=$emailitem->title;
						}
					}
				}
				else
				{
					// we want this field to change, but also have a specific value
					// basically we only want one email triggered for this status, regardless of whether there are multiple changes
					if ($table1->load($id1) && $table2->load($id2))
					{
						foreach (array($table1, $table2) as $mytable)
						{
							$object = new stdClass;
							$object->data = ContenthistoryHelper::prepareData($mytable);
							$object->version_note = $mytable->version_note;
							$object->save_date = $mytable->save_date;
							$myresult[] = $object;
						}

						if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
							//field is the same, so this email is not triggered
							$emailType[$i]="";
						}else{
							//field has changed, so now check if it has specific value
							if ($condition_criteria1<>"-1")
							{
								foreach (array($table1, $table2) as $mytable)
								{
									$object = new stdClass;
									$object->data = ContenthistoryHelper::prepareData($mytable);
									$object->version_note = $mytable->version_note;
									$object->save_date = $mytable->save_date;
									$myresult[] = $object;
								}

								if($condition_criteria1 == 1)
								{
									if($status == $condition_value1){
										//field is the same, so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 0)
								{
									if($status < $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 2)
								{
									if($status > $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
								else if($condition_criteria1 == 3)
								{
									if($status <> $condition_value1){
										//this matches so this email is triggered
										$emailType[$i]=$emailitem->title;
									}
									else
									{
										//don't use this template
										$emailType[$i]="";
									}
								}
							}
						}
					}
				}
			}else{
				//content history not supported, don't send any email
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==2)
		{
			//field has specific value
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			//we only care about the updated value on the form
			if ($table1->load($id1) && $condition_criteria1<>"-1")
			{
				foreach ($table1 as $mytable)
				{
					$object = new stdClass;
					$object->data = ContenthistoryHelper::prepareData($mytable);
					$object->version_note = $mytable->version_note;
					$object->save_date = $mytable->save_date;
					$myresult[] = $object;
				}

				if($condition_criteria1 == 1)
				{
					if($status == $condition_value1){
						//field is the same, so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 0)
				{
					if($status < $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 2)
				{
					if($status > $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 3)
				{
					if($status <> $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
			}
		}
		else
		{
			$emailType[$i]="";
		}
		endforeach;

		return $emailType;
	}

	static function sendEmail($myemail, $table, $catid)
	{
		$menuId = BFSurveyDispatcher::getMenuId($catid);

		$id = 'bfsurvey_'.$catid.'result_id';
		if(isset($table)){
			$url = '<a href="'.JURI::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&id='.$table->$id.'&Itemid='.$menuId.'">'.$table->$id.'</a>';
		}else{
			$url = '<a href="'.JURI::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form'.'&Itemid='.$menuId.'">'.$myemail[0]->title.'</a>';
		}

		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		if(isset($table)){
			$myemail[0]->description=preg_replace('/{Name}/', $table->Name , $myemail[0]->description); // insert Name
			$myemail[0]->description=preg_replace('/{Company}/', $table->Company , $myemail[0]->description); // insert Company
			$myemail[0]->description=preg_replace('/{Email}/', $table->Email , $myemail[0]->description); // insert Email
			$myemail[0]->description=preg_replace('/{uid}/', $table->created_by , $myemail[0]->description); // insert uid

			$myemail[0]->subject=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->subject); // insert id
			$myemail[0]->description=preg_replace('/{bfsurvey_'.$catid.'result_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->description); // insert description

			$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
			$myemail[0]->subject=preg_replace('/{Name}/', $table->Name , $myemail[0]->subject); // insert Name
			$myemail[0]->subject=preg_replace('/{Company}/', $table->Company , $myemail[0]->subject); // insert Company
			$myemail[0]->subject=preg_replace('/{Email}/', $table->Email , $myemail[0]->subject); // insert Email
			$myemail[0]->subject=preg_replace('/{uid}/', $table->created_by , $myemail[0]->subject); // insert uid
		}

		if (strpos($myemail[0]->description,'{allfields}') !== false)
		{
			$fieldChanges = BFSurveyDispatcher::getAllFieldsData($table->$id, $catid);
			$myemail[0]->description=preg_replace('/{allfields}/', $fieldChanges , $myemail[0]->description);
		}

		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		if(isset($table))
		{
			//get list of all fields in the database
			foreach($myFields AS $field)
			{
				$fieldname=$field->field_name;
				if(is_array($table->$fieldname)){
					$table->$fieldname = implode(",", $table->$fieldname);
				}
				$myemail[0]->description=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->description);
				$myemail[0]->subject=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->subject);
			}
		}

		$emailSubject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		//is there a send to group set?
		if($myemail[0]->sendToGroup)
		{
			$sendToGroup = BFSurveyDispatcher::getSendToGroup($myemail[0]->sendToGroup);

			foreach($sendToGroup as $sendEmailTo)
			{
				$myurl = '<a href="'.JURI::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&uuid='.$sendEmailTo->uuid.'&Itemid='.$menuId.'">'.$myemail[0]->title.'</a>';
				$mybody=preg_replace('/{uurl}/', $myurl , $body); // insert unique user url (uurl)

				BFSurveyDispatcher::sendHTMLNotificationEmail($mybody, $sendEmailTo->email, $emailSubject);
			}
		}

		if($myemail[0]->sendTo != '')
		{
			$sendEmailTo = $myemail[0]->sendTo;

			$mysendEmailTo = 	explode( ',', $sendEmailTo );
			foreach($mysendEmailTo AS $sendEmailTo)
			{
				$mybody = $body;

				$uuid = BFSurveyDispatcher::getUuid($sendEmailTo);
				if($uuid != '' && $uuid != null)
				{
					$myurl = '<a href="'.JURI::root().'index.php?option=com_bfsurvey&view='.$catid.'result&layout=form&uuid='.$uuid.'&Itemid='.$menuId.'">'.$myemail[0]->title.'</a>';
					$mybody=preg_replace('/{uurl}/', $myurl , $body); // insert unique user url (uurl)
				}

				BFSurveyDispatcher::sendHTMLNotificationEmail($mybody, $sendEmailTo, $emailSubject);
			}
		}
	}

	static function getAllFieldsData($id, $catid)
	{
		$fieldData = '';

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//need to find out id in #__content_types table
		$query->select('*');
		$query->from('#__bfsurvey_'.$catid.'results');
		$query->where('bfsurvey_'.$catid.'result_id = '.(int)$id);
		$db->setQuery((string)$query);
		$myresult=$db->loadObjectList();

		//get all field names
		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('field_name');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		//loop through all the fields
		foreach($myFields as $field)
		{
			$fieldname=$field->field_name;
			$flag=0;

			if(isset($myresult[0]->$fieldname))
			{
				if($myresult[0]->$fieldname != "" && $myresult[0]->$fieldname != NULL){
					if(is_array($myresult[0]->$fieldname)){
						$value = implode(",", $myresult[0]->$fieldname);
					}else{
						$value = $myresult[0]->$fieldname;
					}
					$question = BFSurveyDispatcher::getQuestion($fieldname, $catid);
					$fieldData.=$question.': '.$value."<br>";
				}
			}
		}

		return $fieldData;
	}

	static function getQuestion($fieldname, $catid)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//need to find out id in #__content_types table
		$query->select('title');
		$query->from('#__bfsurvey_questions');
		$query->where('field_name = '.$db->quote($fieldname));
		$query->where('bfsurvey_category_id = '.$db->quote($catid));
		$db->setQuery((string)$query);
		$question=$db->loadResult();

		return $question;
	}

	static function getSendToGroup($sendToGroup)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('a.email, md5(concat('.$db->quoteName('a.id').','.$db->quoteName('a.username').','.$db->quoteName('a.password').')) AS uuid');
		$query->from($db->quoteName('#__user_usergroup_map') . ' AS map');
		$query->join('LEFT', $db->quoteName('#__users').' AS a ON map.user_id = a.id');
		$query->where('map.group_id = '.$sendToGroup);

		$db->setQuery((string)$query);
		$sendToGroup = $db->loadObjectList();

		return $sendToGroup;
	}

	static function getUuid($sendEmailTo)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('md5(concat('.$db->quoteName('a.id').','.$db->quoteName('a.username').','.$db->quoteName('a.password').')) AS uuid');
		$query->from($db->quoteName('#__users').' AS a');
		$query->where('a.email = '.$db->quote(trim($db->escape($sendEmailTo))));

		$db->setQuery((string)$query);
		$uuid = $db->loadResult();

		return $uuid;
	}

	public static function getMenuId($catid)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, params');
		$query->from('#__menu');
		$query->where('link = "index.php?option=com_bfsurvey&view=survey"');
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$menuId = 0;
		foreach ($rows as $row) {
			$json = json_decode($row->params);
			if ($catid == $json->slug) {
				$menuId = $row->id;
				break;
			}
		}
		return $menuId;
	}

}