<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelCustom404 extends F0FModel
{
	public function getItems()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->clear();
		$query->select('*');
		$query->from('#__bfseo_404s');
		$db->setQuery($query);
		$db->query();
		$rows = $db->loadObjectList();

		return $rows;
	}

	/*
	 * This funciton checks to see if the ordering of bfseoredirect is after plg_system_redirect. If not, it automatically fixes.
	 *
	 * @return boolean
	 */
	static function checkOrdering()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('ordering');
		$query->from('#__extensions');
		$query->where('name='.$db->q('plg_system_redirect'));
		$query->where('type='.$db->q('plugin'));
		$query->where('element='.$db->q('redirect'));
		$db->setQuery($query);
		$db->query();
		$db->setQuery((string)$query);
		$redirectOrdering=$db->loadResult();

		$query->clear();
		$query->select('ordering');
		$query->from('#__extensions');
		$query->where('type='.$db->q('plugin'));
		$query->where('element='.$db->q('bfseoredirect'));
		$query->where('folder='.$db->q('system'));
		$db->setQuery($query);
		$db->query();
		$db->setQuery((string)$query);
		$bfseoOrdering=$db->loadResult();

		if($redirectOrdering > $bfseoOrdering)
		{
			$query->clear();
			$query->select('max(ordering)');
			$query->from('#__extensions');
			$db->setQuery($query);
			$db->query();
			$db->setQuery((string)$query);
			$maxOrdering=$db->loadResult();

			$maxOrdering++;

			$query->clear();
			$query->update('#__extensions');
			$query->set('ordering='.$maxOrdering);
			$query->where('type='.$db->q('plugin'));
			$query->where('element='.$db->q('bfseoredirect'));
			$query->where('folder='.$db->q('system'));
			$db->setQuery($query);
			if(!$db->query()){
				return false;
			}

			return true;
		}

		return false;
	}
}