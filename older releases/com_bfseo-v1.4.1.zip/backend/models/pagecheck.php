<?php
/**
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelPagecheck extends F0FModel
{
	public $pageTitle = '';

	public function check($url)
	{
		$this->params = JComponentHelper::getParams('com_bfseo');

		$html = file_get_contents($url);

		if (empty($html)) {
			return false;
		}

		libxml_use_internal_errors(true);

		$dom = new DOMDocument();
		$dom->loadHTML($html);
		$xpath = new DOMXpath($dom);

		$results['url'] = $url;
		$this->url = $url;

		$results[] = $this->checkPageTitle($xpath);
		$results[] = $this->checkMetaDescription($xpath);
		$results[] = $this->googlePreview();
		$results[] = $this->checkHeading($dom, 'H1');
		$results[] = $this->checkHeading($dom, 'H2');
		//$results[] = $this->checkMetaRobots($xpath);
		$results[] = $this->checkImg($xpath, $dom);
		//$results[] = $this->checkUnderscores($dom);
		$results[] = $this->checkNestedTables($xpath);
		$results['pagetitle'] = $this->pageTitle;

		return $results;
	}


	private function checkPageTitle($xpath)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_TITLE_TAG');
		$title = $xpath->query("//title");
		if ($title->length) {
			$text = $title->item(0)->textContent;
			$this->pageTitle = htmlspecialchars($text);
			$result['text'] = htmlspecialchars($text);
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_PAGE_TITLE_MSG1', strlen($text), $this->params->get('maxTitleLength'));
			$result['status'] = true;
		} else {
			$result['msg'] = 'COM_BFSEO_CHECK_PAGE_TITLE_MSG1';
			$result['status'] = false;
		}
		return $result;
	}

	function checkMetaDescription($xpath)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_META_DESCRIPTION');
		$metadesc = $xpath->query("//meta[@name='description']");
		if ($metadesc->length) {
			$result['text'] = htmlspecialchars($metadesc->item(0)->getAttribute('content'));
			$this->metaDescription  = $result['text'];
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_META_DESC_MSG1', strlen($result['text']), $this->params->get('maxDescLength'));
			$result['status'] = true;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_META_DESC_MSG2');
			$result['status'] = false;
		}
		return $result;
	}


	protected function checkHeading($dom, $type)
	{
		$result['title'] = JText::sprintf('COM_BFSEO_TITLE_META_HEADING', $type);
		$h = $dom->getElementsByTagName(strtolower($type));
		$texts = array();
		if ($h->length) {
			foreach ($h as $tag) {
				$texts[] = htmlspecialchars($tag->textContent);
			}
			$result['text'] = $texts;
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_HEADINGS_MSG1', $type);
			$result['status'] = true;
			if($type=='H1'){
				if(isset($texts[0]) && $texts[0] != ''){
					$this->pageTitle = htmlspecialchars($texts[0]);
				}
			}
		} else {
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_HEADINGS_MSG2', $type);
			$result['status'] = false;
		}

		return $result;
	}

	protected function checkMetaRobots($xpath)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_META_ROBOTS');
		$meta = $xpath->query("//meta[@name='robots']");
		if ($meta->length) {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_META_ROBOTS_MSG1');
			$result['status'] = true;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_META_ROBOTS_MSG2');
			$result['status'] = false;
		}
		return $result;
	}


	protected function checkImg($xpath, $dom)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_IMAGES');
		$imgs = $xpath->query("//img");
		$n = $imgs->length;
		$e = 0;
		if ($n) {
			$text = null;
			foreach ($imgs as $img) {
				$alt = $img->getAttribute('alt');
				if (empty($alt)) {
					$text[] = htmlspecialchars($dom->saveHTML($img));
					$e++;
				};
			}
			$result['text'] = $text;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_META_IMG_MSG1');
		}

		if ($e) {
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_META_IMG_MSG2', $n, $e);
			$result['status'] = false;
		} else if ($n > 0) {
			$result['msg'] = JText::sprintf('COM_BFSEO_CHECK_META_IMG_MSG3', $n);
			$result['status'] = true;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_META_IMG_MSG4');
			$result['status'] = false;
		}
		return $result;
	}

	protected function checkUnderscores($dom)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_META_UNDERSCORES');
		$a = $dom->getElementsByTagName('a');
		$n = 0;
		$text = array();
		foreach ($a as $anchor) {
			$href = $anchor->getAttribute('href');
			if (strpos($href, '_') !== false && strpos($href, 'http', 0) === false) {
				$n++;
				$text[] = htmlspecialchars($href);
			}
		}
		$result['text'] = $text;

		if ($n) {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_UNDERSCORES_MSG2');
			$result['status'] = false;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_UNDERSCORES_MSG1');
			$result['status'] = true;
		}
		return $result;
	}

	protected function checkNestedTables($xpath)
	{
		$result['title'] = JText::_('COM_BFSEO_TITLE_NESTED_TABLES');
		$table = $xpath->query('//table//table');
		if ($table->length) {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_NESTED_TABLES_MSG2');
			$result['status'] = false;
		} else {
			$result['msg'] = JText::_('COM_BFSEO_CHECK_NESTED_TABLES_MSG1');
			$result['status'] = true;
		}
		return $result;

	}

	protected function googlePreview()
	{
		$result['title'] = 'Google Preview';

		$title = $this->truncateTitle($this->pageTitle, 52);
		$desc  = $this->truncateTitle($this->metaDescription, 160);

		$url = $this->url;
		$url = preg_replace('#^https?://#', '', $url);

		$title = htmlspecialchars($title);
		$desc  = htmlspecialchars($desc);
		$url   = htmlspecialchars($url);

		$html = "<div class='google_preview'>
				 <p id='title'>$title</p>
				 <p id='url'>$url</p>
				 <p>$desc</p>
				 </div>";

		$result['msg'] = $html;
		$result['status'] = true;
		return $result;
	}

	protected function truncateTitle($s, $n)
	{
		if (strlen($s) > $n) {
			$s = explode( "\n", wordwrap($s, $n));
			$s = $s[0].' ...';
		}
		return $s;
	}

}


