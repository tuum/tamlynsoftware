<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

jimport( 'joomla.filesystem.file' );

if(!file_exists(JPATH_ROOT. "/robots.txt")){
	echo JText::_('COM_BFSEO_ROBOTS_FILE_MISSING');
?>
	<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
		<input type="hidden" name="option" value="com_bfseo"/>
		<input type="hidden" name="view" value="robots"/>
		<input type="hidden" name="task" value="createrobots"/>

		<?php echo JHtml::_('form.token'); ?>

		<div class="form-actions">
			<input type="submit" class="btn btn-warning btn-large" value="<?php echo JText::_('COM_BFSEO_CREATE_ROBOTS') ?>"/>
		</div>
	</form>
<?php
}
else
{
?>
	<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSEO_ROBOTS_FILE_FOUND'); ?></p>
	</div>
<?php

	$contents = JFile::read(JPATH_ROOT. "/robots.txt");

	$j33CheckImages = 0;
	if(strrpos($contents,'Disallow: /images/')){
		if(!strrpos($contents,'#Disallow: /images/') && !strrpos($contents,'# Disallow: /images/')){
			$j33CheckImages = 1;
		}
	}

	$j33CheckMedia = 0;
	if(strrpos($contents,'Disallow: /media/')){
		if(!strrpos($contents,'#Disallow: /media/') && !strrpos($contents,'# Disallow: /media/')){
			$j33CheckMedia = 1;
		}
	}

	$j33CheckTemplates = 0;
	if(strrpos($contents,'Disallow: /templates/')){
		if(!strrpos($contents,'#Disallow: /templates/') && !strrpos($contents,'# Disallow: /templates/')){
			$j33CheckTemplates = 1;
		}
	}
?>

	<?php if($j33CheckImages){ ?>
		<div class="alert alert-warning">
		<a class="close" data-dismiss="alert" href="#">×</a>
		<p><?php echo JText::_('COM_BFSEO_ROBOTS_JOOMLA33_CHANGES_IMAGES'); ?></p>
		</div>
	<?php } ?>

	<?php if($j33CheckMedia){ ?>
		<div class="alert alert-warning">
		<a class="close" data-dismiss="alert" href="#">×</a>
		<p><?php echo JText::_('COM_BFSEO_ROBOTS_JOOMLA33_CHANGES_MEDIA'); ?></p>
		</div>
	<?php } ?>

	<?php if($j33CheckTemplates){ ?>
		<div class="alert alert-warning">
		<a class="close" data-dismiss="alert" href="#">×</a>
		<p><?php echo JText::_('COM_BFSEO_ROBOTS_JOOMLA33_CHANGES_TEMPLATES'); ?></p>
		</div>
	<?php } ?>

	<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">

	<div class="form-actions update-button">
	<input type="submit" class="btn btn-success btn-large" value="<?php echo JText::_('COM_BFSEO_UPDATE_ROBOTS') ?>"/>
	</div>

	<input type="hidden" name="option" value="com_bfseo"/>
	<input type="hidden" name="view" value="robots"/>
	<input type="hidden" name="task" value="updaterobots"/>
	<?php echo JHtml::_( 'form.token' ); ?>

	<p><b><?php echo JText::_('COM_BFSEO_ROBOTS_MSG1') ?></b></p>

	<textarea class="large-text code" rows="30" cols="70" name="robotsnew"><?php echo $contents; ?></textarea>

	</form>
<?php
}
?>