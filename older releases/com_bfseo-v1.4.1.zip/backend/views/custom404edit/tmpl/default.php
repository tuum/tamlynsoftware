<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');
JHtml::_('behavior.modal');

if (version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

$model = $this->getModel();

$input = JFactory::getApplication()->input;

$id = $input->get('id');

$page = array();
if ($id) {
	$page = $model->getPage($id);
}

$base = JUri::base();

$title = isset($page->title) ? $page->title : '';
$lang  = isset($page->lang)  ? $page->lang  : '';
$html  = isset($page->html)  ? $page->html  : '';

$htaccess = sprintf(JText::_('COM_BFSEO_HTACCESS_FILE_MISSING_CLICK'), JUri::base() . 'index.php?option=com_bfseo&view=htaccess');

$custom404 = JComponentHelper::getParams('com_bfseo')->get('custom404', false);
$custom404Msg = sprintf(JText::_('COM_BFSEO_TITLE_PAGE_404_MSG'), JUri::base() . 'index.php?option=com_config&view=component&component=com_bfseo');

$conf = JFactory::getConfig();
$sef = (bool)$conf->get('sef');
$sefMsg = sprintf(JText::_('COM_BFSEO_TITLE_SEF_DISABLED'), JUri::base() . 'index.php?option=com_config');

$langTag = JFactory::getLanguage()->getTag();

?>

<div class="row-fluid" xmlns="http://www.w3.org/1999/html">

	<div class="span7 well">

		<?php if (!file_exists(JPATH_ROOT . '/.htaccess')): ?>
			<p class='alert alert-warning'>
				<?php echo $htaccess ?>
			</p>
		<?php endif ?>

		<?php if (!$custom404): ?>
			<p class='alert alert-warning'>
				<?php echo $custom404Msg ?>
			</p>
		<?php endif ?>

		<?php if (!$sef): ?>
			<p class='alert alert-warning'>
				<?php echo $sefMsg ?>
			</p>
		<?php endif ?>

		<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">

			<div class='control-group'>
				<div>Title <br/><input type="text" name="title" value="<?php echo $title ?>"></div>
				<br/>

				<div>Language <br/ >
				<select name="lang">
				<?php foreach (JLanguage::getKnownLanguages() as $lang): ?>
					<option value='<?php echo $lang['tag'] ?>' <?php if ($lang['tag'] == $langTag) echo 'selected' 	 ?>><?php echo $lang['tag'] ?></option>
				<?php endforeach ?>
				</select>
				</div>
				<br/>

				<div>
					<p><?php echo JText::_('COM_BFSEO_CUSTOM_TAG_MESSAGE') ?></p>
					<ul>
						<li><b>{siteurl}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_SITEURL') ?></li>
						<li><b>{sitename}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_SITENAME') ?></li>
						<li><b>{sitemail}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_SITEMAIL') ?></li>
						<li><b>{fromname}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_FROMNAME') ?></li>
						<li><b>{errorcode}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_ERRORCODE') ?></li>
						<li><b>{errormessage}</b> <?php echo JText::_('COM_BFSEO_CUSTOM_TAG_ERRORMESSAGE') ?></li>
					</ul>
				</div>
				<div><textarea class="large-text code" rows="20" cols="70" name="html"><?php echo $html; ?></textarea>
				</div>
			</div>

			<div>
				<input type="hidden" name="option" value="com_bfseo"/>
				<input type="hidden" name="id" value="<?php echo $id ?>"/>
				<input type="hidden" name="task" value="custom404edit.save"/>
				<?php echo JHtml::_('form.token'); ?>
			</div>
		</form>
	</div>
</div>

</div>
