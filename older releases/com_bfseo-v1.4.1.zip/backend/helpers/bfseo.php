<?php
/**
 *  @package BF SEO
*  @copyright Copyright (c)2016 Tamlyn Software
*  @license GNU General Public License version 2, or later
*/

// Protect from unauthorized access
defined('_JEXEC') or die();

jimport('joomla.html.toolbar');

class bfseoHelper
{

	static public function createDropDown($selected)
	{
		$views = array(
			JHTML::_('select.option', 'metatagarts', JText::_('COM_BFSEO_TITLE_DROPDOWN_ARTICLE')),
			JHTML::_('select.option', 'metatagcats', JText::_('COM_BFSEO_TITLE_DROPDOWN_CATEGORY')),
			JHTML::_('select.option', 'metatags', JText::_('COM_BFSEO_TITLE_DROPDOWN_MENU')),			
		);

		if (bfseoHelper::isK2installed()) {		
			$views[] = JHTML::_('select.option', 'k2metaarts', JText::_('COM_BFSEO_TITLE_DROPDOWN_K2_ARTICLE'));
			$views[] = JHTML::_('select.option', 'k2metacats', JText::_('COM_BFSEO_TITLE_DROPDOWN_K2_CATEGORY'));
		}
				
		return JHTML::_('select.genericlist', $views, 'tagType', 'onchange="Joomla.submitform(\'metatags.selectTagType\')"', 'value', 'text', $selected);
	}
	
	static public function isK2installed()
	{	
		// prevent warning from showing
		return file_exists(JPATH_ADMINISTRATOR.'/components/com_k2/k2.php') && JComponentHelper::isEnabled('com_k2', true);
	}

}
