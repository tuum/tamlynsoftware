 ALTER TABLE `#__bfsurvey_categories` ADD `theme` varchar(50) NOT NULL;
 ALTER TABLE `#__bfsurvey_questions` ADD `terminate_options` text;
 ALTER TABLE `#__bfsurvey_questions` ADD `terminate_url` varchar(255) NOT NULL;