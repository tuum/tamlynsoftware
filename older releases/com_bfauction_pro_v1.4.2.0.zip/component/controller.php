<?php
/**
 * $Id: controller.php 23 2012-04-04 11:59:04Z tuum $
 * bfauction_pro default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * bfauction_pro Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFAUCTIONPRO_OPERATION_CANCELLED' );

		$Itemid = JRequest::getVar('Itemid');
		$this->setRedirect( 'index.php?option=com_bfauction_pro&view=myitems&Itemid='.(int)$Itemid, $msg );
	}

	function bid()
	{
		JRequest::setVar( 'view', 'bid' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function bidHistory()
	{
		JRequest::setVar( 'view', 'bidhistory' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function listItems()
	{
		JRequest::setVar( 'view', 'bfauction_pro' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/* bid now view to confirm that person wants to commit to buying item	 */
	function bidnow(){
		JRequest::setVar( 'view', 'bidnow' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function mybid()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		global $mainframe;
		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'bid', 0, '', 'float' );
		$bidIncrement 	= JRequest::getVar( 'bidIncrement', 1, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );

    	$Itemid = JRequest::getVar('Itemid');
		//$menu =& JMenu::getInstance('site');
		//$config = & $menu->getParams( $Itemid );
		$params = &$mainframe->getParams();

		$allowEmail = $params->get( 'allowEmail' );
		$bfcurrency = $params->get( 'bfcurrency' );
		if($bfcurrency == ""){
			$bfcurrency = "$";
		}
		$dst_fix = $params->get( 'dst' );
		$reverseAuction = $params->get( 'reverseAuction' );
		$increaseEndTime = $params->get( 'increaseEndTime' );
		$increaseEndTimeLastMinutes = $params->get( 'increaseEndTimeLastMinutes' );
		$increaseEndTimeAmount = $params->get( 'increaseEndTimeAmount' );
		$allowAutoBidding = $params->get( 'allowAutoBidding' );

		if ($itemId==0 | $bid < $bidIncrement)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_PROCESSING_BID') );
			$msg="";
			$this->setRedirect( 'index.php?option=com_bfauction_pro&task=listItem', $msg );
		}else {
			$user =& JFactory::getUser();
			$userusername = $user->username;
			$userid = $user->id;
			$useremail = $user->email;

			// is dst on on that particular date ?
			$now =& JFactory::getDate();
			$date=$now->toFormat();
  			if (is_numeric( $date))
  			{
				$ts = $date;
  			} else {
    			$ts = strtotime( $date . ' UTC');
  			}
  			$dst = date( 'I', $ts);

  			$now =& JFactory::getDate();
  			if($dst_fix){
				$now->setOffset($mainframe->getCfg('offset')+$dst);
  			}else{
  				$now->setOffset($mainframe->getCfg('offset'));
  			}
			$currentDate=$now->toFormat();

			$db			=& JFactory::getDBO();

			$query = 'SELECT *'
	  			. ' FROM #__bfauction_pro AS a'
	  			. ' WHERE a.published = 1 and a.id='.(int)$itemId.''
	  			. ' ORDER BY a.title'
	  			;

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$myresult=&$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( 'index.php?option=com_bfauction_pro&task=listItems&Itemid='.$Itemid, $msg );
			} else {
				//-------------------------------------
				$maxbid=0;
				if($allowAutoBidding){
					//are there any automatic bids for this item?
					$db			=& JFactory::getDBO();

					$query = 'SELECT a.username, a.uid, a.email, a.bid, a.maxbid, a.itemid, a.id'
			  			. ' FROM #__bfbid_pro AS a'
			  			. ' WHERE a.itemid='.(int)$itemId
						. ' AND a.maxbid>0'
			  			. ' ORDER BY a.id DESC'
			  			;
					$db->setQuery( $query );
					$autobidrows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						echo $db->stderr();
						return false;
					}
					if($autobidrows){
						$maxbid = $autobidrows[0]->maxbid;
					}
				}

				//-------------------------------------

				if (($bid >= ($myresult->currentBid + ((float)$bidIncrement)) & $reverseAuction==0) | ($reverseAuction & $bid <= ($myresult->currentBid - ((float)$bidIncrement))) )
				{
					if($allowAutoBidding){
						//need to check that current bid is greater than maxbid of previous bidder
						//this code doesn't support reverse auction
						if($bid >= ($maxbid + (float)$bidIncrement) ){
							//new bidder is now winning. Need to set bid to current bid plus increment, and set the max bid
							$maxbid = $bid;
							if($maxbid >= ($myresult->currentBid + (float)$bidIncrement) ){
								$bid = $myresult->currentBid + (float)$bidIncrement;

								//now check that bid is higher than previous maxbid
								if($bid > $autobidrows[0]->maxbid){
									//all good
								}else{
									$bid = $autobidrows[0]->maxbid + (float)$bidIncrement;
									if($bid > $maxbid){
										JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_LOWER') );
										$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
									}
								}
							}else{
								JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_LOWER') );
								$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
							}

							//now proceed as per normal
							$msg = JText::_( 'COM_BFAUCTIONPRO_BID_CONFIRMED' );
						}else{
							//current bid is lower. Need to write this bid to history, then automatically add new bid for person with automatic bid.
							$db			=& JFactory::getDBO();

							//write new bid to db
							$tempmaxbid = 0;
							$query = 'INSERT INTO #__bfbid_pro (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`)'
							. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->getEscaped($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->getEscaped($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$tempmaxbid.')'
		  					;


							$db->setQuery( $query );
							if (!$db->query())
							{
								echo $db->getErrorMsg();
								return false;
							}

							//now set up automatic bid
							$userusername = $autobidrows[0]->username;
							$userid = $autobidrows[0]->uid;
							$useremail = $autobidrows[0]->email;
							$maxbid = $autobidrows[0]->maxbid;
							//now figure out what the current bid is
							//is maxbid greater than currentBid + increment
							if($maxbid > ($bid + (float)$bidIncrement) ){
								$bid = $bid + (float)$bidIncrement;
							}else{
								$bid = $maxbid;
								$maxbid = 0;
							}

				  			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_LOWER') );

						}
					}

					$db			=& JFactory::getDBO();
					$query = 'UPDATE #__bfauction_pro SET'
						. ' currentBid='.(float)$bid.' ,highBidder='.$db->quote( $db->getEscaped($user->username), false ).', '
						. ' tax='.(float)$tax.' ,commission='.(float)$commission.' '
	  					. ' WHERE id ='.(int)$itemId.''
	  					;

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}

					$query = 'INSERT INTO #__bfbid_pro (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`)'
						. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->getEscaped($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->getEscaped($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$maxbid.')'
	  					;

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}
					$bidId=$db->insertid();

					if(!$allowAutoBidding){
						$msg = JText::_( 'COM_BFAUCTIONPRO_BID_CONFIRMED' );
					}

					//now see if time needs to be added to end time
					if($increaseEndTime){
						//how much time left?
						$secondsDiff = strtotime($myresult->endDate) - strtotime($currentDate);  //convert to unix time (number of seconds) and work out difference
						$remainingMinutes = floor(($secondsDiff)/60);

						if( ($remainingMinutes -1) < $increaseEndTimeLastMinutes ){
							$timestamp = strtotime($currentDate) + $increaseEndTimeAmount*60;
							$newEndTime = date('Y-m-d H:i:s', $timestamp);

							$db			=& JFactory::getDBO();
							$query = 'UPDATE #__bfauction_pro SET'
								. ' endDate='.$db->quote( $db->getEscaped($newEndTime), false )
	  							. ' WHERE id ='.(int)$itemId.''
	  							;

							$db->setQuery( $query );
							if (!$db->query())
							{
								echo $db->getErrorMsg();
								return false;
							}

							$msg .= "<br>".JText::_( 'COM_BFAUCTIONPRO_BID_TIMEINCREASED' );
						}

					}

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						bfauction_proController::triggerEmails("BidConfirm", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						bfauction_proController::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}
				} else {
					if($reverseAuction){
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_HIGHER') );
					}else{
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_LOWER') );
					}
					$msg="";
					$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
				}
			}
		}

		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
	}

    function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
       $conf	=& JFactory::getConfig();

       $mailfrom 	= $conf->getValue('config.mailfrom');
	   $fromname 	= $conf->getValue('config.fromname');

	   $emailBody = $body;
       $mode = 1;

       JUtility::sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
    }

    function getEmailTemplate($title, $catid)
    {
       	$db			=& JFactory::getDBO();

		$query = 'SELECT *'
	  			. ' FROM #__bfauction_email AS a'
				. ' WHERE a.published = 1 AND a.title="'.$title.'" AND a.catid='.(int)$catid
	  			. ' ORDER BY a.title'
	  			;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if(!isset($rows[0]->id)){
			//no email for that category, so just pick the first one
			$query = 'SELECT a.*'
		  			. ' FROM #__bfauction_email AS a'
					. ' WHERE a.published = 1 and a.title="'.$title.'"'
		  			. ' ORDER BY a.title'
		  			;

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
		}

		return $rows;
    }

    function getItem($itemId)
    {
       	$db			=& JFactory::getDBO();

		$query = 'SELECT *'
	  			. ' FROM #__bfauction_pro AS a'
				. ' WHERE a.id ='.(int)$itemId.''
	  			;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
    }

	function myitems()
	{
		JRequest::setVar( 'view', 'myitems' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function item()
	{
		JRequest::setVar( 'view', 'item' );
		JRequest::setVar( 'layout', 'form'  );

		parent::display();
	}

	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfauction_proController::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfauction_proController::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$db 		=& JFactory::getDBO();
		$user 		=& JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_NO_ITEMS_SELECTED') );
			$mainframe->redirect( 'index.php?option='. $option );
		}

		$cids = implode( ',', $cid );

		$query = 'UPDATE #__bfauction_pro'
		. ' SET published = '.(int) $publish
		. ' WHERE id IN ( '. $cids .' )'
		. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )'
		;
		$db->setQuery( $query );
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg() );
		}

		$mainframe->redirect( 'index.php?option='. $option );
    }


/**
* Moves the record up one position
*/
function moveUpQuestion(  ) {
	bfauction_proController::orderQuestion( -1 );
}

/**
* Moves the record down one position
*/
function moveDownQuestion(  ) {
	bfauction_proController::orderQuestion( 1 );
}

/**
* Moves the order of a record
* @param integer The direction to reorder, +1 down, -1 up
*/
function orderQuestion( $inc )
{
	global $mainframe;

	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

    JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfauction_pro'.DS.'tables');
	$row =& JTable::getInstance('item', 'Table');

	$db		=& JFactory::getDBO();
	$cid	= JRequest::getVar('cid', array(0), '', 'array');
	$option = JRequest::getCmd('option');
	JArrayHelper::toInteger($cid, array(0));

	$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
	$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
	$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

	$row =& JTable::getInstance( 'item', 'Table' );
	$row->load( $cid[0] );
	$row->move( $inc, 'catid = '.(int) $row->catid.' AND published != 0' );

	$mainframe->redirect( 'index.php?option='. $option );
}

function saveOrder( )
{
	$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
	global $mainframe;

	// Check for request forgeries
	JRequest::checkToken() or jexit( 'Invalid Token' );

	// Initialize variables
	$db			=& JFactory::getDBO();
	$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
	$total		= count( $cid );
	JArrayHelper::toInteger($order, array(0));

	$row =& JTable::getInstance('item', 'Table');
	$groupings = array();

	// update ordering values
	for( $i=0; $i < $total; $i++ ) {
		$row->load( (int) $cid[$i] );
		// track categories
		$groupings[] = $row->catid;

		if ($row->ordering != $order[$i]) {
			$row->ordering = $order[$i];
			if (!$row->store()) {
				JError::raiseError(500, $db->getErrorMsg() );
			}
		}
	}

	// execute updateOrder for each parent group
	$groupings = array_unique( $groupings );
	foreach ($groupings as $group){
		$row->reorder('catid = '.(int) $group);
	}

	$msg 	= JText::_( 'COM_BFAUCTIONPRO_NEW_ORDERING_SAVED');
	$mainframe->redirect( 'index.php?option=com_bfauction_pro', $msg );
}


	/**
	  Copies one or more item
	 */
	function copy()
	{
		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_bfauction_pro' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();

		$table	=& JTable::getInstance('item', 'Table');

		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->title				= JText::_( 'COM_BFAUCTIONPRO_COPY_OF') . $table->title;
					$table->published 			= 0;
					$table->ordering 			= 0;

					$now =& JFactory::getDate();
					$table->date			= $now->toMySQL();

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}else{
					return JError::raiseWarning( 500, $table->getError() );
			    }
			}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFAUCTIONPRO_ITEMS_COPIED', $n ) );
	}

	/* buy now view to confirm that person wants to commit to buying item	 */
	function buynow(){
		JRequest::setVar( 'view', 'buynow' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/*
	 * buy item now
	 */
	function commitBuyNow(){
		global $mainframe;
		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'buyNowPrice', 0, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );

    	$MenuItemid = JRequest::getVar('Itemid');
		//$menu =& JMenu::getInstance('site');
		//$config = & $menu->getParams( $MenuItemid );
		$params = &$mainframe->getParams();

		$allowEmail = $params->get( 'allowEmail' );
		$bfcurrency = $params->get( 'bfcurrency' );
		if($bfcurrency == ""){
			$bfcurrency = "$";
		}
		$dst_fix = $params->get( 'dst' );

		if ($itemId==0 | $bid < 0.01)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_PROCESSING_BID') );
			$msg="";
			$this->setRedirect( 'index.php?option=com_bfauction_pro&task=listItem', $msg );
		} else {
			$user =& JFactory::getUser();

			// is dst on on that particular date ?
			$now =& JFactory::getDate();
			$date=$now->toFormat();
  			if (is_numeric( $date))
  			{
				$ts = $date;
  			} else {
    			$ts = strtotime( $date . ' UTC');
  			}
  			$dst = date( 'I', $ts);

  			$now =& JFactory::getDate();
  			if($dst_fix){
				$now->setOffset($mainframe->getCfg('offset')+$dst);
  			}else{
  				$now->setOffset($mainframe->getCfg('offset'));
  			}
			$currentDate=$now->toFormat();

			$db			=& JFactory::getDBO();

			$query = 'SELECT *'
	  			. ' FROM #__bfauction_pro AS a'
	  			. ' WHERE a.published = 1 and a.id='.(int)$itemId.''
	  			. ' ORDER BY a.title'
	  			;

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$myresult=&$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( 'index.php?option=com_bfauction_pro&task=listItems&Itemid='.$MenuItemid, $msg );
			} else {
				if ($bid > $myresult->currentBid )
				{
					$db			=& JFactory::getDBO();
					$query = 'UPDATE #__bfauction_pro SET'
						. ' currentBid='.(float)$bid.' ,highBidder='.$db->quote( $db->getEscaped($user->username), false ).', '
						. ' tax='.(float)$tax.' ,commission='.(float)$commission.' '
	  					. ' WHERE id ='.(int)$itemId.''
	  					;

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}

					//since item is bought, set end date to now
					$db			=& JFactory::getDBO();
					$query = 'UPDATE #__bfauction_pro SET'
						. ' endDate="'.$currentDate.'"'
	  					. ' WHERE id ='.(int)$itemId.''
	  					;

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}

					$query = 'INSERT INTO #__bfbid_pro (`itemid`, `username`, `email`, `bid`, `bid_time`, `tax`, `commission`)'
						. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->getEscaped($user->username), false ).', '.$db->quote( $db->getEscaped($user->email), false ).', '.(float)$bid.',  "'.$currentDate.'", '.(float)$tax.', '.(float)$commission.')'
	  					;

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}
					$bidId=$db->insertid();

					$msg = JText::_( 'COM_BFAUCTIONPRO_BUY_NOW_PURCHASE' );

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						bfauction_proController::triggerEmails("BuyNow", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						bfauction_proController::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}
				} else {
					JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_BID_NOT_ACCEPTED_LOWER') );
					$msg="";
					$this->setRedirect( 'index.php?option=com_bfauction_pro&task=listItems&Itemid='.$MenuItemid, $msg );
				}
			}
		}
		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$MenuItemid, $msg );
	}

	function triggerEmails($emailType, $id, $bidId){
		if($emailType == "Outbid" | $emailType == "LoosingBid"){
    		global $mainframe;
    		$params = &$mainframe->getParams();
    		$dateFormat = $params->get( 'dateFormat' );

			//get previous high bidder from bid history
		   	$db			=& JFactory::getDBO();

			$query = ' SELECT * FROM #__bfbid_pro '
				. '  WHERE `itemid` = '.(int)$id.''
				. ' ORDER BY bid_time desc'
	  			;

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}

			// if there is no previous bidder, don't send any outbid or loosing email.
			if($rows == null){
				return false;
			}

			// do not send outbid email if this is the first bid on an item
			if(count($rows)<2){
				return false;
			}

			//don't send outbid or loosing email if the same person bids twice in a row
			if($rows[0]->uid == $rows[1]->uid){
				return false;
			}

			//set bid id for loosing email so we send to the correct person
			if($emailType == "LoosingBid"){
				$bidId = $rows[1]->id;
			}
		}

		//get category id of the item
	   	$db			=& JFactory::getDBO();

		$query = ' SELECT catid FROM #__bfauction_pro '
				. '  WHERE `id` = '.(int)$id.''
	  			;

		$db->setQuery( $query );
		$mycatid = $db->loadObjectList();
		$catid = $mycatid[0]->catid;
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$myemail = bfauction_proController::getEmailTemplate($emailType, $catid);
		$myitem =  bfauction_proController::getItem($id);

		//get seller details
	   	$db			=& JFactory::getDBO();

		$query = ' SELECT * FROM #__users '
				. '  WHERE `id` = '.(int)$myitem[0]->uid.''
	  			;

		$db->setQuery( $query );
		$userdetail = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		$sellername = $userdetail[0]->name; //get seller name
		$selleremail = $userdetail[0]->email; //get seller email

		if($myemail == null){
		   //no email template found so don't send anything
		   return false;
		}

		$db			=& JFactory::getDBO();
		$query = "";

		//get bid details
		if($bidId == null){
			//get the bid with the largest id
			$query = ' SELECT * FROM #__bfbid_pro '
				. '  WHERE `itemid` = '.(int)$id.''
				. ' ORDER BY bid_time desc'
	  			;
		}else{
			//get a sepecific bid
			$query = ' SELECT * FROM #__bfbid_pro '
				. '  WHERE `itemid` = '.(int)$id.' AND `id`='.(int)$bidId
				. ' ORDER BY bid_time desc'
	  			;
		}

		$db->setQuery( $query );
		$bids = $db->loadObjectList();

		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction_pro&task=bid&cid='. $myitem[0]->id.'">'.$myitem[0]->title.'</a>';

		//repace fields with actual data
		$myemail[0]->description=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->description); // insert bfcurrency
		$myemail[0]->description=preg_replace('/{bid}/', (float)$bids[0]->bid , $myemail[0]->description); // insert bid amount
		if($emailType == "Outbid"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->description); // insert user name
		}else{
			$myemail[0]->description=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->description); // insert user name
		}
		$myemail[0]->description=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{enddate}/', strftime($dateFormat, strtotime($myitem[0]->endDate) ) , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->description); // insert item title
		$myemail[0]->description=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->description); // insert item id
		$myemail[0]->description=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->description); // insert product id
		$myemail[0]->description=preg_replace('/{sellername}/', $sellername , $myemail[0]->description); // insert seller name
		$myemail[0]->description=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->description); // insert seller email
		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->description); // insert maxbid


		$myemail[0]->subject=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->subject); // insert bfcurrency
		$myemail[0]->subject=preg_replace('/{bid}/', (float)$bids[0]->bid , $myemail[0]->subject); // insert bid amount
		if($emailType == "Outbid"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->subject); // insert user name
		}else{
			$myemail[0]->subject=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->subject); // insert user name
		}
		$myemail[0]->subject=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{enddate}/', $myitem[0]->endDate , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->subject); // insert item title
		$myemail[0]->subject=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->subject); // insert item id
		$myemail[0]->subject=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->subject); // insert product id
		$myemail[0]->subject=preg_replace('/{sellername}/', $sellername , $myemail[0]->subject); // insert seller name
		$myemail[0]->subject=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->subject); // insert seller email
		$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
		$myemail[0]->subject=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->subject); // insert maxbid

		$subject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		if($emailType == "Outbid"){
			bfauction_proController::sendHTMLNotificationEmail($body, $rows[1]->email, $subject);
		}else{
			bfauction_proController::sendHTMLNotificationEmail($body, $bids[0]->email, $subject);
		}

		return true;
	}

	function triggerBFAuctionEmail()
	{
		global $mainframe;
		$Itemid = JRequest::getVar('Itemid');
		//$menu =& JMenu::getInstance('site');
		//$config = & $menu->getParams( $Itemid );
		$params = &$mainframe->getParams();
		$dst_fix = $params->get( 'dst' );
		$allowEmail = $params->get( 'allowEmail' );

		$db			=& JFactory::getDBO();

		$query = 'SELECT id, endDate, currentBid, buyNowPrice, reservePrice  FROM #__bfauction_pro'
						. ' WHERE winEmailSent=0'
		;

		$db->setQuery( $query );
		$rows = $db->loadObjectList( );

		// is dst on on that particular date ?
		$now =& JFactory::getDate();
		$date=$now->toFormat();
		if (is_numeric( $date))
		{
			$ts = $date;
		} else {
	 		$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		$now =& JFactory::getDate();
		if($dst_fix){
			$now->setOffset($mainframe->getCfg('offset')+$dst);
		}else{
			$now->setOffset($mainframe->getCfg('offset'));
		}
		$currentDate=$now->toFormat();

		// Check if any auctions have finished since this last run
		foreach($rows as $row){
			if ($currentDate > $row->endDate){
				//mark winEmailSent as true
				$now =& JFactory::getDate();
				$db			=& JFactory::getDBO();
				if( ($row->currentBid == $row->buyNowPrice) || !($allowEmail) ){
			   		//don't send emails for BuyNow purchase or when emails are turned off
			   		//but still set the flag winEmailSent so we know auction has finished.
					$query = 'UPDATE #__bfauction_pro SET'
						. ' winEmailSent="2" ,winEmailDate='.$db->quote( $db->getEscaped( $now->toMySQL() ), false )
		  				. ' WHERE id ='.(int)$row->id
		  			;
				}else{
					//auction finished, trigger winning email
					//is reserve price met?
					if($row->currentBid < $row->reservePrice){
						bfauction_proController::triggerEmails("ReserveNotMet", (int)$row->id, NULL);
					}else{
						bfauction_proController::triggerEmails("WinningBid", (int)$row->id, NULL);
					}
					bfauction_proController::triggerEmails("LoosingBid", (int)$row->id, NULL);

					$query = 'UPDATE #__bfauction_pro SET'
						. ' winEmailSent="1" ,winEmailDate='.$db->quote( $db->getEscaped( $now->toMySQL() ), false )
		  				. ' WHERE id ='.(int)$row->id
		  			;
				}

				$db->setQuery( $query );
				if (!$db->query())
				{
					echo $db->getErrorMsg();
					return false;
				}
			}
		}
	}

	/**
	* save a record (and redirect to main page)
	* @return void
	*/
	function save()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] = (int) $cid[0];
		$files  = JRequest::get( 'files' );

		$model = $this->getModel('item');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFAUCTIONPRO_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPRO_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		$config =& JComponentHelper::getParams( 'com_bfauction_pro' );

		$model->save($post,$files,$config,$model);

		$Itemid = JRequest::getVar('Itemid');

		$link = 'index.php?option=com_bfauction_pro&view=myitems&Itemid='.(int)$Itemid;
		$this->setRedirect($link, $msg);
	}

	function watchlist()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user =& JFactory::getUser();
		$userid = $user->id;

		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$Itemid = JRequest::getVar('Itemid');

		$db			=& JFactory::getDBO();

		$query = 'INSERT INTO #__bfauctionpro_watchlist (`itemid`, `uid`)'
							. ' VALUES ('.(int)$itemId.', '.(int)$userid.')'
		  					;

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$msg = JText::_( 'COM_BFAUCTIONPRO_WATCHLIST_CONFIRMED' );
		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
	}

	function watchlistDelete()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user =& JFactory::getUser();
		$userid = $user->id;

		$itemId = JRequest::getVar( 'cid', 0, 'POST', 'int' );
		$Itemid = JRequest::getVar('Itemid');

		$db			=& JFactory::getDBO();

		$query = 'DELETE FROM #__bfauctionpro_watchlist WHERE `itemid`='.(int)$itemId.' AND `uid`='.(int)$userid
		  					;

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$msg = JText::_( 'COM_BFAUCTIONPRO_WATCHLIST_DELETED' );
		$this->setRedirect( 'index.php?option=com_bfauction_pro&view=watchlist&Itemid='.$Itemid, $msg );
	}
}
?>