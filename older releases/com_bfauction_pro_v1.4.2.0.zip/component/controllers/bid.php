<?php
/**
 * $ID$
 * Bid Controller for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * My items Template Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proControllerbid extends JController
{
    /*
     * AJAX lookup of current bid for bid view
     */
    function luCurrentBid(){
    	global $mainframe;
    	$params = &$mainframe->getParams();
    	$dateFormat = $params->get( 'dateFormat' );

    	$itemid=JRequest::getVar( 'itemid');
    	$dst_fix=JRequest::getVar( 'dst_fix', 0);

    	$db 		=& JFactory::getDBO();
    	$query = 'SELECT `currentBid` FROM #__bfauction_pro'
			. ' WHERE `id` = '. (int)$itemid
		;
		$db->setQuery( $query );
		$currentBid=$db->loadResult();
		if($currentBid){
			//do nothing as returned value is ok
		}else{
		    $currentBid=JText::_('COM_BFISSUELOG_ERROR_LIST_NOT_EXIST');
		}

		$db 		=& JFactory::getDBO();
    	$query = 'SELECT `endDate` FROM #__bfauction_pro'
			. ' WHERE `id` = '. (int)$itemid
		;
		$db->setQuery( $query );
		$endDate=$db->loadResult();

		// is dst on on that particular date ?
		$now =& JFactory::getDate();
		$date=$now->toFormat();
		if (is_numeric( $date)) {
			$ts = $date;
		} else {
			$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		global $mainframe;
		$now =& JFactory::getDate();
		if($dst_fix){
			$now->setOffset($mainframe->getCfg('offset')+$dst);
		}else{
			$now->setOffset($mainframe->getCfg('offset'));
		}
		$currentDate=$now->toFormat();

    	$secondsDiff = 0;
		if($currentDate > $endDate){
   			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_AUCTION_HAS_ENDED') );
		}else{
			$endDateAsSeconds = strtotime($endDate);
			$currentDateAsSeconds = strtotime($currentDate);

			$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
		}

		$remainingDay     = floor($secondsDiff/60/60/24);
		$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
		$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
		$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

		// we'll generate XML output
		header('Content-Type: text/xml');
		// generate XML header
		$return = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

		// create the <response> element
		$return .= "<response>";

		$return .= "<myBid>";
		// generate output
   		$return .= htmlentities($currentBid);
		$return .= "</myBid>";

		$return .= "<myDate>";
   		//$return .= htmlentities($endDate);
   		$return .= htmlentities( strftime($dateFormat, strtotime($endDate)) );
		$return .= "</myDate>";

		$return .= "<myDay>";
   		$return .= htmlentities($remainingDay);
		$return .= "</myDay>";

		$return .= "<myHour>";
   		$return .= htmlentities($remainingHour);
		$return .= "</myHour>";

		$return .= "<myMin>";
   		$return .= htmlentities($remainingMinutes);
		$return .= "</myMin>";

		$return .= "<mySec>";
   		$return .= htmlentities($remainingSeconds);
		$return .= "</mySec>";

		// close the <response> element
		$return .= "</response>";

		echo $return;
      	$mainframe->close();
    }

}