<?php
/**
 * $Id: bfauction_pro.php 21 2012-02-25 10:55:23Z tuum $
 * bfauction_pro entry point file for bfauction_pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once( JPATH_COMPONENT.DS.'controller.php' );

// Set the table directory
JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfauction_pro'.DS.'tables');

// Component Helper
jimport('joomla.application.component.helper');

require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfauction_pro'.DS.'helpers'.DS.'helper.php' );

// Require specific controller if requested
if($controller = JRequest::getWord('controller')) {
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    if (file_exists($path)) {
        require_once $path;
    } else {
        $controller = '';
    }
}

$config =& JComponentHelper::getParams( 'com_bfauction_pro' );
$useCSS = $config->get( 'useCSS' );
if($useCSS == "0"){
   //Use template CSS
}else{
   $document =& JFactory::getDocument();
   $cssFile = "./components/com_bfauction_pro/css/bfauction_pro.css";
   $document->addStyleSheet($cssFile, 'text/css', null, array());
}

// Create the controller
$classname	= 'bfauction_proController'.$controller;
$controller = new $classname( );

// Check the task parameter and execute appropriate function
switch( JRequest::getCmd('task')) {
    case "cancel":
        $controller->cancel();
        break;
    case "bid":
        $controller->bid();
        break;
    case "luCurrentBid":
        $controller->luCurrentBid();
        break;
    case "mybid":
        $controller->mybid();
        break;
	case "listItems":
        $controller->listItems();
        break;
	case "bidHistory":
        $controller->bidHistory();
        break;
	case "myitems":
        $controller->myitems();
        break;
    case "edit":
	    $controller->edit();
    	break;
    case "add":
    	$controller->edit();
    	break;
    case "save":
    	$controller->save();
    	break;
    case 'remove':
    	$controller->remove();
    	break;
    case 'publish':
		$controller->publishQuestion( );
		break;
	case 'unpublish':
		$controller->unPublishQuestion( );
		break;
    case 'orderup':
		$controller->moveUpQuestion( );
		break;
	case 'orderdown':
		$controller->moveDownQuestion( );
		break;
	case 'saveorder':
		$controller->saveOrder( );
		break;
    case 'copy':
		$controller->copy();
    	break;
    case 'buynow':
        $controller->buynow();
        break;
    case 'commitBuyNow':
        $controller->commitBuyNow();
        break;
    case 'bidnow':
        $controller->bidnow();
        break;
    case "watchlist":
        $controller->watchlist();
        break;
    case "watchlistDelete":
        $controller->watchlistDelete();
        break;
    default:
        $controller->display();
        break;
}

// Redirect if set by the controller
$controller->redirect();

?>
