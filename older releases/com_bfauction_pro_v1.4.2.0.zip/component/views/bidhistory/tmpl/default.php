<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * Bid history view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

    $Itemid = JRequest::getVar('Itemid');
    $cid = JRequest::getVar('cid');
	$menu =& JMenu::getInstance('site');
	$config = & $menu->getParams( $Itemid );
	$user =& JFactory::getUser();

	$bfcurrency = $this->params->get('bfcurrency');
	if($bfcurrency == ""){
		$bfcurrency = "$";
	}

	$dateFormat = $this->params->get( 'dateFormat' );
?>
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID_HISTORY' ); ?></legend>

	<table class="adminlist">
	<thead>
		<tr class="bfauction_proReportHeader">
		<th width="200">
			<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_USERNAME' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID' ); ?>:
		</th>

		<th width="150">
			<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID_DATE' ); ?>:
		</th>
		</tr>
		</thead>

		<?php
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row = &$this->items[$i];
			?>
			<tr class="bfauction_proReportBody">
			<td align="center">
			   <?php
				if($row->username == $user->username){
					echo $row->username;
				}else{
					echo substr($row->username, 0, 1);
					echo "******";
					echo substr($row->username, -1);
				}
			   ?>
			</td>
			<td align="right">
			   <?php echo $bfcurrency; ?><?php echo $row->bid; ?>
			</td>
			<td align="center">
			    <strong>
						<?php echo strftime($dateFormat, strtotime($row->bid_time) ); ?>
			    </strong>
			</td>
			</tr>
		<?php
		} //end for$row
		?>

	</table>


	</fieldset>
	<br>
	<br>
	<a href="index.php?option=com_bfauction_pro&task=bid&cid=<?php echo (int)$cid; ?>&Itemid=<?php echo $Itemid;?>"><?php echo JText::_( 'COM_BFAUCTIONPRO_BUTTON_CANCEL' ); ?></a>
</div>
<div class="col width-35">
	&nbsp;
</div>
<div class="clr"></div>
