<?php
/**
 * $Id: form.php 22 2012-03-09 07:23:15Z tuum $
 * Item view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

    $Itemid = JRequest::getVar('Itemid');
	$menu =& JMenu::getInstance('site');
	$config = & $menu->getParams( $Itemid );
?>

<?php jimport('joomla.html.editor'); ?>

<script type="text/javascript">
	//<![CDATA[

	window.addEvent('domready', function(){
		$('browseSrv').addEvent('click', function(e){
			e = new Event(e).stop();
			SqueezeBox.initialize();
			SqueezeBox.fromElement(this, {
				handler: 'iframe',
				url: '<?php echo JURI::base()?>index.php?option=com_media&view=images&tmpl=component&e_name=image',
				size: {x: 590, y: 400}
			});
		})
	});


	function jInsertEditorText( text, editor ) {
		if (editor=='image'){
			$('existingImageContainer').setHTML(text);
			var src = $$('#existingImageContainer img').getProperty('src');
			$('image').setProperty('value', src);
		} else if(editor=='image2'){
			$('existingImageContainer2').setHTML(text);
			var src = $$('#existingImageContainer2 img').getProperty('src');
			$('image2').setProperty('value', src);
		} else if(editor=='image3'){
			$('existingImageContainer3').setHTML(text);
			var src = $$('#existingImageContainer3 img').getProperty('src');
			$('image3').setProperty('value', src);
		} else if(editor=='image4'){
			$('existingImageContainer4').setHTML(text);
			var src = $$('#existingImageContainer4 img').getProperty('src');
			$('image4').setProperty('value', src);
		} else if(editor=='image5'){
			$('existingImageContainer5').setHTML(text);
			var src = $$('#existingImageContainer5 img').getProperty('src');
			$('image5').setProperty('value', src);
		} else {
			tinyMCE.execInstanceCommand(editor, 'mceInsertContent',false,text);
		}
	}

	window.addEvent('domready', function(){
		$('browseSrv2').addEvent('click', function(e){
			e = new Event(e).stop();
			SqueezeBox.initialize();
			SqueezeBox.fromElement(this, {
				handler: 'iframe',
				url: '<?php echo JURI::base()?>index.php?option=com_media&view=images&tmpl=component&e_name=image2',
				size: {x: 590, y: 400}
			});
		})
	});

	window.addEvent('domready', function(){
		$('browseSrv3').addEvent('click', function(e){
			e = new Event(e).stop();
			SqueezeBox.initialize();
			SqueezeBox.fromElement(this, {
				handler: 'iframe',
				url: '<?php echo JURI::base()?>index.php?option=com_media&view=images&tmpl=component&e_name=image3',
				size: {x: 590, y: 400}
			});
		})
	});

	window.addEvent('domready', function(){
		$('browseSrv4').addEvent('click', function(e){
			e = new Event(e).stop();
			SqueezeBox.initialize();
			SqueezeBox.fromElement(this, {
				handler: 'iframe',
				url: '<?php echo JURI::base()?>index.php?option=com_media&view=images&tmpl=component&e_name=image4',
				size: {x: 590, y: 400}
			});
		})
	});

	window.addEvent('domready', function(){
		$('browseSrv5').addEvent('click', function(e){
			e = new Event(e).stop();
			SqueezeBox.initialize();
			SqueezeBox.fromElement(this, {
				handler: 'iframe',
				url: '<?php echo JURI::base()?>index.php?option=com_media&view=images&tmpl=component&e_name=image5',
				size: {x: 590, y: 400}
			});
		})
	});

	//]]>
</script>



		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.title.value == "") {
				alert( "<?php echo JText::_( 'COM_BFAUCTIONPRO_PLEASE_ENTER_TITLE', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFAUCTIONPRO_PLEASE_SELECT_CATEGORY', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript" type="text/javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<?php echo bfauction_proHelper::getToolbar(); ?>

<form action="<?php echo JRoute::_( 'index.php' ); ?>" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ITEM_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Category::This is the category that your item will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TITLE' ); ?>: *
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="title" id="title" size="60" maxlength="250" value="<?php echo $this->bfauction_pro->title;?>"/>
			</td>
		</tr>


		<?php
		if ("add" == JRequest::getCmd('task')) {
			$this->bfauction_pro->published=1;
			echo '<input type="hidden" name="published" value="1" />';
		} else {
		?>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->published)){
			          $this->bfauction_pro->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfauction_pro->published ); ?>
			</td>
		</tr>
		<?php }; ?>

		<tr>
			<td class="key">
				<label for="description">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_DESCRIPTION' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title='Description::This is the description of the item. This field can contain HTML.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfauction_pro->description)){
			          $this->bfauction_pro->description = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'description',  $this->bfauction_pro->description, '500', '300', '60', '40', array()) ; ?>
			</td>
		</tr>

	</table>

	<?php
	if(!isset($this->bfauction_pro->ordering)){
		$this->bfauction_pro->ordering = "";
	}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfauction_pro->ordering;?>" />

	</fieldset>
</div>
<div class="col width-35">
	<fieldset class="adminform">
	<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_OPTIONS' ); ?></legend>
	<table class="admintable">

		<tr>
			<td class="key">
				<label for="currentBid">
					<?php if($this->isNew){ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_OPENING_BID' ); ?>: *
					<?php }else{ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CURRENT_BID' ); ?>: *
					<?php } ?>
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->currentBid)){
			          $this->bfauction_pro->currentBid = 0;
			       }
			    ?>
			    <?php if($this->isNew){ ?>
			       <input class="inputbox" type="text" name="currentBid" id="currentBid" size="5" value="<?php echo $this->bfauction_pro->currentBid;?>"/>
			    <?php }else{ ?>
			       <input class="inputbox" type="text" readonly name="currentBid" id="currentBid" size="5" value="<?php echo $this->bfauction_pro->currentBid;?>"/> <i>(read only)</i>
			    <?php } ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="reservePrice">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_RESERVE_PRICE' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->reservePrice)){
			          $this->bfauction_pro->reservePrice = 0;
			       }
			    ?>
			    <input class="inputbox" type="text" name="reservePrice" id="reservePrice" size="5" value="<?php echo $this->bfauction_pro->reservePrice;?>"/>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="bidIncrement">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID_INCREMENT' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->bidIncrement)){
			          $this->bfauction_pro->bidIncrement = 0;
			       }
			    ?>
			    <input class="inputbox" type="text" name="bidIncrement" id="bidIncrement" size="5" value="<?php echo $this->bfauction_pro->bidIncrement;?>"/>
			</td>
		</tr>

		<?php
		if ("add" == JRequest::getCmd('task')) {
			echo '<input type="hidden" name="highBidder" id="highBidder" value="0" />';
		} else {
		?>
		<tr>
			<td class="key">
				<label for="highBidder">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_HIGH_BIDDER' ); ?>: *
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->highBidder)){
			          $this->bfauction_pro->highBidder = 0;
			       }
			    ?>
			    <input class="inputbox" type="text" readonly name="highBidder" id="highBidder" size="20" value="<?php echo $this->bfauction_pro->highBidder;?>"/> <i>(read only)</i>
			</td>
		</tr>
		<? } ?>

		<tr>
			<td class="key">
				<label for="endTime">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_END_DATE_TIME' ); ?>:
				</label>
			</td>
			<td>
			<?php
				$document = &JFactory::getDocument();
				$document->addScript("includes/js/joomla.javascript.js");

			    JHTML::_('behavior.calendar');

			    if(!isset($this->bfauction_pro->endDate)){
			       $this->bfauction_pro->endDate = "";
			    }

			    echo '<input class="inputbox" type="text" id="endDate" name="endDate" size="26" maxlength="25" value="'.$this->bfauction_pro->endDate.'" />';
				echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\'endDate\',\'%Y-%m-%d %H:%M:%S\');" /> ';
		    ?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="End Date::The date and time the auction ends, in the form YYYY-MM-DD HH:MM:SS">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="itemLocation">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ITEM_LOCATION' ); ?>:
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->itemLocation)){
			          $this->bfauction_pro->itemLocation = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="itemLocation" id="itemLocation" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->itemLocation;?>"/>
			    &nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Item Location::Where is this item current located.">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label name="deliveryMethod">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_DELIVERY_METHOD' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->deliveryMethod)){
			          $this->bfauction_pro->deliveryMethod = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="deliveryMethod" id="deliveryMethod" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->deliveryMethod;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Delivery Method::How will this item be delivered once auction ends. Eg. Pickup">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="shipping">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_SHIPPING' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->shipping)){
			          $this->bfauction_pro->shipping = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="shipping" id="shipping" maxlength="13" size="5" value="<?php echo $this->bfauction_pro->shipping;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Shipping:: How much will shipping cost?">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="commissionAmount">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_COMMISSION_AMOUNT' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->commissionAmount)){
			          $this->bfauction_pro->commissionAmount = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="commissionAmount" id="commissionAmount" maxlength="13" size="5" value="<?php echo $this->bfauction_pro->commissionAmount;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Commission Amount:: A value in this field overrides the global setting for commission amount.">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="taxAmount">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TAX_AMOUNT' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->taxAmount)){
			          $this->bfauction_pro->taxAmount = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="taxAmount" id="taxAmount" maxlength="13" size="5" value="<?php echo $this->bfauction_pro->taxAmount;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Tax Amount:: A value in this field overrides the global setting for tax amount.">
			</td>
		</tr>


		<tr>
			<td width="100" align="right" class="key">
				<label name="commission">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_COMMISSION' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->commission)){
			          $this->bfauction_pro->commission = "";
			       }
			    ?>
				<?php echo $this->bfauction_pro->commission;?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Commission:: Calcualted field, based on percent commission set in parameters.">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="tax">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TAX' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->tax)){
			          $this->bfauction_pro->tax = "";
			       }
			    ?>
				<?php echo $this->bfauction_pro->tax;?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Tax:: Calcualted field, based on percent tax. Depending on parameters, it may only apply to commission.">
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="taxableItemText"><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TAXABLE_ITEM' ); ?>:</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->taxableItem)){
			          $this->bfauction_pro->taxableItem = 0;
			       }
			    ?>
				<label name="taxableItem" id="taxableItem"><?php echo JHTML::_( 'select.booleanlist',  'taxableItem', 'class="inputbox"', $this->bfauction_pro->taxableItem ); ?></label>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Taxable Item::Does tax apply to this item?">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="totalPrice">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TOTAL_PRICE' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       $totalPrice = (float)$this->bfauction_pro->currentBid + (float)$this->bfauction_pro->commission + (float)$this->bfauction_pro->tax;
			    ?>
				<?php echo $totalPrice;?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Total Price:: Calcualted field, based on current bid plus commission and tax.">
			</td>
		</tr>

<!--	//hide legacy image fields - to be removed in future version
		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>1 :
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->image)){
			          $this->bfauction_pro->image = '';
			       }
			    ?>

				<input type="text" name="image" id="image" class="text_area" readonly="readonly" value="<?php echo $this->bfauction_pro->image; ?>"> <input type="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_SELECT_IMAGE');?>" id="browseSrv"  />
				<span id="existingImageContainer" style="display:none;"></span>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>2 :
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->image2)){
			          $this->bfauction_pro->image2 = '';
			       }
			    ?>

				<input type="text" name="image2" id="image2" class="text_area" readonly="readonly" value="<?php echo $this->bfauction_pro->image2; ?>"> <input type="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_SELECT_IMAGE');?>" id="browseSrv2"  />
				<span id="existingImageContainer2" style="display:none;"></span>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>3 :
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->image3)){
			          $this->bfauction_pro->image3 = '';
			       }
			    ?>

				<input type="text" name="image3" id="image3" class="text_area" readonly="readonly" value="<?php echo $this->bfauction_pro->image3; ?>"> <input type="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_SELECT_IMAGE');?>" id="browseSrv3"  />
				<span id="existingImageContainer3" style="display:none;"></span>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>4 :
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->image4)){
			          $this->bfauction_pro->image4 = '';
			       }
			    ?>

				<input type="text" name="image4" id="image4" class="text_area" readonly="readonly" value="<?php echo $this->bfauction_pro->image4; ?>"> <input type="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_SELECT_IMAGE');?>" id="browseSrv4"  />
				<span id="existingImageContainer4" style="display:none;"></span>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>5 :
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->image5)){
			          $this->bfauction_pro->image5 = '';
			       }
			    ?>

				<input type="text" name="image5" id="image5" class="text_area" readonly="readonly" value="<?php echo $this->bfauction_pro->image5; ?>"> <input type="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_SELECT_IMAGE');?>" id="browseSrv5"  />
				<span id="existingImageContainer5" style="display:none;"></span>
			</td>
		</tr>
--> // end hide legacy image fields - to be removed in future version

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>1 :
				</label>
			</td>
			<td>
				<input type="file" name="img1"/>
				<?php
				   $a_pic = JPATH_SITE."/images/com_bfauction_pro/".$this->bfauction_pro->id."img1.jpg";
				   if (file_exists($a_pic))
				   {
				     echo '<img src="./images/com_bfauction_pro/'.$this->bfauction_pro->id.'img1_t.jpg?time='.time().'"/>';
				     echo "<input type='checkbox' name='d_img1' value='delete'>".JText::_('COM_BFAUCTIONPRO_IMAGE_DELETE');
				   }else{
				      echo "<input type='hidden' name='d_img1' value=''>";
				   }
				?>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>2 :
				</label>
			</td>
			<td>
				<input type="file" name="img2"/>
				<?php
				   $a_pic = JPATH_SITE."/images/com_bfauction_pro/".$this->bfauction_pro->id."img2.jpg";
				   if (file_exists($a_pic))
				   {
				     echo '<img src="./images/com_bfauction_pro/'.$this->bfauction_pro->id.'img2_t.jpg?time='.time().'"/>';
				     echo "<input type='checkbox' name='d_img2' value='delete'>".JText::_('COM_BFAUCTIONPRO_IMAGE_DELETE');
				   }else{
				      echo "<input type='hidden' name='d_img2' value=''>";
				   }
				?>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>3 :
				</label>
			</td>
			<td>
				<input type="file" name="img3"/>
				<?php
				   $a_pic = JPATH_SITE."/images/com_bfauction_pro/".$this->bfauction_pro->id."img3.jpg";
				   if (file_exists($a_pic))
				   {
				     echo '<img src="./images/com_bfauction_pro/'.$this->bfauction_pro->id.'img3_t.jpg?time='.time().'"/>';
				     echo "<input type='checkbox' name='d_img3' value='delete'>".JText::_('COM_BFAUCTIONPRO_IMAGE_DELETE');
				   }else{
				      echo "<input type='hidden' name='d_img3' value=''>";
				   }
				?>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>4 :
				</label>
			</td>
			<td>
				<input type="file" name="img4"/>
				<?php
				   $a_pic = JPATH_SITE."/images/com_bfauction_pro/".$this->bfauction_pro->id."img4.jpg";
				   if (file_exists($a_pic))
				   {
				     echo '<img src="./images/com_bfauction_pro/'.$this->bfauction_pro->id.'img4_t.jpg?time='.time().'"/>';
				     echo "<input type='checkbox' name='d_img4' value='delete'>".JText::_('COM_BFAUCTIONPRO_IMAGE_DELETE');
				   }else{
				      echo "<input type='hidden' name='d_img4' value=''>";
				   }
				?>
			</td>
		</tr>

		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>5 :
				</label>
			</td>
			<td>
				<input type="file" name="img5"/>
				<?php
				   $a_pic = JPATH_SITE."/images/com_bfauction_pro/".$this->bfauction_pro->id."img5.jpg";
				   if (file_exists($a_pic))
				   {
				     echo '<img src="./images/com_bfauction_pro/'.$this->bfauction_pro->id.'img5_t.jpg?time='.time().'"/>';
				     echo "<input type='checkbox' name='d_img5' value='delete'>".JText::_('COM_BFAUCTIONPRO_IMAGE_DELETE');
				   }else{
				      echo "<input type='hidden' name='d_img5' value=''>";
				   }
				?>
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="priceEstimate">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PRICE_ESTIMATE' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->priceEstimate)){
			          $this->bfauction_pro->priceEstimate = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="priceEstimate" id="priceEstimate" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->priceEstimate;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Price Estimate::You can use this field to give a price range that you expect for this item, eg $50 - $70">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="qtyAvailable">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_QTY_AVAILABLE' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->qtyAvailable)){
			          $this->bfauction_pro->qtyAvailable = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="qtyAvailable" id="qtyAvailable" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->qtyAvailable;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Qty Available::How many of these items are available for purchase">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="condition">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CONDITION' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->condition)){
			          $this->bfauction_pro->condition = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="condition" id="condition" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->condition;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Condition::What condition is this item, eg. NEW">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="buyersPremium">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BUYERS_PREMIUM' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->buyersPremium)){
			          $this->bfauction_pro->buyersPremium = "";
			       }
			    ?>
				<input class="inputbox" type="text" name="buyersPremium" id="buyersPremium" maxlength="255" size="30" value="<?php echo $this->bfauction_pro->buyersPremium;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Buyers Premium::eg. 15%">
			</td>
		</tr>


	</table>
	</fieldset>

	<fieldset class="adminform">
	<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PAYMENT_OPTIONS' ); ?></legend>
	<table class="admintable">
		<tr>
			<td width="100" class="key">
				<label name="image">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PRODUCT_ID' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->productId)){
			          $this->bfauction_pro->productId = '';
			       }
			    ?>
				<input class="inputbox" type="text" name="productId" id="productId" maxlength="11" size="30" value="<?php echo $this->bfauction_pro->productId;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Product Id::Product id for this auction item.">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label for="onlineStore">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PAYMENT_TYPE' ); ?>
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->onlineStore)){
			          $this->bfauction_pro->onlineStore = '';
			       }
			    ?>
				<?php echo bfauction_proHelper::onlineStore( $this->bfauction_pro->onlineStore ); ?>
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label for="paypalEmail">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PAYPAL_EMAIL' ); ?>
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->paypalEmail)){
			          $this->bfauction_pro->paypalEmail = '';
			       }
			    ?>
				<input class="inputbox" type="text" name="paypalEmail" id="paypalEmail" size="30" value="<?php echo $this->bfauction_pro->paypalEmail;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="PayPal Email::This is the PayPal email address that payment is sent to from the buy now button.">
			</td>
		</tr>

		<tr>
			<td width="100" align="right" class="key">
				<label name="buyNowPrice">
				   <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BUYNOW_PRICE' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->buyNowPrice)){
			          $this->bfauction_pro->buyNowPrice = 0;
			       }
			    ?>
				<input class="inputbox" type="text" name="buyNowPrice" id="buyNowPrice" maxlength="13" size="5" value="<?php echo $this->bfauction_pro->buyNowPrice;?>"/>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Buy Now Price:: This is the cost to purchase the auction item now and end the auction. If set to 0, now buy now button will not be visible.">
			</td>
		</tr>

	</table>
	</fieldset>


</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_bfauction_pro" />
<input type="hidden" name="id" value="<?php echo $this->bfauction_pro->id; ?>" />
<input type="hidden" name="Itemid" value="<?php echo $Itemid; ?>" />
<input type="hidden" name="task" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>