<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * My Bids view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'helper.php' );

	JHTML::_('behavior.modal');
	JHTML::script('lytebox.js', 'components/com_bfauction_pro/lib/lytebox/');

	$document =& JFactory::getDocument();
	$cssFile = './components/com_bfauction_pro/lib/lytebox/lytebox.css';
	$document->addStyleSheet($cssFile, 'text/css', null, array());
?>

<?php
$user = &JFactory::getUser();
if($user->id == 0){
	JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_MUST_LOGIN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction_pro&view=watchlist");
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_user&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;
	echo "<br><a href='".$finalUrl."'>".JText::_( 'COM_BFAUCTIONPRO_AUCTION_LOG_IN')."</a><br>";
}else{
?>

<?php
    global $mainframe, $option;
	$items = 0;
	$limitstart = 0;
	$limit = 0;

	$bfcurrency = $this->params->get('bfcurrency');
	if($bfcurrency == ""){
		$bfcurrency = "$";
	}

	$dateFormat = $this->params->get( 'dateFormat' );

	$hideBid = $this->params->get('hideBid');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ID' ); ?>
			</th>
			<th width="90" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_IMAGE' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_END_DATE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CURRENT_BID' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_HIGH_BIDDER' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID_NOW' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				&nbsp;
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction_pro&task=bid&cid='. $row->id );

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php if($row->image != ""){ ?>
    				<a href="<?php echo $row->image;?>"  rel="lytebox[myimages<?php echo $i; ?>]"><img src="<?php echo $row->image;?>" width="90" border=0></a>
    			<?php } ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo strftime($dateFormat, strtotime($row->endDate) ); ?>
			</td>
			<td align="center">
				<?php echo $bfcurrency; ?><?php echo $row->currentBid; ?>
			</td>
			<td align="center">
				<?php
				if($row->highBidder <> '0'){
					if($row->highBidder == $user->username){
						echo $row->highBidder;
					}else{
						echo substr($row->highBidder, 0, 1);
						echo "******";
						echo substr($row->highBidder, -1);
					}
				}
				?>
			</td>
			<td>
				<?php if(!$row->winEmailSent){ ?>
				<form method="post" name="adminForm">
					<input type="hidden" name="option" value="com_bfauction_pro" />
					<input type="hidden" name="task" value="bid" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="cid" value="<?php echo $row->id; ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
					<input name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo ($row->buyNowPrice > $row->currentBid & $hideBid) ? JText::_( 'COM_BFAUCTIONPRO_BUTTON_BUY_NOW' ):JText::_( 'COM_BFAUCTIONPRO_BUTTON_BID_NOW' ); ?>" />
				</form>
				<?php } ?>
			</td>
			<td>
				<form method="post" name="watchlist">
					<input type="hidden" name="option" value="com_bfauction_pro" />
					<input type="hidden" name="task" value="watchlistDelete" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="cid" value="<?php echo $row->id; ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
					<input name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo JText::_( 'COM_BFAUCTIONPRO_BUTTON_WATCHLIST_REMOVE' ) ?>" />
				</form>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="7"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<?php
}  // end force login
?>