<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * Buy now view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

    $Itemid = JRequest::getVar('Itemid');
	$menu =& JMenu::getInstance('site');
	$config = & $menu->getParams( $Itemid );

	$bfcurrency = $this->params->get('bfcurrency');

	$dst_fix = $this->params->get( 'dst' );
	$user =& JFactory::getUser();

	$reverseAuction = 0;
	$bidIncrement = $this->params->get('bidIncrement');

	$includeCommission = $this->params->get('includeCommission');
	$commissionAmount = $this->params->get('commissionAmount');
	if($this->bfauction_pro->commissionAmount){
		$commissionAmount = $this->bfauction_pro->commissionAmount;
	}
	$includeTax = $this->params->get('includeTax');
	$taxableItem = $this->bfauction_pro->taxableItem;
	$taxAmount = $this->params->get('taxAmount');
	if($this->bfauction_pro->taxAmount){
		$taxAmount = $this->bfauction_pro->taxAmount;
	}
	$showTotalPrice = $this->params->get('showTotalPrice');
	$dateFormat = $this->params->get( 'dateFormat' );

	//AJAX code located in /components/com_bfauction_pro/assets/ajax.php
	//executes the luCurrentBid page from the server (located in /controllers/bid.php)
	require_once( JPATH_COMPONENT.'/assets/ajax.php' );
?>
<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ARE_YOU_SURE' ); ?>&nbsp;<?php echo $this->bfauction_pro->title; ?>(<?php if($this->bfauction_pro->productId){ echo $this->bfauction_pro->productId; }else{ echo $this->bfauction_pro->id; } ?>)?

	<form method="post" name="buyNowForm">
		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="BuyNow">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BUY_NOW' ); ?>:
				</label>
			</td>
			<td>
			    <strong><?php echo $bfcurrency; ?>&nbsp;<?php echo $this->bfauction_pro->buyNowPrice; ?></strong>
				<input type="hidden" name="option" value="com_bfauction_pro" />
				<input type="hidden" name="task" value="commitBuyNow" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="controller" value="" />
				<input type="hidden" name="buyNowPrice" value="<?php echo $this->bfauction_pro->buyNowPrice; ?>" />
				<input type="hidden" name="cid" value="<?php echo $this->bfauction_pro->id; ?>" />
				<input type="hidden" name="tax" id="tax">
				<input type="hidden" name="commission" id="commission">
				<?php echo JHTML::_( 'form.token' ); ?>
			</td>
			<td>
				<a href="index.php?option=com_bfauction_pro&task=bid&cid=<?php echo $this->bfauction_pro->id; ?>&Itemid=<?php echo $Itemid;?>"><?php echo JText::_( 'COM_BFAUCTIONPRO_BUTTON_CANCEL' ); ?></a>
			</td>
		</tr>
		<?php if($this->bfauction_pro->shipping > 0){ ?>
		<tr>
			<td width="100" align="right" class="key">
				<label for="shipping">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_SHIPPING' ); ?>:
				</label>
			</td>
			<td>
			    <strong><?php echo $bfcurrency; ?><?php echo $this->bfauction_pro->shipping;?></strong>
			</td>
			<td>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeCommission){ ?>
		<tr>
			<td class="bfauction_proLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_COMMISSION' ); ?>:
				</label>
			</td>
			<td class="bfauction_proDetails">
			    <div id="currencyCommission" style="float: left; text-align: left;"><?php echo $bfcurrency; ?></div><div id="divCommission" style="float: left; text-align: left;" /></div>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeTax){ ?>
		<tr>
			<td class="bfauction_proLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TAX' ); ?>:
				</label>
			</td>
			<td class="bfauction_proDetails">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $bfcurrency; ?></div><div id="divTax" style="float: left; text-align: left;" /></div>
			</td>
		</tr>
		<?php } ?>

		<?php if($showTotalPrice){ ?>
		<tr>
			<td class="bfauction_proLabelTotal">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TOTAL_PRICE' ); ?>:
				</label>
			</td>
			<td class="bfauction_proDetailsTotal">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $bfcurrency; ?></div><div id="divTotalPrice" style="float: left; text-align: left;" /></div>
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td>&nbsp;
			</td>
			<td class="bfauction_proDetails">
				<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPRO_BUTTON_BUY_NOW_COMMIT' ); ?>" />
			</td>
		</tr>

		</table>
		</form>

	<div id="divCurrentBid" style="visibility:hidden" /></div>
	<div id="endDate" style="visibility:hidden" /></div>
	<input type="hidden" name="bid" id="bid" value="<?php echo $this->bfauction_pro->buyNowPrice; ?>" />
	<div id="divCommissionCurrent" style="visibility:hidden" /></div>
	<div id="divTaxCurrent" style="visibility:hidden" /></div>
	<div id="divTotalPriceCurrent" style="visibility:hidden" /></div>

<script language="javascript" type="text/javascript">
<!--
process();
//-->
</script>