<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * My Items view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<?php
$user = &JFactory::getUser();
if($user->id == 0){
	JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_ERROR_MUST_LOGIN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction_pro&view=myitems");
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_user&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;
	echo "<br><a href='".$finalUrl."'>".JText::_( 'COM_BFAUCTIONPRO_AUCTION_LOG_IN')."</a><br>";
}else{
?>

<?php
    global $mainframe, $option;
	$items = 0;
	$limitstart = 0;
	$limit = 0;

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<table class="toolbar">
<tbody>
	<tr>
		<td id="toolbar-new" class="button">
			<a class="toolbar" onclick="javascript:hideMainMenu(); submitbutton('add')" href="#">
				<span title="New" class="icon-32-new"></span>New
			</a>
		</td>
	</tr>
</tbody>
</table>

<form action="<?php echo JRoute::_( 'index.php?option=com_bfauction_pro' ); ?>" method="post" name="adminForm">
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ID' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_END_DATE' ); ?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction_pro&controller=item&task=edit&cid='. $row->id );

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php echo $row->endDate;?>
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="4"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="com_bfauction_pro" />
<input type="hidden" name="task" value="myitems" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="myitems" />
<input type="hidden" name="controller" value="myitems" />
<input type="hidden" name="c" value="myitems" />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>

</form>

<?php
}  // end force login
?>