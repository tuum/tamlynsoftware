<?php
/**
 * $Id: install.bfauction_pro.php 22 2012-03-09 07:23:15Z tuum $
 * Install file for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install()
{
	jimport( 'joomla.filesystem.file' );

	if(!file_exists(JPATH_SITE . "/images/com_bfauction_pro/")){
		JFolder::create(JPATH_SITE. "/images/com_bfauction_pro/");
	};

	if(!file_exists(JPATH_SITE. "/images/com_bfauction_pro/index.html")){
		JFile::copy(JPATH_SITE."/components/com_bfauction_pro/index.html",JPATH_SITE. "/images/com_bfauction_pro/index.html");
	};

	$db	= &JFactory::getDBO();

	//check for sample data
	$db->setQuery('SELECT `id` from `#__categories` WHERE `section`="com_bfauction_pro"');
	$result=$db->loadResult();

	if($result){
		//no need for sample data
	}else{
		//create category
		$query = "INSERT INTO `#__categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
('', 0, 'Example', '', 'example', '', 'com_bfauction_pro', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '')
		";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}

	//check if upgrade required
	$table="#__bfauction_pro";
	$fields =& $db->getTableFields( $table, true );
	if( sizeof( $fields[$table] ) ) {
		// We found some fields so let's create the HTML list
		$options = array();
		foreach( $fields[$table] as $field => $type ) {
			$options[] = JHTML::_( 'select.option', $field, $field );
		}
	}

	$table2="#__bfbid_pro";
	$fields2 =& $db->getTableFields( $table2, true );
	if( sizeof( $fields2[$table2] ) ) {
		// We found some fields so let's create the HTML list
		$options2 = array();
		foreach( $fields2[$table2] as $field => $type ) {
			$options2[] = JHTML::_( 'select.option', $field, $field );
		}
	}

	//CHECK FOR V1.0 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "productId") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `productId` int(11), ADD  `onlineStore` varchar(20), ADD  `paypalEmail` varchar(150)";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}


		$query = "ALTER TABLE `#__bfbid_pro` ADD  `email` varchar(255) NOT NULL default ''";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$query = "CREATE TABLE IF NOT EXISTS `#__bfauction_email` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$db->setQuery('SELECT @catid := max(id) from `#__categories` WHERE `section`="com_bfauction_pro"');
		$result=$db->loadResult();

		$query = "INSERT INTO `#__bfauction_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`) VALUES
			(1, @catid, 'BidConfirm', 'Your bid is confirmed {itemtitle}', 'Thank you {username} for your bid of <strong>{currency}{bid}</strong> for {description}', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1),
			(2, @catid, 'Outbid', 'You have been outbid on {itemtitle}', '<p>Unfortunately {username} you have been outbid for {description}.</p>\r\n<p> </p>\r\n<p>The auction for this item will end on {enddate}, so there may still be time to increase your bid.</p>', '2010-05-09 12:22:34', 0, '0000-00-00 00:00:00', 1, 2),
			(3, @catid, 'WinningBid', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '2011-02-20 05:19:36', 0, '0000-00-00 00:00:00', 1, 3),
			(4, @catid, 'LoosingBid', 'Sorry you didn''t win {itemid} {itemtitle} ', '<p>Unfortunately the auction for {itemid} {itemtitle} has finished and you did not win this item. Better luck next time.</p>', '2011-02-20 05:20:45', 0, '0000-00-00 00:00:00', 1, 4)
		";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$query = "CREATE TABLE IF NOT EXISTS `#__bfauction_access` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL default '',
  `uid` int(11),
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	//CHECK FOR V1.1.2 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "bidIncrement") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `bidIncrement` int(11)";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` ADD `shipping` float(10,2) NOT NULL DEFAULT '0.00'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` ADD `buyNowPrice` float(10,2) NOT NULL DEFAULT '0.00'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` CHANGE `bidIncrement` `bidIncrement` FLOAT( 10, 2 ) NOT NULL DEFAULT '1'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` CHANGE `currentBid` `currentBid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfbid_pro` CHANGE `bid` `bid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	//CHECK FOR V1.3.0 UPGRADE
	$found=0;
	foreach( $fields2[$table2] as $field => $type ) {
		if ($field == "uid") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfbid_pro` ADD `uid` int(11)";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query='ALTER TABLE `#__bfauction_pro` ADD `image2` varchar(255) NOT NULL, '
  					.' ADD `image3` varchar(255) NOT NULL,'
  					.' ADD `image4` varchar(255) NOT NULL,'
  					.' ADD `image5` varchar(255) NOT NULL';
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_access` ADD `gid` int(11)";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` ADD `uid` int(11)";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	// winEmailSent added in v1.3.0
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "winEmailSent") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `winEmailSent` tinyint(1) NOT NULL default '0', ADD `winEmailDate` datetime NOT NULL default '0000-00-00 00:00:00'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	// bidCurrency added in v1.3.0
	$found=0;
	foreach( $fields2[$table2] as $field => $type ) {
		if ($field == "bidCurrency") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfbid_pro` ADD `bidCurrency` varchar(2)";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	//check for v1.3.5 upgrade (added reserve price)
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "reservePrice") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `reservePrice` FLOAT( 10, 2 ) NOT NULL DEFAULT '0'";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		//add ReserveNotMet email data
		$db->setQuery('SELECT @catid := max(id) from `#__categories` WHERE `section`="com_bfauction_pro"');
		$result=$db->loadResult();

			$query = "INSERT INTO `#__bfauction_email` (`catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`) VALUES
			(@catid, 'ReserveNotMet', 'Reserve Price not reached for {itemtitle}', 'Unfortunately the reserve price has not been reached for this item so it was not sold.', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1)
		";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}

	//check for v1.4.0 upgrade
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "commission") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `commission` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
					ADD `tax` FLOAT( 10, 2 ) NOT NULL DEFAULT '0';
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "taxableItem") {
			$found=1;
		}
	}

	// v1.4.0 upgrade, add taxablieItem and commission
	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `taxableItem` tinyint(1) NOT NULL default '0';
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfbid_pro` ADD `commission` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
					ADD `tax` FLOAT( 10, 2 ) NOT NULL DEFAULT '0';
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	// v1.4.0 upgrade add commissionAmount
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "commissionAmount") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `commissionAmount` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  				ADD `taxAmount` FLOAT( 10, 2 ) NOT NULL DEFAULT '0';
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "priceEstimate") {
			$found=1;
		}
	}

	// v1.4.0 upgrade add some more fields, and change productId to varchar
	if($found == 0){
		$query="ALTER TABLE `#__bfauction_pro` ADD `priceEstimate` varchar(255) NOT NULL,
  					ADD `qtyAvailable` varchar(255) NOT NULL,
  					ADD `condition` varchar(255) NOT NULL,
  					ADD `buyersPremium` varchar(255) NOT NULL;
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="ALTER TABLE `#__bfauction_pro` CHANGE `productId` `productId` varchar(255) NOT NULL;";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

	//check for email sample data
	$db->setQuery('SELECT `id` FROM `#__bfauction_email`');
	$result=$db->loadResult();

	if($result){
		//no need for sample email data
	}else{
		//install email data
		$db->setQuery('SELECT @catid := max(id) from `#__categories` WHERE `section`="com_bfauction_pro"');
		$result=$db->loadResult();

		$query = "INSERT INTO `#__bfauction_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`) VALUES
			(1, @catid, 'BidConfirm', 'Your bid is confirmed {itemtitle}', 'Thank you {username} for your bid of <strong>{currency}{bid}</strong> for {description}', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1),
			(2, @catid, 'Outbid', 'You have been outbid on {itemtitle}', '<p>Unfortunately {username} you have been outbid for {description}.</p>\r\n<p> </p>\r\n<p>The auction for this item will end on {enddate}, so there may still be time to increase your bid.</p>', '2010-05-09 12:22:34', 0, '0000-00-00 00:00:00', 1, 2),
			(3, @catid, 'WinningBid', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '2011-02-20 05:19:36', 0, '0000-00-00 00:00:00', 1, 3),
			(4, @catid, 'LoosingBid', 'Sorry you didn''t win {itemid} {itemtitle} ', '<p>Unfortunately the auction for {itemid} {itemtitle} has finished and you did not win this item. Better luck next time.</p>', '2011-02-20 05:20:45', 0, '0000-00-00 00:00:00', 1, 4),
			(5, @catid, 'ReserveNotMet', 'Reserve Price not reached for {itemtitle}', 'Unfortunately the reserve price has not been reached for this item so it was not sold.', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1)
		";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}

	// v1.4.1 upgrade, add maxbid
	$found=0;
	foreach( $fields2[$table2] as $field => $type ) {
		if ($field == "maxbid") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER TABLE `#__bfbid_pro` ADD `maxbid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0';
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}

		$query="CREATE TABLE IF NOT EXISTS `#__bfauctionpro_watchlist` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `itemid` int(11) NOT NULL default '0',
  `uid` int(11),
  PRIMARY KEY  (`id`)
);
		";
		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}

?>

<div class="header"><strong>BF Auction Pro</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

                <br/>BF Auction Pro is a simple auction tool.
                <br/>
                <br/>Congratulations, you have successfully installed BF Auction Pro!
        </p>
    </td>
  </tr>
    </table>
</center>

<?php
}
?>