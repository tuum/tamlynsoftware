-- <?php /* $Id: uninstall.sql 2 2011-11-15 04:55:13Z tuum $ */ defined('_JEXEC') or die() ?>;

DROP TABLE IF EXISTS `#__bfauction_pro`;
DROP TABLE IF EXISTS `#__bfbid_pro`;
DROP TABLE IF EXISTS `#__bfauction_email`;
DROP TABLE IF EXISTS `#__bfauction_access`;
DELETE FROM `#__categories` WHERE section="com_bfauction_pro";
