<?php
/**
 * $Id: default.php 23 2012-04-04 11:59:04Z tuum $
 * BF Auction view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php
    global $mainframe;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'a.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";

	$context="";
	$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
	$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
	$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',			'word' );
	$filter_auction_status		= $mainframe->getUserStateFromRequest( $context.'filter_auction_status',		'filter_auction_status',		'',			'word' );
	$search				= $mainframe->getUserStateFromRequest( $context.'search',			'search',			'',				'string' );

	$lists = array();

	$config =& JComponentHelper::getParams( 'com_bfauction_pro' );
	$dateFormat = $config->get( 'dateFormat' );

	// build list of categories
	$javascript		= 'onchange="document.adminForm.submit();"';
	$lists['catid'] = JHTML::_('list.category',  'filter_catid', 'com_bfauction_pro', (int) $filter_catid, $javascript );

	// state filter
	$lists['state']	= JHTML::_('grid.state',  $filter_state );

	// table ordering
	$lists['order_Dir']	= $filter_order_Dir;
	$lists['order']		= $filter_order;

	// search filter
	$lists['search']= $search;
?>

<form action="index.php" method="post" name="adminForm">
<table>
	<tr>
		<td align="left" width="100%">
			<?php echo JText::_( 'COM_BFAUCTIONPRO_SEARCH_FILTER' ); ?>:
			<input type="text" name="search" id="search" value="<?php echo htmlspecialchars($lists['search']);?>" class="text_area" onchange="document.adminForm.submit();" />
			<button onclick="this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPRO_SEARCH_BUTTON_GO' ); ?></button>
			<button onclick="document.getElementById('search').value='';this.form.getElementById('filter_catid').value='0';this.form.getElementById('filter_state').value='';this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPRO_SEARCH_BUTTON_RESET' ); ?></button>
		</td>
		<td nowrap="nowrap">
			<select name="filter_auction_status" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_BFAUCTIONPRO_SELECT_AUCTION_STATUS');?></option>
				<?php echo JHtml::_('select.options', bfauction_proHelper::getOptions(), 'value', 'text', $filter_auction_status, true);?>
			</select>

			<?php
			echo $lists['catid'];
			echo $lists['state'];
			?>
		</td>
	</tr>
</table>
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ID' ); ?>
			</th>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_END_DATE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PUBLISHED' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ORDER' ); ?>
				<?php
				echo JHTML::_('grid.order',  $this->items );
				?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_HIGH_BIDDER' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CURRENT_BID' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_RESERVE_PRICE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_BID_DATE' ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction_pro&controller=item&task=edit&cid[]='. $row->id );

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center" <?php if($row->winEmailSent){ echo "class='bfsurvey_proEnded'"; } ?>>
				<?php echo strftime($dateFormat, strtotime($row->endDate) ); ?>
			</td>
			<td align="center">
				<?php echo $published;?>
			</td>
            <td class="order">
			    <span><?php echo $this->pagination->orderUpIcon($i, true, 'orderup', 'Move Up', isset($this->items[$i-1]) ); ?></span>
			    <span><?php echo $this->pagination->orderDownIcon($i, $n, true, 'orderdown', 'Move Down', isset($this->items[$i+1]) ); ?></span>

				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>
			<td align="center">
				<?php echo $row->highBidder;?>
			</td>
			<td align="center">
				<?php echo $row->currentBid;?>
			</td>
			<td align="center">
				<?php echo $row->reservePrice;?>
			</td>
			<td align="center">
				<?php
					$lastBidDate = bfauction_proController::getHighBidDate($row->id);
					if($lastBidDate){
						echo JHTML::_('date',  $lastBidDate, $dateFormat );
					}
				?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="13"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>
	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>

</form>

<div align="center">
<?php echo LiveUpdate::getIcon(); ?>
</div>