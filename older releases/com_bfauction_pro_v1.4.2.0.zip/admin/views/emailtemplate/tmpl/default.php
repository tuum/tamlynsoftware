<?php 
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * Email Template view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php
    global $mainframe;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'a.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";

	$context="";
	$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
	$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
	$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',			'word' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm.submit();"';
	$lists['catid'] = JHTML::_('list.category',  'filter_catid', 'com_bfauction_pro', (int) $filter_catid, $javascript );

	// table ordering
	$lists['order_Dir']	= $filter_order_Dir;
	$lists['order']		= $filter_order;
?>

<form action="index.php" method="post" name="adminForm">
<table>
<tr>
	<td nowrap="nowrap">
		<?php
		echo $lists['catid'];
		?>
	</td>
</tr>
</table>
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ID' ); ?>
			</th>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>
			</th>
			<th>
			    <?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_SUBJECT' ); ?>
			</th>						
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PUBLISHED' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_ORDER' ); ?>
				<?php
				echo JHTML::_('grid.order',  $this->items );
				?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction_pro&controller=emailitem&task=edit&cid[]='. $row->id );

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php echo $row->subject;?>
			</td>			
			<td align="center">
				<?php echo $published;?>
			</td>
            <td class="order">
			    <span><?php echo $this->pagination->orderUpIcon($i, true, 'orderup', 'Move Up', isset($this->items[$i-1]) ); ?></span>
			    <span><?php echo $this->pagination->orderDownIcon($i, $n, true, 'orderdown', 'Move Down', isset($this->items[$i+1]) ); ?></span>

				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="7"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="emailtemplate" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />
<input type="hidden" name="controller" value="emailtemplate" />
<input type="hidden" name="c" value="emailtemplate" />
<input type='hidden' name='view' value='emailtemplate' />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>

</form>