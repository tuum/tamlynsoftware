<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * Plugins View for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 * @author		Tim Plummer
 * @author 		This code is based on the payment plugin code from Tuan Pham Ngoc's document seller. Copyright (C) 2010 Ossolution Team
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

JToolBarHelper::title( JText::_( 'COM_BFAUCTIONPRO_TITLE_PAYMENT_PLUGIN' ), 'bfauction_pro_toolbar_title');			
JToolBarHelper::publishList('plugins_publish');
JToolBarHelper::unpublishList('plugins_unpublish');	
JToolBarHelper::deleteList( JText::_( 'COM_BFAUCTIONPRO_PLUGIN_CONFIRM_UNINSTALL'), 'uninstall_plugin', 'Uninstall');				
?>
<form action="index.php" method="post" name="adminForm" enctype="multipart/form-data">
<table>
<tr>
	<td align="left" width="100%">
		<?php echo JText::_( 'Filter' ); ?>:
		<input type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />		
		<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
		<button onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>		
	</td>	
</tr>
</table>
<div id="editcell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'NUM' ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th class="title" style="text-align: left;">
				<?php echo JHTML::_('grid.sort',  JText::_('COM_BFAUCTIONPRO_TITLE_NAME'), 'a.name', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>
			<th class="title" width="20%" style="text-align: left;">
				<?php echo JHTML::_('grid.sort', JText::_('COM_BFAUCTIONPRO_TITLE_TITLE'), 'a.title', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>			
			<th class="title" style="text-align: left;">
				<?php echo JHTML::_('grid.sort', JText::_('COM_BFAUCTIONPRO_TITLE_AUTHOR') , 'a.author', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>			
			<th class="title">
				<?php echo JHTML::_('grid.sort', JText::_('COM_BFAUCTIONPRO_TITLE_AUTHOR_EMAIL'), 'a.email', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>			
			<th>
				<?php echo JHTML::_('grid.sort', JText::_('COM_BFAUCTIONPRO_TITLE_PUBLISHED') , 'a.published', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>
			<th width="8%" nowrap="nowrap">
				<?php echo JHTML::_('grid.sort',  'Order', 'a.ordering', $this->lists['order_Dir'], $this->lists['order'] ); ?>
				<?php echo JHTML::_('grid.order',  $this->items , 'filesave.png', 'save_plugin_order' ); ?>
			</th>												
			<th>
				<?php echo JHTML::_('grid.sort', JText::_('ID') , 'a.id', $this->lists['order_Dir'], $this->lists['order'] ); ?>
			</th>
		</tr>		
	</thead>
	<tfoot>
		<tr>
			<td colspan="9">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$link 	= JRoute::_( 'index.php?option=com_bfauction_pro&task=edit_plugin&cid[]='. $row->id );
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$ordering = ($this->lists['order'] == 'a.ordering');
		$ordering = true ;
		$published 	= JHTML::_('grid.published', $row, $i, 'tick.png', 'publish_x.png', 'plugins_' );			
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $this->pagination->getRowOffset( $i ); ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>	
			<td>
				<a href="<?php echo $link; ?>">
					<?php echo $row->name; ?>
				</a>
			</td>
			<td>
				<?php echo $row->title; ?>
			</td>												
			<td>
				<?php echo $row->author; ?>
			</td>
			<td align="center">
				<?php echo $row->author_email;?>
			</td>
			<td align="center">
				<?php echo $published ; ?>
			</td>			
			<td class="order">
				<span><?php echo $this->pagination->orderUpIcon( $i, true,'orderup_plugin', 'Move Up', $ordering ); ?></span>
				<span><?php echo $this->pagination->orderDownIcon( $i, $n, true, 'orderdown_plugin', 'Move Down', $ordering ); ?></span>
				<?php $disabled = $ordering ?  '' : 'disabled="disabled"'; ?>
				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>			
			<td align="center">
				<?php echo $row->id; ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</tbody>
	</table>
	<table class="adminform" style="margin-top: 50px;">
		<tr>
			<td>
				<fieldset class="adminform">
					<legend><?php echo JText::_('COM_BFAUCTIONPRO_INSTALL_NEW_PLUGIN'); ?></legend>
					<table>
						<tr>
							<td>
								<input type="file" name="plugin_package" id="plugin_package" size="50" class="inputbox" /> <input type="button" class="button" value="<?php echo JText::_('COM_BFAUCTIONPRO_BUTTON_INSTALL'); ?>" onclick="installPlugin();" />
							</td>
						</tr>
					</table>					
				</fieldset>
			</td>
		</tr>		
	</table>
	</div>
	<input type="hidden" name="option" value="com_bfauction_pro" />
	<input type="hidden" name="task" value="show_plugins" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />	
	<?php echo JHTML::_( 'form.token' ); ?>				 
	<script type="text/javascript">
		function installPlugin() {
			var form = document.adminForm ;
			if (form.plugin_package.value =="") {
				alert("<?php echo JText::_('COM_BFAUCTIONPRO_CHOOSE_PLUGIN_TO_INSTALL'); ?>");
				return ;	
			}
			form.task.value = 'install_plugin' ;
			form.submit();
		}
	</script>
</form>