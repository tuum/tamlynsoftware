<?php
/**
 * $Id: form.php 23 2012-04-04 11:59:04Z tuum $
 * Email Item view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php defined('_JEXEC') or die('Restricted access'); ?>

		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.title.value == "") {
				alert( "<?php echo JText::_( 'COM_BFAUCTIONPRO_PLEASE_ENTER_EMAIL_TYPE', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFAUCTIONPRO_PLEASE_SELECT_CATEGORY', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_EMAIL_ITEM_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Category::This is the category that your item will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_EMAIL_TYPE' ); ?>: *
				</label>
			</td>
			<td>
			    <?php echo bfauction_proHelper::emailType( $this->bfauction_pro->title ); ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="subject">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_SUBJECT' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->subject)){
			          $this->bfauction_pro->subject="";
			       }
			    ?>
			    <input class="text_area" type="text" name="subject" id="subject" size="60" maxlength="250" value="<?php echo $this->bfauction_pro->subject;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->published)){
			          $this->bfauction_pro->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfauction_pro->published ); ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="description">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_EMAIL_BODY' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title='Description::This is the description of the item. This field can contain HTML.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfauction_pro->description)){
			          $this->bfauction_pro->description = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'description',  $this->bfauction_pro->description, '500', '300', '60', '40', array()) ; ?>
			</td>
		</tr>

	</table>

<?php
    if(!isset($this->bfauction_pro->ordering)){
	    $this->bfauction_pro->ordering = 0;
	}
?>

	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfauction_pro->ordering;?>" />

	</fieldset>
</div>

<div class="col width-35">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_HELP' ); ?></legend>

		<table class="admintable">
		<tr>
		   <td colspan=2>
		      <?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_FIELDS_REPLACED' ); ?>
		   </td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{currency}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_CURRENCY' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{bid}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_BID' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{username}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_USERNAME' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{description}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_DESCRIPTION' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{enddate}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_END_DATE' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{itemtitle}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_ITEM_TITLE' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{itemid}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_ITEMID' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{productid}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_PRODUCT_ID' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{sellername}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_SELLER_NAME' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{selleremail}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_SELLER_EMAIL' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{url}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_URL' ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				{maxbid}
			</td>
			<td>
				<?php echo JText::_( 'COM_BFAUCTIONPRO_HELP_MAXBID' ); ?>
			</td>
		</tr>
		</table>

	</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="option" value="com_bfauction_pro" />
<input type="hidden" name="id" value="<?php echo $this->bfauction_pro->id; ?>" />
<input type="hidden" name="task" value="saveemailitem" />
<input type="hidden" name="controller" value="emailitem" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>