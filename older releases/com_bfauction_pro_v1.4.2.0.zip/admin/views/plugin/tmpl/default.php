<?php
/**
 * $Id: default.php 21 2012-02-25 10:55:23Z tuum $
 * Plugins View for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 * @author		Tim Plummer
 * @author 		This code is based on the payment plugin code from Tuan Pham Ngoc's document seller. Copyright (C) 2010 Ossolution Team
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

	JHTML::_('behavior.tooltip');
		
	JToolBarHelper::title(   JText::_( 'COM_BFAUCTIONPRO_TITLE_PLUGIN' ).': <small><small>[edit]</small></small>' );
	JToolBarHelper::save('save_plugin');	
	JToolBarHelper::cancel('cancel_plugin');
	JHTML::_( 'behavior.modal' )	
?>
<script language="javascript" type="text/javascript">
	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel_plugin') {
			submitform( pressbutton );
			return;				
		} else {
			submitform( pressbutton );
		}
	}
</script>
<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col" style="float:left; width:65%">
	<fieldset class="adminform">
		<legend><?php echo JText::_('Plugin Detail'); ?></legend>
			<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo  JText::_('COM_BFAUCTIONPRO_TITLE_NAME'); ?>
					</td>
					<td>
						<?php echo $this->item->name ; ?>
					</td>
				</tr>
				<tr>
					<td width="100" align="right" class="key">
						<?php echo  JText::_('COM_BFAUCTIONPRO_TITLE_TITLE'); ?>
					</td>
					<td>
						<?php echo $this->item->title;?>
					</td>
				</tr>					
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_AUTHOR'); ?>
					</td>
					<td>
						<?php echo $this->item->author;?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_CREATION_DATE'); ?>
					</td>
					<td>
						<?php echo $this->item->creation_date; ?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_COPYRIGHT') ; ?>
					</td>
					<td>
						<?php echo $this->item->copyright; ?>
					</td>
				</tr>	
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_LICENSE'); ?>
					</td>
					<td>
						<?php echo $this->item->license; ?>
					</td>
				</tr>							
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_AUTHOR_EMAIL'); ?>
					</td>
					<td>
						<?php echo $this->item->author_email; ?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_AUTHOR_URL'); ?>
					</td>
					<td>
						<?php echo $this->item->author_url; ?>
					</td>
				</tr>				
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_VERSION'); ?>
					</td>
					<td>
						<?php echo $this->item->version; ?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_DESCRIPTION'); ?>
					</td>
					<td>
						<?php echo $this->item->description; ?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('COM_BFAUCTIONPRO_TITLE_PUBLISHED'); ?>
					</td>
					<td>
						<?php					
							echo $this->lists['published'];					
						?>						
					</td>
				</tr>
		</table>
	</fieldset>				
</div>						
<div class="col" style="float:left; width:35%">
	<fieldset class="adminform">
		<legend><?php echo JText::_('COM_BFAUCTIONPRO_PLUGIN_PARAMETERS'); ?></legend>
		<?php
			$output = $this->params->render('params') ;
			if ($output) :
				echo $output;
			else :
				echo "<div style=\"text-align: center; padding: 5px; \">".JText::_('COM_BFAUCTIONPRO_NO_PARAMETERS')."</div>";
			endif;
		?>				
	</fieldset>				
</div>
		
<div class="clr"></div>	
	<?php echo JHTML::_( 'form.token' ); ?>
	<input type="hidden" name="option" value="com_bfauction_pro" />
	<input type="hidden" name="cid[]" value="<?php echo $this->item->id; ?>" />	
	<input type="hidden" name="task" value="" />
</form>