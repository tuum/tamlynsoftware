<?php 
/**
 * $Id: form.php 21 2012-02-25 10:55:23Z tuum $
 * Email Item view for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php defined('_JEXEC') or die('Restricted access'); ?>

		<script language="javascript" type="text/javascript">
		<!--


		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.uid.value == 0 && form.gid.value==0) {
				alert( "<?php echo JText::_( 'COM_BFAUCTIONPRO_PLEASE_SELECT_USER_OR_GROUP', true ); ?>" );
			} else {
				submitform( pressbutton );
			}
		}

		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_USER_ACCESS_DETAILS' ); ?></legend>

	    <?php
		$js = "
		function jSelectUser(id, title, catid, object) {
		 	aid = document.getElementById('uid');
		 	/*if (aid.value !='') aid.value += ',';*/
			aid.value = id;
			SqueezeBox.close();
		}";
		/*
		 * CSS for article button
		 */
		$css = "
		}";
		$doc =& JFactory::getDocument();
		$doc->addScriptDeclaration($js);
		$doc->addStyleDeclaration($css);

		$link = 'administrator/index.php?option=com_bfauction_pro&task=listusers&tmpl=component';
	    ?>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfauction_pro/images/con_info.png" class="hasTip" title="Category::This is the category that your item will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="uid">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_UID' ); ?>:
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->uid)){
			          $this->bfauction_pro->uid='';
			       }
			    ?>
			    <?php JHTML::_('behavior.modal'); ?>
			    <input class="text_area" type="text" name="uid" id="uid" size="10" maxlength="11" value="<?php echo $this->bfauction_pro->uid;?>"/>
			    <a class="modal" title="<?php echo JText::_("COM_BFAUCTIONPRO_SELECT_USER");?>" href="<?php echo JUri::root().$link;?>" rel="{handler: 'iframe', size: {x: 770, y: 400}}"><img src="components/com_bfauction_pro/images/b_browse.png"/></a>			    
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="onlineStore">
					<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_GID' ); ?>
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfauction_pro->gid)){
			          $this->bfauction_pro->gid = '';
			       }
			    ?>
				<?php echo bfauction_proHelper::groupID( $this->bfauction_pro->gid ); ?>
			</td>
		</tr>				
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFAUCTIONPRO_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfauction_pro->published)){
			          $this->bfauction_pro->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfauction_pro->published ); ?>
			</td>
		</tr>
	</table>

	<?php
		if(!isset($this->bfauction_pro->ordering)){
			$this->bfauction_pro->ordering='';
		}
	?>
	<input class="inputbox" type="hidden" name="ordering" id="ordering" size="6" value="<?php echo $this->bfauction_pro->ordering;?>" />

	</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="option" value="com_bfauction_pro" />
<input type="hidden" name="id" value="<?php echo $this->bfauction_pro->id; ?>" />
<input type="hidden" name="task" value="useraccess" />
<input type="hidden" name="controller" value="useraccess" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>