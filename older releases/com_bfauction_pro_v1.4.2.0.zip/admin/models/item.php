<?php
/**
 * $Id: item.php 22 2012-03-09 07:23:15Z tuum $
 * Item Model for bfauction_pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Item Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proModelitem extends JModel
{
	var $_id = null;
	var $_data = null;

	/**
	 * Constructor that retrieves the ID from the request
	 *
	 * @access	public
	 * @return	void
	 */
	function __construct()
	{
		parent::__construct();

		$array = JRequest::getVar('cid', array(0), '', 'array');
		$edit	= JRequest::getVar('edit',true);
		if($edit)
			$this->setId((int)$array[0]);
	}

	/**
	 * Method to set the Item identifier
	 *
	 * @access	public
	 * @param	int Item identifier
	 * @return	void
	 */
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}


	/**
	 * Method to get a Item
	 * @return object with data
	 */
	function &getData()
	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__bfauction_pro '.
					'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->title = null;
		}
		return $this->_data;
	}

	/**
	 * Method to store a record
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function store()	{
		$row =& $this->getTable();

		$data = JRequest::get( 'post' );
		//allow html code in description field.
		$data['description']= JRequest::getVar( 'description', '', 'post', 'string', JREQUEST_ALLOWHTML );

		// Bind the form fields to the Item table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Set order if 0 or blank
		if ($row->ordering == "0" | $row->ordering == "" | $row->ordering==0) {
		   // get next ordering
		   $query = ' SELECT MAX(ordering) as ordering FROM #__bfauction_pro';
		   $this->_db->setQuery( $query );
		   $this->_mydata = $this->_db->loadObject();
		   $row->ordering = intval($this->_mydata->ordering)+1;
		}

		// Make sure the bfauction_pro record is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the item table to the database
		if (!$row->store()) {
			$this->setError( $this->_db->getErrorMsg() );
			return false;
		}
		$this->setId($row->id);

		return true;
	}

	/**
	 * Method to delete record(s)
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

		$row =& $this->getTable();

		if (count( $cids ))		{
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}

/**
 * @author		Tim Plummer
 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
 */
    function save($post,$files,$config,$model)
    {
    	$app = &JFactory::getApplication();

    	$conf = "";
		$conf->max_width = $config->get( 'max_width' );
		$conf->max_height = $config->get( 'max_height' );
		$conf->max_width_t = $config->get( 'max_width_t' );
		$conf->max_height_t = $config->get( 'max_height_t' );
		$conf->max_image_size = $config->get( 'max_image_size' );

		for($i = 1; $i < 6; $i++){
			// image5 delete
			if ( $post['d_img'.$i] == "delete") {
				$pict = JPATH_SITE."/images/com_bfauction_pro/".$this->_id."img".$i.".jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
				$pict = JPATH_SITE."/images/com_bfauction_pro/".$this->_id."img".$i."_t.jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
			}

			if (isset( $files['img'.$i])) {
				if ( $files['img'.$i]['size'] > $conf->max_image_size) {
					$app->redirect("index.php?option=com_bfauction_pro&view=bfauction_pro", JText::_('COM_BFAUCTIONPRO_IMAGETOOBIG'));
					return;
				}
			}

			// image5 upload
			if (isset( $files['img'.$i]) and !$files['img'.$i]['error'] ) {
				$path= JPATH_SITE."/images/com_bfauction_pro/";
				$model->createImageAndThumb($files['img'.$i]['tmp_name'],
											$this->_id."img".$i.".jpg",
											$this->_id."img".$i."_t.jpg",
											$conf->max_width,
											$conf->max_height,
											$conf->max_width_t,
											$conf->max_height_t,
											"",
											$path,
											$files['img'.$i]['name']);
			}
		}

		$app->redirect("index.php?option=com_bfauction_pro&view=bfauction_pro");
    }

/**
 * @author		Tim Plummer
 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
 */
	function createImageAndThumb($src_file,$image_name,$thumb_name,
								$max_width,
							    $max_height,
								$max_width_t,
								$max_height_t,
								$tag,
								$path,
								$orig_name)
	{
		if (intval(ini_get('memory_limit')) < 64)
			ini_set('memory_limit', '64M');

		$src_file = urldecode($src_file);

		$orig_name = strtolower($orig_name);
		$findme  = '.jpg';
		$pos = strpos($orig_name, $findme);
		if ($pos === false)
		{
			$findme  = '.jpeg';
			$pos = strpos($orig_name, $findme);
			if ($pos === false)
			{
				$findme  = '.gif';
				$pos = strpos($orig_name, $findme);
				if ($pos === false)
				{
					$findme  = '.png';
					$pos = strpos($orig_name, $findme);
					if ($pos === false)
					{
						return;
					}
					else
					{
						$type = "png";
					}
				}
				else
				{
					$type = "gif";
				}
			}
			else
			{
				$type = "jpeg";
			}
		}
		else
		{
			$type = "jpeg";
		}

		$max_h = $max_height;
		$max_w = $max_width;
		$max_thumb_h = $max_height_t;
		$max_thumb_w = $max_width_t;

		if ( file_exists( "$path/$image_name")) {
			unlink( "$path/$image_name");
		}

		if ( file_exists( "$path/$thumb_name")) {
			unlink( "$path/$thumb_name");
		}

		$read = 'imagecreatefrom' . $type;
		$write = 'image' . $type;

		$src_img = $read($src_file);

		// height/width
		$imginfo = getimagesize($src_file);
		$src_w = $imginfo[0];
		$src_h = $imginfo[1];

		$zoom_h = $max_h / $src_h;
	    $zoom_w = $max_w / $src_w;
	    $zoom   = min($zoom_h, $zoom_w);
	    $dst_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
	    $dst_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$zoom_h = $max_thumb_h / $src_h;
	    $zoom_w = $max_thumb_w / $src_w;
	    $zoom   = min($zoom_h, $zoom_w);
	    $dst_thumb_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
	    $dst_thumb_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$dst_img = imagecreatetruecolor($dst_w,$dst_h);
		$white = imagecolorallocate($dst_img,255,255,255);
		imagefill($dst_img,0,0,$white);
		imagecopyresampled($dst_img,$src_img, 0,0,0,0, $dst_w,$dst_h,$src_w,$src_h);
		if($type == 'jpeg'){
	        $desc_img = $write($dst_img,"$path/$image_name", 75);
		}else{
	        $desc_img = $write($dst_img,"$path/$image_name", 2);
		}

		imagedestroy($dst_img);

		$dst_t_img = imagecreatetruecolor($dst_thumb_w,$dst_thumb_h);
		$white = imagecolorallocate($dst_t_img,255,255,255);
		imagefill($dst_t_img,0,0,$white);
		imagecopyresampled($dst_t_img,$src_img, 0,0,0,0, $dst_thumb_w,$dst_thumb_h,$src_w,$src_h);
		if($type == 'jpeg'){
	        $desc_img = $write($dst_t_img,"$path/$thumb_name", 75);
		}else{
	        $desc_img = $write($dst_t_img,"$path/$thumb_name", 2);
		}

		imagedestroy($dst_t_img);
	}

}
?>
