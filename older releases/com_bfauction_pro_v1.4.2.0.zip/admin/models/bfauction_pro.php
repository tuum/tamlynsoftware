<?php
/**
 * $Id: bfauction_pro.php 21 2012-02-25 10:55:23Z tuum $
 * Default Model for bfauction_pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * bfauction_pro Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proModelbfauction_pro extends JModel
{
	/**
	 * Item data array
	 *
	 * @var array
	 */
	var $_data;

	 /**
	  * Items total
	  * @var integer
	  */
	 var $_total = null;

	 /**
	  * Pagination object
	  * @var object
	  */
	 var $_pagination = null;



	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
		global $mainframe;
	    $db =& JFactory::getDBO();
	    $context="";
	    $filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',				'word' );
	    $filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
		$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
		$filter_auction_status		= $mainframe->getUserStateFromRequest( $context.'filter_auction_status',		'filter_auction_status',		'',			'word' );
		$search				= $mainframe->getUserStateFromRequest( $context.'search',			'search',			'',				'string' );

		if (strpos($search, '"') !== false) {
			$search = str_replace(array('=', '<'), '', $search);
		}
		$search = JString::strtolower($search);

		if($filter_order=='a.name' ){
			$filter_order = 'a.title';
		}

		$where = array();

		if ($filter_catid) {
			$where[] = 'cc.id = ' . (int) $filter_catid;
		}
		if ($search) {
			$where[] = '(LOWER(a.title) LIKE '.$db->Quote( '%'.$db->getEscaped( $search, true ).'%', false ).'OR LOWER(a.description) LIKE '.$db->Quote( '%'.$db->getEscaped( $search, true ).'%', false ).')';
		}
		if ( $filter_state ) {
			if ( $filter_state == 'P' ) {
				$where[] = 'a.published = 1';
			} else if ($filter_state == 'U' ) {
				$where[] = 'a.published = 0';
			}
		}
		if($filter_auction_status == ""){
			// do nothing because we want to show all
		}else if($filter_auction_status == "Ended") {
			$where[] = 'a.winEmailSent > 0';
		}else{
			$where[] = 'a.winEmailSent = 0';
		}

		$where		= count( $where ) ? ' WHERE ' . implode( ' AND ', $where ) : '';
		$orderby	= ' ORDER BY '. $filter_order .' '. $filter_order_Dir .', a.ordering';


		$query = 'SELECT a.*,  cc.title AS category_name'
						. ' FROM #__bfauction_pro AS a'
						. ' LEFT JOIN #__categories AS cc ON cc.id = a.catid'
						. $where
						. $orderby
		;

		return $query;
	}

	/**
	 * Retrieves the data
	 * @return array Array of objects containing the data from the database
	 */
	function getData()
	{
		// if data hasn't already been obtained, load it
		if (empty($this->_data)) {
		    $query = $this->_buildQuery();
		    $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_data;

	}


	function __construct()
	  {
	 	parent::__construct();

		global $mainframe, $option;

		// Get pagination request variables
		$limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);

	    $filter_ord = $mainframe->getUserStateFromRequest($option.'filter_order', 'filter_order', 'orderdate');
		$filter_ord_Dir = strtoupper($mainframe->getUserStateFromRequest($option.'filter_order_Dir', 'filter_order_Dir', 'DESC' ));
	  }

      function getTotal()
	    {
	   	// Load the content if it doesn't already exist
	   	if (empty($this->_total)) {
	   	    $query = $this->_buildQuery();
	   	    $this->_total = $this->_getListCount($query);
	   	}
	   	return $this->_total;
	  }

      function getPagination()
	    {
	   	// Load the content if it doesn't already exist
	   	if (empty($this->_pagination)) {
	   	    jimport('joomla.html.pagination');
	   	    $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
	   	}
	   	return $this->_pagination;
	  }

}
