<?php
/**
 * $Id: helper.php 21 2012-02-25 10:55:23Z tuum $
 * Helper for bfauction_pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.html.toolbar');

class bfauction_proHelper
{
	/**
	* build the select list for online store
	*/
	function onlineStore( &$onlineStore )
	{

		$click[] = JHTML::_('select.option',  'None', JText::_( 'COM_BFAUCTIONPRO_NONE' ) );
		//$click[] = JHTML::_('select.option',  'VirtueMart', JText::_( 'COM_BFAUCTIONPRO_VIRTUEMART' ) );
		//$click[] = JHTML::_('select.option',  'Oscommerce', JText::_( 'COM_BFAUCTIONPRO_OSCOMMERCE' ) );
		$click[] = JHTML::_('select.option',  'PayPal', JText::_( 'COM_BFAUCTIONPRO_PAYPAL' ) );

		if($onlineStore == null){
		   $onlineStore="None";
		}

		$target = JHTML::_('select.genericlist',   $click, 'onlineStore', 'class="inputbox" size="3"', 'value', 'text',  $onlineStore );

		return $target;
	}

	/**
	* build the select list for email type
	*/
	function emailType( &$title )
	{

		$click[] = JHTML::_('select.option',  'BidConfirm', JText::_( 'COM_BFAUCTIONPRO_BIDCONFIRM' ) );
		$click[] = JHTML::_('select.option',  'Outbid', JText::_( 'COM_BFAUCTIONPRO_OUTBID' ) );
		$click[] = JHTML::_('select.option',  'WinningBid', JText::_( 'COM_BFAUCTIONPRO_WINNING_BID' ) );
		$click[] = JHTML::_('select.option',  'LoosingBid', JText::_( 'COM_BFAUCTIONPRO_LOOSING_BID' ) );
		$click[] = JHTML::_('select.option',  'BuyNow', JText::_( 'COM_BFAUCTIONPRO_BUYNOW_BID' ) );
		$click[] = JHTML::_('select.option',  'ReserveNotMet', JText::_( 'COM_BFAUCTIONPRO_RESERVE_NOT_MET' ) );

		if($title == null){
		   $title="BidConfirm";
		}

		$target = JHTML::_('select.genericlist',   $click, 'title', 'class="inputbox" size="6"', 'value', 'text',  $title );

		return $target;
	}

	/**
	* build the select list for group id
	*/
	function groupID( &$gid )
	{

		$db = JFactory::getDbo();
		$db->setQuery(
		 'SELECT DISTINCT map.group_id as gid, groups.name as mygroup'.
		 ' FROM #__core_acl_groups_aro_map AS map'.
		 ' LEFT JOIN #__core_acl_aro_groups AS groups on map.group_id=groups.id'
		);

		$result = $db->loadObjectList();

		if ($error = $db->getErrorMsg()) {
			$this->setError($error);
			return false;
		}


		for($i=0; $i < count($result); $i++){
			$click[] = JHTML::_('select.option',  $result[$i]->gid, $result[$i]->mygroup );
		}

		$target = JHTML::_('select.genericlist',   $click, 'gid', 'class="inputbox" size="5"', 'value', 'text',  $gid );

		return $target;
	}
 	
    /* Front end toolbar */
 	function getToolbar() {
 		$bar = new JToolBar( JText::_( 'COM_BFAUCTIONPRO_TOOLBAR_ITEM' ) );
 		$bar->appendButton( 'Standard', 'save', 'Save', 'save', false );
 		$bar->appendButton( 'Separator' );
 		$bar->appendButton( 'Standard', 'cancel', 'Close', 'cancel', false );
 
 		return $bar->render();
 	}
 
    function orderList($title)
    {
    	$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFAUCTIONPRO_ORDER_SORT_BY' ) );
    	$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFAUCTIONPRO_ORDER_TIME_ASC' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFAUCTIONPRO_ORDER_TIME_NEW' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFAUCTIONPRO_ORDER_PRICE_ASC' ) );
		$click[] = JHTML::_('select.option',  '4', JText::_( 'COM_BFAUCTIONPRO_ORDER_PRICE_DESC' ) );
		
		if($title == null){
		   $title="0";
		}

		$javascript		= 'onchange="document.adminForm2.submit();"'; 
		$target = JHTML::_('select.genericlist',   $click, 'filter_sort', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $title );
		return $target;        
    } 	

    function filterList($title)
    {
    	$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFAUCTIONPRO_FILTER_FILTER' ) );
    	$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFAUCTIONPRO_FILTER_BUY_NOW' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFAUCTIONPRO_FILTER_BID_ONLY' ) );
		
		if($title == null){
		   $title="0";
		}

		$javascript		= 'onchange="document.adminForm2.submit();"'; 
		$target = JHTML::_('select.genericlist',   $click, 'filter_filter', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $title );
		return $target;
    }
	
	/**
	 * Display Copyright information
	 * 
	 */
	function displayVersion() {
		global $bfauctionpro_version ;
		echo '<div class="copyright" style="text-align:center;margin-top: 5px;">'.JText::_( 'COM_BFAUCTIONPRO_VERSION').' <strong>'.$bfauctionpro_version.'</strong></div>' ;
	}
	
	public function getOptions()
	{
   		$options = array();
			
		$options[] = JHTML::_('select.option',  'Active', JText::_( 'COM_BFAUCTIONPRO_ACTIVE' ) );
		$options[] = JHTML::_('select.option',  'Ended', JText::_( 'COM_BFAUCTIONPRO_ENDED' ) );

		return $options;
	}	    
}