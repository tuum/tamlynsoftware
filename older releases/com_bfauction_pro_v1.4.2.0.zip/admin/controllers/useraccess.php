<?php
/**
 * $Id: useraccess.php 21 2012-02-25 10:55:23Z tuum $
 * User Access Controller for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * Email Template Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proControlleruseraccess extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
		bfauction_proHelper::displayVersion();
	}
	
	function useraccess()
	{
		JRequest::setVar( 'view', 'useraccess' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_proHelper::displayVersion();
	}		

	/**
	* email item view
	*/
	function user()
	{
		JRequest::setVar( 'view', 'user' );
		JRequest::setVar( 'layout', 'form'  );

		parent::display();
		bfauction_proHelper::displayVersion();
	}	

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'user' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
		bfauction_proHelper::displayVersion();
	}	
	
	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfauction_proControlleruseraccess::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfauction_proControlleruseraccess::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_( 'COM_BFAUCTIONPRO_INVALID_TOKEN') );

		$db 		=& JFactory::getDBO();
		$user 		=& JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_NO_ITEMS_SELECTED') );
			$mainframe->redirect( 'index.php?option='. $option .'&task=useraccess&controller=useraccess' );
		}

		$cids = implode( ',', $cid );

		$query = 'UPDATE #__bfauction_access'
		. ' SET published = '.(int) $publish
		. ' WHERE id IN ( '. $cids .' )'
		. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )'
		;
		$db->setQuery( $query );
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg() );
		}

		$mainframe->redirect( 'index.php?option='. $option .'&task=useraccess&controller=useraccess' );
    }


	/**
	* Moves the record up one position
	*/
	function moveUpQuestion(  ) {
		bfauction_proControlleruseraccess::orderQuestion( -1 );
	}

	/**
	* Moves the record down one position
	*/
	function moveDownQuestion(  ) {
		bfauction_proControlleruseraccess::orderQuestion( 1 );
	}

	/**
	* Moves the order of a record
	* @param integer The direction to reorder, +1 down, -1 up
	*/
	function orderQuestion( $inc )
	{
		global $mainframe;

	    JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfauction_pro'.DS.'tables');
		$row =& JTable::getInstance('user', 'Table');

		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar('cid', array(0), '', 'array');
		$option = JRequest::getCmd('option');
		JArrayHelper::toInteger($cid, array(0));

		$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
		$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
		$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

		$row =& JTable::getInstance( 'user', 'Table' );
		$row->load( $cid[0] );
		$row->move( $inc, 'catid = '.(int) $row->catid.' AND published != 0' );

		$mainframe->redirect( 'index.php?option='. $option .'&task=useraccess&controller=useraccess' );
	}

	function saveOrder( )
	{
		$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_( 'COM_BFAUCTIONPRO_INVALID_TOKEN') );

		// Initialize variables
		$db			=& JFactory::getDBO();
		$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
		$total		= count( $cid );
		JArrayHelper::toInteger($order, array(0));

		$row =& JTable::getInstance('user', 'Table');
		$groupings = array();

		// update ordering values
		for( $i=0; $i < $total; $i++ ) {
			$row->load( (int) $cid[$i] );
			// track categories
			$groupings[] = $row->catid;

			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				if (!$row->store()) {
					JError::raiseError(500, $db->getErrorMsg() );
				}
			}
		}

		// execute updateOrder for each parent group
		$groupings = array_unique( $groupings );
		foreach ($groupings as $group){
			$row->reorder('catid = '.(int) $group);
		}

		$msg 	= JText::_( 'COM_BFAUCTIONPRO_NEW_ORDERING_SAVED');
		$mainframe->redirect( 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess', $msg );
	}
	
	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('user');
		$post	= JRequest::get('post');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFAUCTIONPRO_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPRO_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('user');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFAUCTIONPRO_ERROR_DELETED_USER' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPRO_DELETED_USER' );
		}

		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFAUCTIONPRO_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess', $msg );
	}

	/**
	  Copies one or more item
	 */
	function copy()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_( 'COM_BFAUCTIONPRO_INVALID_TOKEN') );

		$this->setRedirect( 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();

		$table	=& JTable::getInstance('user', 'Table');

		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->published 			= 0;
					$table->ordering 			= 0;

					$now =& JFactory::getDate();
					$table->date			= $now->toMySQL();

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}else{
					return JError::raiseWarning( 500, $table->getError() );
			    }
			}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFAUCTIONPRO_ITEMS_COPIED', $n ) );
	}
	
	
}
?>