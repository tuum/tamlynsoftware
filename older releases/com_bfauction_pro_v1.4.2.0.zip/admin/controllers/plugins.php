<?php
/**
 * $Id: plugins.php 21 2012-02-25 10:55:23Z tuum $
 * Plugins Controller for BF Auction Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 * @author		Tim Plummer
 * @author 		This code is based on the payment plugin code from Tuan Pham Ngoc's document seller. Copyright (C) 2010 Ossolution Team
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * Email Template Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_proControllerPlugins extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
		bfauction_proHelper::displayVersion();
	}
	
	/**
	 * method to display the plugins view
	 */
	function plugins()
	{
		JRequest::setVar('view', 'plugins');
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_proHelper::displayVersion();
	}

	/**
	 * method to display the plugin view
	 */
	function plugin()
	{
		JRequest::setVar('view', 'plugin');
		JRequest::setVar('hidemainmenu', 1);
		JRequest::setVar('edit', true);
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_proHelper::displayVersion();
	}	
	
}