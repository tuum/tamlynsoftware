-- <?php /* $Id: install.sql 21 2012-02-25 10:55:23Z tuum $ */ defined('_JEXEC') or die() ?>;

CREATE TABLE IF NOT EXISTS `#__bfauction_pro` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL,
  `description` text,
  `currentBid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `highBidder` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `endDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `itemLocation` varchar(255) NOT NULL,
  `deliveryMethod` varchar(255) NOT NULL, 
  `image` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `image4` varchar(255) NOT NULL,
  `image5` varchar(255) NOT NULL,
  `productId` varchar(255) NOT NULL,
  `onlineStore` varchar(20),
  `paypalEmail` varchar(150),
  `bidIncrement` FLOAT( 10, 2 ) NOT NULL DEFAULT '1',
  `shipping` float(10,2) NOT NULL DEFAULT '0.00',
  `buyNowPrice` float(10,2) NOT NULL DEFAULT '0.00',
  `winEmailSent` tinyint(1) NOT NULL default '0',
  `winEmailDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `uid` int(11),
  `reservePrice` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `commission` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `tax` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `taxableItem` tinyint(1) NOT NULL default '0', 
  `commissionAmount` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `taxAmount` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `priceEstimate` varchar(255) NOT NULL,       
  `qtyAvailable` varchar(255) NOT NULL,
  `condition` varchar(255) NOT NULL,
  `buyersPremium` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
);


CREATE TABLE IF NOT EXISTS `#__bfbid_pro` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `itemid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL default '',
  `uid` int(11),  
  `email` varchar(255) NOT NULL default '',
  `bid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `bid_time` datetime NOT NULL default '0000-00-00 00:00:00', 
  `bidCurrency` varchar(2),
  `commission` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `tax` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  `maxbid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
);


CREATE TABLE IF NOT EXISTS `#__bfauction_email` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL,  
  `subject` varchar(255) NOT NULL,
  `description` text,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `#__bfauction_access` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL default '',
  `uid` int(11),
  `gid` int(11),    
  `date` datetime NOT NULL default '0000-00-00 00:00:00',  
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',  
  PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `#__bfauctionpro_payment_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `creation_date` varchar(50) DEFAULT NULL,
  `copyright` varchar(100) DEFAULT NULL,
  `license` varchar(255) DEFAULT NULL,
  `author_email` varchar(50) DEFAULT NULL,
  `author_url` varchar(100) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `description` text,
  `params` text,
  `ordering` int(11) DEFAULT NULL,
  `published` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `#__bfauctionpro_watchlist` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `itemid` int(11) NOT NULL default '0',
  `uid` int(11),
  PRIMARY KEY  (`id`)
);