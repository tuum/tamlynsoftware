<?php
/**
 * $Id: admin.bfauction_pro.php 23 2012-04-04 11:59:04Z tuum $
 * Default entry point file for bfauction_pros component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
global $bfauctionpro_version;
$bfauctionpro_version =  '1.4.2.0';

require_once( JPATH_COMPONENT.DS.'controller.php' );

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'liveupdate'.DS.'liveupdate.php';
if(JRequest::getCmd('view','') == 'liveupdate'){
	LiveUpdate::handleRequest();
	return;
}

// Set the table directory
JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfauction_pro'.DS.'tables');

// Require specific controller if requested
if($controller = JRequest::getWord('controller')) {
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    if (file_exists($path)) {
        require_once $path;
    } else {
        $controller = '';
    }
}

if(JRequest::getCmd('task') == 'category') {
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_ITEMS'), 'index.php?option=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_CATEGORIES'), 'index.php?option=com_categories&section=com_bfauction_pro',true);
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_EMAIL_TEMPLATE'), 'index.php?option=com_bfauction_pro&task=emailtemplate&controller=emailtemplate');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_USER_ACCESS_CONTROL'), 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_PAYMENT_PLUGINS'), 'index.php?option=com_bfauction_pro&task=plugins&controller=plugins&view=plugins');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_LIVE_UPDATE'), 'index.php?option=com_bfauction_pro&view=liveupdate');
}else if(JRequest::getCmd('task') == 'emailtemplate' | JRequest::getCmd('task') == 'emailitem') {
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_ITEMS'), 'index.php?option=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_CATEGORIES'), 'index.php?option=com_categories&section=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_EMAIL_TEMPLATE'), 'index.php?option=com_bfauction_pro&task=emailtemplate&controller=emailtemplate',true);
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_USER_ACCESS_CONTROL'), 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_PAYMENT_PLUGINS'), 'index.php?option=com_bfauction_pro&task=plugins&controller=plugins&view=plugins');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_LIVE_UPDATE'), 'index.php?option=com_bfauction_pro&view=liveupdate');
}else if(JRequest::getCmd('task') == 'useraccess' | JRequest::getCmd('task') == 'user' ) {
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_ITEMS'), 'index.php?option=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_CATEGORIES'), 'index.php?option=com_categories&section=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_EMAIL_TEMPLATE'), 'index.php?option=com_bfauction_pro&task=emailtemplate&controller=emailtemplate');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_USER_ACCESS_CONTROL'), 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess',true);
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_PAYMENT_PLUGINS'), 'index.php?option=com_bfauction_pro&task=plugins&controller=plugins&view=plugins');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_LIVE_UPDATE'), 'index.php?option=com_bfauction_pro&view=liveupdate');
}else if(JRequest::getCmd('task') == 'plugin' | JRequest::getCmd('task') == 'plugins' | JRequest::getCmd('task') == 'show_plugins' | JRequest::getCmd('task') == 'edit_plugin' ) {
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_ITEMS'), 'index.php?option=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_CATEGORIES'), 'index.php?option=com_categories&section=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_EMAIL_TEMPLATE'), 'index.php?option=com_bfauction_pro&task=emailtemplate&controller=emailtemplate');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_USER_ACCESS_CONTROL'), 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_PAYMENT_PLUGINS'), 'index.php?option=com_bfauction_pro&task=plugins&controller=plugins&view=plugins',true);
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_LIVE_UPDATE'), 'index.php?option=com_bfauction_pro&view=liveupdate');
}else{
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_ITEMS'), 'index.php?option=com_bfauction_pro',true);
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_CATEGORIES'), 'index.php?option=com_categories&section=com_bfauction_pro');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_EMAIL_TEMPLATE'), 'index.php?option=com_bfauction_pro&task=emailtemplate&controller=emailtemplate');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_USER_ACCESS_CONTROL'), 'index.php?option=com_bfauction_pro&task=useraccess&controller=useraccess');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_PAYMENT_PLUGINS'), 'index.php?option=com_bfauction_pro&task=plugins&controller=plugins&view=plugins');
   JSubMenuHelper::addEntry(JText::_('COM_BFAUCTIONPRO_MENU_LIVE_UPDATE'), 'index.php?option=com_bfauction_pro&view=liveupdate');
}

$document =& JFactory::getDocument();
$cssFile = './components/com_bfauction_pro/css/bfauction_pro.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

require_once( JPATH_COMPONENT.DS.'helpers'.DS.'helper.php' );

// Create the controller
$classname	= 'bfauction_proController'.$controller;
$controller = new $classname( );

// Check the task parameter and execute appropriate function
switch( JRequest::getCmd('task')) {
    case "cancel":
        $controller->cancel();
        break;
    case "edit":
	    $controller->edit();
    	break;
    case "add":
    	$controller->edit();
    	break;
    case "save":
    	$controller->save();
    	break;
    case 'remove':
    	$controller->remove();
    	break;
    case 'publish':
		$controller->publishQuestion( );
		break;
	case 'unpublish':
		$controller->unPublishQuestion( );
		break;
    case 'orderup':
		$controller->moveUpQuestion( );
		break;
	case 'orderdown':
		$controller->moveDownQuestion( );
		break;
	case 'saveorder':
		$controller->saveOrder( );
		break;
	case 'choose_css':
	    $controller->chooseCSS( );
	    break;
	case 'edit_css':
		$controller->editCSS();
		break;
    case 'save_css':
    	$controller->saveCSS();
    	break;
    case 'category':
		$controller->category();
    	break;
    case 'copy':
		$controller->copy();
    	break;
    case "show":
		$controller->show();
    	break;
    case "setdefault":
        $controller->setdefault();
        break;
    case "emailtemplate":
        $controller->emailtemplate();
        break;
    case "saveemailitem":
        $controller->saveemailitem();
        break;
	case "useraccess":
        $controller->useraccess();
        break;
	case "listusers":
        $controller->listusers();
        break;
	case "show_plugins":
        $controller->plugins();
        break;
	case "edit_plugin":
		$controller->plugin();
		break;
	case "install_plugin":
		$controller->install_plugin();
		break;
	case "save_plugin":
		$controller->save_plugin();
		break;
	case "uninstall_plugin":
		$controller->uninstall_plugin();
		break;
	case "plugins_publish":
		$controller->plugins_publish();
		break;
	case "plugins_unpublish":
		$controller->plugins_unpublish();
		break;
	case "save_plugin_order":
		$controller->save_plugin_order();
		break;
	case "orderup_plugin":
		$controller->orderup_plugin();
		break;
	case "orderdown_plugin":
		$controller->orderdown_plugin();
		break;
	case "cancel_plugin":
		$controller->cancel_plugin();
		break;
    default:
        $controller->display();
        break;
}

// Redirect if set by the controller
$controller->redirect();

?>
