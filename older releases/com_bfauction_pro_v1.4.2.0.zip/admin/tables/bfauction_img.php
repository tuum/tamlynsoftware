<?php
/**
 * $Id: bfauction_img.php 2 2011-11-15 04:55:13Z tuum $
 * BF Auction Image table class
 *
 * @package    Joomla
 * @subpackage Components
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');

class Tablebfauction_img extends JTable
{
	/** @var int */
	var $id = null;
	
	/** @var text */
	var $description = null;
	
	/** @var tinyint */
	var $published = null;
	
	/** @var int */
	var $ordering = null;
	var $gallery_id = null;
	
	/** @var varchar(128) */
	var $filename = null;
	
	/** @var int */
	var $filesize = null;
	var $lightbox_width = null;
	var $lightbox_height = null;
	var $width = null;
	var $height = null;
	
	/** @var varchar(255) */
	var $link = null;
	
	/** @var int */
	var $target_blank = null;
	var $access = null;
	var $thumb_width = null;
	var $thumb_height = null;
	var $lightbox_thumb_width = null;
	var $lightbox_thumb_height = null;
	
	/** @var varchar(255) */
	var $alt_text = null;
	
	function Tablebfauction_img(& $db) 
	{
		parent::__construct('#__bfauction_img', 'id', $db);
	}

}
?>
