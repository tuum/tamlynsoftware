<?php
/**
 * $Id: plugin.php 21 2012-02-25 10:55:23Z tuum $
 * Plugin table class
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');


/**
 * Plugin Table class
 *
 * @package    Joomla
 * @subpackage Components
 */
class TablePlugin extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null ;
	/**
	 * name
	 *
	 * @var string
	 */
	var $name = null;		
	/**
	 * Title of the image
	 *
	 * @var string
	 */
	var $title = null;
	/**
	 * Author of the plugin
	 *
	 * @var string
	 */
	var $author = null ;	
	/**
	 * Creation Date
	 *
	 * @var string
	 */
	var $creation_date = null ;
	/**
	 * Copyright
	 *
	 * @var string
	 */
	var $copyright = null ;
	/**
	 * License
	 *
	 * @var string
	 */
	var $license = null;
	/**
	 * Author email
	 *
	 * @var string
	 */
	var $author_email =  null;
	/**
	 * Authro url
	 *
	 * @var string
	 */
	var $author_url = null;
	/**
	 * Plugin version
	 *
	 * @var string
	 */
	var $version =  null;
	/**
	 * Description
	 *
	 * @var string
	 */
	var $description = null;
	/**
	 * Plugin parameters
	 *
	 * @var string
	 */
	var $params = null;	
	/**
	 * Plugin ordering
	 *
	 * @var int
	 */
	var $ordering = null ;
	/**
	 * Published
	 *
	 * @var tinyint
	 */	
	var $published = 0;
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.5
	 */
	function __construct(& $db) {
		parent::__construct('#__bfauctionpro_payment_plugins', 'id', $db);
	}
}