<?php
/**
 * $Id: item.php 22 2012-03-09 07:23:15Z tuum $
 * Item table class
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');


/**
 * Item Table class
 *
 * @package    Joomla
 * @subpackage Components
 */
class Tableitem extends JTable
{
	/** Primary Key @var int */
	var $id = null;

    /** @var int */
	var $catid				= null;
	var $uid				= 0;

	/** @var string */
	var $title 				= '';
	var $highBidder			= '';

	/** @var TEXT */
	var $description 		= null;

	/** @var float(10,2) */
	var $currentBid			= 0;
	var $reservePrice		= 0;
	var $tax				= 0;
	var $commission			= 0;
	var $taxAmount			= 0;
	var $commissionAmount	= 0;

	/** @var date */
	var $date				= null;

	/** @var time */
	var $endDate			= 0;

	/** @var string */
	var $checked_out		= 0;

	/** @var time */
	var $checked_out_time	= 0;

	/** @var boolean */
	var $published			= 0;
	var $taxableItem		= 0;

	/** @var int(11) */
    var $ordering			= 0;

	/** @var varchar(255) */
	var $itemLocation		= '';
	var $deliveryMethod		= '';
	var $image				= '';
	var $image2				= '';
	var $image3				= '';
	var $image4				= '';
	var $image5				= '';
	var $productId			= '';
	var $priceEstimate		= '';
	var $qtyAvailable		= '';
	var $condition			= '';
	var $buyersPremium		= '';

	/* @var varchar(20) */
  	var $onlineStore 		= '';

  	/* @var varchar(150) */
  	var $paypalEmail 		= '';

  	/* @var float(10,2) */
  	var $bidIncrement		= 0;

  	/* @var float(10,2)	 */
  	var $shipping			= 0;
  	var $buyNowPrice		= 0;

  	/** @var boolean */
	var $winEmailSent			= 0;

	/** @var time */
	var $winEmailDate	= 0;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function Tableitem(& $db) {
		parent::__construct('#__bfauction_pro', 'id', $db);

		$now =& JFactory::getDate();
		$this->set( 'date', $now->toMySQL() );

		$user = &JFactory::getUser();
		$this->set( 'uid', (int)$user->id );
	}
}
?>
