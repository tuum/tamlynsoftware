<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die();

jimport('joomla.html.html.bootstrap');

/* Override the parameters when specifically set in the auction item */
if ($this->form->getValue('commissionAmount') > 0) {
	$this->cparams->commissionAmount = $this->form->getValue('commissionAmount');
}
if ($this->form->getValue('taxAmount') > 0) {
	$this->cparams->taxAmount = $this->form->getValue('taxAmount');
}
if ($this->form->getValue('bidIncrement') > 0) {
	$this->cparams->bidIncrement = $this->form->getValue('bidIncrement');
}
/* End overrides */

$bfcurrency 		 = $this->cparams->bfcurrency;
$currencySymbolAfter = $this->cparams->currencySymbolAfter;
$currencyLeft 		 = $currencySymbolAfter ? '' : $bfcurrency;
$currencyRight		 = $currencySymbolAfter ? $bfcurrency : '';

/* Get some default values */
$endDate = $this->form->getValue('endDate');
$taxableItem = $this->form->getValue('taxableItem');
$currentDate = JFactory::getDate()->format('Y-m-d H:i:s');
$quantityPurchased = $this->form->getValue('quantityPurchased');
if ($quantityPurchased < 1) {
	$quantityPurchased = 1;
}
/* End get some default values */

$user = JFactory::getUser();

//AJAX code located in /components/com_bfauction/assets/ajax.php
//executes the luCurrentBid page from the server (located in /dispatcher.php)
require_once(JPATH_COMPONENT . '/assets/ajax.php');

$itemid = JRequest::getVar('Itemid');

$grid = JRequest::getVar('grid', 0, '', 'int');
if ($user->id == 0) {
	JError::raiseWarning(403, JText::_('COM_BFAUCTION_YOU_MUST_LOG_IN'));
	$id = $this->form->getValue('bfauction_item_id');
	if (!$id) {
		$id = JRequest::getVar('id', 0, '', 'int');
	}
	$redirectUrl = base64_encode("index.php?option=com_bfauction&view=auction&id=" . (int)$id . "&grid=" . (int)$grid . "&Itemid=" . (int)$itemid);
	$redirectUrl = '&return=' . $redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
	$finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<a href='" . JRoute::_($finalUrl) . "'>" . JText::_('COM_BFAUCTION_AUCTION_LOG_IN') . "</a><br/>";
}

$app = JFactory::getApplication();
$menu = $app->getMenu();

if ($grid) {
	$catid = JRequest::getVar('catid');
	echo "<a href='" . JRoute::_('index.php?option=com_bfauction&view=grids&cid=' . $catid . '&Itemid=' . $itemid) . "'>" . JText::_('COM_BFAUCTION_BUTTON_BACK_TO_ITEM_LIST') . "</a></br/>";
} else {
	$menuItem = $menu->getItems('link', 'index.php?option=com_bfauction&view=auctions', true);
	echo "<a href='" . JRoute::_('index.php?Itemid=' . $menuItem->id) . "'>" . JText::_('COM_BFAUCTION_BUTTON_BACK_TO_ITEM_LIST') . "</a></br/>";
}

//if auction has ended and you are the winning bidder, show PayPal Buy now button
$winner = 0;

if (($currentDate >= $endDate) && ($this->form->getValue('highBidder') == $user->username)) {

	$winner = 1;
}

$reserveNotMet = false;

/* Prepare for the countdown timer */
$secondsDiff = 0;
if ($currentDate > $endDate) {
	JError::raiseWarning(403, JText::_('COM_BFAUCTION_AUCTION_HAS_ENDED'));
	if ($this->form->getValue('currentBid') < $this->form->getValue('reservePrice')) {
		$reserveNotMet = true;
		JError::raiseWarning(403, JText::_('COM_BFAUCTION_TITLE_RESERVE_PRICE_NOT_MET'));
	}
} else {
	$endDateAsSeconds = strtotime($endDate);
	$currentDateAsSeconds = strtotime($currentDate);
	$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
}
$timerText = "";
$remainingDay = floor($secondsDiff / 60 / 60 / 24);
$remainingHour = floor(($secondsDiff - ($remainingDay * 60 * 60 * 24)) / 60 / 60);
$remainingMinutes = floor(($secondsDiff - ($remainingDay * 60 * 60 * 24) - ($remainingHour * 60 * 60)) / 60);
$remainingSeconds = floor(($secondsDiff - ($remainingDay * 60 * 60 * 24) - ($remainingHour * 60 * 60)) - ($remainingMinutes * 60));

if ($remainingSeconds < 10) {
	$remainingSecs = "0" . $remainingSeconds;
} else {
	$remainingSecs = $remainingSeconds;
}

$timerinit = "" . $remainingMinutes . ":" . $remainingSecs;
/*end countdown timer */

// use full image

if (isset($this->form->image1)) {
	$this->form->image1 = str_replace('_t.', '.', $this->form->image1);
}
?>

<div class="row-fluid">
	<legend>Item Details</legend>
	<div class="bfauction_Introtext">You are about to bid on the following item:</div>
</div>

<div class="row-fluid">
	<div class="span7 form-horizontal">
		<fieldset>

			<div class="control-group">
				<div class="control-label bfauction_Label">
					<label for="title"><?php echo JText::_('COM_BFAUCTION_TITLE_TITLE'); ?>:</label>
				</div>
				<div class="controls bfauction_Details">
					<div class="bfauction_ItemTitle"><?php echo $this->form->getValue('title'); ?></div>
				</div>
			</div>

			<?php if ($this->cparams->showSeller) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="supplier"><?php echo JText::_('COM_BFAUCTION_TITLE_SELLER'); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<div class="bfauction_ItemSupplier"><?php echo $this->form->seller; ?></div>
					</div>
				</div>
			<?php } ?>

			<?php if (!empty($this->form->getValue('productId'))): ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="itemid">
							<?php if ($this->form->getValue('productId')) { ?>
								<?php echo JText::_('COM_BFAUCTION_TITLE_PRODUCTID'); ?>:
							<?php } else { ?>
								<?php echo JText::_('COM_BFAUCTION_TITLE_ITEM_ID'); ?>:
							<?php } ?>
						</label>
					</div>

					<div class="controls bfauction_Details">
						<?php if ($this->form->getValue('productId')) { ?>
							<?php echo $this->form->getValue('productId'); ?>
						<?php } else { ?>
							<?php echo $this->form->id; ?>
						<?php } ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if ($this->form->getValue('supplier') != "") { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="supplier">
							<?php echo JText::_('COM_BFAUCTION_TITLE_SUPPLIER'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('supplier'); ?>
					</div>
				</div>
			<?php } ?>

			<?php if ($this->form->getValue('quantity') > 1) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="quantity">
							<?php if ($winner) { ?>
								<?php echo JText::_('COM_BFAUCTION_TITLE_QTY_PURCHASED'); ?>:
							<?php } else { ?>
								<?php echo JText::_('COM_BFAUCTION_TITLE_QUANTITY'); ?>:
							<?php } ?>
						</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="quantityPurchased"><?php echo $this->form->getValue('quantity'); ?></div>
					</div>
				</div>
			<?php } ?>

			<?php if ($this->form->getValue('priceEstimate') != "") { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="priceEstimate">
							<?php echo JText::_('COM_BFAUCTION_TITLE_PRICE_ESTIMATE'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('priceEstimate'); ?>
					</div>
				</div>
			<?php } ?>

			<?php if ($this->form->getValue('itemCondition') != "") { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="condition">
							<?php echo JText::_('COM_BFAUCTION_TITLE_CONDITION'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('itemCondition'); ?>
					</div>
				</div>
			<?php } ?>

			<?php if ($this->form->getValue('itemLocation')) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="itemLocation">
							<?php echo JText::_('COM_BFAUCTION_TITLE_ITEM_LOCATION'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('itemLocation'); ?>
					</div>
				</div>
			<?php } ?>


			<?php if ($this->form->getValue('deliveryMethod')) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for='deliveryMethod'><?php echo JText::_('COM_BFAUCTION_TITLE_DELIVERY_METHOD'); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('deliveryMethod') ?>
					</div>
				</div>
			<?php } ?>


			<?php if ($this->form->getValue('buyersPremium') != "") { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="buyersPremium">
							<?php echo JText::_('COM_BFAUCTION_TITLE_BUYERS_PREMIUM'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<?php echo $this->form->getValue('buyersPremium'); ?>
					</div>
				</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label bfauction_Label">
					<label for="Bid">
						<?php echo JText::_('COM_BFAUCTION_TITLE_CURRENT_BID'); ?>:
					</label>
				</div>
				<div class="controls bfauction_Details">
					<div id="currency"><?php echo $currencyLeft ?></div>
					<div id="divCurrentBid"></div>
					&nbsp;<?php echo $currencyRight ?>
				</div>
			</div>

			<?php if ($this->form->getValue('shipping') > 0) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="shipping"><?php echo JText::_('COM_BFAUCTION_TITLE_SHIPPING'); ?>:</label>
					</div>
					<div
						class="controls bfauction_Details"><?php echo bfauctionHelper::toCurrency($this->form->getValue('shipping')) ?></div>
				</div>
			<?php } ?>

			<?php if ($this->cparams->includeCommission && $this->cparams->commissionAmount > 0) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="Bid"><?php echo JText::_('COM_BFAUCTION_TITLE_COMMISSION'); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="currencyCommission"><?php echo $currencyLeft ?></div>
						<div id="divCommissionCurrent"></div><?php echo $currencyRight ?>
					</div>
				</div>
			<?php } ?>

			<?php if ($taxableItem && $this->cparams->includeTax && $this->cparams->taxAmount > 0 ) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="Bid">
							<?php echo JText::_('COM_BFAUCTION_TITLE_TAX'); ?>:
						</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="currencyTax"><?php echo $currencyLeft ?></div>
						<div id="divTaxCurrent"></div>
						&nbsp;<?php echo $currencyRight ?>
					</div>
				</div>
			<?php } ?>

			<?php if ($this->cparams->showTotalPrice && $this->form->getValue('currentBid') > 0) { ?>
				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="Bid"><?php echo JText::_('COM_BFAUCTION_TITLE_TOTAL_PRICE'); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<strong>
							<div id="currencyTax"><?php echo $currencyLeft ?></div>
							<div id="divTotalPriceCurrent"></div>&nbsp;<?php echo $currencyRight ?></strong>
					</div>
				</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label bfauction_Label">
					<label for="EndDate">
						<?php echo JText::_('COM_BFAUCTION_TITLE_END_DATE'); ?>:
					</label>
				</div>
				<div class="controls bfauction_Details timeremaining_enddate">
					<span class="timeremaining" id="txt" name="txt" value="<?php echo $timerinit; ?>"></span>
					<strong><span
							id="endDate"><?php echo JHTML::_('date', $endDate, $this->cparams->dateFormat); ?></span></strong>
				</div>
			</div>

			<?php if ($user->id) { ?>

				<div class="control-group">
					<div class="control-label bfauction_Label">
						<label for="highbidder" id"><?php echo JText::_('COM_BFAUCTION_TITLE_CURRENT_BIDDER'); ?>:</label>
					</div>
					<div class="controls bfauction_Details">
						<div id="highBidder"></div>
						<?php
						if ($this->form->getValue('highBidder') == $user->username) {
							if ($this->lastbid->maxbid > 0) {
								echo $this->cparams->currencySymbolAfter ? ' (' : ' (' . $this->cparams->bfcurrency;
								echo $this->lastbid->maxbid;
								echo $this->cparams->currencySymbolAfter ? ' ' . $this->cparams->bfcurrency . ')' : ')';
							}
						}
						?>
					</div>
				</div>

				<?php if (($currentDate < $endDate)) { ?>

					<?php if ($this->form->getValue('buyNowPrice') > 0 && $this->cparams->hideBid) { ?>
					<?php } else { ?>

						<div class="control-group">
							<div class="control-label bfauction_Label">
								<label for="Bid">
									<?php echo JText::_('COM_BFAUCTION_TITLE_YOUR_BID'); ?>:
								</label>
							</div>
							<div class="controls bfauction_Details bidnowForm">
								<form action="<?php echo JRoute::_('index.php?option=com_bfauction&view=confirmbids'); ?>" method="post" name="adminForm" id="adminForm">
									<?php
									if ($this->cparams->reverseAuction) {
										$nextBid = $this->form->getValue('currentBid') - (float)$this->cparams->bidIncrement;
										if ($nextBid < 0) {
											$nextBid = (float)$this->cparams->bidIncrement;
										}
									} else {
										if ($this->form->getValue('highBidder') == '0') {
											/* no bids yet so use opening bid */
											$nextBid = $this->form->getValue('currentBid');
										} else {
											$nextBid = $this->form->getValue('currentBid') + (float)$this->cparams->bidIncrement;
										}
									}
									?>
									<?php
									if ($this->form->getValue('currentBid') < 1) {
										$nextBid = $this->cparams->bidIncrement;
									}
									?>
									<div class="bfauctionCurrency"><?php echo $currencyLeft ?></div>&nbsp;<input class="inputbox" type="text" name="bid" id="bid" size="5" value="<?php echo $nextBid; ?>" onblur="process()"/>&nbsp;<?php echo $currencyRight; ?>
									<input type="hidden" name="option" value="com_bfauction"/>
									<input type="hidden" name="view" value="confirmbids"/>
									<input type="hidden" name="boxchecked" value="0"/>
									<input type="hidden" name="controller" value=""/>
									<input type="hidden" name="cid" value="<?php echo $this->form->id; ?>"/>
									<input type="hidden" name="bidIncrement" value="<?php echo $this->cparams->bidIncrement; ?>"/>
									<input type="hidden" name="tax" id="tax">
									<input type="hidden" name="commission" id="commission">
									<input type="hidden" name="quantity" value="<?php echo $this->form->getValue('quantity'); ?>"/>
									<?php echo JHTML::_('form.token'); ?>
									<input class="btn btn-small btn-success" name="Submit" type="submit" id="Submit" value="<?php echo JText::_('COM_BFAUCTION_BUTTON_BID_NOW'); ?>"/>
								</form>
							</div>
						</div>

						<div class="control-group">
							<div class="controls bfauction_Details">
								<i><?php echo JText::_('COM_BFAUCTION_TITLE_MINIMUM_BID_INCREMENT'); ?>&nbsp;<strong><?php echo bfauctionHelper::toCurrency($this->cparams->bidIncrement) ?></strong></i>
							</div>
						</div>
					<?php } ?>

					<?php if (($this->form->getValue('buyNowPrice') > 0) & ($this->form->getValue('buyNowPrice') > $this->form->getValue('currentBid')) & ($currentDate < $endDate)) { ?>
						<div class="control-group">
							<div class="control-label bfauction_Label">
								<label for="BuyNow">
									<?php echo JText::_('COM_BFAUCTION_TITLE_BUY_NOW'); ?>:
								</label>
							</div>

							<div class="controls bfauction_Details">
								<form method="post" name="buyNowForm" action="<?php echo JRoute::_('index.php?option=com_bfauction&view=confirmpurchases'); ?>">
									<strong><?php echo bfauctionHelper::toCurrency($this->form->getValue('buyNowPrice')) ?></strong>
									<input type="hidden" name="boxchecked" value="0"/>
									<input type="hidden" name="cid" value="<?php echo $this->form->id; ?>"/>
									<input type="hidden" name="quantity" value="<?php echo $this->form->getValue('quantity'); ?>"/>
									<?php echo JHTML::_('form.token'); ?>
									<input class="btn btn-small btn-success" name="Submit" type="submit" id="Submit" value="<?php echo JText::_('COM_BFAUCTION_BUTTON_BUY_NOW'); ?>"/>
								</form>
							</div>
						</div>
					<?php } ?>
					<?php } else { ?>

					<div class="control-group">
						<div class="control-label bfauction_Label">
							<label for="User id">&nbsp;</label>
						</div>
						<div class="controls bfauction_Details">
							<div style="color: #ff0000" class="auctionEnded"><?php echo JText::_('COM_BFAUCTION_AUCTION_HAS_CLOSED'); ?></div>
							<input type="hidden" name="bid" id="bid">
							<input type="hidden" name="tax" id="tax">
							<input type="hidden" name="commission" id="commission">
						</div>
					</div>

				<?php } ?>


				<?php if ($winner) { ?>

					<form action="<?php echo JRoute::_('index.php?option=com_bfauction'); ?>" method="post">

						<?php if ($this->form->getValue('currentBid') < $this->form->getValue('reservePrice')) { ?>

							<div class="control-group">
								<div class="controls bfauction_Details">
									<div style="color: #ff0000"
										 class="reserveNotMet"><?php echo JText::_('COM_BFAUCTION_TITLE_RESERVE_PRICE_NOT_MET'); ?></div>
								</div>
							</div>

						<?php } else { ?>

							<?php if ($this->item->orderStatus !== "C"): ?>

								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label
											for="paymentOptions"><?php echo JText::_('COM_BFAUCTION_PAYMENT_OPTION') ?>
											:</label>
									</div>
									<div class="controls bfauction_Details">
										<?php
										$params = JComponentHelper::getParams('com_bfauction');
										$gateways = array();
										$dispatcher = JDispatcher::getInstance();
										JPluginHelper::importPlugin('payment');
										if (!is_array($params->get('gateways'))) {
											$gateway_param[] = $params->get('gateways');
										} else {
											$gateway_param = $params->get('gateways');
										}
										if (!empty($gateway_param)) {
											$gateways = $dispatcher->trigger('onTP_GetInfo', array($gateway_param));
											foreach ($gateways as $gateway) {
												$checked = $gateway->id == 'paypal' ? 'checked' : '';
												$img = $gateway->id == 'paypal' ? '<img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/pp-acceptance-small.png" alt="Buy now with PayPal" />' : '';
												echo "<div><input type='radio' name='processor' value='{$gateway->id}' $checked> {$gateway->name} &nbsp;</div>";
											}
										}
										?>
									</div>
								</div>
								<?php if ($this->cparams->showDeliveryOptions): ?>
									<div class="control-group">
										<div class="control-label bfauction_Label">
											<br/><label
												for="deliveryOptions"><?php echo JText::_('COM_BFAUCTION_TITLE_DELIVERY_METHOD'); ?>
												:</label>
										</div>
										<div class="controls bfauction_Details">
											<input type="radio" name="deliveryOption" value=<?php echo COM_BFAUCTION_DELIVERY_HOME ?>>&nbsp;<?php echo JText::_('COM_BFAUCTION_DELIVERY_OPTION1'); ?>
											<br>
											<input type="radio" name="deliveryOption" value=<?php echo COM_BFAUCTION_DELIVERY_DIRECT ?>>&nbsp;<?php echo JText::_('COM_BFAUCTION_DELIVERY_OPTION2'); ?>
										</div>
										<br/>
									</div>
								<?php endif ?>

								<div class="control-group">
									<div class="controls bfauction_Details">
										<div>
											<input type="hidden" name="option" value="com_bfauction"/>
											<input type="hidden" name="task" value="save"/>
											<input type="hidden" name="view" value="payments"/>
											<input type="hidden" name="item_id" value="<?php echo $this->form->id; ?>"/>
											<?php echo JHTML::_('form.token'); ?>
											<input class="btn btn-success" name="Submit" type="submit" id="Submit"
												   value="<?php echo JText::_('COM_BFAUCTION_PAY_NOW'); ?>"/>
										</div>
									</div>
								</div>

							<?php else: ?>

								<div class="control-group">
									<div class="controls bfauction_Details">
										<div style="color: #00ff00"><a
												href="<?php echo JRoute::_('index.php?option=com_bfauction&view=payment&orderId='.$this->form->getValue('orderId')) ?>"><?php echo JText::_('PAYMENT STATUS'); ?></a>
										</div>
									</div>
								</div>

							<?php endif ?>

						<?php } ?>
					</form>
				<?php } ?>

				<?php if ($this->cparams->allowWatchlist && !$winner) { ?>
					<div class="control-group">
						<div class="controls bfauction_Details">
							<form action="<?php echo JRoute::_('index.php?option=com_bfauction&task=watchlist') ?>" method="post" name="watchlist">
								<input type="hidden" name="option" value="com_bfauction"/>
								<input type="hidden" name="boxchecked" value="0"/>
<!--								<input type="hidden" name="task" value="auctions.watchlist"/>-->
								<input type="hidden" name="cid" value="<?php echo $this->form->id ?>"/>
								<?php echo JHTML::_('form.token'); ?>
								<input class="btn btn-success btn-small" name="Submit" type="submit" id="Submit" value="<?php echo JText::_('COM_BFAUCTION_BUTTON_WATCHLIST'); ?>"/>
							</form>
						</div>
					</div>
				<?php } ?>

				<?php if ($this->form->getValue('description')): ?>
					<div class="control-label bfauction_Label">
						<label><?php echo JText::_('COM_BFAUCTION_LBL_DESCRIPTION'); ?>:</label>
					</div>
					<div class="control-group">
						<div class="controls bfauction_Details">
							<?php echo $this->form->getValue('description') ?>
						</div>
					</div>
				<?php endif; ?>

				<div class="control-group">
					<div class="controls bfauction_Details">
						<a href="<?php echo JRoute::_('index.php?option=com_bfauction&view=bidhistories&id='.$this->form->id); ?>"><?php echo JText::_('COM_BFAUCTION_TITLE_BID_HISTORY'); ?></a>
					</div>
				</div>

				<?php
			} else { //end authenticated user ?>
				<div id="highBidder" style="display: none;"></div>
				<?php
			} //end if
			?>

			<?php
			$link = JURI::root() . 'index.php?option=com_bfauction&view=auction&id=' . $this->form->id . '&Itemid=' . (int)$itemid;
			$encodedLink = JURI::root() . 'index.php?option=com_bfauction%26view=auction%26id=' . $this->form->id . '%26Itemid=' . (int)$itemid;
			?>
			<?php
			$params = JComponentHelper::getParams('com_bfauction');
			$showFacebookIcon = $params->get('showFacebookIcon');
			$showTwitterIcon = $params->get('showTwitterIcon');
			$showGooglePlusIcon = $params->get('showGooglePlusIcon');
			$showLinkedInIcon = $params->get('showLinkedInIcon');
			?>
			<?php if ($showFacebookIcon || $showTwitterIcon || $showGooglePlusIcon || $showLinkedInIcon): ?>
				<div class="control-group">
					<div class="controls bfAuction_Details social-icons">
						<?php if ($showTwitterIcon): ?><a
							href="https://twitter.com/intent/tweet?text=<?php echo $this->form->getValue('title'); ?>&url=<?php echo $encodedLink; ?>"
							class="twitter-share-button" target="_blank"><img
									src="./media/com_bfauction/images/twitter.png"></a><?php endif; ?>
						<?php if ($showFacebookIcon): ?><a
							href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $encodedLink; ?>"
							target="_blank"><img src="./media/com_bfauction/images/facebook.png"></a><?php endif; ?>
						<?php if ($showGooglePlusIcon): ?><a
							href="https://plus.google.com/share?url=<?php echo $encodedLink; ?>" target="_blank"><img
									src="./media/com_bfauction/images/google.png"></a><?php endif; ?>
						<?php if ($showLinkedInIcon): ?><a
							href="https://www.linkedin.com/cws/share?url=<?php echo $encodedLink; ?>" target="_blank">
								<img src="./media/com_bfauction/images/linkedin.png"></a><?php endif; ?>
					</div>
				</div>
			<?php endif; ?>


		</fieldset>
	</div>

	<div class="main_image span5">
		<?php
		$imageShared = $this->form->getValue('imageShared');
		if (isset($this->form->image1)) {
			if (file_exists(JPATH_SITE . $this->form->image1)) {
				echo '<a href="' . JUri::base() . $this->form->imagefull1 . '?time=' . time() . '"  class="lytebox" data-lyte-options="group:myimages"><img src="' . JUri::base() . $this->form->image1 . '?time=' . time() . '" width="' . $this->cparams->mainImageSize . '" border="0"/></a>';
			}
		}
		?>
	</div>

	<div class="thumb_images span5">
		<?php

		for ($i = 2; $i < 21; $i++) {
			$image = 'image' . $i;
			$imagefull = 'imagefull' . $i;
			if (isset($this->form->$image)) {
				if (file_exists(JPATH_SITE . $this->form->$image)) {
					echo '<div class="sml_image"><a href="' . JUri::base() . $this->form->$imagefull . '?time=' . time() . '"  class="lytebox" data-lyte-options="group:myimages"><img src="' . JUri::base() . $this->form->$image . '?time=' . time() . '" border="0"/></a></div>';
				}
			}
		}
		?>
	</div>
</div>

<script language="javascript" type="text/javascript">
	<!--
	process();
	//-->
</script>

<script language="javascript" type="text/javascript">

	// get variable from php
	var days = <?php echo $remainingDay; ?>;
	var hours = <?php echo $remainingHour; ?>;
	var minutes = <?php echo $remainingMinutes; ?>;
	var seconds = <?php echo $remainingSeconds; ?>;

	function setCountDown() {
		seconds--;
		if (seconds < 0) {
			minutes--;
			seconds = 59
		}
		if (minutes < 0) {
			hours--;
			minutes = 59
		}
		if (hours < 0) {
			days--;
			hours = 23
		}
		//document.getElementById("txt").innerHTML = hours+" hours, "+minutes+" minutes, "+seconds+" seconds";
		if (seconds < 10) {
			seconds = "0" + seconds;
		}

		document.getElementById("txt").innerHTML = "&nbsp;" + days + "d " + hours + "h " + minutes + ":" + seconds + '&nbsp;&nbsp;';

		if (days == 0 && hours == 0 && minutes == 0 && seconds < 1) { // no time left
			window.location.reload();
		}

		if (days < 0) {
			clearInterval(ct);
			document.getElementById("txt").innerHTML = "&nbsp;0:00&nbsp;";
		}
	}

	var ct = setInterval("setCountDown()", 1000); // Start clock.

</script>
