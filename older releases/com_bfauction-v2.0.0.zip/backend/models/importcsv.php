<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelImportcsv extends F0FModel
{
	function import()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );
		$app = JFactory::getApplication();

		$file = JRequest::getVar('file_source', null, 'files', 'array');
		$filename = $file['tmp_name'];

		$csv_terminated = "\n";
		$csv_separator = ",";
		$csv_enclosed = '"';
		$csv_escaped = "\\";

		$table = $app->getCfg('dbprefix')."bfauction_items";

		$db	= JFactory::getDBO();
		if (version_compare(JVERSION, '3.0', 'ge'))
		{
			$fields = $db->getTableColumns( $table, true);

			if(!$fields){
				JError::raiseWarning( 500, JText::_('COM_BFAUCTION_ERROR_NO_COLUMNS_FOUND') );
			}else{
				if( sizeof( $fields ) ) {
					// We found some fields so let's create the list
					foreach( $fields as $field => $type ) {
						$fieldnames[] = $field;
					}
				}
			}
		}
		else
		{
			$fieldsArray = $db->getTableFields( $table, true );
			$fields = array_shift($fieldsArray);

			$fieldnames = array();
			foreach( $fields[$table] as $field => $type ) {
				$fieldnames[]=$field;
			}
		}

		$query = "LOAD DATA LOCAL INFILE '".@mysql_escape_string($filename).
		"' REPLACE INTO TABLE `".$table.
		"` CHARACTER SET utf8 ".
		" FIELDS TERMINATED BY '".@mysql_escape_string($csv_separator).
		"' OPTIONALLY ENCLOSED BY '".@mysql_escape_string($csv_enclosed).
		"' ESCAPED BY '".@mysql_escape_string($csv_escaped).
		"' LINES TERMINATED BY '".@mysql_escape_string($csv_terminated).
		"' ".
		" IGNORE 1 LINES "
				."(`".implode("`,`", $fieldnames)."`)";

		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}else{
			$msg = JText::_('COM_BFAUCTION_CSV_IMPORT_COMPLETE');
		}

		//$this->setRedirect( 'index.php?option=com_bfauction&view=items', $msg );
		$app->redirect( JRoute::_('index.php?option=com_bfauction&view=items', false), $msg );
	}
}