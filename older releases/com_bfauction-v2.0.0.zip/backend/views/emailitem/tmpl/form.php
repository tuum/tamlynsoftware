<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfauction/css/backend.css');
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfauction&view=emailitem&id='.(int) $this->item->bfauction_emailitem_id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<input type="hidden" name="bfauction_emailitem_id" value="<?php echo $this->item->bfauction_emailitem_id ?>" />

	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->bfauction_emailitem_id) ? JText::_('COM_BFAUCTION_TITLE_DETAILS') : JText::sprintf('COM_BFAUCTION_TITLE_EMAIL_TEMPLATE', $this->item->bfauction_emailitem_id); ?></a></li>
		</ul>
		<div class="tab-content">

			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('catid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('catid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('subject'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('subject'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
			</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('enabled'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('enabled'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<div class="span2">
		<h4><?php echo JText::_( 'COM_BFAUCTION_HELP_FIELDS_REPLACED' ); ?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<?php echo JText::_( 'COM_BFAUCTION_FIELDS_REPLACED' ); ?><br>
				<ul class="adminformlist">

					<li>{currency}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_CURRENCY' ); ?></li>

					<li>{bid}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_BID' ); ?></li>

					<li>{username}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_USERNAME' ); ?></li>

					<li>{description}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_DESCRIPTION' ); ?></li>

					<li>{enddate}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_END_DATE' ); ?></li>

					<li>{itemtitle}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_ITEM_TITLE' ); ?></li>

					<li>{itemid}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_ITEMID' ); ?></li>

					<li>{productid}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_PRODUCT_ID' ); ?></li>

					<li>{sellername}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_SELLER_NAME' ); ?></li>

					<li>{selleremail}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_SELLER_EMAIL' ); ?></li>

					<li>{url}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_URL' ); ?></li>

					<li>{maxbid}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_MAXBID' ); ?></li>

					<li>{deliverymethod}
					<?php echo JText::_( 'COM_BFAUCTION_HELP_DELIVERYMETHOD' ); ?></li>
				</ul>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
</form>