<?php defined('_JEXEC') or die(); ?>
<?php
/**
 * $Id: default.php 66 2015-01-12 11:44:33Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php
if($this->uid == 0){
	JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_MUST_LOGIN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfquiz_plus&view=myquizzes&Itemid=".$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".$finalUrl."'>".JText::_( 'COM_BFQUIZPLUS_LOG_IN')."</a><br>";
}else{

$Itemid = JRequest::getVar('Itemid');
$readOnly = $this->params->get( 'readOnly' );

$session = JFactory::getSession();
$session->set('readOnly', $readOnly);

?>

<div id="editcell">
    <table width="100%">
    <thead>
        <tr class="Bfquiz_plusQuestion">
            <th align="center">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_DATE' ); ?>
            </th>
            <th align="center">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_QUIZ_NAME' ); ?>
            </th>
            <th align="center">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_RESULT' ); ?>
            </th>
            <th align="center">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_TIME_TAKEN' ); ?>
            </th>
            <!--
            <th align="center">
                &nbsp;
            </th>
            -->
        </tr>
    </thead>
    <?php
    $k = 0;
    $catid	= JRequest::getVar( 'cid', 0, '', 'int' );

    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row = $this->items[$i];
        ?>
        <tr class="Bfquiz_plusOptions">
            <td align="center">
                <?php echo $row->DateReceived; ?>
            </td>
            <td align="center">
			    <?php echo $row->title; ?>
            </td>
            <td align="center">
				<?php echo $row->score; ?>
            </td>
            <td align="center">
				<?php echo $row->TimeTaken; ?>
            </td>
			<td align="center">
				<form action="<?php echo JRoute::_( 'index.php?option=com_bfquiz_plus&view=edit' ); ?>" method="post" name="adminForm">
					<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFQUIZPLUS_EDIT' ); ?>" />
					<input type="hidden" name="option" value="com_bfquiz_plus" />
					<input type="hidden" name="task" value="edit" />
					<input type="hidden" name="catid" value="<?php echo $row->catid ?>" />
					<input type="hidden" name="id" value="<?php echo $row->id ?>" />
					<input type="hidden" name="Itemid" value="<?php echo $Itemid ?>" />
				</form>
			</td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<?php
}
?>