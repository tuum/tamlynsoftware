<?php
/**
 * $Id: default.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
$app = JFactory::getApplication();

$user	= JFactory::getUser();
$userId	= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
$canOrder	= $user->authorise('core.edit.state',	'com_bfquiz_plus');
$saveOrder	= $listOrder == 'a.ordering';

$params		= (isset($this->state->params)) ? $this->state->params : new JObject;
$params = JComponentHelper::getParams('com_bfquiz_plus');
$downloadid = $params->get('downloadid');

$version = new JVersion();
if( floatval($version->RELEASE) >= 3 ) {
	JHtml::_('dropdown.init');
	if ($saveOrder)
	{
		$saveOrderingUrl = 'index.php?option=com_bfquiz_plus&task=questions.saveOrderAjax&tmpl=component';
		JHtml::_('sortablelist.sortable', 'questionList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
	}
	$sortFields = $this->getSortFields();
}
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, '');
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&view=questions'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<div id="filter-bar" class="btn-toolbar">
		<div class="filter-search btn-group pull-left">
			<label for="filter_search" class="element-invisible"><?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_QUESTION');?></label>
			<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_QUESTION'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_QUESTION'); ?>" />
		</div>
		<div class="btn-group pull-left">
			<button type="submit" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
			<button type="button" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
			<?php echo $this->pagination->getLimitBox(); ?>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="directionTable" class="element-invisible"><?php echo JText::_('JFIELD_ORDERING_DESC');?></label>
			<select name="directionTable" id="directionTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JFIELD_ORDERING_DESC');?></option>
				<option value="asc" <?php if ($listDirn == 'asc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_ASCENDING');?></option>
				<option value="desc" <?php if ($listDirn == 'desc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_DESCENDING');?></option>
			</select>
		</div>
		<div class="btn-group pull-right">
			<label for="sortTable" class="element-invisible"><?php echo JText::_('JGLOBAL_SORT_BY');?></label>
			<select name="sortTable" id="sortTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JGLOBAL_SORT_BY');?></option>
				<?php echo JHtml::_('select.options', $sortFields, 'value', 'text', $listOrder);?>
			</select>
		</div>
	</div>

	<div class="clearfix"> </div>
	<table class="table table-striped" id="questionList">
<?php
	} //end Joomla 3.x

	$version = new JVersion();
	if(floatval($version->RELEASE) <= '2.5') {
?>
	<fieldset id="filter-bar">
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_TITLE'); ?>" />
			<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
		</div>
		<div class="filter-select fltrt">


			<select name="filter_published" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_PUBLISHED');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.state'), true);?>
			</select>

			<select name="filter_category_id" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_bfquiz_plus'), 'value', 'text', $this->state->get('filter.category_id'));?>
			</select>
		</div>
	</fieldset>
	<div class="clr"> </div>

	<table class="adminlist">
<?php
	} //end Joomla 2.5
?>

	<thead>
		<tr>
			<?php if( floatval($version->RELEASE) >= 3 ) { ?>
			<th width="1%" class="nowrap center hidden-phone">
				<?php echo JHtml::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
			</th>
			<?php } ?>
			<th width="1%" class="hidden-phone">
				<input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
			</th>
			<th width="1%" class="nowrap center">
				<?php echo JHtml::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
			</th>
			<th class="title">
				<?php echo JHtml::_('grid.sort',  'COM_BFQUIZPLUS_TITLE_QUESTION', 'a.question', $listDirn, $listOrder); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_TYPE' ); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_NEXT_QN' ); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_DB_FIELD_NAME' ); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_FIELD_TYPE' ); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_VALIDATION' ); ?>
			</th>
			<th width="5%" class="hidden-phone">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE_CAT' ); ?>
			</th>
			<?php if(floatval($version->RELEASE) <= '2.5') { ?>
			<th width="10%" nowrap="nowrap">
				<?php echo JHtml::_('grid.sort',  'JGRID_HEADING_ORDERING', 'a.ordering', $listDirn, $listOrder); ?>
				<?php if ($canOrder && $saveOrder) :?>
					<?php echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'questions.saveorder'); ?>
				<?php endif; ?>
			</th>
			<?php } ?>
			<th width="1%" class="nowrap center hidden-phone">
				<?php echo JHtml::_('grid.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="14">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
		<?php foreach ($this->items as $i => $item) :
			$orderkey = array_search($item->id, $this->ordering[$item->parent]);
			$ordering   = ($listOrder == 'a.ordering');
			$item->cat_link	= JRoute::_('index.php?option=com_categories&extension=com_bfquiz_plus&task=edit&type=other&cid[]='. $item->catid);
			$canCreate	= $user->authorise('core.create',		'com_bfquiz_plus.category.'.$item->catid);
			$canEdit	= $user->authorise('core.edit',			'com_bfquiz_plus.category.'.$item->catid);
			$canCheckin	= $user->authorise('core.manage',		'com_checkin') || $item->checked_out==$user->get('id') || $item->checked_out==0;
			$canChange	= $user->authorise('core.edit.state',	'com_bfquiz_plus.category.'.$item->catid) && $canCheckin;
			?>

		<tr class="row<?php echo $i % 2; ?>" sortable-group-id="<?php echo $item->catid?>">
			<?php if( floatval($version->RELEASE) >= 3 ) { ?>
			<td class="order nowrap center hidden-phone">
			<?php if ($canChange) :
				$disableClassName = '';
				$disabledLabel	  = '';
				if (!$saveOrder) :
					$disabledLabel    = JText::_('JORDERINGDISABLED');
					$disableClassName = 'inactive tip-top';
				endif; ?>
				<span class="sortable-handler <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>" rel="tooltip">
					<i class="icon-menu"></i>
				</span>
				<input type="text" style="display:none"  name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
			<?php else : ?>
				<span class="sortable-handler inactive" >
					<i class="icon-menu"></i>
				</span>
			<?php endif; ?>
			</td>
			<?php } ?>
			<td class="center hidden-phone">
				<?php echo JHtml::_('grid.id', $i, $item->id); ?>
			</td>
			<td class="center nowrap">
				<?php echo JHtml::_('jgrid.published', $item->state, $i, 'questions.', $canChange, 'cb', $item->publish_up, $item->publish_down); ?>
			</td>
			<td class="nowrap">
				<?php if ($item->checked_out) : ?>
					<?php echo JHtml::_('jgrid.checkedout', $i, '', $item->checked_out_time, 'questions.', $canCheckin); ?>
				<?php endif; ?>
				<?php if ($canEdit) : ?>
						<a href="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&task=question.edit&id='.(int) $item->id); ?>">
						<?php echo $this->escape($item->question); ?></a>
				<?php else : ?>
						<?php echo $this->escape($item->question); ?>
				<?php endif; ?>
				<?php
					if($item->mandatory){
						echo "<img src='./components/com_bfquiz_plus/images/mandatory.gif' width='12'>";
					}
				?>
				<div class="small">
					<?php if($item->parent){ ?>
						--
					<?php } ?>
					<?php echo $this->escape($item->category_name); ?>
				</div>
			</td>
			<td class="center hidden-phone">
				<?php echo bfquiz_plusHelper::ShowQuestionType( $item->question_type ); ?>
			</td>
			<td class="center hidden-phone">
				<?php
				    for($z=1; $z < 20; $z++){
				       $tempname = "next_question".$z;
				       if($item->$tempname <> 0){
				          echo $item->$tempname;
				          echo " ";
				       }
				    }
				?>
			</td>
			<td class="center hidden-phone">
				<?php echo $item->field_name; ?>
				<?php if(!isset($myFields[$item->catid])){
				   $myFields[$item->catid] = "";
				}
				?>
				<?php $myFields[$item->catid].= "`".$item->field_name."` varchar($item->fieldSize) default NULL,";	?>
			</td>
			<td class="center hidden-phone">
				<?php echo $item->field_type; ?>
			</td>
			<td class="center hidden-phone">
				<?php echo $item->validation_type; ?>
			</td>
			<td class="center hidden-phone">
				<?php echo $item->scorecategory; ?>
			</td>
			<?php if(floatval($version->RELEASE) <= '2.5') { ?>
			<td class="order">
				<?php if ($canChange) : ?>
					<?php if ($saveOrder) : ?>
						<span><?php echo $this->pagination->orderUpIcon($i, isset($this->ordering[$item->parent][$orderkey - 1]), 'questions.orderup', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>
						<span><?php echo $this->pagination->orderDownIcon($i, $this->pagination->total, isset($this->ordering[$item->parent][$orderkey + 1]), 'questions.orderdown', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>
					<?php endif; ?>
					<?php $disabled = $saveOrder ?  '' : 'disabled="disabled"'; ?>
					<input type="text" name="order[]" size="5" value="<?php echo $orderkey + 1;?>" <?php echo $disabled ?> class="text-area-order" />
					<?php $originalOrders[] = $orderkey + 1; ?>
				<?php else : ?>
					<?php echo $orderkey + 1;?>
				<?php endif; ?>
			</td>
			<?php } ?>
			<td class="center hidden-phone">
				<?php echo (int) $item->id; ?>
			</td>
		</tr>

	<?php endforeach; ?>
	 </tbody>
	</table>

	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

<?php if(version_compare(PHP_VERSION, '5.3.0', 'ge') && $downloadid){ ?>
<div align="center">
<?php echo LiveUpdate::getIcon(); ?>
</div>
<?php } ?>

<?php
	$errors = bfquiz_plusController::buildAnswerTables();
	if($errors){
		JError::raiseWarning(500, $errors);
	}
?>