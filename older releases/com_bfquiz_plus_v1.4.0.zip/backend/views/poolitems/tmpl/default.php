<?php
/**
 * $Id: default.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');

$user	= JFactory::getUser();
$userId	= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
$canOrder	= $user->authorise('core.edit.state',	'com_bfquiz_plus');
$archived	= $this->state->get('filter.published') == 2 ? true : false;
$trashed	= $this->state->get('filter.published') == -2 ? true : false;
$params		= (isset($this->state->params)) ? $this->state->params : new JObject;
$saveOrder	= $listOrder == 'a.ordering';
$ordering 	= ($listOrder == 'a.ordering');

$version = new JVersion();
if( floatval($version->RELEASE) >= 3 ) {
	JHtml::_('dropdown.init');
	if ($saveOrder)
	{
		$saveOrderingUrl = 'index.php?option=com_bfquiz_plus&task=poolitems.saveOrderAjax&tmpl=component';
		JHtml::_('sortablelist.sortable', 'poolitemsList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
	}
	$sortFields = $this->getSortFields();
}
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, '');
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&view=poolitems'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<div id="filter-bar" class="btn-toolbar">
		<div class="filter-search btn-group pull-left">
			<label for="filter_search" class="element-invisible"><?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_DESC');?></label>
			<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_DESC'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_DESC'); ?>" />
		</div>
		<div class="btn-group pull-left">
			<button type="submit" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
			<button type="button" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
			<?php echo $this->pagination->getLimitBox(); ?>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="directionTable" class="element-invisible"><?php echo JText::_('JFIELD_ORDERING_DESC');?></label>
			<select name="directionTable" id="directionTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JFIELD_ORDERING_DESC');?></option>
				<option value="asc" <?php if ($listDirn == 'asc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_ASCENDING');?></option>
				<option value="desc" <?php if ($listDirn == 'desc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_DESCENDING');?></option>
			</select>
		</div>
		<div class="btn-group pull-right">
			<label for="sortTable" class="element-invisible"><?php echo JText::_('JGLOBAL_SORT_BY');?></label>
			<select name="sortTable" id="sortTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JGLOBAL_SORT_BY');?></option>
				<?php echo JHtml::_('select.options', $sortFields, 'value', 'text', $listOrder);?>
			</select>
		</div>
	</div>

	<div class="clearfix"> </div>
	<table class="table table-striped" id="poolitemsList">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<fieldset id="filter-bar">
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFQUIZPLUS_SEARCH_IN_TITLE'); ?>" />
			<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
		</div>
		<div class="filter-select fltrt">

			<select name="filter_published" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_PUBLISHED');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.state'), true);?>
			</select>

			<select name="filter_category_id" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_bfquiz_plus'), 'value', 'text', $this->state->get('filter.category_id'));?>
			</select>
		</div>
	</fieldset>
	<div class="clr"> </div>

	<table class="adminlist">
<?php
	} //end Joomla 2.5
?>
	<thead>
		<tr>
			<?php if( floatval($version->RELEASE) >= 3 ) { ?>
			<th width="1%" class="nowrap center hidden-phone">
				<?php echo JHtml::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
			</th>
			<?php } ?>
			<th width="1%" class="hidden-phone">
				<input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
			</th>
			<th width="1%" class="nowrap center">
				<?php echo JHtml::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
			</th>
			<th class="title">
				<?php echo JHtml::_('grid.sort',  JText::_( 'COM_BFQUIZPLUS_TITLE_DESCRIPTION' ), 'a.description', $listDirn, $listOrder); ?>
			</th>
			<th width="1%" class="nowrap center">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_QNS' ); ?>
			</th>
			<th width="1%" class="nowrap center">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PER_PAGE' ); ?>
			</th>
			<th width="1%" class="nowrap center">
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_QNS_IN_EVERY_QUIZ' ); ?>
			</th>
			<?php if(floatval($version->RELEASE) <= '2.5') { ?>
			<th width="10%" nowrap="nowrap">
				<?php echo JHtml::_('grid.sort',  'JGRID_HEADING_ORDERING', 'a.ordering', $listDirn, $listOrder); ?>
				<?php if ($canOrder && $saveOrder) :?>
					<?php echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'poolitems.saveorder'); ?>
				<?php endif; ?>
			</th>
			<?php } ?>
			<th width="1%" class="nowrap center hidden-phone">
				<?php echo JHtml::_('grid.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="9">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$originalOrders = array();
	foreach ($this->items as $i => $item) :
			$orderkey = array_search($item->id, $this->ordering[$item->parent]);
			$ordering   = ($listOrder == 'a.ordering');
			$item->cat_link	= JRoute::_('index.php?option=com_categories&extension=com_bfquiz_plus&task=edit&type=other&cid[]='. $item->catid);
			$canCreate	= $user->authorise('core.create',		'com_bfquiz_plus.category.'.$item->catid);
			$canEdit	= $user->authorise('core.edit',			'com_bfquiz_plus.category.'.$item->catid);
			$canCheckin	= $user->authorise('core.manage',		'com_checkin') || $item->checked_out==$user->get('id') || $item->checked_out==0;
			$canChange	= $user->authorise('core.edit.state',	'com_bfquiz_plus.category.'.$item->catid) && $canCheckin;
			?>

		<tr class="row<?php echo $i % 2; ?>" sortable-group-id="<?php echo $item->catid?>">
			<?php if( floatval($version->RELEASE) >= 3 ) { ?>
			<td class="order nowrap center hidden-phone">
			<?php if ($canChange) :
				$disableClassName = '';
				$disabledLabel	  = '';
				if (!$saveOrder) :
					$disabledLabel    = JText::_('JORDERINGDISABLED');
					$disableClassName = 'inactive tip-top';
				endif; ?>
				<span class="sortable-handler <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>" rel="tooltip">
					<i class="icon-menu"></i>
				</span>
				<input type="text" style="display:none"  name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
			<?php else : ?>
				<span class="sortable-handler inactive" >
					<i class="icon-menu"></i>
				</span>
			<?php endif; ?>
			</td>
			<?php } ?>
			<td class="center hidden-phone">
				<?php echo JHtml::_('grid.id', $i, $item->id); ?>
			</td>
			<td class="center nowrap">
				<?php echo JHtml::_('jgrid.published', $item->state, $i, 'poolitems.', $canChange, 'cb', $item->publish_up, $item->publish_down); ?>
			</td>
			<td class="nowrap">
				<?php if ($item->checked_out) : ?>
					<?php echo JHtml::_('jgrid.checkedout', $i, '', $item->checked_out_time, 'poolitems.', $canCheckin); ?>
				<?php endif; ?>
				<?php if ($canEdit) : ?>
					<a href="<?php echo JRoute::_('index.php?option=com_bfquiz_plus&task=poolitem.edit&id='.(int) $item->id); ?>">
						<?php echo $this->escape($item->description); ?></a>
				<?php else : ?>
						<?php echo $this->escape($item->description); ?>
				<?php endif; ?>
				<div class="small">
					<?php echo $this->escape($item->category_name); ?>
				</div>
			</td>
			<td class="center nowrap">
				<?php echo $item->qnsPerQuiz;?>
			</td>
			<td class="center nowrap">
				<?php echo $item->qnsPerPage;?>
			</td>
			<td class="center nowrap">
				<?php echo $item->mandatoryQns;?>
			</td>
			<?php if(floatval($version->RELEASE) <= '2.5') { ?>
			<td class="order">
				<?php if ($canChange) : ?>
					<?php if ($saveOrder) : ?>
						<span><?php echo $this->pagination->orderUpIcon($i, isset($this->ordering[$item->parent][$orderkey - 1]), 'poolitems.orderup', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>
						<span><?php echo $this->pagination->orderDownIcon($i, $this->pagination->total, isset($this->ordering[$item->parent][$orderkey + 1]), 'poolitems.orderdown', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>
					<?php endif; ?>
					<?php $disabled = $saveOrder ?  '' : 'disabled="disabled"'; ?>
					<input type="text" name="order[]" size="5" value="<?php echo $orderkey + 1;?>" <?php echo $disabled ?> class="text-area-order" />
					<?php $originalOrders[] = $orderkey + 1; ?>
				<?php else : ?>
					<?php echo $orderkey + 1;?>
				<?php endif; ?>
			</td>
			<?php } ?>
			<td class="center hidden-phone">
				<?php echo (int) $item->id; ?>
			</td>
		</tr>

	<?php endforeach; ?>
	 </tbody>
	</table>

	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

<?php
//Automatic Database Table Builder
$database = JFactory::getDBO();
$config = JFactory::getConfig();

$mycategory = bfquiz_plusController::getCategoryPool();

$db = JFactory::getDBO();
$app = JFactory::getApplication();

if( sizeof( $mycategory ) ) {
    foreach( $mycategory as $mycat  ) {
	    $myid = $mycat->id;
	    $table=$app->getCfg('dbprefix')."bfquizplus_".$myid."_pool";

	    $result = $database->getTableList();
	    if (!in_array($table, $result)) {
	       //Table does not exist

	       $myFieldsMissing="";
		   for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		   {
		   		$row = &$this->items[$i];

				if($row->id == $myid){
				   for($z=1; $z < $row->qnsPerQuiz+1; $z++){
				   	  $tempqid = "qid".$z;
				   	  $tempanswer = "answer".$z;
	 		    		if($app->getCfg('dbtype') == 'sqlsrv'){
	 		       			$myFieldsMissing.= "[".$tempqid."] [int],";
			       			$myFieldsMissing.= "[".$tempanswer."] [nvarchar](max),";
			       		}else{
			       			$myFieldsMissing.= "`".$tempqid."` int(11),";
	 			      		$myFieldsMissing.= "`".$tempanswer."` TEXT,";
			       		}

	 			   }
				}
       		}

       		if($app->getCfg('dbtype') == 'sqlsrv'){
		       $query="CREATE TABLE [".$table."](
	  			    [id] [bigint] IDENTITY(1,1) NOT NULL,
	      			[Name] [nvarchar](150) NOT NULL,
	      			[Email] [nvarchar](150) NOT NULL,
	      			[uid] [int],
	      			[DateReceived] [datetime] NOT NULL,
	      			[ip] [nvarchar](50) NOT NULL,
					[score1] [int],
					[matrixid] [int],
					[answerseq] [nvarchar](255) NOT NULL,
					[DateCompleted] [datetime] NOT NULL,
	      			[state] [smallint],
	  			    ".$myFieldsMissing."
					 CONSTRAINT [PK_".$table."_id] PRIMARY KEY CLUSTERED
					(
						[id] ASC
					)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
		    	);";
       		}else{
		       $query="CREATE TABLE ".$table." (
	  			    `id` int(11) NOT NULL auto_increment,
	      			`Name` varchar(150) default NULL,
	      			`Email` varchar(150) default NULL,
	      			`uid` int(11) NOT NULL default 0,
	      			`DateReceived` datetime NOT NULL,
	      			`ip` varchar(50) default NULL,
	      			`score` int(11) NOT NULL default 0,
	      			`matrixid` int(11) NOT NULL default 0,
	      			`answerseq` varchar(255) default NULL,
	      			`DateCompleted` datetime NOT NULL,
	      			`state` tinyint(3) NOT NULL default '1',
	  			    ".$myFieldsMissing."
	      			PRIMARY KEY  (`id`)
		    	);";
       		}

	       $db->setQuery( $query );
	       if (!$db->query())
	       {
	       	   echo $db->getErrorMsg();
	    	   return false;
	       }
	       //Finished Table creation


	    }else{
	       //Table already exists
			$db = JFactory::getDBO();
		    // Grab the fields for the selected table
		    $fields = $db->getTableColumns( $table, true );

		    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		    {
		    	$query="";
	   			$row = &$this->items[$i];

				if($row->id == $myid){
			   		//how many fields should there be?
			   		$numfields=($row->qnsPerQuiz * 2)+11;
			   		if(sizeof( $fields ) < $numfields){
			      		$numbermissing=($numfields-sizeof( $fields ))/2;
			   			for($z=($row->qnsPerQuiz+1)-$numbermissing; $z < $row->qnsPerQuiz+1; $z++){
			   				if($z==($row->qnsPerQuiz+1)-$numbermissing){ //first one
			   					$query="ALTER TABLE ".$table;
			   				}
			   	  			$tempqid = "qid".$z;
			   	  			$tempanswer = "answer".$z;
			   	  			if($z==$row->qnsPerQuiz){ //last one
			   	  				if($app->getCfg('dbtype') == 'sqlsrv'){
				   	  			   $query.= " ADD [".$tempqid."] [int],";
				      			   $query.= " ADD [".$tempanswer."] [nvarchar](max);";
			   	  				}else{
				   	  			   $query.= " ADD `".$tempqid."` int(11),";
				      			   $query.= " ADD `".$tempanswer."` TEXT;";
			   	  				}
			   	  			}else{
			   	  				if($app->getCfg('dbtype') == 'sqlsrv'){
				      			   $query.= " ADD [".$tempqid."] [int],";
				      			   $query.= " ADD [".$tempanswer."] [nvarchar](max),";
			   	  				}else{
				      			   $query.= " ADD `".$tempqid."` int(11),";
				      			   $query.= " ADD `".$tempanswer."` TEXT,";
			   	  				}
			   	  			}
			   			}
			   		}
				}

				if($query != ""){
					$db->setQuery( $query );
	  	       		if (!$db->query())
	  	       		{
	  	       			echo $db->getErrorMsg();
		  	  	   		return false;
		       		}
				}
		    }
	    }
   }

}

?>