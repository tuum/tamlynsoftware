<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelCategories extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'categories';
	}

	public function save($data)
	{
		parent::save($data);

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			//does content_type record exist for this category?
			$catid=$data['bfsurvey_category_id'];

			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('type_id');
			$query->from('#__content_types');
			$query->where('type_alias = '.$db->quote('com_bfsurvey.'.$catid.'result'));

			$db->setQuery((string)$query);
			$type_id=$db->loadResult();

			if($type_id > 0)
			{
				//do nothing
			}
			else
			{
				//need to add record to content type table
				$table = JTable::getInstance('Contenttype', 'JTable');
				if(!$table->load(array('type_alias' => 'com_bfsurvey.'.$catid.'result')))
				{
					$common = new stdClass;
					$common->core_content_item_id = 'bfsurvey_'.$catid.'result_id';
					$common->core_title = 'title';
					$common->core_state = 'enabled';
					//$common->core_alias = 'slug';
					$common->core_created_time = 'created_on';
					$common->core_modified_time = 'modified_on';
					$common->core_ordering = 'ordering';
					//$common->core_catid = 'bfsurvey_category_id';
					$common->asset_id = null;
					$field_mappings = new stdClass;
					$field_mappings->common[] = $common;
					$field_mappings->special = array();
					$special = new stdClass;
					$special->dbtable = '#__bfsurvey_'.$catid.'results';
					$special->key = 'bfsurvey_'.$catid.'result_id';
					$special->type = 'My'.$catid.'result';
					$special->prefix = 'BFSurveyTable';
					$special->config = 'array()';
					$table_object = new stdClass;
					$table_object->special = $special;
					$contenttype['type_title'] = 'BFSurvey '.$catid.'result';
					$contenttype['type_alias'] = 'com_bfsurvey.'.$catid.'result';
					$contenttype['table'] = json_encode($table_object);
					$contenttype['rules'] = '';
					$contenttype['router'] = 'BFSurveyHelperRoute::getBFSurveyRoute';
					$contenttype['field_mappings'] = json_encode($field_mappings);
					$contenttype['formFile'] = 'components\\/com_bfsurvey\\/views\\/'.$catid.'result\\/tmpl\\/form.form.xml';
					$contenttype['hideFields'] = '["locked_by","locked_on"]';
					$contenttype['ignoreChanges'] = '["modified_by", "modified_on", "locked_by","locked_on","recaptcha_challenge_field","recaptcha_response_field","id","Itemid"]';
					$contenttype['convertToInt'] = '["ordering"]';
					$contenttype['displayLookup'] = '[{"sourceColumn":"bfsurvey_category_id","targetTable":"#__bfsurvey_categories","targetColumn":"bfsurvey_category_id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]';

					$table->save($contenttype);
				}
			}
		}

		return true;
	}
}