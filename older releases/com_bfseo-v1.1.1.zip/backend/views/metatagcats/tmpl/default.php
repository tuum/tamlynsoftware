<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');

if (version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');
F0FTemplateUtils::addJS('media://com_bfseo/js/checkmeta.js');

$input = JFactory::getApplication()->input;
$options = JComponentHelper::getParams('com_bfseo');
$minDescLength = $options->get('minDescLength', 6);
$maxDescLength = $options->get('maxDescLength', 160);
$minWarningText = $options->get('minWarningText', 'Too short');
$maxWarningText = $options->get('maxWarningText', 'Too long');
?>

<div class="row">
	<form id="adminForm" name="adminForm" method="post" action="<?php echo JRoute::_('index.php?option=com_bfseo') ?>">
		<div class="row">
			<div class="span4" style='margin-left: 50px'><?php echo bfseoHelper::createDropDown($input->get('view')); ?></div>
		</div>
		<div class="row">
			<div class='span12'>
				<table class='table table-condensed metatable'>
					<tr>
						<th class='menu-id'><?php echo JText::_('COM_BFSEO_TITLE_CATEGORYID'); ?></th>
						<th class='category'><?php echo JText::_('COM_BFSEO_TITLE_CATEGORY'); ?></th>
						<th class='descrip'><?php echo JText::_('COM_BFSEO_TITLE_METADESCRIPTION'); ?></th>
					</tr>
					<?php foreach ($this->menuItems as $menu): ?>
						<tr>
							<td class='menu-id'><?php echo $menu->id ?>
								<input type='hidden' name='id[<?php echo $menu->id ?>]' value='<?php echo $menu->id ?>'>
							</td>
							<td class='category'>
								<?php echo $menu->title ?>
								<br>
								<!-- <a href="<?php //echo JRoute::_('index.php?option=com_categories&view=category&layout=edit&id='.$menu->id.'&extension=com_content'); ?>" target="_blank"><span class="icon-edit"></span></a> -->
							</td>
							<?php
							$id = $menu->id;
							$desc = $menu->metadesc;

							$borderColor = "border-color: ";
							$textColor = 'color: ';
							$warning='';
							?>
							<td><?php
								if (!empty($desc)) {
									if (strlen($desc) < $minDescLength) {
										$borderColor .= "DarkViolet";
										$warning=$minWarningText;
										$textColor .= "DarkViolet";
									} else if (strlen($desc) > $maxDescLength) {
										$borderColor .= "yellow";
										$warning=$maxWarningText;
										$textColor .= "DeepPink";
									}
								}

								//check for duplicate
								foreach ($this->menuItems as $tempmenu){
									$tempid = $tempmenu->id;
									$tempdesc = $tempmenu->metadesc;
									if($tempdesc == $desc && $tempid != $id && $desc != ''){
										$warning= JText::_('COM_BFSEO_ERROR_DUPLICATE_CONTENT');
										$borderColor = 'border-color: red';
										$textColor = 'color: red';
									}
								}
								?>
								<textarea rows=1 class='metaDescCat metaDesc' style='<?php echo $borderColor ?>'
										  name='desc[<?php echo $menu->id ?>]'
										  id='desc<?php echo $menu->id ?>'><?php echo $desc ?></textarea>
								<div id="warningdesc<?php echo $menu->id ?>" style="width:100%; <?php echo $textColor ?>" /><?php echo $warning; ?></div>
							</td>
						</tr>
					<?php endforeach ?>
				</table>
			</div>

			<input type="hidden" name="task" value=""/>
			<?php echo JHtml::_('form.token'); ?>

		</div>
	</div>
	</form>
	<script>
		var minDescLength = <?php echo $minDescLength ?>;
		var maxDescLength = <?php echo $maxDescLength ?>;
		var minWarningText = '<?php echo $minWarningText ?>';
		var maxWarningText = '<?php echo $maxWarningText ?>';
	</script>
</div>