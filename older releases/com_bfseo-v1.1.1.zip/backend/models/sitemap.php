<?php
/**
 *  @package BF SEO
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelSitemap extends F0FModel
{
	public function createsitemap($sitemap_menus)
	{
		//save the value of sitemap_menus
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);

		//check to see if record already exists
		$query->clear();
		$query->select('bfseo_xmlsitemap_id');
		$query->from('#__bfseo_xmlsitemap');
		$query->where('bfseo_xmlsitemap_id = 1');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$sitemapsetting = $db->loadResult();

		$query->clear();
		if($sitemapsetting)
		{
			$query->update('#__bfseo_xmlsitemap');
		}
		else
		{
			$query->insert('#__bfseo_xmlsitemap');
			$query->columns(array($db->quoteName('sitemap_menus')));
		}
		$query->set('sitemap_menus='.$db->quote($sitemap_menus));
		$query->where('bfseo_xmlsitemap_id=1');
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum()) {
			echo $db->stderr();
			return false;
		}

		if(file_exists(JPATH_ROOT. "/sitemap.xml")){
			//sitemap file already exists, so exit
			return false;
		}

$contents = '<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
   <sitemap>
      <loc>'.JURI::root().'index.php?option=com_bfseo&amp;view=xmlsitemap&amp;format=raw</loc>
   </sitemap>
</sitemapindex>';

		JFile::write(JPATH_ROOT. "/sitemap.xml", $contents);

		if(file_exists(JPATH_ROOT. "/sitemap.xml")){
			//sitemap file has been created successfully
			return true;
		}
	}

	static function getMenuItems()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('id, menutype, title, description');
		$query->from('#__menu_types');
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		return $rows;
	}

	public function deletesitemap()
	{
		$result = JFile::delete(JPATH_ROOT. "/sitemap.xml");

		return $result;
	}
}