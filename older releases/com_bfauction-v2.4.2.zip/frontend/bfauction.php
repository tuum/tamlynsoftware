<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

include_once(JPATH_COMPONENT_ADMINISTRATOR.'/helpers/const.php');
include_once(JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfauction.php');

// Load F0F
include_once JPATH_LIBRARIES.'/f0f/include.php';
if(!defined('F0F_INCLUDED')) {
	JError::raiseError ('500', 'F0F is not installed');
}

F0FDispatcher::getTmpInstance('com_bfauction')->dispatch();