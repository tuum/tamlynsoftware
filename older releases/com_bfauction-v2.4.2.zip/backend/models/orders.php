<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelOrders extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'items';
	}


	public function getOrders()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('orderStatus = "P"');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		return $rows;

	}
}