<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelRptitems extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'items';
	}

	public function buildQuery($overrideLimits = false)
	{
		// Create a new query object.
		$db		= $this->getDbo();
		$query	= $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
				$this->getState(
						'list.select',
						'a.bfauction_item_id, a.endDate, a.currentBid, a.tax, a.commission, a.saleType,' .
						'a.productId, a.title, a.highBidder, a.itemLocation, a.shipping,'.
						'a.costPrice, '.
						'a.checked_out, a.checked_out_time,' .
						'a.enabled, a.access, a.ordering,'.
						'a.language, a.publish_up, a.publish_down,'.
						'a.winEmailSent, a.reservePrice,' .
						'a.uid,' .
						'a.bfauction_category_id'
				)
		);

		$query->from($db->quoteName('#__bfauction_items').' AS a');

		// Join over the asset groups.
		$query->select('ag.title AS access_level');
		$query->join('LEFT', '#__viewlevels AS ag ON ag.id = a.access');

		// Join over the categories.
		$query->select('c.title AS category_name');
		$query->join('LEFT', '#__bfauction_categories AS c ON c.bfauction_category_id = a.bfauction_category_id');

		// Join over the users
		$query->select('d.username');
		$query->join('LEFT', '#__users AS d ON d.id = a.uid');

		// Join over the users (for high bidder)
		$query->select('e.name');
		$query->join('LEFT', '#__users AS e ON e.username = a.highBidder');

		// Filter by access level.
		if ($access = $this->getState('filter.access')) {
			$query->where('a.access = '.(int) $access);
		}

		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published)) {
			$query->where('a.enabled = '.(int) $published);
		} else if ($published === '') {
			$query->where('(a.enabled IN (0, 1, 2))');  //include archived items
		}

		// Filter by category.
		$categoryId = $this->getState('filter.category_id');
		if (is_numeric($categoryId)) {
			$query->where('a.bfauction_category_id = '.(int) $categoryId);
		}

		// Filter by search in question
		$search = $this->getState('filter.search');
		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.bfauction_item_id = '.(int) substr($search, 3));
			} else {
				$search = $db->Quote('%'.$db->escape($search, true).'%');
				$query->where('(a.title LIKE '.$search.')');
			}
		}

		// Filter on the language.
		if ($language = $this->getState('filter.language')) {
			$query->where('a.language = ' . $db->quote($language));
		}

		// Filter by auction status.
		$auction_status = $this->getState('filter.auction_status');
		if($auction_status == ""){
			// do nothing because we want to show all
		}else if($auction_status == "Ended") {
			$query->where('a.winEmailSent > 0');
		}else if($auction_status == "SoldItems"){
			$query->where('a.saleType > 0');
			$query->where('a.currentBid >= a.reservePrice');
		}else if($auction_status == "UnsoldItems"){
			$query->where('a.saleType = 0');
		}else{
			$query->where('a.winEmailSent = 0');
		}

		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering');
		$orderDirn	= $this->state->get('list.direction');
		if ($orderCol == 'a.ordering' || $orderCol == 'category_name') {
			$orderCol = 'c.title '.$orderDirn.', a.ordering';
		}
		if($orderCol){
			$orderCol='a.parent,'.$orderCol;
		}else{
			$orderCol='a.parent';
		}
		$query->order($db->escape($orderCol.' '.$orderDirn));

		return $query;
	}
}