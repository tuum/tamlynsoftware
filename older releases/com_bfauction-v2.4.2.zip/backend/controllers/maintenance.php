<?php
/**
 * @package BF Auction
 * @copyright Copyright (c)2015 Tim Plummer
 * @license GNU General Public License version 3, or later
 * @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionControllerMaintenance extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'maintenance';
	}

	public function execute($task)
	{
		if (!in_array($task, array('import'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function import()
	{
		$model = $this->getThisModel();

		$includeEmail = JFactory::getApplication()->input->get('includeEmail');

		$msg = $model->import($includeEmail);
		if ($msg === true) {
			$msg = JText::_('COM_BFAUCTION_IMPORT_SUCCESS');
		}

		$this->setRedirect('index.php?option=com_bfauction&view=maintenance', $msg);
		$this->redirect();
	}


}