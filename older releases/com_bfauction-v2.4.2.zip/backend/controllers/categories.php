<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2015 Tim Plummer
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionControllerCategories extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'categories';
	}

	public function edit()
	{
		$input = JFactory::getApplication()->input;
		$model = $this->getThisModel();
		$validUser = $model->isValidUser($input->get('id'));
		if ($validUser) {
			parent::edit();
		} else {
			return JError::raiseWarning(500, JText::_('COM_BFAUCTION_ACCESS_DENIED'));
		}
	}

}