<?php
/**
 * $Id: view.html.php 63 2014-03-04 10:44:40Z tuum $
 * scorecats View for bfquiz_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * Questions View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusViewScorecats extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;

    /**
     * Email Template view display method
     * @return void
     **/
    function display($tpl = null)
    {
    	$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');

		bfquiz_plusHelper::addSubmenu('scorecats');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->ordering = array();

		// Preprocess the list of items to find ordering divisions.
		//foreach ($this->items as $item) {
		//	$this->ordering[$item->parent][] = $item->id;
		//}

		$this->addToolbar();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';

		$state	= $this->get('State');
		$canDo	= bfquiz_plusHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title(JText::_('COM_BFQUIZPLUS_TOOLBAR_SCORE_CAT'), 'bfquiz_toolbar_title');
		if ($canDo->get('core.create')) {
			JToolBarHelper::addNew('scorecat.add','JTOOLBAR_NEW');
		}
		if ($canDo->get('core.edit')) {
			JToolBarHelper::editList('scorecat.edit','JTOOLBAR_EDIT');
		}
		if ($canDo->get('core.edit.state')) {

			JToolBarHelper::divider();
			JToolBarHelper::custom('scorecats.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom('scorecats.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);

			JToolBarHelper::divider();
			JToolBarHelper::archiveList('scorecats.archive','JTOOLBAR_ARCHIVE');
		}
		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'scorecats.delete','JTOOLBAR_EMPTY_TRASH');
			JToolBarHelper::divider();
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('scorecats.trash','JTOOLBAR_TRASH');
			JToolBarHelper::divider();
		}

		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom( 'scorecats.copyItem', 'copy.png', 'copy_f2.png', 'COM_BFQUIZPLUS_TOOLBAR_COPY' );
		}

		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_bfquiz_plus&view=scorecats');

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_PUBLISHED'),
				'filter_published',
				JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_CATEGORY'),
				'filter_category_id',
				JHtml::_('select.options', JHtml::_('category.options', 'com_bfquiz_plus'), 'value', 'text', $this->state->get('filter.category_id'))
			);
		}
	}


	/**
	* Returns an array of fields the table can be sorted by
	*
	* @return  array  Array containing the field name to sort by as the key and display text as value
	*
	* @since   3.0
	*/
	protected function getSortFields()
	{
		return array(
			'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
			'a.state' => JText::_('JSTATUS'),
			'a.title' => JText::_('JGLOBAL_TITLE'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}
}