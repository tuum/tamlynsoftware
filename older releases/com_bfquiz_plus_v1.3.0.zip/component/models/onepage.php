<?php
/**
 * $Id: onepage.php 63 2014-03-04 10:44:40Z tuum $
 * Onepage Model for Bfquiz_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.modelitem');

/**
 * Onepage Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class Bfquiz_plusModelOnepage extends JModelItem
{
	/**
	 * @var object item
	 */
	protected $item;

	/**
	 * Method to auto-populate the model state.
	 *
	 * This method should only be called once per instantiation and is designed
	 * to be called on the first call to the getState() method unless the model
	 * configuration flag to ignore the request is set.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @return	void
	 * @since	1.6
	 */
	protected function populateState()
	{
		$app = JFactory::getApplication();

		// Load the parameters.
		$params = $app->getParams();
		$this->setState('params', $params);
		parent::populateState();
	}

	/**
	 * Get the questions
	 * @return object The questions to be displayed to the user
	 */
	public function getItem()
	{
		$app		= JFactory::getApplication();
		$params		= $app->getParams();

		$catid=JRequest::getInt('catid', 0);

		$db		= $this->getDbo();
		$query	= $db->getQuery(true);

		if (!isset($this->item))
		{
			$query->from('#__bfquiz_plus AS a');
			$query->select('a.*,  cc.title AS category_name');
			$query->join('LEFT', '#__categories AS cc ON cc.id = a.catid');
			$query->where('a.state = 1');
			$query->where('a.catid = '.(int) $catid);
			$query->order('a.parent, a.ordering');
			$db->setQuery((string)$query);

			if (!$this->item = $db->loadObjectList())
			{
				$this->setError($db->getError());
			}

			//establish the parent-child hierarchy
			$children = array();
			// first pass - collect children
			foreach ($this->item as $v )
			{
				//get the parent id
				$pt = $v->parent;
				// @ symbol tests to see if $children[parentid] is blank
				// ? ternary operator if first part is true, then $children[$pt] otherwise array()
				$list = @$children[$pt] ? $children[$pt] : array();
				//add current row element to the bottom of list array
				array_push( $list, $v );
				$children[$pt] = $list;
			}

			//second pass - reorder elements
			$mylist = array();
			foreach ($this->item as $v )
			{
				if ($v->parent==0)
				{
					array_push($mylist, $v);

					//now are there any children
					if (isset($children[$v->id]))
					{
						foreach ($children[$v->id] as $c )
						{
							array_push($mylist, $c);
						}
					}
				}
			}
		}
		$this->item = $mylist;
		return $this->item;
	}
}