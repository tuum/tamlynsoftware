<?php defined('_JEXEC') or die(); ?>
<?php 
/**
 * $Id: default.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
    <table width="100%">
    <tr>
    	<td>
    	<?php
    	   $row =& $this->items[0];
    	   echo JText::_( 'Score = ' );
    	   echo $row->score;
    	?>
    	</td>
    </tr>
    </table>

    <table width="100%">
    <thead>
        <tr>
            <th width="50%">
                <?php echo JText::_( 'Question' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'Answer' ); ?>
            </th>
        </tr>
    </thead>
    <?php


    $k = 0;
    for ($i=0, $n=count( $this->items2 ); $i < $n; $i++)
    {
        $row =& $this->items[0];
        $row2 =& $this->items2[$i];

        if(isset($row2->question)){

        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
			    <?php echo $row2->question; ?>

            </td>
			<td>
			    <?php

			    if(!isset($row2->field_name)){
			       $row2->field_name = "";
			    }

				if(!isset($row2->question_type)){
				   $row2->question_type = "";
				}

			    $tempvalue = $row2->field_name;

			    if(!isset($tempvalue)){
			       $tempvalue = "";
			    }


			    if(isset($row->$tempvalue)){
			      echo $row->$tempvalue;
			    }
			    ?>

			</td>
        </tr>
        <?php
        }

        $k = 1 - $k;
    }
    ?>
    </table>
