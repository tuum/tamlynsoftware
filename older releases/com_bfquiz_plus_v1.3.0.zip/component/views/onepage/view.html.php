<?php
/**
 * $Id: view.html.php 63 2014-03-04 10:44:40Z tuum $
 * One Page View for BF Quiz Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * Bfquiz_plusViewOnePage View
 *
 * @package    Joomla
 * @subpackage Components
 */
class Bfquiz_plusViewOnepage extends JViewLegacy
{
	protected $state;
	protected $item;

    function display($tpl = null)
    {
    	$app		= JFactory::getApplication();
		$params		= $app->getParams();

        // Get data from the model
		$items		= $this->get('Item');

		$this->assignRef( 'items', $items );
		$this->assignRef( 'params', $params );

		$this->_prepareDocument();

		$catid=JRequest::getInt('catid', 0);
	    if($catid){
        	parent::display($tpl);
	    }else{
	    	echo JText::_( "COM_BFQUIZPLUS_ERROR_MUST_SELECT_CATEGORY");
	    }
    }

    /**
     * Prepares the document
     */
    protected function _prepareDocument()
    {
    	$app	= JFactory::getApplication();
    	$menus	= $app->getMenu();
    	$title	= null;

    	// Because the application sets a default page title,
    	// we need to get it from the menu item itself
    	$menu = $menus->getActive();
    	if($menu)
    	{
    		$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
    	} else {
    		$this->params->def('page_heading', JText::_('COM_BFQUIZPLUS_DEFAULT_PAGE_TITLE'));
    	}
    	$title = $this->params->get('page_title', '');
    	if (empty($title)) {
    		$title = $app->getCfg('sitename');
    	}
    	elseif ($app->getCfg('sitename_pagetitles', 0) == 1) {
    		$title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
    	}
    	elseif ($app->getCfg('sitename_pagetitles', 0) == 2) {
    		$title = JText::sprintf('JPAGETITLE', $title, $app->getCfg('sitename'));
    	}
    	$this->document->setTitle($title);

    	if ($this->params->get('menu-meta_description'))
    	{
    		$this->document->setDescription($this->params->get('menu-meta_description'));
    	}

    	if ($this->params->get('menu-meta_keywords'))
    	{
    		$this->document->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
    	}

    	if ($this->params->get('robots'))
    	{
    		$this->document->setMetadata('robots', $this->params->get('robots'));
    	}
    }
}