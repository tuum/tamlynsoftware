<?php
/**
 * $Id: file.script.php 101 2015-03-07 04:09:57Z tuum $
 * Install file for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die;

class Com_bfauction_plusInstallerScript {

function install($parent) {
	jimport( 'joomla.filesystem.file' );

	if(!file_exists(JPATH_SITE . "/images/com_bfauction_plus/")){
		JFolder::create(JPATH_SITE. "/images/com_bfauction_plus/");
	};

	if(!file_exists(JPATH_SITE. "/images/com_bfauction_plus/index.html")){
		JFile::copy(JPATH_SITE."/components/com_bfauction_plus/index.html",JPATH_SITE. "/images/com_bfauction_plus/index.html");
	};

	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);

	//check for sample data
	$query->select('id');
	$query->from('#__bfauction_plus');
	$db->setQuery((string)$query);
	$result=$db->loadResult();

	if($result){
		//no need for sample data
	}else{
		//install sample data
		$query->clear();
		$query->insert('#__categories');
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			//new way of doing this to support multiple database types such as SQL Server
			$query->columns(array($db->quoteName('parent_id'), $db->quoteName('title'), $db->quoteName('alias'), $db->quoteName('extension'), $db->quoteName('published'), $db->quoteName('level'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('metadesc'), $db->quoteName('metakey'), $db->quoteName('metadata'), $db->quoteName('lft'), $db->quoteName('rgt') ));
			$query->values('1, '.$db->quote( $db->escape('Example'), false ).', '.$db->quote( $db->escape('example'), false ).', '.$db->quote('com_bfauction_plus').', 1, 1, 1, '.$db->quote('*').', '.$db->quote('').' , '.$db->quote('').' ,'.$db->quote('{"page_title":"","author":"","robots":""}').', 1, 2' );
		}else{
			//the following is required to support Joomla 1.6. Remove this when we drop 1.6 support.
			$query->set('`parent_id` = 1');
        	$query->set('`title` = '.$db->quote( $db->escape('Example'), false ));
        	$query->set('`alias` = '.$db->quote( $db->escape('example'), false ));
        	$query->set('`extension` = '.$db->quote('com_bfauction_plus'));
        	$query->set('`published` = 1');
        	$query->set('`level` = 1');
        	$query->set('`access` = 1');
			$query->set('`lft` = 1');
			$query->set('`rgt` = 2');
		}
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

	$query->clear();
	$query->select('max(id) AS id');
	$query->from('#__categories');
	$db->setQuery((string)$query);
	$catid=$db->loadResult();
	if ($db->getErrorNum())
	{
		echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
		return;
	}

	//check for email sample data
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);
	$query->clear();
	$query->select('id');
	$query->from('#__bfauction_plus_email');
	$db->setQuery((string)$query);
	$result=$db->loadResult();

	if($result){
		//no need for sample email data
	}else{
		//install email data
		$query->clear();
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->insert('#__bfauction_plus_email');
			$query->columns(array($db->quoteName('catid'), $db->quoteName('title'), $db->quoteName('subject'), $db->quoteName('description'), $db->quoteName('date'), $db->quoteName('checked_out'), $db->quoteName('checked_out_time'), $db->quoteName('state'), $db->quoteName('ordering'), $db->quoteName('publish_down'), $db->quoteName('archived'), $db->quoteName('approved'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('created'), $db->quoteName('created_by'), $db->quoteName('modified'), $db->quoteName('modified_by'), $db->quoteName('parent'), $db->quoteName('publish_up')));
			$query->values($catid.", 'BidConfirm', 'Your bid is confirmed {itemtitle}', 'Thank you {username} for your bid of <strong>{currency}{bid}</strong> for {description}', '', 0, '', 1, 1, '','','','','*','','','','',0,''");
			$query->values($catid.", 'Outbid', 'You have been outbid on {itemtitle}', '<p>Unfortunately {username} you have been outbid for {description}.</p>\r\n<p> </p>\r\n<p>The auction for this item will end on {enddate}, so there may still be time to increase your bid.</p>', '', 0, '', 1, 2, '','','','','*','','','','',0,''");
			$query->values($catid.", 'WinningBid', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '', 0, '', 1, 3, '','','','','*','','','','',0,''");
			$query->values($catid.", 'LoosingBid', 'Sorry you did not win {itemid} {itemtitle} ', '<p>Unfortunately the auction for {itemid} {itemtitle} has finished and you did not win this item. Better luck next time.</p>', '', 0, '', 1, 4, '','','','','*','','','','',0,''");
			$query->values($catid.", 'ReserveNotMet', 'Reserve Price not reached for {itemtitle}', 'Unfortunately the reserve price has not been reached for this item so it was not sold.', '', 0, '', 1, 1, '','','','','*','','','','',0,''");
			$query->values($catid.", 'BuyNow', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '', 0, '', 1, 3, '','','','','*','','','','',0,''");
		}else{
		$query = "INSERT INTO `#__bfauction_plus_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `state`, `ordering`) VALUES
			(1, ".$catid.", 'BidConfirm', 'Your bid is confirmed {itemtitle}', 'Thank you {username} for your bid of <strong>{currency}{bid}</strong> for {description}', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1),
			(2, ".$catid.", 'Outbid', 'You have been outbid on {itemtitle}', '<p>Unfortunately {username} you have been outbid for {description}.</p>\r\n<p> </p>\r\n<p>The auction for this item will end on {enddate}, so there may still be time to increase your bid.</p>', '2010-05-09 12:22:34', 0, '0000-00-00 00:00:00', 1, 2),
			(3, ".$catid.", 'WinningBid', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '2011-02-20 05:19:36', 0, '0000-00-00 00:00:00', 1, 3),
			(4, ".$catid.", 'LoosingBid', 'Sorry you did not win {itemid} {itemtitle} ', '<p>Unfortunately the auction for {itemid} {itemtitle} has finished and you did not win this item. Better luck next time.</p>', '2011-02-20 05:20:45', 0, '0000-00-00 00:00:00', 1, 4),
			(5, ".$catid.", 'ReserveNotMet', 'Reserve Price not reached for {itemtitle}', 'Unfortunately the reserve price has not been reached for this item so it was not sold.', '2010-05-10 03:07:53', 0, '0000-00-00 00:00:00', 1, 1),
			(6, ".$catid.", 'BuyNow', 'Congratulations you won {itemid} {itemtitle}', '<p>Congratulations {username} you won the following item {itemid} {itemtitle} for {currency}{bid}</p>\r\n<p>{description}</p>', '2011-02-20 05:19:36', 0, '0000-00-00 00:00:00', 1, 6)";
		}
		$db->setQuery( $query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}
?>

	<div><strong>BF Auction Plus</strong> Component <em>for Joomla!</em></div>
	<center>
	<table width = "100%" border = "0">
	<tr>
    	<td width = "10%"></td>

    	<td width = "90%">
      	<p>
                <br/>BF Auction Plus is a simple auction tool for Joomla 2.5.x / 3.x
                <br/>
                <br/>Congratulations, you have successfully installed BF Auction Plus!
        </p>
    	</td>
	</tr>
    </table>
	</center>

<?php
}

	function uninstall($parent) {
		?>
		<div>BF Auction Plus has now been removed from your system.</div>
		<p>
		We're sorry to see you go! Please feel free to post reasons on our forum to help us to improve our product.<br>
		<br>
		Don't forget to delete any BF Auction Plus menu items.
		<br>
		<br>
		</p>
		<?php
	}

	function update( $parent ) {
		$db = JFactory::getDBO();
		$table=array("#__bfauction_plus_bid");
		$found=0;
		//forwards compatibility for Joomla 3.0
		//$fields = $db->getTableFields( $table, true );
		$fields = $db->getTableColumns( "#__bfauction_plus_bid", true );
		if ( isset($fields['maxbid']) ){
			$found=1;
		}

		//foreach( $fields[$table] as $field => $type ) {
		//	if ($field == "maxbid") {
		//		$found=1;
		//	}
		//}

		if($found == 0){
			$query="ALTER TABLE `#__bfauction_plus_bid` ADD `maxbid` FLOAT( 10, 2 ) NOT NULL DEFAULT '0'";
			$db->setQuery( $query);
			if (!$db->query())
			{
				echo $db->getErrorMsg();
				return false;
			}
		}

		jimport( 'joomla.filesystem.file' );

		if(!file_exists(JPATH_SITE . "/images/com_bfauction_plus/")){
			JFolder::create(JPATH_SITE. "/images/com_bfauction_plus/");
		};

		if(!file_exists(JPATH_SITE. "/images/com_bfauction_plus/index.html")){
			JFile::copy(JPATH_SITE."/components/com_bfauction_plus/index.html",JPATH_SITE. "/images/com_bfauction_plus/index.html");
		};
	}

	function preflight($type, $parent) {
		//not implemented
	}

	/**
	* method to run after an install/update/uninstall method
	*
	* @return void
	*/
	function postflight($type, $parent)  {
        // define the following parameters only if it is an original install
        if ( $type == 'install' ) {
                $params['showDisclaimer'] = '0';
                $params['allowEmail'] = '1';
				$params['bfcurrency'] = '$';
				$params['bfcurrency_code'] = 'USD';
				$params['dateFormat'] = 'd-m-Y H:i';
				$params['bidIncrement'] = '1';
				$params['dst'] = '0';
				$params['reverseAuction'] = '0';
				$params['ownBidsOnly'] = '0';
				$params['hideBid'] = '1';
				$params['increaseEndTime'] = '0';
				$params['increaseEndTimeLastMinutes'] = '5';
				$params['increaseEndTimeAmount'] = '5';
				$params['includeCommission'] = '0';
				$params['commissionAmount'] = '15';
				$params['includeCommission'] = '0';
				$params['includeTax'] = '0';
				$params['taxAmount'] = '10';
				$params['showTotalPrice'] = '0';
				$params['mainImageSize'] = '200';
				$params['max_width'] = '250';
				$params['max_height'] = '250';
				$params['max_width_t'] = '90';
				$params['max_height_t'] = '90';
				$params['max_image_size'] = '2048000';

				$this->setParams( $params );
        }

        jimport( 'joomla.filesystem.file' );

        //change router file for Joomla 2.5
        $version = new JVersion();
        if(floatval($version->RELEASE) <= '2.5') {
        	$router25=JPATH_SITE."/components/com_bfauction_plus/router.j25.php";
        	$router=JPATH_SITE."/components/com_bfauction_plus/router.php";
        	$router3=JPATH_SITE."/components/com_bfauction_plus/router.j3.php";
        	JFile::delete($router3);
        	if (is_file($router25) && is_file($router) && !is_file($router3)) {
        		JFile::move($router, $router3);
        		JFile::move($router25, $router);
        	}
        }
	}

    function setParams($param_array) {
            if ( count($param_array) > 0 ) {
                    // read the existing component value(s)
                    $db = JFactory::getDbo();
                    $db->setQuery('SELECT params FROM #__extensions WHERE name = "com_bfauction_plus"');
                    $params = json_decode( $db->loadResult(), true );
                    // add the new variable(s) to the existing one(s)
                    foreach ( $param_array as $name => $value ) {
                            $params[ (string) $name ] = (string) $value;
                    }
                    // store the combined new and existing values back as a JSON string
                    $paramsString = json_encode( $params );
                    $db->setQuery('UPDATE #__extensions SET params = ' .
                            $db->quote( $paramsString ) .
                            ' WHERE name = "com_bfauction_plus"' );
                            $db->query();
            }
    }
}