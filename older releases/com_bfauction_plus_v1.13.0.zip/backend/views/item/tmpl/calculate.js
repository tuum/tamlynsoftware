function calcualteTotalPrice(){
	if(document.getElementById("jform_commission").value){
	   commission = parseFloat(document.getElementById("jform_commission").value);
	}else{
	   commission = 0;
	}
	
	if(document.getElementById("jform_tax").value){
	   tax = parseFloat(document.getElementById("jform_tax").value);
	}else{
	   tax = 0;
	}
	
	if(document.getElementById("jform_shipping").value){
	   shipping = parseFloat(document.getElementById("jform_shipping").value);
	}else{
	   shipping = 0;
	}	
	
	if(document.getElementById("jform_currentBid").value){
		document.getElementById("jform_totalPrice").value = parseFloat(document.getElementById("jform_currentBid").value) + commission + tax + shipping;
	}else{
		document.getElementById("jform_totalPrice").value = 0;
	}
}