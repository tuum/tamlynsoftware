-- <?php /* $Id: install.sqlsrv.utf8.sql 94 2014-11-25 04:32:56Z tuum $ */ defined('_JEXEC') or die() ?>;

SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfauction_plus](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[title] [nvarchar](255) NOT NULL,
  	[description] [nvarchar](max) NOT NULL,
	[currentBid] [numeric](10, 2) NOT NULL,
	[highBidder] [nvarchar](255) NOT NULL,
	[date] [datetime] NOT NULL,
	[startDate] [datetime] NOT NULL,
	[endDate] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[itemLocation] [nvarchar](255) NOT NULL,
	[deliveryMethod] [nvarchar](255) NOT NULL,
	[image] [nvarchar](255) NOT NULL,
	[image2] [nvarchar](255) NOT NULL,
	[image3] [nvarchar](255) NOT NULL,
	[image4] [nvarchar](255) NOT NULL,
	[image5] [nvarchar](255) NOT NULL,
	[image6] [nvarchar](255) NOT NULL,
	[image7] [nvarchar](255) NOT NULL,
	[image8] [nvarchar](255) NOT NULL,
	[image9] [nvarchar](255) NOT NULL,
	[image10] [nvarchar](255) NOT NULL,
	[image11] [nvarchar](255) NOT NULL,
	[image12] [nvarchar](255) NOT NULL,
	[image13] [nvarchar](255) NOT NULL,
	[image14] [nvarchar](255) NOT NULL,
	[image15] [nvarchar](255) NOT NULL,
	[image16] [nvarchar](255) NOT NULL,
	[image17] [nvarchar](255) NOT NULL,
	[image18] [nvarchar](255) NOT NULL,
	[image19] [nvarchar](255) NOT NULL,
	[image20] [nvarchar](255) NOT NULL,
	[imageShared] [int] NOT NULL,
	[productId] [nvarchar](255) NOT NULL,
	[onlineStore] [nvarchar](20) NOT NULL,
	[paypalEmail] [nvarchar](150) NOT NULL,
	[bidIncrement] [numeric](10, 2) NOT NULL,
	[shipping] [numeric](10, 2) NOT NULL,
	[buyNowPrice] [numeric](10, 2) NOT NULL,
	[winEmailSent] [smallint] NOT NULL,
	[winEmailDate] [datetime] NOT NULL,
	[uid] [int] NOT NULL,
	[reservePrice] [numeric](10, 2) NOT NULL,
	[commission] [numeric](10, 2) NOT NULL,
	[tax] [numeric](10, 2) NOT NULL,
	[taxableItem] [smallint] NOT NULL,
	[commissionAmount] [numeric](10, 2) NOT NULL,
	[taxAmount] [numeric](10, 2) NOT NULL,
	[priceEstimate] [nvarchar](255) NOT NULL,
	[qtyAvailable] [nvarchar](255) NOT NULL,
	[condition] [nvarchar](255) NOT NULL,
	[buyersPremium] [nvarchar](255) NOT NULL,
	[saleType] [smallint] NOT NULL,
	[address1] [nvarchar](255) NOT NULL,
	[address2] [nvarchar](255) NOT NULL,
	[city] [nvarchar](255) NOT NULL,
	[region] [nvarchar](255) NOT NULL,
	[postcode] [nvarchar](255) NOT NULL,
	[country] [nvarchar](255) NOT NULL,
	[phone] [nvarchar](255) NOT NULL,
	[quantity] [int] NOT NULL,
	[quantityPurchased] [int] NOT NULL,
	[deliveryOption] [nvarchar](255) NOT NULL,
	[supplier] [nvarchar](255) NOT NULL,
  	[costPrice] [numeric](10, 2) NOT NULL,
  	[featured] [smallint] NOT NULL,
  	[alias] [nvarchar](255) NOT NULL,
	[metakey] [nvarchar](max) NOT NULL,
	[metadesc] [nvarchar](max) NOT NULL,
	[metadata] [nvarchar](max) NOT NULL,
	[params] [nvarchar](max) NOT NULL,
	[url] [nvarchar](250) NOT NULL DEFAULT '',
	[created_by_alias] [nvarchar](255) NOT NULL DEFAULT '',
 CONSTRAINT [PK_#__bfauction_plus_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus_bid]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfauction_plus_bid](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[itemid] [int] NOT NULL,
	[username] [nvarchar](255) NOT NULL,
	[uid] [int] NOT NULL,
	[email] [nvarchar](255) NOT NULL,
	[bid] [numeric](10, 2) NOT NULL,
	[bid_time] [datetime] NOT NULL,
	[bidCurrency] [nvarchar](255) NOT NULL,
	[commission] [numeric](10, 2) NOT NULL,
	[tax] [numeric](10, 2) NOT NULL,
	[maxbid] [numeric](10, 2) NOT NULL,
	[quantity] [int] NOT NULL,
	[deliveryOption] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfauction_plus_bid_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauction_plus_email]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfauction_plus_email](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[title] [nvarchar](250) NOT NULL,
	[subject] [nvarchar](255) NOT NULL,
	[sendTo] [nvarchar](255) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
 CONSTRAINT [PK_#__bfauction_plus_email_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfauctionpro_watchlist]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfauctionpro_watchlist](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[itemid] [int],
	[uid] [int],
	[emailSent] [smallint] NOT NULL,
	[emailDate] [datetime] NOT NULL,
 CONSTRAINT [PK_#__bfauctionpro_watchlist_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfuserlog]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfuserlog_plus](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [int],
	[site] [smallint] NOT NULL,
	[visitDate] [datetime] NOT NULL,
	[login] [smallint] NOT NULL,
	[published] [smallint] NOT NULL,
	[archived] [smallint] NOT NULL,
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
 CONSTRAINT [PK_#__bfuserlog_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;