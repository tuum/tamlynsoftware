<?php
/**
 * $Id: router.php 97 2015-02-04 12:16:24Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die;

/**
 * Routing class from com_bfauction_plus
 *
 * @package     Joomla.Site
 * @subpackage  com_bfauction_plus
 * @since       3.3
 */
class bfauction_plusRouter extends JComponentRouterBase
{

	public function build(&$query)
	{
		$segments = array();

		// Get a menu item based on Itemid or currently active
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		$params = JComponentHelper::getParams('com_bfauction_plus');
		$advanced = $params->get('sef_advanced_link', 0);

		// We need a menu item.  Either the one specified in the query, or the current active one if none specified
		if (empty($query['Itemid']))
		{
			$menuItem = $menu->getActive();
		}
		else
		{
			$menuItem = $menu->getItem($query['Itemid']);
		}

		$mView = (empty($menuItem->query['view'])) ? null : $menuItem->query['view'];
		$mId = (empty($menuItem->query['id'])) ? null : $menuItem->query['id'];

		if (isset($query['view']))
		{
			$view = $query['view'];

			if (empty($query['Itemid']) || empty($menuItem) || $menuItem->component != 'com_bfauction_plus')
			{
				$segments[] = $query['view'];
			}

			// We need to keep the view for forms since they never have their own menu item
			if ($view != 'form')
			{
				unset($query['view']);
			}
		}

		// Are we dealing with an bfauction_plus that is attached to a menu item?
		if (isset($query['view']) && ($mView == $query['view']) and (isset($query['id'])) and ($mId == (int) $query['id']))
		{
			unset($query['view']);
			unset($query['catid']);
			unset($query['id']);

			return $segments;
		}

		$grid=0;
		if (isset($query['grid']))
		{
			$grid = $query['grid'];
			if (!empty($query['Itemid']) && isset($menuItem->query['grid']))
			{
				if ($query['grid'] == $menuItem->query['grid'])
				{
					unset($query['grid']);
				}
			}
			else
			{
				if ($query['grid'] == '')
				{
					unset($query['grid']);
				}
			}
		}

		$cid = 0;
		if (isset($query['cid']))
		{
			$cid = $query['cid'];
			if (!empty($query['Itemid']) && isset($menuItem->query['cid']))
			{
				if ($query['cid'] == $menuItem->query['cid'])
				{
					unset($query['cid']);
				}
			}
			else
			{
				if ($query['cid'] == '')
				{
					unset($query['cid']);
				}
			}
		}

		$limitstart = 0;
		if (isset($query['limitstart']))
		{
			$cid = $query['limitstart'];
			if (!empty($query['Itemid']) && isset($menuItem->query['limitstart']))
			{
				if ($query['limitstart'] == $menuItem->query['limitstart'])
				{
					unset($query['limitstart']);
				}
			}
			else
			{
				if ($query['limitstart'] == '')
				{
					unset($query['limitstart']);
				}
			}
		}

		if (isset($query['layout']))
		{
			if (!empty($query['Itemid']) && isset($menuItem->query['layout']))
			{
				if ($query['layout'] == $menuItem->query['layout'])
				{
					unset($query['layout']);
				}
			}
			else
			{
				if ($query['layout'] == 'default')
				{
					unset($query['layout']);
				}
				else
				{
					if(isset($view))
					{
						$segments[] = $view;
						$segments[] = $query['layout'];
						$segments[] = $cid;
					}
					unset($query['layout']);
				}
			}
		}

		if (isset($view))
		{
			if($view == 'bid')
			{
				$segments[0] = $view;
				$segments[1] = $cid;
				$segments[2] = $grid;
				unset($query['cid']);
				unset($query['grid']);
			}

			if($view == 'bfauction_plus')
			{
				$segments[0] = $view;
				//$segments[1] = $limitstart;
				//unset($query['limitstart']);
			}
		}

		$total = count($segments);

		for ($i = 0; $i < $total; $i++)
		{
			$segments[$i] = str_replace(':', '-', $segments[$i]);
		}

		return $segments;
	}

	/**
	 * Parse the segments of a URL.
	 *
	 * @param   array  &$segments  The segments of the URL to parse.
	 *
	 * @return  array  The URL attributes to be used by the application.
	 *
	 * @since   3.3
	 */
	public function parse(&$segments)
	{
		$total = count($segments);
		$vars = array();

		for ($i = 0; $i < $total; $i++)
		{
			$segments[$i] = preg_replace('/-/', ':', $segments[$i], 1);
		}

		// Get the active menu item.
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		$item = $menu->getActive();
		$params = JComponentHelper::getParams('com_bfauction_plus');
		$advanced = $params->get('sef_advanced_link', 0);

		// Count route segments
		$count = count($segments);

		// Standard routing for bfauction_plus
		if (!isset($item))
		{
			$vars['view'] = $segments[0];
			$vars['id'] = $segments[$count - 1];

			return $vars;
		}

		if($segments[0] == 'item'){
			$vars['view'] = $segments[0];
			$vars['layout'] = $segments[1];
			$vars['cid'] = $segments[2];
		}

		if($segments[0] == 'bid'){
			$vars['view'] = $segments[0];
			$vars['cid'] = $segments[1];
			$vars['grid'] = $segments[2];
		}

		if($segments[0] == 'bfauction_plus'){
			$vars['view'] = $segments[0];
			//$vars['limitstart'] = $segments[1];
		}

		return $vars;
	}

}

/**
 * BF Auction Plus router functions
 *
 * These functions are proxys for the new router interface
 * for old SEF extensions.
 *
 * @deprecated  4.0  Use Class based routers instead
 */
function bfauction_plusBuildRoute(&$query)
{
	$router = new bfauction_plusRouter;

	return $router->build($query);
}

function bfauction_plusParseRoute($segments)
{
	$router = new bfauction_plusRouter;

	return $router->parse($segments);
}