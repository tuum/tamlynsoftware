<?php
/**
 * $Id: bfsurvey_plus.php 46 2013-03-28 00:51:01Z tuum $
 * bfsurvey_plus entry point file for bfsurvey_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');
require_once JPATH_ROOT.'/administrator/components/com_bfsurvey_plus/helpers/bfsurvey_plus.php';

$jlang = JFactory::getLanguage();
$jlang->load('com_bfsurvey_plus', JPATH_SITE, 'en-GB', true);
$jlang->load('com_bfsurvey_plus', JPATH_SITE, $jlang->getDefault(), true);
$jlang->load('com_bfsurvey_plus', JPATH_SITE, null, true);

$document = JFactory::getDocument();
$cssFile = "./components/com_bfsurvey_plus/css/style.css";
$document->addStyleSheet($cssFile, 'text/css', null, array());

if (!class_exists('JControllerLegacy')) {
	require_once( JPATH_COMPONENT_ADMINISTRATOR.'/legacy.php' );
}
$controller	= JControllerLegacy::getInstance('bfsurveyplus');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();