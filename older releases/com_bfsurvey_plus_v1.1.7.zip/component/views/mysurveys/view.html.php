<?php
/**
 * $Id: view.html.php 34 2012-07-20 03:21:16Z tuum $
 * My Surveys View for BF Survey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;

jimport( 'joomla.application.component.view' );

/**
 * My Surveys View
 *
 * @package    Joomla
 * @subpackage Components
 */
class BFSurveyPlusViewmysurveys extends JViewLegacy
{
    function display($tpl = null)
    {
		$user = JFactory::getUser();
		$uid = $user->id;

		$app		= JFactory::getApplication();
		$params		= $app->getParams();

		//check if user is logged in
		if($uid == 0){
		   echo JText::_("COM_BFSURVEYPLUS_ERROR_YOU_MUST_LOG_IN_VIEW");
		}else{

        	$items = BFSurveyPlusController::getmysurveys($uid);

        	$this->assignRef( 'items', $items );
        	$this->assignRef( 'uid', $uid );
        	$this->assignRef( 'params', $params );

        	parent::display($tpl);
        }
    }
}