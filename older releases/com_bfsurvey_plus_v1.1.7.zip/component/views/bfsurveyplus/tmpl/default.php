<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/*
 * $Id: default.php 46 2013-03-28 00:51:01Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

$session = JFactory::getSession();

$introText = $this->params->get('introText');
$surveyTitle = $this->params->get('surveyTitle');
$thankyouText = $this->params->get( 'thankyouText' );
$emailText = $this->params->get( 'emailText' );
$nameText = $this->params->get( 'nameText' );
$allowEmail = $this->params->get( 'allowEmail' );
$sendEmailTo = $this->params->get( 'sendEmailTo' );
$allowAuthorEmail = $this->params->get( 'authorEmail' );
$submitText = $this->params->get( 'submitText' );
$anonymous = $this->params->get( 'anonymous' );
$anonymousText = $this->params->get( 'anonymousText' );
$anonymousYes = $this->params->get( 'anonymousYes' );
$anonymousNo = $this->params->get( 'anonymousNo' );
$nameText = $this->params->get( 'nameText' );
$companyText = $this->params->get( 'companyText' );
$emailText = $this->params->get( 'emailText' );
$showName = $this->params->get( 'showName' );
$showCompany = $this->params->get( 'showCompany' );
$showEmail = $this->params->get( 'showEmail' );
$errorText = $this->params->get( 'errorText' );
$use_captcha = $this->params->get( 'use_captcha' );
$redirectURL = $this->params->get( 'redirectURL' );
$registeredUsers = $this->params->get( 'registeredUsers' );
$preventMultiple = $this->params->get( 'preventMultiple' );
$preventMultipleEmail = $this->params->get( 'preventMultipleEmail' );
$preventMultipleUID = $this->params->get( 'preventMultipleUID' );
$showReferenceNo = $this->params->get( 'showReferenceNo' );
$workflow = $this->params->get( 'workflow' );
$summation_counter = 0;
$user="";
$emailcount=0;

/* Load Recaptcha if Bigo Captcha not on site */
if (!class_exists('plgSystemBigocaptcha')) {
	JPluginHelper::importPlugin('captcha');
	$dispatcher = JDispatcher::getInstance();
	$dispatcher->trigger('onInit','dynamic_recaptcha_1');
}
/* End Recaptcha */

if($anonymous == "")
{
   $anonymous = "1";
}

if($showName == "")
{
   $showName = "1";
}

if($showCompany == "")
{
   $showCompany = "1";
}

if($showEmail == "")
{
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );

if($catid == 0)
{
   echo JText::_('COM_BFSURVEYPLUS_ERROR_MUST_SELECT_CATEGORY');
}

$table="#__bfsurveyplus_".(int)$catid;

$ip = BFSurveyPlusController::getIP();
$ipcount = BFSurveyPlusController::checkIP($table,$ip);

//increment page no
$page_no = JRequest::getVar( 'page_no' );
if(!empty($page_no)){
	$start_qn = JRequest::getVar( 'start_qn', 0, 'post', 'int' );
	$end_qn = JRequest::getVar( 'end_qn', 0, 'post', 'int' );

	// get answers to last question(s)
	$numberQns = $end_qn - $start_qn;
	if($numberQns < 1){
		$numberQns = 1;
	}

	for($y = ($page_no-$numberQns)+1;$y < $page_no+1; $y++)
	{
		$qid = JRequest::getVar( 'question'.$y, 0, 'post', 'int' );
		$session->set('question'.$y, $qid);
		$session->set('questiontype'.$y, JRequest::getVar( 'question_type'.$y, 0, 'post', 'int' ) );

		if( JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) != NULL ){
            if($session->get('questiontype'.$y) == "2" | $session->get('questiontype'.$y) == "8"){   //checkbox or summation
                  $session->set('q'.$qid, JRequest::getVar( 'q'.$qid, array(), 'post', 'array' ) );
            }else{
                  $session->set('q'.$qid, JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) );
            }
      	}else{
      		$session->set('q'.$qid, "");
      	}

		if( JRequest::getVar( 'q'.$qid.'_OTHER_', "", 'POST', 'string' ) ){
			$session->set('q'.$qid.'_OTHER_', JRequest::getVar( 'q'.$qid.'_OTHER_', "", 'POST', 'string' ) );
		}else{
			$session->set('q'.$qid.'_OTHER_', "");
		}

		$session->set('field_name'.$y, JRequest::getVar( 'field_name'.$y, 0, 'post', 'string' ) );
		$session->set('page_no', $y);

		if( $session->get('questiontype'.$y) == 9 ){ // Rating
        	for($z=0; $z < 20; $z++)
         	{
         		if( JRequest::getVar( 'q'.$qid.'_'.$z, "", 'POST', 'string' ) ){
         			$session->set('q'.$qid.'_'.$z, JRequest::getVar( 'q'.$qid.'_'.$z, "", 'POST', 'string'  ) );
    	    	}else{
    	    		$session->set('q'.$qid.'_'.$z, "");
       	    	}
   	     	}
		}
   }

   $page_no = $page_no + 1;

}else{
   // defaults for first page
   $page_no = 1;
   $start_qn = -1;
   $end_qn = 0;
   $numberQns=1;
}

if($page_no - $numberQns == 1)   // second page
{
	$session->set('fullname', JRequest::getVar( 'fullname', '', 'post', 'string' ));
	$session->set('company', JRequest::getVar( 'company', '', 'post', 'string' ));
	$session->set('email', JRequest::getVar( 'email', '', 'post', 'string' ));
	$session->set('sendEmailTo', $sendEmailTo);

   if($session->get('fullname') == "")
   {
      $session->set('fullname', "Anonymous");
   }

   $preventMultipleEmail = JRequest::getVar( 'preventMultipleEmail', 0, '' );
   $emailcount = BFSurveyPlusController::checkEmail($table,$session->get('email'));

   /**
	Captcha
	*/
	if($use_captcha)
	{
		if (class_exists('plgSystemBigocaptcha')) {
	   		$correct=BFSurveyPlusController::_checkCaptcha();
	   		if(!$correct)
	   		{
	   			JError::raiseWarning( "666", JText::_( 'COM_BFSURVEYPLUS_ERROR_WRONG_CAPTCHA') );
	   			$page_no=1;
	   			$start_qn = -1;
	   			$end_qn = 0;
	   		}else{
	   		   // captcha is correct
			}
		}else{
			/* Recaptcha */
			$post = JRequest::get('post');
			JPluginHelper::importPlugin('captcha');
			$dispatcher = JDispatcher::getInstance();
			$res = $dispatcher->trigger('onCheckAnswer',$post['recaptcha_response_field']);
			if(!$res[0]){
				JError::raiseWarning( "666", JText::_( 'COM_BFSURVEYPLUS_ERROR_WRONG_CAPTCHA') );
				$page_no=1;
				$start_qn = -1;
				$end_qn = 0;
			}
			/* End Recaptcha */
		}
	}
}

$total_qns=count( $this->items );

//Use conditional branching to determine next question
if($page_no > 1)
{
   if($qid == "")
   {
      $next_question = 0;
   }else{
      $next_question = BFSurveyPlusController::getNextQuestion($qid, $session->get('q'.$qid));
   }
}else{
   $next_question=0;
}

if($next_question == 0)
{
   // default to next question
   if($start_qn == -1){
      //first page
      $start_qn = $start_qn +1;
   }else{
      $start_qn = $end_qn;
   }
   $end_qn = $end_qn + 1;
}else if($next_question == -1)   // end of survey
{
   $start_qn = $total_qns;

   // null answers to all other questions
   for($i=$page_no; $i < $total_qns+1; $i++){
		$session->set('question'.$i, null);
		$session->set('questiontype'.$i, null);
   }
}else{
   $page=0;
   for($i=0; $i < $total_qns; $i++){

      //blank out questions that were skipped
      $mypage=$i;
      if($mypage > $page_no-1)
      {
      	$session->set('question'.$mypage, null);
      	$session->set('questiontype'.$mypage, null);
      }

      $row = &$this->items[$i];
      if($row->id == $next_question)
      {
         $i = $total_qns+1;
      }

      $page++;
   }
   $start_qn = $page-1;
   $end_qn = $page;
   $page_no = $page;
}

?>

<?php
 $user = JFactory::getUser();
 if($registeredUsers == "1")
 {
    $emailcount = BFSurveyPlusController::checkEmail($table,$user->email);
    $uidcount = BFSurveyPlusController::checkUID($table,$user->id);
 }else{
 	//$emailcount = 0;
 	$uidcount = 0;
 }

 if (($user->id) | $registeredUsers != "1")   // test if registerd users only
 {
    if($ipcount < 1 | $preventMultiple != "1")   // check if IP address has already completed survey
    {
        if($emailcount < 1 | $preventMultipleEmail != "1")   // check if email address has already completed survey
        {
        	if($uidcount < 1 | $preventMultipleUID != "1")  // check if UID has already completed survey
        	{
?>

<?php if($start_qn > $total_qns-1)
{
// no more questions left, need to write this all to db now.

// save basic details to db, and generate id
$result = BFSurveyPlusController::save($session->get('fullname'),$session->get('company'),$session->get('email'),$table);
$session->set('referenceNo', $result);

//save uid
BFSurveyPlusController::saveField($result,"uid",$user->id,$table);

$emailBody = "";

//debug show all answers
for ($i=1; $i < $total_qns+1; $i++)
{
   $check_msg = "";
   $qid = $session->get('question'.$i);

	$question = BFSurveyPlusController::getQuestion($qid);
	if($session->has('q'.$qid)){
		$answer = $session->get('q'.$qid);
	}else{
		$answer = "";
	}

	if( $session->get('question_type'.$i) == 1)   // radio
	{
		if($answer == "_OTHER_"){
			$answer = $session->get('q'.$qid.'_OTHER_');
		}
	}

   if($session->get('questiontype'.$i) == 2){ // checkbox
     if($answer=="")
     {
         // do nothing
     }else{
         foreach($answer as $value){
           if($value == "_OTHER_")
           {
               $value = $session->get('q'.$qid.'_OTHER_');
           }
               $check_msg .= "$value\n";
           }
         $answer = $check_msg;
     }
   }

	if($session->get('questiontype'.$i) == 8){ // summation
		if(isset($answer)){
    		foreach($answer as $value) {
   	  			$check_msg .= "$value\n";
   	  		}
   	  		$answer = $check_msg;
		}else{
			$answer = "";
		}
   	}

   if($session->get('questiontype'.$i) == 9){ // Rating
	   $emailBody .= "<br>".$question.": <br>";
       for($z=0; $z < 20; $z++)
       {
          $answer = $session->get('q'.$qid.'_'.$z);
		  $field = $session->get('field_name'.$i);
          $field .= ($z+1);
          if($answer != "" & $answer != "NULL")
          {
             BFSurveyPlusController::saveField($result,$field,$answer,$table);
             $tempvalue="option".($z+1);
             $myoption=BFSurveyPlusController::getOption($qid,$tempvalue);
             $emailBody .= "<br>".$myoption.": <br>".$answer."<br>";
          }
       }

       // skip the next bit as we've already done it. '
       $answer="";
       $session->set('field_name'.$i, null);
   }

   	if($answer == ""){
    	// do nothing
   	}else{
    	$emailBody .= "<br>".$question.": <br>".$answer."<br>";
   	}

	if($session->has('field_name'.$i)){
		if( $session->get('field_name'.$i) == "" | $session->get('field_name'.$i) == "NULL" | (int)$session->get('questiontype'.$i) < 0 ){
    		// do nothing
		}else if($session->get('questiontype'.$i) == 10){  //heading
			//do nothing
		}else{ // save data to db
        	BFSurveyPlusController::saveField($result,$session->get('field_name'.$i),$answer,$table);
      	}
   	}
}

//send email confirmation
if($allowEmail){
	BFSurveyPlusController::triggerEmails("Admin", $sendEmailTo, $emailBody, $catid);
}
if($allowAuthorEmail == "1" & $session->get('email')!=""){
	BFSurveyPlusController::triggerEmails("Author", $session->get('email'), $emailBody, $catid);
}

//clear session data
$session->set('dateReceived', null);

for($y=0; $y < $page_no+1; $y++){
	$session->set('question'.$y, null);
	$session->set('q'.$qid, null);
	$session->set('q'.$qid.'_OTHER_', null);
	$session->set('field_name'.$y, null);
}

$session->set('page_no', null);
$session->set('fullname', null);
$session->set('email', null);
$session->set('sendEmailTo', null);
$session->set('uid', null);

$session->set('body', null);

for($i=$page_no; $i < $total_qns+1; $i++){
	$session->set('question'.$i, null);
	$session->set('questiontype'.$i, null);
}
//end clear session data

BFSurveyPlusController::myRedirect();
?>

<?php
}else{
?>

<script language="Javascript">
<!--
   // get variable from php
   var showName = "<?php echo $showName ?>";
   var showCompany = "<?php echo $showCompany ?>";
   var showEmail = "<?php echo $showEmail ?>";
   var toggle = 1;
   var othertoggle = 0;

   function ToggleDetails()
   {
   		if(toggle == 1)
   		{
   		   // hide details
   		   if(showName=="1")
   		   {
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		   }

		   if(showCompany=="1")
		   {
		      document.getElementById("MyCompany").style.display = 'none';
              document.getElementById("company").className = 'none';
           }

           if(showEmail=="1")
           {
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1")
           {
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		   }

		   if(showCompany=="1")
		   {
   		      document.getElementById("MyCompany").style.display = '';
              document.getElementById("company").className = 'required';
		   }

		   if(showEmail=="1")
		   {
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
           }
		   toggle=1;
        }
   }

   function MakeOtherMandatory(seq, z)
   {
      myid = 'q' + seq + z + '_other';
      if(othertoggle == 1)
      {
	      // hide details
	      document.getElementById(myid).className = 'none';
	      othertoggle=0;
	  }else{
	      document.getElementById(myid).className = 'required';
	      othertoggle=1;
	  }
   }
//-->
</script>



<?php
// Check that the class exists before trying to use it
if (class_exists('plgBFValidatePlus'))
{
   plgBFValidatePlus::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f))
	{
	    f.check='';
		f.check.value='<?php echo JSession::getFormToken(); ?>';//send token
		return true;
	}
	else
	{
		alert('<?php echo $errorText ?>');
	}
	return false;
}
function imposeMaxLength(Event, Object, MaxLen)
{
   return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40));
}

</script>

<form action="<?php echo JRoute::_( 'index.php?option=com_bfsurvey_plus&view=BFSurveyPlus' ); ?>" method="POST" name="survey" id="survey" class="form-validate" onSubmit="return myValidate(this);">

<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="preventMultipleEmail" value="<?php echo $preventMultipleEmail ?>" />

<table width="100%" cellspacing="0">
	<thead>
		<tr>
			<th>
				<div class="bfsurvey_plusTitle"><?php echo JText::_( $surveyTitle ); ?></div>
			</th>
		</tr>
	</thead>


<?php if($page_no == 1){
// only show this bit on first page
?>

<tr>
    <td>
    <div class="bfsurvey_plusIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="bfsurvey_plusQuestionFooter">
	</div>
    </td>
</tr>

<?php if($showName == "1"){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table>
       <tr>
           <td>
               <div class="BFSurveyCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="BFSurveyCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table>
        <tr>
            <td width="70">
                <div class="BFSurveyCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="BFSurveyCustomerOptions">
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $user->name; ?>' >
                </div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php }else{ ?>
<input type="hidden" name="fullname" id="fullname" size='55' value='<?php echo $user->name; ?>' >
<?php } ?>

<?php if($showCompany == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyCompany">
        <table>
	       <tr>
	           <td width="70">
	               <div class="BFSurveyCustomerQuestion">
	               <?php echo JText::_( $companyText ); ?>
	               </div>
	           </td>
	           <td>
	               <div class="BFSurveyCustomerOptions">
	               <input name="company" id="company" size='55' <?php echo 'class="required"'; ?>>
	               </div>
	           </td>
	       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php }else{ ?>
<input type="hidden" name="company" id="company" size='55'>
<?php } ?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table>
		       <tr>
		           <td width="70">
		               <div class="BFSurveyCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="BFSurveyCustomerOptions">
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $user->email; ?>' >
		               </div>
		           </td>
		       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php }else{ ?>
<input type="hidden" name="email" id="email" size='55' value='<?php echo $user->email; ?>' >
<?php } ?>

<tr>
<td>
<?php if ($use_captcha) {
	// Check that the class exists before trying to use it
	if (class_exists('plgSystemBigocaptcha')) {
	?>
	<!-- Bigo Captcha -->
	<img src="index.php?option=com_bfsurvey_plus&task=displaycaptcha&catid=<?php echo $catid; ?>&use_captcha=<?php echo $use_captcha; ?>">
	<br />
	<input type="text" name="word"/><br>
	<?php
	   echo JText::_("COM_BFSURVEYPLUS_INPUT_WORD_FROM_IMAGE");
	}else{
		// Recaptcha
		echo '<div id="dynamic_recaptcha_1"></div>';
	}
	?>
<?php } ?>
</td>
</tr>

<?php
   }  // end only show on first page
?>

<?php
$k = 0;

for ($i=$start_qn; $i < $end_qn; $i++)
{
	$row = &$this->items[$i];

	$numChildren=0;

	//is this a parent item?
	if($row->parent == 0){
	   //count number of children
	   $numChildren=BFSurveyPlusController::getNumChildren($row->id);
	   $end_qn = $end_qn + $numChildren;
	   $page_no = $page_no + $numChildren;
	}
?>

    <?php if($row->suppressQuestion != "1"){ ?>
	<tr>
	    <th>
	       <div class="bfsurvey_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<?php } ?>

	<tr class="bfsurvey_plusTableRow">
	    <th>
	      <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="bfsurvey_plusOptions">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == "")
	       {
	          // do nothing
	       }else{
	          ?>
	          <div class="bfsurvey_helptext">
	          <?php echo JHTML::_('content.prepare', $row->helpText); ?>
	          </div>
	          <?php
	       }

	       if(!isset($row->prefix))
	       {
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix))
		   {
	          $row->suffix = "";
	       }

	       $sequence = $row->id;

	       if($row->question_type == "0")   //text
	       {
	           $mylength="65";
	           if($row->fieldSize < 65)
	           {
	              $mylength=$row->fieldSize;
	           }
	           if($row->mandatory)
	           {
    		      if($row->suppressQuestion != "1")
    		      {
	                 echo "".JText::_($row->prefix)."<input id='q".$sequence."' name='q".$sequence."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
	              }else{
	              ?>
		             <div class="BFSurveyPlusSuppressQuestion">
	                 <?php echo $row->prefix; ?>
	                 </div>
	                 <div class="BFSurveyPlusSuppressOptions">
	                 <?php
				     	echo "<input id='q".$sequence."' name='q".$sequence."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
					 ?>
	                 </div>
       			  <?php
       			  }
	           }else{
				  if($row->suppressQuestion != "1")
				  {
	                 echo "".JText::_($row->prefix)."<input id='q".$sequence."' name='q".$sequence."' size='$mylength' MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	              }else{
	              ?>
	              		<div class="BFSurveyPlusSuppressQuestion">
	                	<?php echo JText::_($row->prefix); ?>
	                	</div>
	                	<div class="BFSurveyPlusSuppressOptions">
	                	<?php
				        	echo "<input id='q".$sequence."' name='q".$sequence."' size='$mylength' MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
						?>
	                	</div>
       			  <?php
       			  }

	           }
	       }else if($row->question_type == "1"){   // Radio
			   $tempfield=$row->sqlfield;

	       	   if($row->horizontal == "1")
			   {
				   $myclass="bfradiohorizontal";
			   }else{
				   $myclass="bfradio";
			   }

		       if($row->sql != "")
		       {
		   		   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );

		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  $tempvalue="option".($z+1);
					  if($SQLrow->$tempfield != "")
					  {
	                     if($row->mandatory & class_exists('plgBFValidatePlus'))
	                     {
	                     	?>
					        <?php echo JText::_($row->prefix); ?>
					        <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($SQLrow->$tempfield); ?>" class="required validate-radio"><?php echo JText::_($SQLrow->$tempfield); ?></label> <?php echo JText::_($row->suffix); ?>
					        <?php
					     }else{
					     	?>
				  			<?php echo JText::_($row->prefix); ?>
				  			<label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($SQLrow->$tempfield); ?>"><?php echo JText::_($SQLrow->$tempfield); ?></label> <?php echo JText::_($row->suffix); ?>
				  			<?php
			  		     }
						 if($row->horizontal == "1")
						 {
 				    	     echo "&nbsp;&nbsp;&nbsp;";
			   	    	 }else{
			   	    	     echo "<br>";
		   		   	 	 }
			  		  }

		   		   }
				}else{
	       		    for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != "")
	       		        {
	       		            if($row->$tempvalue == "_OTHER_")
	       		            {
	       		               if($row->mandatory & class_exists('plgBFValidatePlus'))
	       		               {
								  ?>
				  			      <?php echo JText::_($row->prefix); ?>
				  			      <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio" onchange="MakeOtherMandatory(<?php echo $sequence; ?>,<?php echo $z; ?>)"><?php echo JText::_($row->otherprefix); ?></label><input id="q<?php echo $sequence; ?><?php echo $z; ?>_other" name="q<?php echo $sequence; ?>_OTHER_" class=""><?php echo JText::_($row->othersuffix); ?> <?php echo JText::_($row->suffix); ?>
				  			      <?php
	       		               }else{
								  ?>
				  			      <?php echo JText::_($row->prefix); ?>
				  			      <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->otherprefix); ?></label><input id="q<?php echo $sequence; ?><?php echo $z; ?>_other" name="q<?php echo $sequence; ?>_OTHER_" class=""><?php echo JText::_($row->othersuffix); ?> <?php echo JText::_($row->suffix); ?>
				  			      <?php
	       		               }
	       		            }else{
				  			   if($row->mandatory & class_exists('plgBFValidatePlus'))
				  			   {
								  ?>
				  			      <?php echo JText::_($row->prefix); ?>
				  			      <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				  			      <?php
				  			   }else{
				  			      ?>
                                  <?php echo JText::_($row->prefix); ?>
                                  <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                                  <?php
			  				   }
			  				}
			  				if($row->horizontal == "1")
			  				{
					    	    echo "&nbsp;&nbsp;&nbsp;";
		   		   	    	}else{
		   		   	    	    echo "<br>";
		   		   	    	}
	       	        	}
	       	     	}

	           }

	       }else if($row->question_type == "2"){   // Checkbox
			   $tempfield=$row->sqlfield;

		       if($row->sql != "")
		       {
		   		   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );
		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  if($SQLrow->$tempfield != ""){
					  	if($row->mandatory & class_exists('plgBFValidatePlus'))
					  	{
					  	   echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'"><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($SQLrow->$tempfield).'" id="q'.$sequence.''.$z.'" class="'.$row->validation_type.'">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix);
					  	}else{
					  	   echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'"><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($SQLrow->$tempfield).'" id="q'.$sequence.''.$z.'">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix);
			  		  	}
			  		  	if($row->horizontal == "1")
			  		  	{
				    	    echo "&nbsp;&nbsp;&nbsp;";
			   	    	}else{
			   	    	    echo "<br>";
		   		   	 	}
			  		  }
		   		   }

				}else{

					if($row->horizontal == "1")
					{
					   $myclass="bfradiohorizontal";
					}else{
					   $myclass="bfradio";
					}

			   	   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
	   	               if($row->$tempvalue != "")
	   	               {
	   	                   if($row->$tempvalue == "_OTHER_")
	   	                   {
	   	                       if($row->mandatory & class_exists('plgBFValidatePlus'))
	   	                       {
	       		                   echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'" class="'.$row->validation_type.'" onchange="MakeOtherMandatory('.$sequence.','.$z.')">'.JText::_($row->otherprefix).'</label><input id="q'.$sequence.''.$z.'_other" name="q'.$sequence.'_OTHER_" class="">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       		               }else{
	       		                   echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->otherprefix).'</label><input id="q'.$sequence.''.$z.'" name="q'.$sequence.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       		               }
	       		            }else{
				   	            if($row->mandatory & class_exists('plgBFValidatePlus'))
				   	            {
	   	                           echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" class="'.$row->validation_type.'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				   		        }else{
	   	                           echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" >'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
	   	                    	}
				   		  	}
			  				if($row->horizontal == "1")
			  				{
					    	    echo "&nbsp;&nbsp;&nbsp;";
		   		   	    	}else{
		   		   	    	    echo "<br>";
		   		   	    	}
	   	               }
	   	           }
	           }
	       }else if($row->question_type == "3"){   // Textarea
	           if($row->mandatory)
	           {
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" class="required" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');" ></textarea> '.JText::_($row->suffix);
		       }else{
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');"></textarea> '.JText::_($row->suffix);
		       }
	       }else if($row->question_type == "5"){   // date
 				$document = JFactory::getDocument();
   				$document->addScript(JURI::root() . "/components/com_bfsurvey_plus/includes/calendar.js");

	            JHTML::_('behavior.calendar');

	            if($row->mandatory){
	            	echo ''.$row->prefix.'<input class="inputbox required" type="text" id="q'.$sequence.'" name="q'.$sequence.'" size="10" maxlength="25" value="" />';
	            }else{
	            	echo ''.$row->prefix.'<input class="inputbox" type="text" id="q'.$sequence.'" name="q'.$sequence.'" size="10" maxlength="25" value="" />';
	            }

				echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\'q'.$sequence.'\',\'%d-%m-%Y\');" /> '.$row->suffix.'';
	       }else if($row->question_type == "6"){   // dropdown
				$tempfield=$row->sqlfield;

	       		if($row->suppressQuestion != "1")
				{

					if($row->mandatory & class_exists('plgBFValidatePlus'))
					{
   						?>
   						<div class="BFSurveyPlusSuppressQuestion">
      						<?php echo $row->prefix; ?>
   						</div>
   						<div class="BFSurveyPlusSuppressOptions">
   						<?php
      						echo "<select id='q".$sequence."' name='q".$sequence."' class='required validate-dropdown'>";
					}else{
   						?>
   						<div class="BFSurveyPlusSuppressQuestion">
      						<?php echo $row->prefix; ?>
   						</div>
   						<div class="BFSurveyPlusSuppressOptions">
   						<?php
      						echo "<select id='q".$sequence."' name='q".$sequence."'>";
					}

				}else{

					if($row->mandatory & class_exists('plgBFValidatePlus'))
					{
	               		echo "".JText::_($row->prefix)."<select id='q".$sequence."' name='q".$sequence."' class='required validate-dropdown'>";
	            	}else{
	               		echo "".JText::_($row->prefix)."<select id='q".$sequence."' name='q".$sequence."'>";
	            	}

				}

				?>

	            <option value="-1"><?php echo JText::_('PLEASE SELECT'); ?></option>

				<?php
				if($row->sql != "")
				{
				   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
				   $this->assignRef( 'SQLitems', $mySQLitems );
				   $n2=count( $mySQLitems );
				   for($z=0; $z < $n2; $z++)
				   {
				      $SQLrow = &$this->SQLitems[$z];
				      echo '<option value="'.JText::_($SQLrow->$tempfield).'">'.JText::_($SQLrow->$tempfield).'</option>';
				   }

				}else{
				   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
				       if($row->$tempvalue != "")
				       {
				           echo '<option value="'.JText::_($row->$tempvalue).'">'.JText::_($row->$tempvalue).'</option>';
				       }
 	               }
 	            }

				echo "</select> ".JText::_($row->suffix);
				echo "</div>";
			}else if($row->question_type == "8"){  // Summation
				    $total = $row->sqlfield;

					$num=0;
					echo "<table>";
				    for($z=0; $z < 20; $z++)
					{
					    $tempvalue="option".($z+1);
	   	                if($row->$tempvalue != "")
	   	                {
				 	        echo '<tr><td>'.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'">'.JText::_($row->$tempvalue).'</td><td><input id="q'.$sequence.''.$z.'" name="q'.$sequence.'[]" size="5" value=0 onchange="updateTotal'.$summation_counter.'()"></label> '.JText::_($row->suffix).'</td></tr>';
				 	        $num++;
				 	    }
					}
					echo "<tr><td></td><td><input id='total".$summation_counter."' name='total' value='".$total."' size='5' READONLY></td></tr>";

					echo "</table>";

					$optionname = 'q'.$sequence.'';

					?>

				    <script language="javascript" type="text/javascript">
					<!--
					// get variable from php
   					var total<?php echo $summation_counter; ?> = "<?php echo $total ?>";
   					var num<?php echo $summation_counter; ?> = "<?php echo $num ?>";
   					var optionname<?php echo $summation_counter; ?>="<?php echo $optionname ?>";

   					function updateTotal<?php echo $summation_counter; ?>()
					{
					   var i=0;
					   var temptotal=0;
					   for (i=0;i<num<?php echo $summation_counter; ?>;i++)
					   {
						   tempvalue=optionname<?php echo $summation_counter; ?> + i;
						   temptotal=temptotal + parseInt(document.getElementById(tempvalue).value);
	       			   }

	       			   document.getElementById("total<?php echo $summation_counter; ?>").value=total<?php echo $summation_counter; ?>-temptotal;
					}

					//-->
					</script>
					<?php
					$summation_counter++;
				}else if($row->question_type == "9"){  // Rating
				 	echo "<table>";
	       		    echo "<tr>";
	       		    echo "<td></td>";

					$mylabels = array();
	       		    if($row->titles == "")
	       		    {
	       		       // do nothing
	       		    }else{
	       		       $mylabels = explode(";",$row->titles);
	       		    }

	       		    for($y=1; $y < $row->sqlfield+1; $y++)
	       		    {
					   if($row->titles == ""){
 	       		          echo "<td align='center'>".$y."</td>";
 	       		       }else{
 	       		          if(isset($mylabels[$y-1])){
 	       		             echo "<td width='50'><center>".JText::_($mylabels[$y-1])."</center></td>";
 	       		          }else{
 	       		             echo "<td  width='50'>&nbsp;</td>";
 	       		          }
 	       		       }
	       		    }
	       		    echo "</tr>";

					for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != "")
	       		        {
	       		           echo "<tr>";
	       		           echo '<td><label for="q'.$sequence.'_'.$z.'">'.JText::_($row->$tempvalue).'</label></td>';
			  			   if($row->mandatory & class_exists('plgBFValidatePlus'))
			  			   {
       		   			      for($y=1; $y < $row->sqlfield+1; $y++){
       		   			         if($row->titles == "")
       		   			         {
       		   			            echo '<td>'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value="'.$y.'" class="required validate-radio"> '.JText::_($row->suffix).'</td>';
       		   			         }else{
       		   			            if(isset($mylabels[$y-1]))
       		   			            {
       		   			               echo '<td align="center">'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value="'.JText::_($mylabels[$y-1]).'" class="required validate-radio"> '.JText::_($row->suffix).'</td>';
       		   			            }else{
       		   			               echo '<td>'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value="" class="required validate-radio"> '.JText::_($row->suffix).'</td>';
       		   			            }
       		   			         }
			  			      }

			  			   }else{
							  for($y=1; $y < $row->sqlfield+1; $y++)
							  {
							     if($row->titles == "")
							     {
 							  	    echo '<td>'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value="'.$y.'"> '.JText::_($row->suffix).'</td>';
 							  	 }else{
 							  	    if(isset($mylabels[$y-1]))
 							  	    {
 							  	       echo '<td align="center">'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value="'.JText::_($mylabels[$y-1]).'"> '.JText::_($row->suffix).'</td>';
 							  	    }else{
 							  	       echo '<td>'.JText::_($row->prefix).'<input type="radio" id="q'.$sequence.'_'.$z.'" name="q'.$sequence.'_'.$z.'" value=""> '.JText::_($row->suffix).'</td>';
 							  	    }
 							   	 }
 							  }
		  				   }
		  				   echo "</tr>";
	       	        	}
	       	     	}

	       	     	echo "</table>";

				}

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
		   echo '<input type="hidden" name="field_name'.($i+1).'" value="'.$row->field_name.'">';
	       ?>
	       </div>
	       <?php if($row->suppressQuestion != "1"){ ?>
	       <div class="bfsurvey_plusQuestionFooter"></div>
	       <?php } ?>
	    </th>
	</tr>
	<?php
	$k = 1 - $k;
}
?>
</table>

<input type="hidden" name="workflowTitle" value="<?php echo $workflow ?>" />

<?php
$num=count( $this->items );
?>

<input type="hidden" name="page_no" value="<?php echo $page_no ?>" />
<input type="hidden" name="start_qn" value="<?php echo $start_qn ?>" />
<input type="hidden" name="end_qn" value="<?php echo $end_qn ?>" />
<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfsurvey_plus" />
<input type="hidden" name="task" value="add" />
<input type="hidden" name="thankyouText" value="<?php echo $thankyouText ?>" />
<input type="hidden" name="redirectURL" value="<?php echo $redirectURL ?>" />
<input type="hidden" name="showReferenceNo" value="<?php echo $showReferenceNo ?>" />
<input type="hidden" name="allowEmail" value="<?php echo $allowEmail ?>" />
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
</form>

<?php

//echo "Page ".$page_no." of ".$total_qns;
?>


<table width="200" border=1>
<tr>
<td>
<div class="progressbar_color_1" style="height:5px;width:<?php echo (($page_no/$total_qns)*100) ?>%"></div>
</td>
</tr>
</table>

<?php
}  // end check start_qn
?>

<?php
	      }else{
	  	     echo JText::_( "COM_BFSURVEYPLUS_ERROR_UID_ALREADY_COMPLETED");
	      }

      }else{
  	     echo JText::_( "COM_BFSURVEYPLUS_ERROR_EMAIL_ALREADY_COMPLETED" );
      }

   }else{
      echo JText::_( "COM_BFSURVEYPLUS_ERROR_IP_ALREADY_COMPLETED" );
   }

}else{
   echo JText::_( "COM_BFSURVEYPLUS_ERROR_YOU_MUST_LOG_IN" );
}
?>
