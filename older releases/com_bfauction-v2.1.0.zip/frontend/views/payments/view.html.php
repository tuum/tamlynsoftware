<?php

defined('_JEXEC') or die;

class BfauctionViewPayments extends F0FView
{
	public function display($tpl = null)
	{
		$item = $this->item;

		if ($item->orderStatus !== "C" && $item->orderStatus !== "P") {

			switch ($this->item->processor) {

				case 'paypal':
					$this->paymentButton = $this->generatePaypalButton($item->orderId);
					break;

				case 'cod':
					$this->paymentButton = $this->generateCODButton($item->orderId);
					break;

				default:
					throw new Exception(JText::_('Please set a Payment Processor.'), 403);
			}
		}
		parent::display($tpl);
	}

	public function generatePaypalButton($orderId)
	{
		$params = JComponentHelper::getParams('com_bfauction');

		$user = JFactory::getUser();
		$user_name = $user->username;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('orderId=' . $orderId);
		$query->where("highBidder='$user_name'");
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if (empty($rows) || $db->getErrorNum()) {
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()) . '<br />';
			return;
		}
		$item = $rows[0];

		// check current date > enddate

		$plugin = JPluginHelper::getPlugin('payment', $item->processor);
		$pluginParams = new JRegistry($plugin->params);

		$email = $pluginParams->get('business');
		if (empty($email)) {
			throw new Exception(JText::_('Please set your Paypal email.'), 403);
		}

		$vars = new stdClass;
		$vars->order_id = $item->orderId;
		$vars->user_id = $user->id;
		$vars->user_firstname = $user->name;
		$vars->user_email = $email;
		$vars->phone = $item->phone;
		$vars->item_name = $item->title;
		$vars->amount = $item->totalAmount;
		//$vars->quantity = $item->quantity;
		if ($item->deliveryOption == COM_BFAUCTION_DELIVERY_DIRECT) {
			$vars->shipping = $item->shipping;	// Paypal's shipping and handling
			$vars->amount -= $item->shipping;
		}

		$vars->currency_code = $params->get('addcurrency');
		$vars->submiturl = "";
		$vars->return = JURI::root() . substr(JRoute::_("index.php?option=com_bfauction&task=payment.update&orderId=" . ($orderId) . "&processor={$item->processor}&Itemid=0", false), strlen(JURI::base(true)) + 1);
		$vars->cancel_return = "";
		$vars->notify_url = "";
		$vars->url = $vars->notify_url;
		$vars->comment = "";
		$vars->payment_description = JText::_('COM_BFAUCTION_PAYMENT_DESCRIPTION');

		JPluginHelper::importPlugin('payment', $item->processor);
		$dispatcher = JDispatcher::getInstance();

		$html = $dispatcher->trigger('onTP_GetHTML', array($vars));

		return $html[0];
	}


	public function generateCODButton($orderId)
	{
		JPluginHelper::importPlugin('payment', 'cod');
		$dispatcher = JDispatcher::getInstance();

		$vars  = new stdClass();
		$vars->order_id = $orderId;

		$html = $dispatcher->trigger('onTP_GetHTML', array($vars));

		return $html[0];
	}

}
