<?php
/**
 *  @package bfauction
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionControllerAuction extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'auction';
	}
}