ALTER TABLE [#__bfsurvey_reports] ADD [customQuery] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_categories] ADD [customCSS] [nvarchar](max) NOT NULL,;