<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 *
 * This form is used when displaying the report via HTML
 */

defined('_JEXEC') or die();

$report=$this->reportDetails[0];

if(!isset($this->items))
{
	echo JText::_('COM_BFSURVEY_REPORT_NO_RECORDS');
	return;
}

echo '<h1>'.$report->title.'</h1>';

if($report->since != "0000-00-00 00:00:00"){
	echo JText::_('COM_BFSURVEY_REPORT_SINCE').$report->since.' ';
}

if($report->until != "0000-00-00 00:00:00"){
	echo JText::_('COM_BFSURVEY_REPORT_UNTIL').$report->until;
}
?>

	<div id="j-main-container" class="span10">

		<div class="clearfix"> </div>
		<table class="table table-striped" id="reportList">
			<thead>
				<tr>
					<?php foreach (explode(',',$report->fields) as $i => $item) :
					?>
						<th>
							<?php echo $item; ?>
						</th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
			<?php foreach ($this->items as $i => $item) :
				?>
				<tr class="row<?php echo $i % 2; ?>">
					<?php foreach (explode(',',$report->fields) as $i => $field) :
					$field=trim($field);
					?>
						<td>
							<?php echo $this->escape($item->$field); ?>
						</td>
					<?php endforeach; ?>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</form>