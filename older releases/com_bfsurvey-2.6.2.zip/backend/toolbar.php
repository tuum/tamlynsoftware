<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyToolbar extends F0FToolbar
{
	public function onQuestionsBrowse()
	{
		//show toolbar on front end
		$this->renderFrontendButtons = true;
		$app = JFactory::getApplication();

		$this->onBrowse();

		JToolBarHelper::divider();
		if($app->isAdmin()){
			JToolBarHelper::custom('copy', 'copy.png', 'copy_f2.png', 'JLIB_HTML_BATCH_COPY', false);
			JToolBarHelper::custom( 'fixDatabase', 'fix', 'refresh', 'COM_BFSURVEY_TOOLBAR_FIX_DATABASE', false );
			JToolBarHelper::divider();
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
		}
	}

	public function onQuestionsEdit()
	{
		include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
		$canDo	= BfsurveyModelSurvey::getActions();

		if ($canDo->get('core.create')) {
			//show toolbar on front end
			$this->renderFrontendButtons = true;

			parent::onEdit();

			if(version_compare(JVERSION, '3.2', 'ge')) {
				$question=$this->input->getdata();

				JToolBarHelper::divider();
				JToolbarHelper::versions('com_bfsurvey.question', $question["id"]);
			}
		}
	}

	public function onQuestionsAdd()
	{
		include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
		$canDo	= BfsurveyModelSurvey::getActions();

		if ($canDo->get('core.create')) {
			$this->renderFrontendButtons = true;
		}

		parent::onAdd();
	}

	public function onCategoriesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolBarHelper::custom( 'fixDatabase', 'fix', 'refresh', 'COM_BFSURVEY_TOOLBAR_FIX_DATABASE', false );
		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onSurveysBrowse()
	{
		include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
		$canDo	= BfsurveyModelSurvey::getActions();

		if ($canDo->get('core.create')) {
			$this->renderFrontendButtons = true;
		}

		$this->onBrowse();
	}

	public function onEmailitemsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onEmailitemsEdit()
	{
		parent::onEdit();

		JToolBarHelper::custom( 'sendnow', 'refresh', 'refresh', 'COM_BFSURVEY_TOOLBAR_SEND_EMAIL_NOW', false );
	}

	public function onEmailitemsAdd()
	{
		parent::onAdd();

		JToolBarHelper::custom( 'sendnow', 'refresh', 'refresh', 'COM_BFSURVEY_TOOLBAR_SEND_EMAIL_NOW', false );
	}


	public function onReportsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::custom('copy', 'copy.png', 'copy_f2.png', 'JLIB_HTML_BATCH_COPY', false);
		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onResultscategoriesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onMaintenancesBrowse()
	{
		//$this->onBrowse();
		JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_MAINTENANCE'));

		//JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onBrowse()
	{
		include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
		$canDo	= BfsurveyModelSurvey::getActions();

		if ($canDo->get('core.create')) {
			//$this->renderFrontendButtons = true;
		}

		parent::onBrowse();

		$app = JFactory::getApplication();
		if($app->isAdmin()){
			if (strpos($this->input->getCmd('view', 'cpanel'),'results') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULTS'));
			}
			elseif (strpos($this->input->getCmd('view', 'cpanel'),'result') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'));
			}
		}
	}

	public function onRead()
	{
		parent::onRead();

		$app = JFactory::getApplication();
		if($app->isAdmin()){
			if (strpos($this->input->getCmd('view', 'cpanel'),'results') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULTS'));
			}
			elseif (strpos($this->input->getCmd('view', 'cpanel'),'result') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'));
			}
		}
	}

	public function onAdd()
	{
		parent::onAdd();

		$app = JFactory::getApplication();
		if($app->isAdmin()){
			if (strpos($this->input->getCmd('view', 'cpanel'),'results') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULTS'));
			}
			elseif (strpos($this->input->getCmd('view', 'cpanel'),'result') !== false)
			{
				JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'));
			}
		}
	}

	public function onStatisticsBrowse()
	{
		JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_STATISTICS'));

		$app = JFactory::getApplication();
		if($app->isAdmin()){
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
		}
	}

	public function onStatsBrowse()
	{
		JToolBarHelper::title(JText::_('COM_BFSURVEY') . ': ' . JText::_('COM_BFSURVEY_TITLE_STATISTICS'));

		$app = JFactory::getApplication();
		if($app->isAdmin()){
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=statistics');
		}
	}

	public function on1resultsEdit()
	{
		//parent::onEdit();

		$result=$this->input->getdata();

		$option = $this->input->getCmd('option', 'com_foobar');
		$componentName = str_replace('com_', '', $option);

		// Set toolbar title
		JToolBarHelper::title(JText::_(strtoupper($option)) . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'), $componentName);

		JToolBarHelper::cancel();
		JToolBarHelper::divider();

		if(version_compare(JVERSION, '3.2', 'ge')) {
			JToolbarHelper::versions('com_bfsurvey.1result', $result["id"]);
		}
	}

	public function on2resultsEdit()
	{
		//parent::onEdit();

		$result=$this->input->getdata();

		$option = $this->input->getCmd('option', 'com_foobar');
		$componentName = str_replace('com_', '', $option);

		// Set toolbar title
		JToolBarHelper::title(JText::_(strtoupper($option)) . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'), $componentName);

		JToolBarHelper::cancel();
		JToolBarHelper::divider();

		if(version_compare(JVERSION, '3.2', 'ge')) {
			JToolbarHelper::versions('com_bfsurvey.2result', $result["id"]);
		}
	}

	public function on3resultsEdit()
	{
		//parent::onEdit();

		$result=$this->input->getdata();

		$option = $this->input->getCmd('option', 'com_foobar');
		$componentName = str_replace('com_', '', $option);

		// Set toolbar title
		JToolBarHelper::title(JText::_(strtoupper($option)) . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'), $componentName);

		JToolBarHelper::cancel();
		JToolBarHelper::divider();

		if(version_compare(JVERSION, '3.2', 'ge')) {
			JToolbarHelper::versions('com_bfsurvey.3result', $result["id"]);
		}
	}

	public function on4resultsEdit()
	{
		//parent::onEdit();

		$result=$this->input->getdata();

		$option = $this->input->getCmd('option', 'com_foobar');
		$componentName = str_replace('com_', '', $option);

		// Set toolbar title
		JToolBarHelper::title(JText::_(strtoupper($option)) . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'), $componentName);

		JToolBarHelper::cancel();
		JToolBarHelper::divider();

		if(version_compare(JVERSION, '3.2', 'ge')) {
			JToolbarHelper::versions('com_bfsurvey.4result', $result["id"]);
		}
	}

	public function on5resultsEdit()
	{
		//parent::onEdit();

		$result=$this->input->getdata();

		$option = $this->input->getCmd('option', 'com_foobar');
		$componentName = str_replace('com_', '', $option);

		// Set toolbar title
		JToolBarHelper::title(JText::_(strtoupper($option)) . ': ' . JText::_('COM_BFSURVEY_TITLE_RESULT'), $componentName);

		JToolBarHelper::cancel();
		JToolBarHelper::divider();

		if(version_compare(JVERSION, '3.2', 'ge')) {
			JToolbarHelper::versions('com_bfsurvey.5result', $result["id"]);
		}
	}
}