<?php
/**
 * $Id: default.php 100 2015-02-27 00:59:02Z tuum $
 * Bid now view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	//check form is submitted from our site
	JRequest::checkToken() or die( 'Invalid Token' );

	$bfcurrency = $this->params->get('bfcurrency');
	$bidIncrement = $this->params->get('bidIncrement');
	$reverseAuction = $this->params->get('reverseAuction');

	if($reverseAuction == NULL){
		$reverseAuction = 0;
	}

	if($this->bfauction_plus->bidIncrement > 0){
		$bidIncrement = $this->bfauction_plus->bidIncrement;
	}

	$dst_fix = $this->params->get( 'dst' );
	$user = JFactory::getUser();

	$includeCommission = $this->params->get('includeCommission');
	$commissionAmount = $this->params->get('commissionAmount');
	if($this->bfauction_plus->commissionAmount){
		$commissionAmount = $this->bfauction_plus->commissionAmount;
	}
	$includeTax = $this->params->get('includeTax');
	$taxableItem = $this->bfauction_plus->taxableItem;
	$taxAmount = $this->params->get('taxAmount');
	if($this->bfauction_plus->taxAmount){
		$taxAmount = $this->bfauction_plus->taxAmount;
	}
	$showTotalPrice = $this->params->get('showTotalPrice');

	$nextBid = JRequest::getVar( 'bid', 0, 'POST', 'float' );
	//$nextBid = JRequest::getVar( 'bid', 0, 'POST', 'string' );
	//$nextBid = floatval(str_replace('.', ',', str_replace(',', '', $nextBid)));

	$dateFormat = $this->params->get( 'dateFormat' );
	$showDeliveryOptions = $this->params->get('showDeliveryOptions');
	$currencySymbolAfter= $this->params->get('currencySymbolAfter', 0);

	$quantity = $this->bfauction_plus->quantity;

	require_once( JPATH_COMPONENT.'/assets/confirm.php' );
?>
<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ARE_YOU_SURE' ); ?>&nbsp;<?php echo $this->bfauction_plus->title; ?> (<?php if($this->bfauction_plus->productId){ echo $this->bfauction_plus->productId; }else{ echo $this->bfauction_plus->id; } ?>)?

	<form method="post" name="adminForm">
		<table class="admintable">
		<tr>
			<td class="bfauction_plusLabel">
				<label for="BidNow">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_NOW' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div class="bfauction_plusCurrency"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div>&nbsp;<input class="inputbox" type="text" name="bid" id="bid" size="5" value="<?php echo $nextBid; ?>" onblur="process()" />&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
				<input type="hidden" name="option" value="com_bfauction_plus" />
				<input type="hidden" name="task" value="mybid" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="controller" value="" />
				<input type="hidden" name="cid" value="<?php echo $this->bfauction_plus->id; ?>" />
				<input type="hidden" name="bidIncrement" value="<?php echo $bidIncrement; ?>" />
				<input type="hidden" name="tax" id="tax">
				<input type="hidden" name="commission" id="commission">
				<?php echo JHTML::_( 'form.token' ); ?>
			</td>
			<td>
				<?php echo "<a href='".JRoute::_('index.php?option=com_bfauction_plus&task=bid&cid='.$this->bfauction_plus->id)."'>".JText::_( 'COM_BFAUCTIONPLUS_BUTTON_CANCEL')."</a>"; ?>
			</td>
		</tr>
		<?php if($this->bfauction_plus->shipping > 0){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="shipping">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_SHIPPING' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <strong><?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $this->bfauction_plus->shipping;?>&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?></strong>
			</td>
			<td>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeCommission){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_COMMISSION' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div id="currencyCommission" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divCommission" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeTax){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TAX' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divTax" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($showTotalPrice){ ?>
		<tr>
			<td class="bfauction_plusLabelTotal">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_PRICE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsTotal">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divTotalPrice" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td>&nbsp;
			</td>
			<td class="bfauction_plusDetails">
				<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_BID_NOW_COMMIT' ); ?>" />
			</td>
		</tr>

		<tr>
			<td>
				&nbsp;
			</td>
			<td class="bfauction_plusLabel">
				<i><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_MINIMUM_BID_INCREMENT' ); ?>&nbsp;<strong><?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $bidIncrement; ?></strong></i>
				&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>

		<?php if($showDeliveryOptions){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_DELIVERY_OPTIONS' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
				<input type="radio" name="deliveryOption" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_DELIVERY_OPTION1' ); ?>"><?php echo JText::_( 'COM_BFAUCTIONPLUS_DELIVERY_OPTION1' ); ?><br>
				<input type="radio" name="deliveryOption" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_DELIVERY_OPTION2' ); ?>"><?php echo JText::_( 'COM_BFAUCTIONPLUS_DELIVERY_OPTION2' ); ?>
			</td>
		</tr>
		<?php }else{ ?>
			<input type="hidden" name="deliveryOption" id="deliveryOption" value="">
		<?php } ?>

		</table>
</form>

	<div id="divCurrentBid" style="visibility:hidden" /></div>
	<div id="endDate" style="visibility:hidden" /></div>
	<div id="divCommissionCurrent" style="visibility:hidden" /></div>
	<div id="divTaxCurrent" style="visibility:hidden" /></div>
	<div id="divTotalPriceCurrent" style="visibility:hidden" /></div>
	<div id="highBidder" style="visibility:hidden" /></div>
	<div id="quantityPurchased" style="visibility:hidden" value="1"/></div>

<script language="javascript" type="text/javascript">
<!--
process();
//-->
</script>