<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */
defined('_JEXEC') or die();

require_once JPATH_ADMINISTRATOR.'/components/com_bfauction/models/items.php';