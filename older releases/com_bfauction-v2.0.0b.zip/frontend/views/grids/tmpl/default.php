<?php
/**
 * $Id: default.php 90 2014-05-11 12:54:57Z tuum $
 * Grid view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	//require_once( JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfauction.php' );

    $app = JFactory::getApplication();
    $user = JFactory::getUser();

    $params = JComponentHelper::getParams('com_bfauction');
	$bfcurrency = $params->get('bfcurrency', '$');
	$rowColour = $params->get('rowColour');
	$alternateColour = $params->get('alternateColour');
	$max_width_t = $params->get('max_width_t');
	$max_height_t = $params->get('max_height_t');
	$showTimer = $params->get('showTimer');
	$currencySymbolAfter= $params->get('currencySymbolAfter', 0);

	$items = 0;
	$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
	$limit = JRequest::getVar('limit', 0, '', 'int');

	$context="";
	$filter_catid		= $app->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_sort		= $app->getUserStateFromRequest( $context.'filter_sort',		'filter_sort',		'',			'int' );
	$filter_filter		= $app->getUserStateFromRequest( $context.'filter_filter',		'filter_filter',	'',			'int' );
	$search				= $app->getUserStateFromRequest( $context.'search',				'search',			'',			'string' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm2.submit();"';

	// state filter
	//$lists['order'] = bfauctionHelper::orderList($filter_sort);
	//$lists['filter'] = bfauctionHelper::filterList($filter_filter);

	//$session = JFactory::getSession();
	//$catid = $session->get('catid');
	//$showAllCategories = $session->get('showAllCategories');

	// search filter
	//$lists['search']= $search;

	/******************** countdown timer ***************************/
	if($showTimer){
		$now = JFactory::getDate();
		$currentDate=$now->format('Y-m-d H:i:s');
?>
		<script type="text/javascript">
		<!--
		  var days = 0;
		  var hours = 0;
		  var minutes = 0;
		  var seconds = 0;

		function setCountDown (days, hours, mintues, seconds, i)
		{
			seconds--;
			if (seconds < 0){
				mintues--;
				seconds = 59
			}
			if (mintues < 0){
				hours--;
				mintues = 59
			}
			if (hours < 0){
				days--;
				hours = 23
			}
			if(seconds < 10){
				seconds = "0"+seconds;
			}
			document.getElementById("txt"+i).value = days+"d "+hours+"h "+mintues+":"+seconds;

			if(days < 0){
				document.getElementById("txt"+i).value = "0:00";
			}else{
				setTimeout(function() {
					setCountDown(days, hours, mintues, seconds, i);
			    }, 1000);
			}
		}

		//-->

		</script>
<?php
	}
	/****************************************************************/
?>

<div class="clr"></div>
<div class="span12">
	<?php

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];

		$input 		= JFactory::getApplication()->input;
		$catid 		= $input->get('cid');
		$link 		= JRoute::_( 'index.php?option=com_bfauction&view=auction&id='. $row->id.'&grid=1&catid='.$catid);

		$newrow = ($i > 1) && ($i % 6 == 0);
		if($newrow){
			echo '<div class="clrgap"></div>';
		}

		$image = bfauctionModelGrids::getFirstImage($row->id);
	?>

		<div class="span2" style="background-color:<?php echo $i & 1 ? $alternateColour : $rowColour; ?>;<?php echo $newrow ? "margin-left: 0px;": ""?>">

			<div style="margin-top:5px; height: <?php echo $max_height_t; ?>px; text-align: center">
				<?php if($image != ""){ ?>
    				<a href="<?php echo $link;?>"><img src="<?php echo $image;?>" border=0 <?php echo 'width="'.$max_width_t.'px"' ?>></a>
    			<?php }else{ ?>
    				<a href="<?php echo $link;?>"><div class="noimage">No Image</div></a>
    			<?php } ?>
			</div>
			<div align="center">
				<a href="<?php echo $link; ?>" alt="<?php echo $row->title; ?>"><?php echo $row->title; ?></a>
			</div>

			<div align="center">
				<?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $row->currentBid; ?>
				<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</div>
			<?php if($showTimer){ ?>
			<div align="center" class="gridcountdown">
				<input id="txt<?php echo $i; ?>" name="txt" readonly value="" class="gridtimer">
			</div>
			<?php } ?>
		</div>

		<?php
		/******************** countdown timer ***************************/
		if($showTimer){
			$endDate = $row->endDate;

			$secondsDiff = 0;
			if($currentDate < $endDate){
				$endDateAsSeconds = strtotime($endDate);
				$currentDateAsSeconds = strtotime($currentDate);
				$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
			}

			$remainingDay     = floor($secondsDiff/60/60/24);
			$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
			$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
			$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));
			?>

			<script type="text/javascript">
			<!--
			 setCountDown(<?php echo $remainingDay; ?>, <?php echo $remainingHour; ?>, <?php echo $remainingMinutes; ?>, <?php echo $remainingSeconds; ?>, <?php echo $i; ?>); // Start clock.
			//-->
			</script>
		<?php
		}
		/******************** end countdown timer ***************************/
	}
	?>
</div>
<div class="clr"></div>
<div class="span12">
	      <form method="post" name="adminForm" action="index.php?option=com_bfauction">
	      	<?php echo $this->pagination->getListFooter(); ?>
	      	<input type="hidden" name="option" value="com_bfauction" />
		  	<input type="hidden" name="task" value="grid" />
		  	<input type="hidden" name="boxchecked" value="0" />
		  	<input type="hidden" name="cid" value="<?php if(isset($row)){ echo $row->id; } ?>" />
		  	<input type="hidden" name="view" value="grid" />
		  </form>
</div>
<div class="clr"></div>

<?php //bfauctionController::triggerBFAuctionEmail(); ?>

