<?php

defined('_JEXEC') or die;

class BfauctionViewPayments extends F0FView
{

	public function display($tpl = null)
	{

		if ($this->item->orderStatus !== "C") {
			$this->paymentButton = $this->generatePaymentButton($this->item->orderId);
		}

		parent::display($tpl);
	}

	public function generatePaymentButton($orderId)
	{
		$params = JComponentHelper::getParams('com_bfauction');

		$user = JFactory::getUser();
		$user_name = $user->username;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('orderId=' . $orderId);
		$query->where("highBidder='$user_name'");
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if (empty($rows) || $db->getErrorNum()) {
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()) . '<br />';
			return;
		}
		$item = $rows[0];

		// check current date > enddate

		$plugin = JPluginHelper::getPlugin('payment', $item->processor);
		$pluginParams = new JRegistry($plugin->params);

		$email = $pluginParams->get('business');
		if (empty($email)) {
			throw new Exception(JText::_('Please set your Paypal email.'), 403);
		}

		$vars = new stdClass;
		$vars->order_id = $item->orderId;
		$vars->user_id = $user->id;
		$vars->user_firstname = $user->name;
		$vars->user_email = $email;
		$vars->phone = $item->phone;
		$vars->item_name = $item->title;
		$vars->amount = $item->totalAmount;
		//$vars->quantity = $item->quantity;
		$vars->shipping = $item->shipping;
		$vars->currency_code = $params->get('addcurrency');
		$vars->submiturl = "";
		$vars->return = JURI::root() . substr(JRoute::_("index.php?option=com_bfauction&task=payment.update&orderId=" . ($orderId) . "&processor={$item->processor}&Itemid=0", false), strlen(JURI::base(true)) + 1);
		$vars->cancel_return = "";
		$vars->notify_url = "";
		$vars->url = $vars->notify_url;
		$vars->comment = "";
		$vars->payment_description = JText::_('COM_BFAUCTION_PAYMENT_DESCRIPTION');

		//$vars->submiturl = JRoute::_("index.php?option=com_tjcpg&controller=payment&task=confirmpayment&processor={$pg_plugin}");
		//$vars->return = JURI::root().substr(JRoute::_("index.php?option=com_bfauction&view=orders&layout=order&orderid=".($orderid)."&processor={$pg_plugin}&Itemid=".$orderItemid,false),strlen(JURI::base(true))+1);
		//$vars->cancel_return = JURI::root().substr(JRoute::_("index.php?option=com_tjcpg&view=orders&layout=cancel&processor={$pg_plugin}&Itemid=".$orderItemid,false),strlen(JURI::base(true))+1);
		//$vars->url=$vars->notify_url=JRoute::_(JURI::root()."index.php?option=com_tjcpg&controller=payment&task=processpayment&order_id=".($orderid)."&processor=".$pg_plugin,false);

		JPluginHelper::importPlugin('payment', $item->processor);
		$dispatcher = JDispatcher::getInstance();
		$html = $dispatcher->trigger('onTP_GetHTML', array($vars));

		return $html[0];
	}

}



