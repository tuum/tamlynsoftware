<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoControllerMetatagarts extends F0FController
{

	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'metatagarts';

		$options = JComponentHelper::getParams('com_bfseo');
		$this->maxDescLength = $options->get('maxDescLength', 160);
		$this->minDescLength = $options->get('minDescLength', 6);
		$this->skipWords = $options->get('skipWords');
		$this->skipTags = $options->get('skipTags');
		$this->metaKeywordLocation = $options->get('metaKeywordLocation', 0);
	}

	public function execute($task)
	{
		if (!in_array($task, array('view', 'save', 'generate', 'generate2'))) $task = 'add';
		parent::execute($task);
	}

	public function view()
	{
		$input = JFactory::getApplication()->input;

		$limitstart = $input->get('limitstart', 0);
		$listlimit  = $input->get('listlimit', 20);

		$this->setRedirect('index.php?option=com_bfseo&view=metatagarts&limitstart=' . $limitstart . '&listlimit=' . $listlimit);

		return true;
	}

	public function save()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		$model = $this->getThisModel();

		$app = JFactory::getApplication();
		$input = $app->input;

		$data = $input->getArray();
		$ids = $data['id'];

		foreach ($ids as $id) {
			$metadesc = $data['desc'][$id];

			$model->updateMeta($metadesc, $id);
		}

		$input = JFactory::getApplication()->input;
		$limitstart = $input->get('limitstart', 0);
		$listlimit  = $input->get('listlimit', 20);

		$this->setMessage(JText::_('COM_BFSEO_METADATA_SAVED'));
		$this->setRedirect('index.php?option=com_bfseo&view=metatagarts&limitstart=' . $limitstart . '&listlimit=' . $listlimit);

		return true;
	}

	public function generate2()
	{
		$this->generate(true);
	}

	public function generate($all = false)
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		//save data first, in case user has blanked out any fields
		BfseoControllerMetatagarts::save();

		$app = JFactory::getApplication();
		$input = $app->input;

		$db = JFactory::getDbo();

		if ($all) {
			$query = $db->getQuery(true);
			$query->select('id');
			$query->from('#__content');
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1000'), JText::_('COM_BFSEO_DATABASE_ERROR'));
			}
			$rows = $db->loadObjectList();
			if (empty($rows)) {
				if ($db->getErrorNum()) {
					JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1001'), JText::_('COM_BFSEO_DATABASE_ERROR'));
				}
			}
			$ids = array();
			foreach ($rows as $row) {
				$ids[$row->id] = $row->id;
			}
		} else {
			$data = $input->getArray();
			$ids = $data['id'];
		}

		foreach ($ids as $id) {
			$query = $db->getQuery(true);
			$query->select('metadesc, introtext, `fulltext`, title');
			$query->from('#__content');
			$query->where("id = {$id}");
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1000'), JText::_('COM_BFSEO_DATABASE_ERROR'));
			}
			$rows = $db->loadAssoc();
			if (empty($rows)) {
				if ($db->getErrorNum()) {
					JError::raiseError(JText::_('COM_BFSEO_ERROR_CODE_1001'), JText::_('COM_BFSEO_DATABASE_ERROR'));
				}
			}

			$trimmed = trim($rows['metadesc']);
			if (!empty($trimmed)) {
				continue;
			}

			$metadesc = $this->generateMetaDescription($rows['introtext'] . $rows['fulltext'], $rows['title']);

			$metadesc = $db->quote($metadesc);

			$query->clear();
			$query->update('#__content');
			$query->set("metadesc=$metadesc");
			$query->where('id=' . (int)$id);
			$db->setQuery($query);
			if (!$db->query()) {
				return false;
			}
		}

		$limitstart = $input->get('limitstart', 0);
		$listlimit  = $input->get('listlimit', 20);

		$this->setRedirect('index.php?option=com_bfseo&view=metatagarts&limitstart=' . $limitstart . '&listlimit=' . $listlimit);

		return true;
	}

	private function generateMetaDescription($text, $title)
	{
		libxml_use_internal_errors(true);

		$doc = new DOMDocument();
		//$doc->loadHTML($text);
		$doc->loadXML($text);
		$xpath = new DOMXpath($doc);
		$texts = array();
		$tags = $xpath->query("//p");
		foreach ($tags as $tag) {
			$texts[] = $tag->textContent;
		}

		$skipWords = $this->skipWords;
		$skipWords = explode(', ', $skipWords);

		if ($this->metaKeywordLocation == 1) {
			//get keywords from article text
			$words = str_word_count(strtolower($text), 1);
		} else {
			//get keywords from title
			$words = array_unique(str_word_count(strtolower($title), 1));
		}
		arsort($words);

		$keywords = array();
		foreach ($words as $word) {
			if (in_array($word, $skipWords)) {
				continue;
			}
			$keywords[] = $word;
		}
		$skipTags = $this->skipTags;
		$skipTags = explode(', ', $skipTags);

		$candidates = array();
		foreach ($texts as $text) {
			foreach ($skipTags as $tag) {
				if (preg_match('/{\s*?' . $tag . '(\s.*)?}/i', $text)) {
					continue 2;
				}
			}

			$n = 0;
			foreach ($keywords as $word) {
				if (stripos($text, $word) !== false) {
					$n++;
				}
			}

			if (empty($candidates[$n])) {
				$candidates[$n] = $text;
			};
		}

		krsort($candidates);

		$metadesc = substr(array_shift($candidates) . ' ', 0, $this->maxDescLength);
		$metadesc = strip_tags(substr($metadesc, 0, strrpos($metadesc, ' ')));

		$matches = null;
		//$match = preg_match("/^.*?[\.\!\?]/", $metadesc, $matches);
		$match = preg_match("/^.*?\./", $metadesc, $matches);
		if ($match) {
			$metadesc = $matches[0];
		} else if (strlen($metadesc) < $this->minDescLength) {
			$metadesc = '';
		}

		return $metadesc;

	}


}


