<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerRobots extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'robots';
	}

	public function execute($task)
	{
		if (!in_array($task, array('createrobots','updaterobots'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function createrobots()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN')); 
		
		$model = $this->getThisModel();

		$result = $model->createrobots();

		$url = 'index.php?option=com_bfseo&view=robots';
		if($result !== true) {
			$this->setRedirect($url, JText::_('COM_BFSEO_ERROR_CANT_CREATE_ROBOTS'),'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSEO_CREATED_ROBOTS'));
		}

		$this->redirect();
	}

	function updaterobots()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN')); 
		
		$model = $this->getThisModel();

		$result = $model->updaterobots();

		$url = 'index.php?option=com_bfseo&view=robots';
		if($result !== true) {
			$this->setRedirect($url, JText::_('COM_BFSEO_ERROR_CANT_UPDATE_ROBOTS'),'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSEO_UPDATED_ROBOTS'));
		}

		$this->redirect();
	}
}