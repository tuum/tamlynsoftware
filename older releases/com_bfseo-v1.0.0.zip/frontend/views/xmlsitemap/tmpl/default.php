<?php
/*
 * @package bfauction
* @copyright Copyright (c)2014 Tamlyn Software
* @license GNU General Public License version 2 or later
*/

defined('_JEXEC') or die();

$model = $this->getModel();
$this->menuItems = $model->getMenuItems();

header('Content-type: text/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>',"\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($this->menuItems as $menu): ?>
<?php //$link = JUri::root().$menu->link; ?>
<?php $link = JRoute::_($menu->link, true, @$node->secure == 0 ? (JFactory::getURI()->isSSL() ? 1 : -1) : $node->secure); ?>
<url>
	<loc><?php echo $link; ?></loc>
<?php if(isset($menu->modified)){ ?>
	<lastmod><?php echo $menu->modified; ?></lastmod>
<?php } ?>
	<changefreq>weekly</changefreq>
	<priority>0.5</priority>
</url>
<?php endforeach; ?>

</urlset>
