<?php
/**
 *  @package BF SEO
*  @copyright Copyright (c)2016 Tamlyn Software
* @license GNU General Public License version 2 or later
*/

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoToolbar extends F0FToolbar
{
	public function onMetatagsAdd()
	{
	
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_METATAGS_EDIT'));

		JToolBarHelper::apply('metatags.save', 'JTOOLBAR_APPLY');

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onMetatagCatsAdd()
	{
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_METATAGS_EDIT'));

		JToolBarHelper::apply('metatagcats.save', 'JTOOLBAR_APPLY');

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onMetatagArtsAdd()
	{	
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_METATAGS_EDIT'));

		JToolBarHelper::apply('metatagarts.save', 'JTOOLBAR_APPLY');

		JToolBarHelper::custom('metatagarts.generate', 'generate', 'generate', 'COM_BFSEO_TITLE_GENERATE_META_DESC', false);

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}
		
	public function onK2MetaArtsAdd()
	{	
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_METATAGS_EDIT'));

		JToolBarHelper::apply('k2metaart.save', 'JTOOLBAR_APPLY');

		JToolBarHelper::custom('k2metaart.generate', 'generate', 'generate', 'COM_BFSEO_TITLE_GENERATE_META_DESC', false);

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}
	
	public function onK2MetaCatsAdd()
	{
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_METATAGS_EDIT'));

		JToolBarHelper::apply('k2metacats.save', 'JTOOLBAR_APPLY');

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onSitecheckAdd()
	{
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_SITECHECK'));

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onSitecheckBrowse()
	{
		$this->onSitecheckAdd();
	}

	public function onSitecheckEdit()
	{
		$this->onSitecheckAdd();
	}

	public function onRobotsAdd()
	{
		JToolBarHelper::title(JText::_('COM_BFSEO_TITLE_ROBOTS'));

		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onRobotsBrowse()
	{
		$this->onRobotsAdd();
	}

	public function onRobotsEdit()
	{
		$this->onRobotsAdd();
	}

	public function onBrowse()
	{
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onRead()
	{
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}

	public function onAdd()
	{
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfseo&view=cpanels');
	}
}
