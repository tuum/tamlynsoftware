<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');
JHtml::_('behavior.modal');

if (version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');
F0FTemplateUtils::addJS('media://com_bfseo/js/checkmeta.js');

$input = JFactory::getApplication()->input;
$options = JComponentHelper::getParams('com_bfseo');
$minTitleLength = $options->get('minTitleLength', 6);
$maxTitleLength = $options->get('maxTitleLength', 55);
$minDescLength = $options->get('minDescLength', 6);
$maxDescLength = $options->get('maxDescLength', 160);
$minWarningText = $options->get('minWarningText', 'Too short');
$maxWarningText = $options->get('maxWarningText', 'Too long');
?>

<div class="row">
	<form id="adminForm" name="adminForm" method="post" action="<?php echo JRoute::_('index.php?option=com_bfseo') ?>">
		<div class="row">
			<div class="span4" style='margin-left: 50px'><?php echo bfseoHelper::createDropDown($input->get('view')); ?></div>
		</div>
		<div class="row">
			<div class='span12'>
				<table class='table table-condensed metatable'>
					<tr>
						<th class='menu-id'><?php echo JText::_('COM_BFSEO_TITLE_MENUID'); ?></th>
						<th class='category'><?php echo JText::_('COM_BFSEO_TITLE_MENUTITLE'); ?></th>
						<th><?php echo JText::_('COM_BFSEO_TITLE_METATITLE'); ?></th>
						<th><?php echo JText::_('COM_BFSEO_TITLE_METADESCRIPTION'); ?></th>
					</tr>
					<?php foreach ($this->menuItems as $menu): ?>
						<tr>
							<td class='menu-id'><?php echo $menu->id ?>
								<input type='hidden' name='id[<?php echo $menu->id ?>]' value='<?php echo $menu->id ?>'>
							</td>
							<td class='category'>
								<?php echo $menu->title ?>
								<br>
								<?php
			                    	$link = JUri::root().$menu->link;
									if(strpos($link, "Itemid") === FALSE){
										if(strpos($link, "?") === FALSE){
											$link .= "?Itemid=".intval($menu->id);
										}
										else{
											$link .= "&Itemid=".intval($menu->id);
										}
									}
								?>
								<a href="index.php?option=com_menus&task=item.edit&id=<?php echo $menu->id; ?>"  class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-edit"></span></a>
								<a href="<?php echo $link; ?>" class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-preview"></span></a>
								<a href="index.php?option=com_bfseo&view=pagecheck&task=check&urltocheck=<?php echo base64_encode($link); ?>"  class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-wrench"></span></a>
							</td>
							<?php
							$params = json_decode($menu->params, true);
							$pageTitle = isset($params['page_title']) ? $params['page_title'] : '';
							$metaDescription = isset($params['menu-meta_description']) ? $params['menu-meta_description'] : '';
							$metaKeywords = isset($params['menu-meta_keywords']) ? $params['menu-meta_keywords'] : '';
							?>
							<?php
							$warning='';
							$borderColor = 'border-color: ';
							$textColor = 'color: ';
							if (!empty($pageTitle)) {
								if (strlen($pageTitle) < $minTitleLength) {
									$borderColor .= "DarkViolet";
									$warning=$minWarningText;
									$textColor .= "DarkViolet";
								} else if (strlen($pageTitle) > $maxTitleLength) {
									$borderColor .= "DeepPink";
									$warning=$maxWarningText;
									$textColor .= "DeepPink";
								}
							}


							//check for duplicate
							foreach ($this->menuItems as $tempmenu){
								$tempparams = json_decode($tempmenu->params, true);
								$temppageTitle = isset($tempparams['page_title']) ? $tempparams['page_title'] : '';
								if($temppageTitle == $pageTitle && $tempmenu->id != $menu->id && $pageTitle != ''){
									$warning= JText::_('COM_BFSEO_ERROR_DUPLICATE_CONTENT');
									$borderColor = 'border-color: red';
									$textColor = 'color: red';
								}
							}

							?>
							<td width='20%'>
								<textarea rows=1 class='metaTitle' style='<?php echo $borderColor ?>'
									name='title[<?php echo $menu->id ?>]'
									id='title<?php echo $menu->id ?>'><?php echo $pageTitle ?></textarea>
								<div id="warningtitle<?php echo $menu->id ?>" style="width:100%; <?php echo $textColor ?>" /><?php echo $warning; ?></div>
							</td>
							<?php
							$borderColor = 'border-color: ';
							$textColor = 'color: ';
							$warning='';
							if (!empty($metaDescription)) {
								if (strlen($metaDescription) < $minDescLength) {
									$borderColor .= "DarkViolet";
									$warning=$minWarningText;
									$textColor .= "DarkViolet";
								} else if (strlen($metaDescription) > $maxDescLength) {
									$borderColor .= "DeepPink";
									$warning=$maxWarningText;
									$textColor .= "DeepPink";
								}
							}

							//check for duplicate
							foreach ($this->menuItems as $tempmenu){
								$tempparams = json_decode($tempmenu->params, true);
								$tempmetaDescription = isset($tempparams['menu-meta_description']) ? $tempparams['menu-meta_description'] : '';
								if($tempmetaDescription == $metaDescription && $tempmenu->id != $menu->id && $metaDescription != ''){
									$warning= JText::_('COM_BFSEO_ERROR_DUPLICATE_CONTENT');
									$borderColor = 'border-color: red';
									$textColor = 'color: red';
								}
							}
							?>
							<td>
								<textarea rows=1 class='metaDesc' style='<?php echo $borderColor ?>'
										  name='desc[<?php echo $menu->id ?>]'
										  id='desc<?php echo $menu->id ?>'><?php echo $metaDescription ?></textarea>
								<div id="warningdesc<?php echo $menu->id ?>" style="width:100%; <?php echo $textColor ?>" /><?php echo $warning; ?></div>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<input type="hidden" name="task" value=""/>
				<?php echo JHtml::_('form.token'); ?>

			</div>
		</div>
	</form>

	<script>
		var minTitleLength = <?php echo $minTitleLength ?>;
		var maxTitleLength = <?php echo $maxTitleLength ?>;
		var minDescLength = <?php echo $minDescLength ?>;
		var maxDescLength = <?php echo $maxDescLength ?>;
		var minWarningText = '<?php echo $minWarningText ?>';
		var maxWarningText = '<?php echo $maxWarningText ?>';
	</script>

</div>