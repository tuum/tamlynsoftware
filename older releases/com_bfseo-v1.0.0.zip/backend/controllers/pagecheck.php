<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerPagecheck extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'pagecheck';
	}

	public function execute($task)
	{
		if (!in_array($task, array('check','results'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function check()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN')); 
		
		$model = $this->getThisModel();

		$app = JFactory::getApplication();
		$input = $app->input;

		$url = $input->getString('url');

		//see if there is a url passed from meta view
		$urltocheck = $input->getString('urltocheck');
		if(isset($urltocheck))
		{
			$url = base64_decode($urltocheck);
		}

		$results = $model->check($url);

		if ($results === false) {
			$this->setMessage(JText::sprintf( 'COM_BFSEO_FETCH_URL_FAILED', $url), 'error');
			$this->setRedirect('index.php?option=com_bfseo&view=pagecheck');
			return;
		}

		$session = JFactory::getSession();
		$session->set('results', $results);

		$this->setRedirect('index.php?option=com_bfseo&view=pagecheck');

	}
}