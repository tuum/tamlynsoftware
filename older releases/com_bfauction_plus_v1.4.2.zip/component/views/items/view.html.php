<?php
/**
 * $Id: view.html.php 84 2013-11-28 02:01:32Z tuum $
 * My Items View for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

JLoader::register('JToolbarHelper', JPATH_ADMINISTRATOR.'/includes/toolbar.php');

jimport( 'joomla.application.component.view' );

/**
 * Default View
 *
 * @package    Joomla
 * @subpackage Components
 */
//forwards compatibility for Joomla 3.0
//class bfauction_plusViewitems extends JView
class bfauction_plusViewitems extends JViewLegacy
{
    function display($tpl = null)
    {
    	$app = JFactory::getApplication();

		// Get the component configuration
		$params = $app->getParams();
		$this->assignRef('params',		$params);

	    // Get data from the model
	    $items = $this->get('Data');
	    $pagination = $this->get('Pagination');

	    // push data into the template
	    $this->assignRef('items', $items);
  	    $this->assignRef('pagination', $pagination);

        parent::display($tpl);
    }

 	/* Front end toolbar */
	function getToolbar() {
		// add required stylesheets from admin template
		$document    =  JFactory::getDocument();
		$document->addStyleSheet('administrator/templates/system/css/system.css');
		//now we add the necessary stylesheets from the administrator template
		//in this case i make reference to the bluestork default administrator template in joomla 1.6
		$document->addCustomTag(
			'<link href="administrator/templates/bluestork/css/template.css" rel="stylesheet" type="text/css" />'."\n\n".
			'<!--[if IE 7]>'."\n".
			'<link href="administrator/templates/bluestork/css/ie7.css" rel="stylesheet" type="text/css" />'."\n".
			'<![endif]-->'."\n".
			'<!--[if gte IE 8]>'."\n\n".
			'<link href="administrator/templates/bluestork/css/ie8.css" rel="stylesheet" type="text/css" />'."\n".
			'<![endif]-->'."\n".
			'<link rel="stylesheet" href="administrator/templates/bluestork/css/rounded.css" type="text/css" />'."\n"
			);
		//load the JToolBar library and create a toolbar
		jimport('joomla.html.toolbar');
		$bar = new JToolBar( 'toolbar' );

		//and make whatever calls you require
		require_once JPATH_COMPONENT.'/helpers/bfauction_plus.php';

		$state	= $this->get('State');
		$canDo	= bfauction_plusHelper::getActions($state->get('filter.category_id'));

		if ($canDo->get('core.create')) {
			$bar->appendButton( 'Standard', 'addNew', 'New', 'item.add', false );
		}

		//generate the html and return
		return $bar->render();
	}
}