<?php
/**
 * $Id: rptsales.php 84 2013-11-28 02:01:32Z tuum $
 * Sales Report Controller for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controlleradmin');

/**
 * BF Auction Plus list controller class.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_bfauction_plus
 * @since		1.6
 */
class bfauction_plusControllerrptsales extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function getModel($name = 'Item', $prefix = 'bfauction_plusModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

    /**
     * Method to copy items
     *
     */
    public function copy()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Item', 'Table');

        $this->setRedirect( 'index.php?option=com_bfauction_plus' );

        $n		= count( $cid );

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	$row->title		= JText::_('COM_BFAUCTIONPLUS_COPY_OF').' '. $row->title;
            	$row->id            = 0;
            	$row->state     	= 0;
				$row->highBidder	= "";
				$row->currentBid	= 0;
				$row->ordering 		= 0;
				$row->winEmailSent	= 0;
				$row->winEmailDate = '0000-00-00 00:00:00';

				$now = JFactory::getDate();
				if(is_callable(array('JDate', 'toSql'))){
					$row->date	= $now->toSql();
				}else{
					$row->date 	= $now->toMySQL();
				}

				// set end date to be 7 days from now
				$date = JFactory::getDate();
				$date->modify("+7 days");

				if(is_callable(array('JDate', 'toSql'))){
					$row->endDate = $date->toSql();
				}else{
					$row->endDate = $date->toMySQL();
				}

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::sprintf( 'COM_BFAUCTIONPLUS_ITEMS_COPIED', $n ) );

        return true;
    }

	public function relist()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Item', 'Table');

        $this->setRedirect( 'index.php?option=com_bfauction_plus' );

        $n		= count( $cid );

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	$row->state     	= 1;
				$row->highBidder	= "";
				$row->currentBid	= 0;
				$row->ordering 		= 0;
				$row->winEmailSent	= 0;
				$row->winEmailDate = '0000-00-00 00:00:00';

				$now = JFactory::getDate();
				if(is_callable(array('JDate', 'toSql'))){
					$row->date	= $now->toSql();
				}else{
					$row->date 	= $now->toMySQL();
				}

				// set end date to be 7 days from now
				$date = JFactory::getDate();
				$date->modify("+7 days");

				if(is_callable(array('JDate', 'toSql'))){
					$row->endDate = $date->toSql();
				}else{
					$row->endDate = $date->toMySQL();
				}

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::plural( 'COM_BFAUCTION_PLUS_N_ITEMS_RELISTED', $n ) );

        return true;
    }

}