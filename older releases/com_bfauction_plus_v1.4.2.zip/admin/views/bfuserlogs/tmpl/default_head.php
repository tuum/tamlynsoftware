<?php
/**
 * $Id: default_head.php 84 2013-11-28 02:01:32Z tuum $
 * BF User log Component for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF User Log is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));

$version = new JVersion();
?>
<tr>
	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
	<th width="1%" class="nowrap center hidden-phone">
		<?php echo JHtml::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
	</th>
	<?php } ?>
	<th width="1%" class="hidden-phone">
		<input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
	</th>
	<th width="1%" class="nowrap center">
		<?php echo JHtml::_('grid.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
	</th>
	<th width="1%" class="hidden-phone">
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_UID'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_UID' ) . "\t"; ?>
	</th>
	<th>
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_NAME'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_NAME' ) . "\t"; ?>
	</th>
	<th width="1%" class="hidden-phone">
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_USERNAME'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_USERNAME' ) . "\t"; ?>
	</th>
	<th width="1%" class="hidden-phone">
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_EMAIL'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_EMAIL' ) . "\t"; ?>
	</th>
	<th width="1%" class="hidden-phone">
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_SITE'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_SITE' ) . "\t"; ?>
	</th>
	<th>
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_VISITDATE'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_VISITDATE' ) . "\t"; ?>
	</th>
	<th width="1%" class="hidden-phone">
		<?php echo JText::_('COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_LOGIN'); ?>
		<?php $this->header .= JText::_( 'COM_BFAUCTIONPLUS_BFUSERLOG_HEADING_LOGIN' ) . "\t"; ?>
	</th>
	<th width="1%" class="nowrap center hidden-phone">
		<?php echo JHtml::_('grid.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
		<?php $this->header .= JText::_( 'JGRID_HEADING_ID' ) . "\t"; ?>
	</th>
</tr>
