<?php
/**
 * $Id: view.html.php 84 2013-11-28 02:01:32Z tuum $
 * Items Report for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * Default View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusViewrptitems extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;
	protected $form;

	/**
	 * Items view display method
	 * @return void
	 **/
	function display($tpl = null)
	{
		$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->form			= $this->get('Form');

		bfauction_plusHelper::addSubmenu('rptitems');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->ordering = array();

		$this->addToolbar();
		require_once JPATH_COMPONENT .'/models/fields/auctionstatus.php';
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfauction_plus.php';

		$state	= $this->get('State');
		$canDo	= bfauction_plusHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title(JText::_('COM_BFAUCTIONPLUS_TOOLBAR_RPTITEMS_LIST'), 'bfauction_plus_toolbar_title');
		$toolbar = JToolBar::getInstance('toolbar');
		if ($canDo->get('core.create')) {
			JToolBarHelper::addNew('item.add','JTOOLBAR_NEW');
		}
		if ($canDo->get('core.edit')) {
			JToolBarHelper::editList('item.edit','JTOOLBAR_EDIT');
		}
		if ($canDo->get('core.edit.state')) {

			JToolBarHelper::divider();
			JToolBarHelper::custom('items.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom('items.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);

			JToolBarHelper::divider();
			JToolBarHelper::archiveList('items.archive','JTOOLBAR_ARCHIVE');
		}
		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'items.delete','JTOOLBAR_EMPTY_TRASH');
			JToolBarHelper::divider();
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('items.trash','JTOOLBAR_TRASH');
			JToolBarHelper::divider();
		}

		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom( 'items.copy', 'copy.png', 'copy_f2.png', 'COM_BFAUCTIONPLUS_TOOLBAR_COPY' );
			JToolBarHelper::custom( 'items.relist', 'refresh', 'refresh', 'COM_BFAUCTIONPLUS_TOOLBAR_RELIST' );
		}

		//if ($canDo->get('core.admin')) {
		//	JToolBarHelper::custom('rptitems.export_csv', 'export', 'export', 'COM_BFAUCTIONPLUS_EXPORT_CSV', false);
		//}

		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_bfauction_plus&view=rptitems');

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_PUBLISHED'),
				'filter_published',
				JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_CATEGORY'),
				'filter_category_id',
				JHtml::_('select.options', JHtml::_('category.options', 'com_bfauction_plus'), 'value', 'text', $this->state->get('filter.category_id'))
			);

			require_once JPATH_COMPONENT.'/models/fields/auctionstatus.php';
			JSubMenuHelper::addFilter(
				JText::_('COM_BFAUCTIONPLUS_SELECT_AUCTION_STATUS'),
				'filter_auction_status',
				JHtml::_('select.options', JFormFieldAuctionStatus::getOptions(), 'value', 'text', $this->state->get('filter.auction_status'))
			);
		}
	}

	/**
	 * Returns an array of fields the table can be sorted by
	 *
	 * @return  array  Array containing the field name to sort by as the key and display text as value
	 *
	 * @since   3.0
	 */
	protected function getSortFields()
	{
		return array(
			'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
			'a.state' => JText::_('JSTATUS'),
			'a.title' => JText::_('JGLOBAL_TITLE'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}
}