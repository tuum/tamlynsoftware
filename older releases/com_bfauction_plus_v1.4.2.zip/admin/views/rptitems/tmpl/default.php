<?php
/**
 * $Id: default.php 84 2013-11-28 02:01:32Z tuum $
 * Sold Items Report view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');

$user = JFactory::getUser();
$userId	= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
$canOrder	= $user->authorise('core.edit.state',	'com_bfauction_plus');
$archived	= $this->state->get('filter.published') == 2 ? true : false;
$trashed	= $this->state->get('filter.published') == -2 ? true : false;
$params		= (isset($this->state->params)) ? $this->state->params : new JObject;
$saveOrder	= $listOrder == 'a.ordering';
$ordering 	= ($listOrder == 'a.ordering');

$params = JComponentHelper::getParams('com_bfauction_plus');
$dateFormat = $params->get('dateFormat');
$bfcurrency = $params->get('bfcurrency', '$');

$header=""; // excel export
$data="";

$version = new JVersion();
if( floatval($version->RELEASE) >= 3 ) {
	JHtml::_('dropdown.init');
	if ($saveOrder)
	{
		$saveOrderingUrl = 'index.php?option=com_bfauction_plus&task=rptitems.saveOrderAjax&tmpl=component';
		JHtml::_('sortablelist.sortable', 'emailList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
	}
	$sortFields = $this->getSortFields();
}
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, '');
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=rptitems'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<div id="filter-bar" class="btn-toolbar">
		<div class="filter-search btn-group pull-left">
			<label for="filter_search" class="element-invisible"><?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN_TITLE');?></label>
			<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN_TITLE'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN_TITLE'); ?>" />
		</div>
		<div class="btn-group pull-left">
			<button type="submit" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
			<button type="button" class="btn" rel="tooltip" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
			<?php echo $this->pagination->getLimitBox(); ?>
		</div>
		<div class="btn-group pull-right hidden-phone">
			<label for="directionTable" class="element-invisible"><?php echo JText::_('JFIELD_ORDERING_DESC');?></label>
			<select name="directionTable" id="directionTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JFIELD_ORDERING_DESC');?></option>
				<option value="asc" <?php if ($listDirn == 'asc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_ASCENDING');?></option>
				<option value="desc" <?php if ($listDirn == 'desc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_DESCENDING');?></option>
			</select>
		</div>
		<div class="btn-group pull-right">
			<label for="sortTable" class="element-invisible"><?php echo JText::_('JGLOBAL_SORT_BY');?></label>
			<select name="sortTable" id="sortTable" class="input-medium" onchange="Joomla.orderTable()">
				<option value=""><?php echo JText::_('JGLOBAL_SORT_BY');?></option>
				<?php echo JHtml::_('select.options', $sortFields, 'value', 'text', $listOrder);?>
			</select>
		</div>
	</div>

	<div class="clearfix"> </div>
	<table class="table table-striped" id="emailList">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<fieldset id="filter-bar">
		<div class="filter-search fltlft">
			<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
			<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN_TITLE'); ?>" />
			<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
			<button type="button" onclick="document.id('filter_search').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
		</div>
		<div class="filter-select fltrt">

			<select name="filter_auction_status" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_BFAUCTIONPLUS_SELECT_AUCTION_STATUS');?></option>
				<?php echo JHtml::_('select.options', JFormFieldAuctionStatus::getOptions(), 'value', 'text', $this->state->get('filter.auction_status'), true);?>
			</select>

			<select name="filter_published" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_PUBLISHED');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.state'), true);?>
			</select>

			<select name="filter_category_id" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_bfauction_plus'), 'value', 'text', $this->state->get('filter.category_id'));?>
			</select>
		</div>
	</fieldset>
	<div class="clr"> </div>

	<table class="adminlist">
<?php
	} //end Joomla 2.5
?>
	<thead>
		<tr>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_DATE_SOLD', 'a.endDate', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_DATE_SOLD' ) . "\t"; ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_SOLD_FOR' ); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_SOLD_FOR' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_COST_PRICE' ); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_COST_PRICE' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_SALE_TYPE', 'a.saleType', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_SALE_TYPE' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_PRODUCT_CODE', 'a.productId', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_PRODUCT_CODE' ) . "\t"; ?>
			</th>
			<th width="15%" nowrap="nowrap">
				<?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_PRODUCTDESCRIPTION', 'a.title', $listDirn, $listOrder); ?>
				<?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_PRODUCTDESCRIPTION' ) . "\t"; ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_PRODUCTCATEGORY', 'category_name', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_PRODUCTCATEGORY' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_CUSTOMER_NUMBER', 'a.uid', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_CUSTOMER_NUMBER' ) . "\t"; ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_CUSTOMER_NAME', 'a.highBidder', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_CUSTOMER_NAME' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_BIDS' ); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_BIDS' ) . "\t"; ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JHtml::_('grid.sort',  'COM_BFAUCTIONPLUS_TITLE_PRODUCT_LOCATION', 'a.itemLocation', $listDirn, $listOrder); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_PRODUCT_LOCATION' ) . "\t"; ?>
			</th>
			<th width="5%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_FREIGHT_FEE' ); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_FREIGHT_FEE' ) . "\t"; ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_PURCHASE_PRICE' ); ?>
			    <?php $header .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_PURCHASE_PRICE' ) . "\t"; ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="14">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$originalOrders = array();
	foreach ($this->items as $i => $item) :
			$ordering	= ($listOrder == 'a.ordering');
			$item->cat_link	= JRoute::_('index.php?option=com_categories&extension=com_bfauction_plus&task=edit&type=other&cid[]='. $item->catid);
			$canCreate	= $user->authorise('core.create',		'com_bfauction_plus.category.'.$item->catid);
			$canEdit	= $user->authorise('core.edit',			'com_bfauction_plus.category.'.$item->catid);
			$canCheckin	= $user->authorise('core.manage',		'com_checkin') || $item->checked_out==$user->get('id') || $item->checked_out==0;
			$canChange	= $user->authorise('core.edit.state',	'com_bfauction_plus.category.'.$item->catid) && $canCheckin;
			?>

		<tr class="row<?php echo $i % 2; ?>">
			<td class="center">
				<?php echo JHtml::_('grid.id', $i, $item->id); ?>
			</td>
			<td align="center">
				<?php if($item->currentBid >= $item->reservePrice){ ?>
					<?php echo ($item->saleType == 0 ? "" : JHTML::_('date',  $item->endDate, $dateFormat )); ?>
					<?php $data .= ($item->saleType == 0 ? "" : JHTML::_('date',  $item->endDate, $dateFormat )) . "\t"; ?>
				<?php }else{ ?>
					<?php $data .= "\t"; ?>
				<?php } ?>
			</td>
			<td align="center">
				<?php if($item->currentBid >= $item->reservePrice){ ?>
					<?php $amount = (float)$item->currentBid + (float)$item->tax + (float)$item->commission; ?>
					<?php echo $bfcurrency.$amount; ?>
					<?php $data .= $bfcurrency.$amount . "\t"; ?>
				<?php }else{ ?>
					<?php $data .= "\t"; ?>
				<?php } ?>
			</td>
			<td align="right">
				<?php echo $bfcurrency.$item->costPrice;?>
				<?php $data .= $bfcurrency.$item->costPrice . "\t"; ?>
			</td>
			<td align="center">
				<?php
				switch($item->saleType){
					case 0: break;
					case 1: echo "Bid";
							$data .= "Bid" . "\t";
							break;
					case 2: echo "Buy Now";
							$data .= "Buy Now" . "\t";
							break;
				}
				 ?>
			</td>
			<td align="center">
				<?php if($item->productId){ ?>
					<?php echo $item->productId; ?>
					<?php $data .= $item->productId . "\t"; ?>
				<?php }else{ ?>
			   		<?php echo $item->id; ?>
			   		<?php $data .= $item->id . "\t"; ?>
			   	<?php } ?>
			</td>
			<td>
				<?php if ($canEdit) : ?>
					<a href="<?php echo JRoute::_('index.php?option=com_bfauction_plus&task=item.edit&id='.(int) $item->id); ?>">
						<?php echo $this->escape($item->title); ?></a>
				<?php else : ?>
						<?php echo $this->escape($item->title); ?>
				<?php endif; ?>
				<?php $numRelisted = bfauction_plusController::getNumRelisted($item->id); ?>
				[<?php echo $numRelisted; ?>]
				<?php $data .= $this->escape($item->title) . "[". $numRelisted . "]" . "\t"; ?>
			</td>
			<td align="center">
				<?php echo $item->category_name;?>
				<?php $data .= $item->category_name . "\t"; ?>
			</td>
			<td align="center">
				<?php if($item->currentBid >= $item->reservePrice){ ?>
					<?php echo $item->highBidder; ?>
					<?php $data .= $item->highBidder . "\t"; ?>
				<?php }else{ ?>
					<?php $data .= "\t"; ?>
				<?php } ?>
			</td>
			<td align="center">
				<?php if($item->currentBid >= $item->reservePrice){ ?>
					<?php echo $item->name;?>
					<?php $data .= $item->name . "\t"; ?>
				<?php }else{ ?>
					<?php $data .= "\t"; ?>
				<?php } ?>
			</td>
			<td align="center">
				<?php $numBids = bfauction_plusController::getNumBids($item->id); ?>
				<?php echo $numBids; ?>
				<?php $data .= $numBids . "\t"; ?>
			</td>
			<td align="center">
				<?php echo $item->itemLocation;?>
				<?php $data .= $item->itemLocation . "\t"; ?>
			</td>
			<td align="right">
				<?php echo $bfcurrency.$item->shipping;?>
				<?php $data .= $bfcurrency.$item->shipping . "\t"; ?>
			</td>
			<td align="right">
				<?php $total = (float)$item->currentBid + (float)$item->tax + (float)$item->commission + (float)$item->shipping; ?>
				<?php echo $bfcurrency.$total; ?>
				<?php $data .= $bfcurrency.$total . "\t"; ?>
			</td>

		</tr>
		<?php $data .= "\n"; ?>

	<?php endforeach; ?>
	 </tbody>
	</table>

	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

<?php
//dodgy way but it will do for now
   // excel export
   print '<form id="ExcelExport" name="ExcelExport" method="POST" action="./components/com_bfauction_plus/excelexport.php">';

   print '<input type=hidden name="myheader"  value="'.$header.'">';

   print '<DIV ID="ExcelDate" style="display:none;"><textarea name="mydata">'.$data.'</textarea></div>';

   ?>
   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_EXPORT_TO_EXCEL' ); ?>" />
   <?php jimport('joomla.html.html'); ?>
   <?php echo JHTML::_( 'form.token' ); ?>
   <?php
   print "</form>";
		?>