<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

class BFSurveyHelperBfsurvey
{
	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	static function saveImages($post,$files,$config,$myFilesFields)
	{
		$app = JFactory::getApplication();

		$conf = new stdClass();
		$conf->max_width = $config->get('max_width');
		$conf->max_height = $config->get('max_height');
		$conf->max_width_t = $config->get('max_width_t');
		$conf->max_height_t = $config->get('max_height_t');
		$conf->max_image_size = $config->get('max_image_size');
		$conf->thumbMethod = $config->get('thumbMethod', 1);
		$id = $post['bfsurvey_1result_id'];

		foreach($myFilesFields as $myFileField){
			$myField = $myFileField->field_name;

			if (isset( $files[$myField])) {
				if ( $files[$myField]['size'] > $conf->max_image_size) {
					$app->redirect("index.php", JText::_('COM_BFSURVEY_IMAGETOOBIG'));
					return;
				}
			}

			if (isset( $files[$myField]) and !$files[$myField]['error'] ) {
				//where is the full stop of the file extension?
				$pos = strrpos($files[$myField]['name'], '.', -1);
				$len = strlen($files[$myField]['name']);

				$path= JPATH_SITE."/images/com_bfsurvey";
				BFSurveyHelperBfsurvey::createImageAndThumb($files[$myField]['tmp_name'],
						$id.$myField.".jpg",
						$id.$myField."_t.jpg",
						$id.$myField."_original".substr($files[$myField]['name'],0-($len-$pos)),
						$conf->max_width,
						$conf->max_height,
						$conf->max_width_t,
						$conf->max_height_t,
						"",
						$path,
						$files[$myField]['name'],
						$conf->thumbMethod);
			}
		}
	}

	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	function createImageAndThumb($src_file,$image_name,$thumb_name,$orig_file_name,
			$max_width,
			$max_height,
			$max_width_t,
			$max_height_t,
			$tag,
			$path,
			$orig_name,
			$thumbMethod)
	{
		if (intval(ini_get('memory_limit')) < 64)
			ini_set('memory_limit', '64M');

		$src_file = urldecode($src_file);

		$orig_name = strtolower($orig_name);
		$findme  = '.jpg';
		$pos = strpos($orig_name, $findme);
		if ($pos === false)
		{
			$findme  = '.jpeg';
			$pos = strpos($orig_name, $findme);
			if ($pos === false)
			{
				$findme  = '.gif';
				$pos = strpos($orig_name, $findme);
				if ($pos === false)
				{
					$findme  = '.png';
					$pos = strpos($orig_name, $findme);
					if ($pos === false)
					{
						//not an image
						//just upload the file as is

						jimport('joomla.filesystem.file');
						JFile::upload($src_file, "$path/$orig_file_name");
						return;
					}
					else
					{
						$type = "png";
					}
				}
				else
				{
					$type = "gif";
				}
			}
			else
			{
				$type = "jpeg";
			}
		}
		else
		{
			$type = "jpeg";
		}

		if($thumbMethod == 1){
			//GD image library
			$max_h = $max_height;
			$max_w = $max_width;
			$max_thumb_h = $max_height_t;
			$max_thumb_w = $max_width_t;

			if ( file_exists( "$path/$image_name")) {
				unlink( "$path/$image_name");
			}

			if ( file_exists( "$path/$thumb_name")) {
				unlink( "$path/$thumb_name");
			}

			//original file
			if ( file_exists( "$path/$orig_file_name")) {
				unlink( "$path/$orig_file_name");
			}

			$read = 'imagecreatefrom' . $type;
			$write = 'image' . $type;

			$src_img = $read($src_file);

			// height/width
			$imginfo = getimagesize($src_file);
			$src_w = $imginfo[0];
			$src_h = $imginfo[1];

			$zoom_h = $max_h / $src_h;
			$zoom_w = $max_w / $src_w;
			$zoom   = min($zoom_h, $zoom_w);
			$dst_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
			$dst_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

			$zoom_h = $max_thumb_h / $src_h;
			$zoom_w = $max_thumb_w / $src_w;
			$zoom   = min($zoom_h, $zoom_w);
			$dst_thumb_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
			$dst_thumb_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

			$dst_img = imagecreatetruecolor($dst_w,$dst_h);
			$white = imagecolorallocate($dst_img,255,255,255);
			imagefill($dst_img,0,0,$white);
			imagecopyresampled($dst_img,$src_img, 0,0,0,0, $dst_w,$dst_h,$src_w,$src_h);
			if($type == 'jpeg'){
				$desc_img = $write($dst_img,"$path/$image_name", 75);
			}else{
				$desc_img = $write($dst_img,"$path/$image_name", 2);
			}

			imagedestroy($dst_img);

			$dst_t_img = imagecreatetruecolor($dst_thumb_w,$dst_thumb_h);
			$white = imagecolorallocate($dst_t_img,255,255,255);
			imagefill($dst_t_img,0,0,$white);
			imagecopyresampled($dst_t_img,$src_img, 0,0,0,0, $dst_thumb_w,$dst_thumb_h,$src_w,$src_h);
			if($type == 'jpeg'){
				$desc_img = $write($dst_t_img,"$path/$thumb_name", 75);
			}else{
				$desc_img = $write($dst_t_img,"$path/$thumb_name", 2);
			}

			imagedestroy($dst_t_img);

		}elseif($thumbMethod == 0){
			//Use JImage instead of GD
			jimport('joomla.image.image');
			jimport('joomla.filesystem.folder');
			jimport('joomla.filesystem.file');

			//now generate large thumbnail
			$thumbFileName = $path.'/'.$image_name;
			$creationMethod = 2;

			$sourceImage = new JImage($src_file);
			if(JFile::exists($src_file)){
				$thumb = $sourceImage->resize($max_width, $max_height, true, $creationMethod);
				$thumb->toFile($thumbFileName, $type);
			}

			//now generate small thumbnail
			$thumbFileName = $path.'/'.$thumb_name;
			$creationMethod = 2;

			$sourceImage = new JImage($src_file);
			if(JFile::exists($src_file)){
				$thumb = $sourceImage->resize($max_width_t, $max_height_t, true, $creationMethod);
				$thumb->toFile($thumbFileName, $type);
			}
		}else{
			//No thumbnails
		}

		//upload original file
		jimport('joomla.filesystem.file');
		JFile::upload($src_file, "$path/$orig_file_name");
	}


	/**************************************************************************/
	/* The next few functions are borrowed from Akeeba Release System */
	/* 	/frontend/helpers/filter.php  */

	/**
	 * Gets the user associated with a specific Download ID
	 *
	 * @param   string  $dlid  The Download ID to check
	 *
	 * @return  array  The user record of the corresponding user and the Download ID
	 *
	 * @throws Exception An exception is thrown if the Download ID is invalid or empty
	 */
	static public function getUserFromDownloadID($dlid)
	{
		// Reformat the Download ID
		$dlid = self::reformatDownloadID($dlid);

		if ($dlid === false)
		{
			throw new Exception('Invalid Download ID', 403);
		}

		// Do we have a userid:downloadid format?
		$user_id = null;
		if (strstr($dlid, ':') !== false)
		{
			$parts = explode(':', $dlid, 2);
			$user_id = (int)$parts[0];
			$dlid = $parts[1];
		}

		if (is_null($user_id))
		{
			$db = JFactory::getDbo();
			$query = $db->getQuery(true)
			->select(array(
					$db->qn('id')
			))
			->from($db->qn('#__users'))
			->where('md5(concat('.$db->qn('id').','.$db->qn('username').','.$db->qn('password').')) = '.$db->q($dlid));
			$db->setQuery($query);
			$user_id = $db->loadResult();
		}
		else
		{
			$db = JFactory::getDbo();
			$query = $db->getQuery(true)
			->select(array(
					'label'
			))->from($db->qn('#__ars_dlidlabels'))
			->where($db->qn('user_id').' = '.$db->q($user_id))
			->where($db->qn('enabled').' = '.$db->q(1));
			$db->setQuery($query);
			$labels = $db->loadColumn();

			if (empty($labels))
			{
				throw new Exception('Invalid Download ID', 403);
			}

			$query = $db->getQuery(true)
			->select(array(
					'md5(concat('.$db->qn('id').','.$db->qn('username').','.$db->qn('password').')) AS '.$db->qn('dlid')
			))
			->from($db->qn('#__users'))
			->where($db->qn('id').' = '.$db->q($user_id));
			$db->setQuery($query);
			$masterDlid = $db->loadResult();

			$found = false;
			foreach($labels as $k => $label)
			{
				$check = md5($user_id . $label . $masterDlid);
				if ($check == $dlid)
				{
					$found = true;
					break;
				}
			}

			if (!$found)
			{
				throw new Exception('Invalid Download ID', 403);
			}
		}

		return JFactory::getUser($user_id);
	}

	static public function myDownloadID()
	{
		$user = JFactory::getUser();

		if ($user->guest)
		{
			return '';
		}

		return md5($user->id . $user->username . $user->password);
	}

	static public function reformatDownloadID($dlid)
	{
		// Check if the Download ID is empty or consists of only whitespace
		if (empty($dlid))
		{
			return false;
		}

		$dlid = trim($dlid);

		if (empty($dlid))
		{
			return false;
		}

		// Is the Download ID too short?
		if (strlen($dlid) < 32)
		{
			return false;
		}

		// Trim the Download ID
		if (strlen($dlid) > 32)
		{
			if(strlen($dlid) > 32) $dlid = substr($dlid,0,32);
		}

		return $dlid;
	}

	/**
	 * Find out how many categories there are
	 */
	public static function getNumberCategoires()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('count(bfsurvey_category_id)');
		$query->from('#__bfsurvey_categories');

		$db->setQuery((string)$query);
		$numCategories=$db->loadResult();

		return $numCategories;
	}
}