<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2016 Tim Plummer
 *  @license GNU General Public License version 3, or later
 */

defined('_JEXEC') or die();

class BfauctionControllerEmailitems extends F0FController
{
	public function edit()
	{
		$this->layout = 'form';
		parent::edit();
	}

}