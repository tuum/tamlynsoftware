<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

//note this class name intentionally does not inlcude underscore before plus
class BfauctionModelCategories extends F0FModel
{
	public function __construct($config = array()) {
		// fix the component name so it includes underscore before plus
		$config['option'] = 'com_bfauction';

		parent::__construct($config);

		$this->table = 'categories';
	}

	public function buildQuery($overrideLimits = false)
	{
		$user   = JFactory::getUser();

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_categories');
		//$query->where('created_by='.$user->id);

		return $query;
	}

	public function isValidUser($itemId)
	{
		if(is_array($itemId))
		{
			$itemId = $itemId[0];
		}

		$user   = JFactory::getUser();

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_categories');
		$query->where('created_by='.$user->id);
		$query->where('bfauction_category_id='.$itemId);
		$db->setQuery($query);
		$db->query();

		return $db->loadResult();
	}

}