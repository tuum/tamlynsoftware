<?php
/**
 * Bid history view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
	defined('_JEXEC') or die();

	$params = JFactory::getApplication()->getParams();

    $cid = JRequest::getVar('id');
	$user = JFactory::getUser();

	$bfcurrency = $params->get('bfcurrency','$');
	$dateFormat = $params->get( 'dateFormat' );
	$currencySymbolAfter= $params->get('currencySymbolAfter', 0);
?>
<?php echo "<a href='".JRoute::_('index.php?option=com_bfauction&view=auction&id='.(int)$cid)."'>".JText::_( 'COM_BFAUCTION_BUTTON_BACK_TO_ITEM')."</a>"; ?>
<div class="row-fluid">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_HISTORY' ); ?></legend>

	<div class="span10 form-horizontal">
	<div class="control-group">
		<div class="bfauction_ReportHeader">
			<div class="bidhistories_item">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_USERNAME' ); ?>
			</div>
			<div class="bidhistories_item">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID' ); ?>
			</div>
			<div class="bidhistories_item">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_DATE' ); ?>
			</div>
		</div>
	</div>

		<?php
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row = $this->items[$i];
			?>
			<div class="control-group bfauction_ReportBody">
			<div class="bidhistories_item <?php echo $i % 2 == 0 ? 'bidhistories_even' : '' ?>">
			   <?php
				if($row->username == $user->username){
					echo $row->username;
				}else{
					echo substr($row->username, 0, 1);
					echo "******";
					echo substr($row->username, -1);
				}
			   ?>
			</div>
			<div class="bidhistories_item <?php echo $i % 2 == 0 ? 'bidhistories_even' : '' ?>">
			   <?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo number_format($row->bid,2); ?>
			   &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</div>
			<div class="bidhistories_item <?php echo $i % 2 == 0 ? 'bidhistories_even' : '' ?>">
			    <?php echo JHTML::_('date',  $row->bid_time, $dateFormat ); ?>
			</div>
			</div>
		<?php
		} //end for$row
		?>

	</div>


	</fieldset>
</div>
<div class="clr"></div>
