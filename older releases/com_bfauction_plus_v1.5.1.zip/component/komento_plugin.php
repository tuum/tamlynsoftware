<?php
/**
 * $Id: komento_plugin.php 84 2013-11-28 02:01:32Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

require_once( JPATH_ROOT . '/components/com_komento/komento_plugins/abstract.php' );

class KomentoComBfauctionplus extends KomentoExtension
{
    public $_item;

    public $_map = array(
		'id' => 'id',
		'title' => 'title',
		'catid' => 'catid',
		'permalink' => 'permalink_field',
		'hits' => 'hits_field',
		'created_by' => 'created_by_field'
    );

    public function __construct( $component )
    {
    	parent::__construct( $component );
    }

    public function load( $cid )
    {
    	static $instances = array();

		if( !isset( $instances[$cid] ) )
		{
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('a.id AS id, a.title AS title, a.catid AS catid');
			$query->select('0 AS hits_field');
			$query->select('0 AS created_by_field');
			$query->from($db->quoteName('#__bfauction_plus').' AS a');
			$query->where('a.id = '.(int)$cid);

			$db->setQuery((string)$query);
			$this->_item = $db->loadObject();

			$this->_item->permalink_field = "index.php?option=com_bfauction_plus&view=bid&id=".(int)$this->_item->id;

			$instances[$cid] = $this->_item;
		}

    	$this->_item = $instances[$cid];

    	return $this;
    }

    public function getContentIds( $categories = '' )
    {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('a.id, a.title');
		$query->from($db->quoteName('#__bfauction_plus').' AS a');
		$query->join('LEFT', '#__categories AS c ON c.id = a.catid');
		$query->order('a.id');

		if( !empty( $categories ) )
		{
			if( is_array( $categories ) )
			{
				$categories = implode( ',', $categories );
			}

			// with category filters
			$query->where('a.catid IN '.$categories);
    	}

		$db->setQuery((string)$query);

    	return $db->loadResultArray();
    }

    public function getCategories()
    {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('c.id, c.title');
		$query->from($db->quoteName('#__categories').' AS c');
		$query->where('extension="com_bfauction_plus"');

		$db->setQuery((string)$query);
		$categories = $db->loadObjectList();

    	return $categories;
    }

    public function isListingView()
    {
    	return JRequest::getCmd('view') == 'bfauction_plus';
    }

    public function isEntryView()
    {
    	return JRequest::getCmd('view') == 'bid';
    }

    public function onExecute( &$article, $html, $view, $options = array() )
    {
		$model	= Komento::getModel( 'comments' );
		$count	= $model->getCount( $this->component, $this->getContentId() );
		$article->numOfComments = $count;

		return $html;
    }

	public function getComponentIcon()
	{
		return './components/com_komento/assets/images/cpanel/integrations.png';
	}

	public function getComponentName()
	{
		return 'Bfauction_plus';
	}

    public function onBeforeLoad($eventTrigger, $context, &$article, &$params, &$page, &$options)
    {
    	if($context=="text")
    	{
    		return false;
    	}
    	else
    	{
    		return true;
    	}
    }
}