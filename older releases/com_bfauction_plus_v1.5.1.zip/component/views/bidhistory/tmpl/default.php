<?php
/**
 * $Id: default.php 84 2013-11-28 02:01:32Z tuum $
 * Bid history view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

    $cid = JRequest::getVar('cid');
	$user = JFactory::getUser();

	$bfcurrency = $this->params->get('bfcurrency');
	if($bfcurrency == ""){
		$bfcurrency = "$";
	}

	$dateFormat = $this->params->get( 'dateFormat' );
?>
<?php echo "<a href='".JRoute::_('index.php?option=com_bfauction_plus&task=bid&cid='.(int)$cid)."'>".JText::_( 'COM_BFAUCTIONPLUS_BUTTON_BACK_TO_ITEM')."</a>"; ?>
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_HISTORY' ); ?></legend>

	<table class="adminlist">
	<thead>
		<tr class="bfauction_plusReportHeader">
		<th width="200">
			<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_USERNAME' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID' ); ?>:
		</th>

		<th width="150">
			<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_DATE' ); ?>:
		</th>
		</tr>
		</thead>

		<?php
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row = $this->items[$i];
			?>
			<tr class="bfauction_plusReportBody">
			<td align="center">
			   <?php
				if($row->username == $user->username){
					echo $row->username;
				}else{
					echo substr($row->username, 0, 1);
					echo "******";
					echo substr($row->username, -1);
				}
			   ?>
			</td>
			<td align="right">
			   <?php echo $bfcurrency; ?><?php echo $row->bid; ?>
			</td>
			<td align="center">
			    <strong><?php echo JHTML::_('date',  $row->bid_time, $dateFormat ); ?></strong>
			</td>
			</tr>
		<?php
		} //end for$row
		?>

	</table>


	</fieldset>
</div>
<div class="col width-35">
	&nbsp;
</div>
<div class="clr"></div>
