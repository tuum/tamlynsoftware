<?php
/**
 * $Id: bfauction_plusfeatured.php 85 2013-11-28 02:52:10Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */


// no direct access
defined('_JEXEC') or die;

/**
 * @package		Joomla.Administrator
 * @subpackage	com_content
 */
abstract class JHtmlBfauction_plusFeatured
{
	/**
	 * @param	int $value	The state value
	 * @param	int $i
	 */
	static function featured($value = 0, $i, $canChange = true)
	{
		$version = new JVersion();
		if (version_compare($version->RELEASE, '3.1.6', 'ge')) {
			JHtml::_('bootstrap.tooltip');

			// Array of image, task, title, action
			$states	= array(
					0	=> array('unfeatured',	'items.featured',	'COM_BFAUCTION_PLUS_UNFEATURED',	'COM_BFAUCTION_PLUS_TOGGLE_TO_FEATURE'),
					1	=> array('featured',		'items.unfeatured',	'COM_BFAUCTION_PLUS_FEATURED',		'COM_BFAUCTION_PLUS_TOGGLE_TO_UNFEATURE'),
			);
			$state	= JArrayHelper::getValue($states, (int) $value, $states[1]);

			$icon	= $state[0];

			if ($canChange)
			{
				$html	= '<a href="#" onclick="return listItemTask(\'cb' . $i . '\',\'' . $state[1] . '\')" class="btn btn-micro hasTooltip' . ($value == 1 ? ' active' : '') . '" title="' . JHtml::tooltipText($state[3]) . '"><i class="icon-'
						. $icon . '"></i></a>';
			}
			else
			{
				$html	= '<a class="btn btn-micro hasTooltip disabled' . ($value == 1 ? ' active' : '') . '" title="' . JHtml::tooltipText($state[2]) . '"><i class="icon-'
						. $icon . '"></i></a>';
			}

		}
		else
		{
			// Array of image, task, title, action
			$states	= array(
					0	=> array('disabled.png',	'items.featured',	'COM_BFAUCTION_PLUS_UNFEATURED',	'COM_BFAUCTION_PLUS_TOGGLE_TO_FEATURE'),
					1	=> array('featured.png',		'items.unfeatured',	'COM_BFAUCTION_PLUS_FEATURED',		'COM_BFAUCTION_PLUS_TOGGLE_TO_UNFEATURE'),
			);
			$state	= JArrayHelper::getValue($states, (int) $value, $states[1]);
			$html	= JHtml::_('image', 'admin/'.$state[0], JText::_($state[2]), NULL, true);
			//if ($canChange) {
			//	$html	= '<a href="#" onclick="return listItemTask(\'cb'.$i.'\',\''.$state[1].'\')" title="'.JText::_($state[3]).'">'
				//			. $html.'</a>';
				//}

		}

		return $html;
	}
}
