<?php
/**
 * $Id: edit.php 58 2014-03-08 08:42:59Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey_plus&view=results'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<!-- Begin Emailitem -->
	<div class="span10 form-horizontal">
		<table class="table table-striped" id="resultList">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
<div id="editcell">
    <table class="adminlist">
    <tr>
    	<td>
    	<?php
    	   $row =& $this->item;
    	   echo $row->Name.'<br>';
    	   echo $row->Email.'<br>';
    	?>
    	</td>
    </tr>
    </table>
    <table class="adminlist">
<?php } ?>
    <thead>
        <tr>
            <th width="50%">
                <?php echo JText::_( 'COM_BFSURVEYPLUS_TITLE_QUESTION' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEYPLUS_TITLE_ANSWER' ); ?>
            </th>
        </tr>
    </thead>
    <?php


    $k = 0;
    for ($i=0, $n=count( $this->items2 ); $i < $n; $i++)
    {
        $row = $this->item;
        $row2 = $this->items2[$i];

        if(isset($row2->question)){

        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
			    <?php echo $row2->question; ?>

			    <?php
			    // this bit is for rating question
	       		if($row2->question_type == "9"){ //rating
				   echo "<br>";
				   for ($z=0; $z < 20; $z++){
				      $tempoption="option".($z+1);
				      if($row2->$tempoption != ""){
				         echo "<br>".$row2->$tempoption;
				      }
				   }
				}

	       		?>

            </td>
			<td>
			    <?php
			    if(!isset($row2->field_name)){
			       $row2->field_name = "";
			    }

				if(!isset($row2->question_type)){
				   $row2->question_type = "";
				}

			    if($row2->question_type == "9"){ //rating
			       // do nothing...code if further down
			    }else{
			       $tempvalue = $row2->field_name;
			    }
			    if(!isset($tempvalue)){
			       $tempvalue = "";
			    }

			    if($row2->question_type == "2"){ //checkbox
			       // put comma between answers
			       $row->$tempvalue = preg_replace("/\n/", ", ", $row->$tempvalue);
			       if(strlen($row->$tempvalue) > 3){
			          $row->$tempvalue = substr($row->$tempvalue, 0, strlen($row->$tempvalue)-2);
			       }
			    }
			    ?>

			    <?php
			    if($row2->question_type == "9"){ //rating
			       echo "<br>";

			       for ($z=0; $z < 20; $z++){
				      $tempoption="option".($z+1);

	 	       	      if($row2->$tempoption != ""){
			          	 $field=$row2->field_name;
			          	 $tempvalue=$field.($z+1);

			          	 if(!isset($tempvalue)){
				      	    $tempvalue = "";
			    	  	 }

			    	  	 if(!isset($row->$tempvalue)){
			    	  	    echo "<br>";
			    	  	 }else{
			    	  	    echo "<br>".$row->$tempvalue;
			    	  	 }
			          }
			       }

			    }else{
			       if(isset($row->$tempvalue)){
			          echo $row->$tempvalue;
			       }
			    }
			    ?>

			</td>
        </tr>
        <?php
        }

        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<?php
$session = JFactory::getSession();
$catid = $session->get('catid');
?>

<input type="hidden" name="option" value="com_bfsurvey_plus" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="results" />
<input type="hidden" name="cid" value="<?php echo (int)$catid; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>