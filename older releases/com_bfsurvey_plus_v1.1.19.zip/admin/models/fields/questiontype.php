<?php
/**
 * $Id: questiontype.php 58 2014-03-08 08:42:59Z tuum $
 * Question_Type feild for bfsurvey_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class for the BF Survey Plus component
 */
class JFormFieldquestiontype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'questiontype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

        		$options[] = JHtml::_('select.option',  '0', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXT' ) );
				$options[] = JHtml::_('select.option',  '1', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RADIO' ) );
				$options[] = JHtml::_('select.option',  '2', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_CHECKBOX' ) );
				$options[] = JHtml::_('select.option',  '3', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXTAREA' ) );
				//$options[] = JHtml::_('select.option',  '4', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_ATTACHMENT' ) );
				$options[] = JHtml::_('select.option',  '5', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DATE' ) );
				$options[] = JHtml::_('select.option',  '6', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DROPDOWN' ) );
				//$options[] = JHtml::_('select.option',  '7', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_LIST' ) );
				$options[] = JHtml::_('select.option',  '8', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_SUMMATION' ) );
				$options[] = JHtml::_('select.option',  '9', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RATING' ) );
        		$options[] = JHtml::_('select.option',  '10', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_HEADING' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
