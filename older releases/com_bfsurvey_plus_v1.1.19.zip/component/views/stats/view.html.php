<?php
/**
 * $Id: view.html.php 58 2014-03-08 08:42:59Z tuum $
 * BFSurvey Stats View for BFSurvey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * BFSurvey Plus Stats View
 *
 * @package    Joomla
 * @subpackage Components
 */
class BFSurveyPlusViewStats extends JViewLegacy
{
	function display($tpl = null)
    {
		$catid	= JRequest::getVar( 'cid', 0, '', 'int' );
		$this->items		= $this->get('Item');

    	// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		if(!$this->items){
	      JError::raiseWarning( 500, JText::_('COM_BFSURVEYPLUS_ERROR_NO_QUESTIONS_FOR_CATEGORY') );
	    }

        $this->assignRef( 'catid', $catid );

        require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfsurvey_plus.php';

        parent::display($tpl);
    }
}