<?php
defined('_JEXEC') or die();

jimport('joomla.form.formfield');

class JFormFieldGateways extends JFormField
{
	function getInput()
	{
		$db = JFactory::getDBO();

		$query = "SELECT extension_id as id, name, element, enabled as published FROM #__extensions WHERE folder = 'payment' AND enabled = 1";

		$db->setQuery($query);
		$plugins = $db->loadobjectList();

		$options = array();

		foreach ($plugins as $gateway) {
			$gateway_name = ucfirst(str_replace('plugpayment', '', $gateway->element));
			$options[] = JHtml::_('select.option', $gateway->element, $gateway_name);
		}

		$control_name = $this->options['control'];

		return JHtml::_('select.genericlist', $options, $this->name, 'class="inputbox" multiple="multiple" size="5" ', 'value', 'text', $this->value, $control_name . $this->name);
	}

}

