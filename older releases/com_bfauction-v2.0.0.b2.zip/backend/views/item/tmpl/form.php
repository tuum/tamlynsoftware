<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2015 Tim Plummer
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$app = JFactory::getApplication();

$params = bfauctionHelper::getOptions($this->input->get('id'));

$includeCommission = $params->includeCommission;
$includeTax = $params->includeTax;

F0FTemplateUtils::addCSS('media://com_bfauction/css/backend.css');
F0FTemplateUtils::addJS('media://com_bfauction/js/calculate.js');

$version = new JVersion();
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfauction&layout=item&id='.(int) $this->item->bfauction_item_id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
	<input type="hidden" name="bfauction_item_id" value="<?php echo $this->item->bfauction_item_id ?>" />
	<input type="hidden" name="option" value="com_bfauction" />
	<input type="hidden" name="view" value="item" />

	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFAUCTION_TITLE_DETAILS') : JText::sprintf('COM_BFAUCTION_EDIT_ITEM', $this->item->id); ?></a></li>
			<li><a href="#images" data-toggle="tab"><?php echo JText::_('COM_BFAUCTION_SLIDER_IMAGES');?></a></li>
			<li><a href="#options" data-toggle="tab"><?php echo JText::_('COM_BFAUCTION_SLIDER_OPTIONS');?></a></li>
		</ul>
		<div class="tab-content">

			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bfauction_category_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bfauction_category_id'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>
				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('endDate'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('endDate'); ?></div>
				</div>
				<?php } ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('quantity'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('quantity'); ?></div>
				</div>
				<?php if($app->isAdmin()){ ?>
					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('featured'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('featured'); ?></div>
					</div>
					<?php } ?>
				<?php } ?>
				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
				<?php } ?>
				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('description'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('description'); ?>
				<?php } ?>
			</div>



			<div class="tab-pane" id="options">



				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('productId'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('productId'); ?></div>
				</div>


				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('buyNowPrice'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('buyNowPrice'); ?></div>
				</div>




				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('endDate'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('endDate'); ?></div>
				</div>
				<?php } ?>

				<?php if ($this->form->getValue('currentBid') < 1): ?>
					<?php $this->form->setFieldAttribute('currentBid','readonly','false');?>
				<?php endif; ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('currentBid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('currentBid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('reservePrice'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('reservePrice'); ?></div>
				</div>
				<?php if($app->isAdmin()){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bidIncrement'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bidIncrement'); ?></div>
				</div>
				<?php } ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('highBidder'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('highBidder'); ?><?php echo $this->form->getInput('quantityPurchased'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('itemLocation'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('itemLocation'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('deliveryMethod'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('deliveryMethod'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('shipping'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('shipping'); ?></div>
				</div>

				<?php if($includeCommission){ ?>
					<?php if($app->isAdmin()){ ?>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('commissionAmount'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('commissionAmount'); ?></div>
					</div>
					<?php } ?>
				<?php } ?>

			<?php if($includeTax){ ?>
				<?php if($app->isAdmin()){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('taxAmount'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('taxAmount'); ?></div>
				</div>
				<?php } ?>
			<?php } ?>

			<?php if($includeCommission){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('commission'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('commission'); ?></div>
				</div>
			<?php }else{ ?>
				<input id="jform_commission" type="hidden" readonly="readonly" value="0.00" name="jform[commission]">
			<?php } ?>

			<?php if($includeTax){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('tax'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('tax'); ?></div>
				</div>
			<?php }else{ ?>
				<input id="jform_tax" type="hidden" readonly="readonly" value="0.00" name="jform[tax]">
			<?php } ?>


			<?php if($includeTax){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('taxableItem'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('taxableItem'); ?></div>
				</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('totalPrice'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('totalPrice'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('priceEstimate'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('priceEstimate'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('itemCondition'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('itemCondition'); ?></div>
			</div>

			<?php if($app->isAdmin()){ ?>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('buyersPremium'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('buyersPremium'); ?></div>
			</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('supplier'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('supplier'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('costPrice'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('costPrice'); ?></div>
			</div>


		</div>
		<div class="tab-pane" id="images">

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('imageShared'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('imageShared'); ?></div>
				</div>

				<?php for($i=1; $i < 21; $i++){ ?>
					<?php if( floatval($version->RELEASE) >= 3 ) { ?>
					<div class="control-group">
						<div class="control-label">
							<?php echo JText::_( 'COM_BFAUCTION_TITLE_IMAGE' ); ?>&nbsp;<?php echo $i; ?></div>
						<div class="controls">
					<?php } // end 3 ?>

					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					<li>
						<label class="hasTip" name="image<?php echo $i; ?>">
						   <?php echo JText::_( 'COM_BFAUCTION_TITLE_IMAGE' ); ?><?php echo $i; ?> :
						</label>
					<div class="fltlft">
					<?php } // end 2.5 ?>

						<input type="file" name="img<?php echo $i; ?>"/>
							<?php
								$a_pic = JPATH_SITE."/images/com_bfauction/".$this->item->bfauction_item_id."img".$i.".jpg";
								if (file_exists($a_pic))
								{
									if($app->isAdmin()){
										echo '<img src="../images/com_bfauction/'.$this->item->bfauction_item_id.'img'.$i.'_t.jpg?time='.time().'"/>';
									}else{
										echo '<img src="./images/com_bfauction/'.$this->item->bfauction_item_id.'img'.$i.'_t.jpg?time='.time().'"/>';
									}
									echo "<input type='checkbox' name='d_img".$i."' value='delete'>".JText::_('COM_BFAUCTION_IMAGE_DELETE');
								}else if($this->item->imageShared > 0){
									$a_pic = JPATH_SITE."/images/com_bfauction/".$this->item->imageShared."img".$i.".jpg";
									if (file_exists($a_pic))
									{
										if($app->isAdmin()){
											echo '<img src="../images/com_bfauction/'.$this->item->imageShared.'img'.$i.'_t.jpg?time='.time().'"/>';
										}else{
											echo '<img src="./images/com_bfauction/'.$this->item->imageShared.'img'.$i.'_t.jpg?time='.time().'"/>';
										}
									}
									echo "<input type='hidden' name='d_img".$i."' value=''>";
								}else{
									echo "<input type='hidden' name='d_img".$i."' value=''>";
								}
							?>
					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					</div>
					</li>
					<?php } ?>

					<?php if( floatval($version->RELEASE) >= 3 ) { ?>
						</div>
					</div>
					<?php } ?>
				<?php }	?>

		</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('enabled'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('enabled'); ?>
				</div>
			</div>
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('featured'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('featured'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
</form>

<script language="javascript" type="text/javascript">
<!--
calculateTotalPrice();
//-->
</script>