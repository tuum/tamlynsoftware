<?php
defined('_JEXEC') or die();

class BfauctionViewLogs extends F0FViewHtml
{
	protected function onBrowse($tpl = null)
	{
		$model = $this->getModel();

		return true;
	}
}