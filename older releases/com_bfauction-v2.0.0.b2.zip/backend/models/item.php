<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2015 Tim Plummer
 *  @license GNU General Public License version 3, or later
 */

defined('_JEXEC') or die();

class BfauctionModelItem extends F0FModel
{

}