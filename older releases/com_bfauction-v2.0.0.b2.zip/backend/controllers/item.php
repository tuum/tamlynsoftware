<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2015 Tim Plummer
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

defined('_JEXEC') or die();

class BfauctionControllerItem extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'item';
	}
}