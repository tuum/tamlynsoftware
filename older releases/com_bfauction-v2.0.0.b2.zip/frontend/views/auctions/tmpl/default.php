<?php

$app = JFactory::getApplication();
$input = $app->input;

$session = JFactory::getSession();

if ($session->get('disclaimer')) {
	echo $this->getRenderedForm();
	return;
}

$menu = $app->getMenu()->getActive();
$params = $menu->params;

if ($params->get('showDisclaimer') < 1) {
	if (method_exists($this, 'getRenderedForm')) {
		echo $this->getRenderedForm();
		BfauctionDispatcher::checkIfAuctionHasEnded();
	}
	return;
}

$session->set('disclaimer', true);

$this->disclaimerText = $params->get('disclaimerText');
$this->setLayout('disclaimer', 'html');
$this->display();
