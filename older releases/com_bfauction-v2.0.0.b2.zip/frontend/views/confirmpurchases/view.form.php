<?php
defined('_JEXEC') or die();

class BfauctionViewConfirmpurchases extends F0FViewForm
{
	public function display($tpl = null)
	{
		$id = $this->input->get('id');
		$this->cparams  = bfauctionHelper::getOptions($id);

		$model = $this->getModel();
		$this->lastbid	= $model->getLastBidData();

		$user = JFactory::getUser();
		$this->profile	= $model->getUserProfile($user->id);

		parent::display($tpl);
	}
}