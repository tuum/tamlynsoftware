<?php defined('_JEXEC') or die('Restricted access');
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
* Calendar Pop-up
*
* @author Tim Plummer
*
* Datebox is a multi-mode date and time picker for JQueryMobile
*
* @license http://creativecommons.org/publicdomain/zero/1.0/
* @link https://github.com/jtsage/jquery-mobile-datebox
* @version 1.5.0
* */

jimport('joomla.form.formfield');

// Load jQuery and Bootstrap
JHtml::_('behavior.framework', true);

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.mobile-1.4.5.min.css');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/jquery.mobile-1.4.5.js');
F0FTemplateUtils::addCSS('media://com_bfsurvey/css/jqm-datebox.css');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/jqm-datebox.core.js');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/jqm-datebox.mode.datebox.js');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/jqm-datebox.lang.utf8.js');

class JFormFieldDatebox extends JFormField {

	/**
	 * field type
	 * @var string
	 */
	protected $type = 'Datebox';

	/**
	 * Method to get the field input markup
	 */
	protected function getInput() {

		$js = 'jQuery.extend(jQuery.mobile,
		{
			ajaxEnabled: false
		});';

		JFactory::getDocument()->addScriptDeclaration($js);

		// The input field
		// class='required' for client side validation
		$class = '';

		if ($this->required) {

			$class = ' class="required"';
		}

		$html = array();
		$html[] = '<input ' . $class . ' type="text" name="' . $this->name . '" id="' . $this->id . '" data-role="datebox" data-datebox-mode="datebox" placeholder="' . $this->hint . '" value="' . $this->value . '" />';

		return implode("\n", $html);
	}

}