<?php
/**
 * $Id: default.php 91 2014-06-07 23:29:18Z tuum $
 * Bid view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

?>
<?php
// For popup help
JHtml::_('behavior.tooltip');
JHtml::_('behavior.modal');

//JHTML::script('lytebox.js', 'components/com_bfauction_plus/lib/lytebox/');
JHtml::script('../../components/com_bfauction_plus/lib/lytebox/lytebox.js', false, true);

$document = JFactory::getDocument();
$cssFile = './components/com_bfauction_plus/lib/lytebox/lytebox.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$app		= JFactory::getApplication();
$menus		= $app->getMenu();
$menu = $menus->getActive();

$user = JFactory::getUser();

$bfcurrency = $this->params->get('bfcurrency');
if($bfcurrency == ""){
	$bfcurrency = "$";
}

$bfcurrency_code = $this->params->get('bfcurrency_code');
$bidIncrement = $this->params->get('bidIncrement');
$hideBid = $this->params->get('hideBid');
$reverseAuction = $this->params->get('reverseAuction');
if($reverseAuction == NULL){
	$reverseAuction = 0;
}

$includeCommission = $this->params->get('includeCommission');
$commissionAmount = $this->params->get('commissionAmount');
if($this->bfauction_plus->commissionAmount){
	$commissionAmount = $this->bfauction_plus->commissionAmount;
}
$includeTax = $this->params->get('includeTax');
$taxableItem = $this->bfauction_plus->taxableItem;
$taxAmount = $this->params->get('taxAmount');
if($this->bfauction_plus->taxAmount){
	$taxAmount = $this->bfauction_plus->taxAmount;
}
$showTotalPrice = $this->params->get('showTotalPrice');

if($this->bfauction_plus->bidIncrement > 0){
	$bidIncrement = $this->bfauction_plus->bidIncrement;
}

$mainImageSize = $this->params->get('mainImageSize');
if($mainImageSize < 1){
	$mainImageSize = 200;
}

$dateFormat = $this->params->get( 'dateFormat' );
$allowWatchlist = $this->params->get( 'allowWatchlist' );
$showDeliveryOptions = $this->params->get('showDeliveryOptions');
$currencySymbolAfter= $this->params->get('currencySymbolAfter', 0);

$dst_fix = $this->params->get( 'dst' );
if($dst_fix == NULL){
	$dst_fix = 0;
}

// is dst on on that particular date ?
$now = JFactory::getDate();
//forwards compatibility for Joomla 3.0
//$date=$now->toFormat();
$date=$now->format('Y-m-d H:i:s');
if (is_numeric( $date)) {
	$ts = $date;
} else {
	$ts = strtotime( $date . ' UTC');
}
$dst = date( 'I', $ts);

$app = JFactory::getApplication();
$now = JFactory::getDate();
//if($dst_fix){
//	$now->setOffset($app->getCfg('offset')+$dst);
//}else{
//	$now->setOffset($app->getCfg('offset'));
//}
//forwards compatibility for Joomla 3.0
//$currentDate=$now->toFormat();
$currentDate=$now->format('Y-m-d H:i:s');
$endDate = $this->bfauction_plus->endDate;

$secondsDiff = 0;
if($currentDate > $endDate){
   JError::raiseWarning( 403, JText::_( 'COM_BFAUCTIONPLUS_AUCTION_HAS_ENDED') );
   	if($this->bfauction_plus->currentBid < $this->bfauction_plus->reservePrice ){
		JError::raiseWarning( 403, JText::_( 'COM_BFAUCTIONPLUS_TITLE_RESERVE_PRICE_NOT_MET') );
	}
}else{
	$endDateAsSeconds = strtotime($endDate);
	$currentDateAsSeconds = strtotime($currentDate);

	$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
}

if($user->id == 0){
	JError::raiseWarning( 403, JText::_( 'COM_BFAUCTIONPLUS_YOU_MUST_LOG_IN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction_plus&task=bid&cid=".$this->bfauction_plus->id."&Itemid=".(int)$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFAUCTIONPLUS_AUCTION_LOG_IN')."</a><br>";
}

//for countdown timer
$timerText="";

$remainingDay     = floor($secondsDiff/60/60/24);
$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

$grid = JRequest::getVar( 'grid' );
if((int)$grid){
	echo "<br><a href='".JRoute::_('index.php?option=com_bfauction_plus&view=grid&task=listItems&limitstart=0')."'>".JText::_( 'COM_BFAUCTIONPLUS_AUCTION_BACK_TO_LIST')."</a><br>";
}else{
	echo "<br><a href='".JRoute::_('index.php?option=com_bfauction_plus&task=listItems&limitstart=0')."'>".JText::_( 'COM_BFAUCTIONPLUS_AUCTION_BACK_TO_LIST')."</a><br>";
}

//AJAX code moved to /components/com_bfauction_plus/assets/ajax.php
//executes the luCurrentBid page from the server (located in /controllers/bid.php)
require_once( JPATH_COMPONENT.'/assets/ajax.php' );

//if auction has ended and you are the winning bidder, show PayPal Buy now button
$winner = 0;
if( ($currentDate >= $endDate) && ($this->bfauction_plus->highBidder == $user->username) ){
	$winner = 1;
}

$quantityPurchased = $this->bfauction_plus->quantityPurchased;
if($quantityPurchased < 1){
	$quantityPurchased = 1;
}
?>

<script language="Javascript">
<!--
  // get variable from php
  var days = <?php echo $remainingDay; ?>;
  var hours = <?php echo $remainingHour; ?>;
  var minutes = <?php echo $remainingMinutes; ?>;
  var seconds = <?php echo $remainingSeconds; ?>;

function setCountDown ()
{
  seconds--;
  if (seconds < 0){
      minutes--;
      seconds = 59
  }
  if (minutes < 0){
      hours--;
      minutes = 59
  }
  if (hours < 0){
      days--;
      hours = 23
  }
  //document.getElementById("txt").innerHTML = hours+" hours, "+minutes+" minutes, "+seconds+" seconds";
  if(seconds < 10){
	  seconds = "0"+seconds;
  }
  document.getElementById("txt").value = days+"d "+hours+"h "+minutes+":"+seconds;

  if(days == 0 && hours == 0 && minutes == 0 && seconds < 1){ // no time left
	  window.location.reload();
  }

  if(days < 0){
     clearInterval(ct);
     document.getElementById("txt").value = "0:00";
  }

}

 var ct = setInterval("setCountDown()",1000); // Start clock.

//-->
</script>

<?php
if($remainingSeconds < 10){
	$remainingSecs = "0".$remainingSeconds;
}else{
    $remainingSecs = $remainingSeconds;
}

$timerinit="".$remainingMinutes.":".$remainingSecs;
?>

<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ITEM_DETAILS' ); ?></legend>

		<table width="100%">
		<tr>
		<td>

		<div class="bfauction_plusIntrotext"><?php echo JText::_( 'COM_BFAUCTIONPLUS_BID_ABOUT_TO_BID' ); ?></div>

		<span id="divCommission" style="visibility:hidden" /></span>
		<span id="divTax" style="visibility:hidden" /></span>
		<span id="divTotalPrice" style="visibility:hidden" /></span>

		<table class="admintable">
		<tr>
			<td class="bfauction_plusLabel">
				<label for="title">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TITLE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			   <div class="bfauction_plusItemTitle"><?php echo $this->bfauction_plus->title; ?></div>
			</td>
		</tr>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="itemid">
					<?php if($this->bfauction_plus->productId){ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_PLUSDUCTID' ); ?>:
					<?php }else{ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ITEM_ID' ); ?>:
					<?php } ?>
				</label>
			</td>
			<td class="bfauction_plusDetails">
				<?php if($this->bfauction_plus->productId){ ?>
					<?php echo $this->bfauction_plus->productId; ?>
				<?php }else{ ?>
			   		<?php echo $this->bfauction_plus->id; ?>
			   	<?php } ?>
			</td>
		</tr>

		<?php if($this->bfauction_plus->supplier != ""){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="supplier">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_SUPPLIER' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <?php echo $this->bfauction_plus->supplier;?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->quantity > 1){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="quantity">
					<?php if($winner){ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_QTY_PURCHASED' ); ?>:
					<?php }else{ ?>
						<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_QUANTITY' ); ?>:
					<?php } ?>
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <?php echo $this->bfauction_plus->quantity;?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->priceEstimate != ""){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="priceEstimate">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_PRICE_ESTIMATE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsSpecs">
			    <?php echo $this->bfauction_plus->priceEstimate;?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->qtyAvailable != ""){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="qtyAvailable">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_QTY_AVAILABLE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsSpecs">
			    <?php echo $this->bfauction_plus->qtyAvailable;?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->condition != ""){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="condition">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CONDITION' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsSpecs">
			    <?php echo $this->bfauction_plus->condition;?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->buyersPremium != ""){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="buyersPremium">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BUYERS_PREMIUM' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsSpecs">
			    <?php echo $this->bfauction_plus->buyersPremium;?>
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CURRENT_BID' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div id="currency" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divCurrentBid" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>

		<?php if($this->bfauction_plus->shipping > 0){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="shipping">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_SHIPPING' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <strong><?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $this->bfauction_plus->shipping;?>&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?></strong>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeCommission){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_COMMISSION' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div id="currencyCommission" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divCommissionCurrent" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($includeTax){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TAX' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divTaxCurrent" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($showTotalPrice){ ?>
		<tr>
			<td class="bfauction_plusLabelTotal">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TOTAL_PRICE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetailsTotal">
			    <div id="currencyTax" style="float: left; text-align: left;"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div><div id="divTotalPriceCurrent" style="float: left; text-align: left;" /></div>
			    &nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td class="bfauction_plusLabel">
				<label for="EndDate">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_END_DATE' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <div class="timeremaining"><?php echo JText::_($timerText); ?> <input id="txt" name="txt" readonly value="<?php echo $timerinit; ?>"></div>
			    <div id="endDate"><strong><?php echo JHTML::_('date',  $endDate, $dateFormat ); ?></strong></div>
			</td>
		</tr>

<?php
if($user->id != 0){
?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="User id">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CURRENT_BIDDER' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
				<div id="highBidder" style="float: left; text-align: left;" /></div>
				<?php
				if($this->bfauction_plus->highBidder == $user->username){
					if($this->lastbid->maxbid > 0){
						echo $currencySymbolAfter? ' (': ' ('.$bfcurrency;
						echo $this->lastbid->maxbid;
						echo $currencySymbolAfter? ' '.$bfcurrency.')' : ')';
					}
				}
				?>
			</td>
		</tr>

		<?php if( ($currentDate < $endDate) ){ ?>
			<?php if($this->bfauction_plus->buyNowPrice > 0 & $hideBid){ ?>
				<?php //hide bid now button ?>
				<input class="inputbox" type="hidden" name="bid" id="bid" size="5" value="<?php echo $nextBid; ?>"/>
			<?php }else{ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="Bid">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_YOUR_BID' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <form method="post" name="adminForm">
			    <?php
			    if($reverseAuction){
			    	$nextBid=$this->bfauction_plus->currentBid-(float)$bidIncrement;
			    	if($nextBid < 0){
			    		$nextBid=(float)$bidIncrement;
			    	}
			    }else{
					if($this->bfauction_plus->highBidder == '0'){
						/* no bids yet so use opening bid */
						$nextBid=$this->bfauction_plus->currentBid;
					}else{
			    		$nextBid=$this->bfauction_plus->currentBid+(float)$bidIncrement;
			    	}
			    }
			    ?>
			    <div class="bfauction_plusCurrency"><?php echo $currencySymbolAfter? '':$bfcurrency; ?></div>&nbsp;<input class="inputbox" type="text" name="bid" id="bid" size="5" value="<?php echo $nextBid; ?>" onblur="process()" />&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
				<input type="hidden" name="option" value="com_bfauction_plus" />
				<input type="hidden" name="task" value="bidnow" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="controller" value="" />
				<input type="hidden" name="cid" value="<?php echo $this->bfauction_plus->id; ?>" />
				<input type="hidden" name="bidIncrement" value="<?php echo $bidIncrement; ?>" />
				<input type="hidden" name="tax" id="tax">
				<input type="hidden" name="commission" id="commission">
				<input type="hidden" name="quantity" value="<?php echo $this->bfauction_plus->quantity; ?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
				<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_BID_NOW' ); ?>" />
				</form>
			</td>
		</tr>

		<tr>
			<td>
				&nbsp;
			</td>
			<td class="bfauction_plusDetails">
				<i><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_MINIMUM_BID_INCREMENT' ); ?>&nbsp;<strong><?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $bidIncrement; ?>&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?></strong></i>
			</td>
		</tr>
		<?php }	?>

		<?php if( ($this->bfauction_plus->buyNowPrice > 0) & ($this->bfauction_plus->buyNowPrice > $this->bfauction_plus->currentBid) & ($currentDate < $endDate) ){ ?>
		<tr>
			<td>
				&nbsp;
			</td>
			<td>
				&nbsp;
			</td>
		</tr>

		<tr>
			<td class="bfauction_plusLabel">
				<label for="BuyNow">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BUY_NOW' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			    <form method="post" name="buyNowForm">
			    <strong><?php echo $currencySymbolAfter? '':$bfcurrency; ?>&nbsp;<?php echo $this->bfauction_plus->buyNowPrice; ?>&nbsp;<?php echo $currencySymbolAfter? $bfcurrency : ''; ?></strong>
				<input type="hidden" name="option" value="com_bfauction_plus" />
				<input type="hidden" name="task" value="buynow" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="controller" value="" />
				<input type="hidden" name="cid" value="<?php echo $this->bfauction_plus->id; ?>" />
				<input type="hidden" name="quantity" value="<?php echo $this->bfauction_plus->quantity; ?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
				<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_BUY_NOW' ); ?>" />
				</form>
			</td>
		</tr>
		<?php } ?>

		<?php }else{ ?>
		<tr>
			<td colspan="2">
				<div class="auctionEnded"><?php echo JText::_( 'COM_BFAUCTIONPLUS_AUCTION_HAS_CLOSED' ); ?></div>
				<input type="hidden" name="bid" id="bid">
				<input type="hidden" name="tax" id="tax">
				<input type="hidden" name="commission" id="commission">
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->itemLocation){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="itemLocation">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ITEM_LOCATION' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			   <?php echo $this->bfauction_plus->itemLocation; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($this->bfauction_plus->deliveryMethod){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="deliveryMethod">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_DELIVERY_METHOD' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			   <?php echo $this->bfauction_plus->deliveryMethod; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($showDeliveryOptions & $winner){ ?>
		<tr>
			<td class="bfauction_plusLabel">
				<label for="deliveryOptions">
					<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_DELIVERY_OPTION' ); ?>:
				</label>
			</td>
			<td class="bfauction_plusDetails">
			   <?php echo $this->bfauction_plus->deliveryOption; ?>
			</td>
		</tr>
		<?php } ?>

		<?php if($allowWatchlist){ ?>
		<tr>
			<td>
				&nbsp;
			</td>
			<td class="bfauction_plusDetails">
			    <form method="post" name="watchlist">
				<input type="hidden" name="option" value="com_bfauction_plus" />
				<input type="hidden" name="task" value="watchlist" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="controller" value="" />
				<input type="hidden" name="cid" value="<?php echo $this->bfauction_plus->id; ?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
				<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_WATCHLIST' ); ?>" />
				</form>
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td>
				&nbsp;
			</td>
			<td class="bfauction_plusDetails">
				<a href="<?php echo JRoute::_('index.php?option=com_bfauction_plus&task=bidHistory&cid='.$this->bfauction_plus->id); ?>"><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_HISTORY' ); ?></a>
			</td>
		</tr>

		<?php
		if($this->bfauction_plus->onlineStore == "PayPal"){
			//if auction has ended and you are the winning bidder, show PayPal Buy now button
			if($winner){

				// is reserve price met?
				if($this->bfauction_plus->currentBid < $this->bfauction_plus->reservePrice ){
					?>
					<tr>
						<td colspan=2>
							<div class="reserveNotMet"><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_RESERVE_PRICE_NOT_MET' ); ?></div>
						</td>
					</tr>
					<?php
				}else{
				?>
					<tr>
						<td>
							<div class="youWonItem"><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_YOU_WON' ); ?></div>
						</td>
						<td>
							<?php
								$profile = bfauction_plusController::getUserProfile($user->id);

								$paypal = "https://www.paypal.com";
								$confbutton = "http://www.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif";
								$business = $this->bfauction_plus->paypalEmail;
								$itemName = $this->bfauction_plus->title;
								if($this->bfauction_plus->productId > 0){
									$item_number = $this->bfauction_plus->productId;
								}else{
									$item_number = $this->bfauction_plus->id;
								}
								$amount = $this->bfauction_plus->currentBid;
								$tax = $this->bfauction_plus->tax;
								$commission = $this->bfauction_plus->commission;
								$shipping = $this->bfauction_plus->shipping;
								$quantity = $this->bfauction_plus->quantityPurchased ? $this->bfauction_plus->quantityPurchased : 1;

								$amount = ((float)$amount + (float)$tax + (float)$commission) * (int)$quantity;

								if($quantity > 1){
									$itemName .= " (".$quantity.")";
								}

								$html = "";

								// create the form
								$html .= "<form action=\"".$paypal."/cgi-bin/webscr\" method=\"post\">";
								$html .= "<input type=\"hidden\" name=\"cmd\" value=\"_xclick\"/>";
								$html .= "<input type=\"hidden\" name=\"business\" value=\"".$business."\"/>";
								$html .= "<input type=\"hidden\" name=\"item_name\" value=\"".$itemName."\"/>";
								$html .= "<input type=\"hidden\" name=\"item_number\" value=\"".$item_number."\"/>";
								$html .= "<input type=\"hidden\" name=\"amount\" value=\"".$amount."\"/>";
								$html .= "<input type=\"hidden\" name=\"currency_code\" value=\"".strtoupper($bfcurrency_code)."\"/>";
								$html .= "<input type=\"hidden\" name=\"shipping\" value=\"".$shipping."\"/>";
								$html .= "<input type=\"hidden\" name=\"no_shipping\" value=\"0\"/>";
								if($profile){
									$html .= "<input type=\"hidden\" name=\"address1\" value=".$profile->address1."/>";
									$html .= "<input type=\"hidden\" name=\"address2\" value=".$profile->address2."/>";
									$html .= "<input type=\"hidden\" name=\"city\" value=".$profile->city."/>";
									$html .= "<input type=\"hidden\" name=\"state\" value=".$profile->region."/>";
									$html .= "<input type=\"hidden\" name=\"zip\" value=".$profile->postcode."/>";
									$html .= "<input type=\"hidden\" name=\"country\" value=".$profile->country."/>";
									$html .= "<input type=\"hidden\" name=\"night_phone_b\" value=".$profile->phone."/>";
								}
								$html .= "<input type=\"image\" src=\"".$confbutton."\" name=\"submit\" alt=\"Make payments with payPal - it's fast, free and secure!\"/>";
	    						$html .= "<img alt=\"\" src=\"https://www.paypal.com/en_US/i/scr/pixel.gif\" width=\"1\" height=\"1\"/>";
								$html .= "</form>";

								echo $html;

								if($profile){
									$itemid = JRequest::getVar( 'Itemid' );
									$redirectUrl = base64_encode("index.php?option=com_bfauction_plus&task=bid&cid=".$this->bfauction_plus->id."&Itemid=".$itemid);
									$redirectUrl = '&return='.$redirectUrl;
									$joomlauserprofile = 'index.php?option=com_users&view=profile&layout=edit';
								   	$finalUrl = $joomlauserprofile . $redirectUrl;

									echo "<div style='float: left' width='100%'>";
									echo "<br><a href='".$finalUrl."' target='_blank'>".JText::_( 'COM_BFAUCTIONPLUS_TITLE_DELIVERY_ADDRESS' )."</a><br>";
									echo "<br>";
									echo preg_replace("/\"/", "", $profile->address1)."<br>";
									echo ($profile->address2 == "\"\"" ? "" : preg_replace("/\"/", "", $profile->address2)."<br>" );
									echo preg_replace("/\"/", "", $profile->city).", ";
									echo preg_replace("/\"/", "", $profile->region).", ";
									echo preg_replace("/\"/", "", $profile->postcode)."<br>";
									echo preg_replace("/\"/", "", $profile->country)."<br>";
									echo preg_replace("/\"/", "", $profile->phone);
									echo "</div>";
								}
							?>
						</td>
					</tr>
				<?php } ?>
			<?php
			}
		}
		?>
<?php
}else{
?>
	<div id="highBidder" style="display: none;" /></div>
<?php
} //end if
?>

	</table>
	</td>
	<td>

	<?php
		$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->bfauction_plus->id."img1.jpg";
		if (file_exists($a_pic)){
			//echo '<a href="./images/com_bfauction_plus/'.$this->bfauction_plus->id.'img1.jpg?time='.time().'"  rel="lytebox[myimages]"><img src="./images/com_bfauction_plus/'.$this->bfauction_plus->id.'img1.jpg?time='.time().'"/></a>';
			echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->id.'img1.jpg?time='.time().'"  class="lytebox" data-lyte-options="group:myimages"><img src="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->id.'img1.jpg?time='.time().'" width="'.$mainImageSize.'" border="0"/></a>';
		}elseif($this->bfauction_plus->imageShared > 0){
			$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->bfauction_plus->imageShared."img1.jpg";
			if (file_exists($a_pic)){
				//echo '<a href="./images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img1.jpg?time='.time().'"  rel="lytebox[myimages]"><img src="./images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img1_t.jpg?time='.time().'"/></a>';
				echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img1.jpg?time='.time().'"  class="lytebox" data-lyte-options="group:myimages"><img src="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img1.jpg?time='.time().'" width="'.$mainImageSize.'" border="0"/></a>';
			}
	?>
	<?php }elseif($this->bfauction_plus->image != ""){ ?>
    	<a href="<?php echo $this->bfauction_plus->image;?>"  class="lytebox" data-lyte-options="group:myimages"><img src="<?php echo $this->bfauction_plus->image;?>" width="<?php echo $mainImageSize; ?>" border=0></a>
    <?php } ?>


    </td>
    </tr>
    </table>

	<div class="bfauction_images">
		<?php
		for($i=2; $i < 21; $i++)
		{
			echo '<div class="bfauction_image">';
			$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->bfauction_plus->id."img".$i.".jpg";
			$image = 'image'.$i;
			if (file_exists($a_pic)){
				echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->id.'img'.$i.'.jpg?time='.time().'"  class="lytebox" data-lyte-options="group:myimages"><img src="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->id.'img'.$i.'_t.jpg?time='.time().'"/></a>';
			}elseif($this->bfauction_plus->imageShared > 0){
				$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->bfauction_plus->imageShared."img'.$i.'.jpg";
				if (file_exists($a_pic)){
					echo '<a href="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img'.$i.'.jpg?time='.time().'"  class="lytebox" data-lyte-options="group:myimages"><img src="'.JUri::base().'images/com_bfauction_plus/'.$this->bfauction_plus->imageShared.'img'.$i.'_t.jpg?time='.time().'"/></a>';
				}
			?>
    		<?php }elseif($this->bfauction_plus->$image != ""){ ?>
			<a href="<?php echo $this->bfauction_plus->$image;?>"  class="lytebox" data-lyte-options="group:myimages"><img src="<?php echo $this->bfauction_plus->$image;?>" height="50" border=0></a>
			<?php } ?>
			</div>
		<?php
		}
		?>
	</div>

    <br>
    <div class="bfauction_plusItemDescription">
		<?php echo JHTML::_('content.prepare', $this->bfauction_plus->description); ?>
	</div>

	<?php
  	$comments = JPATH_SITE.'/components/com_jcomments/jcomments.php';
  	if (file_exists($comments)) {
	    require_once($comments);
	    echo JComments::showComments($this->bfauction_plus->id, 'com_bfauction_plus', $this->bfauction_plus->title);
  	}
	?>

	<div class="bfauction_plusItemDescription">
	<?php
		$this->bfauction_plus->text = $this->bfauction_plus->description;
		$this->bfauction_plus->introtext = $this->bfauction_plus->description;

		$options = array();
		if (class_exists('plgContentKomento'))
		{
			require_once( JPATH_ROOT . '/components/com_komento/bootstrap.php' );
			echo Komento::commentify( 'com_bfauction_plus', $this->bfauction_plus, $options );
		}
	?>
	</div>

	</fieldset>
</div>
<div class="col width-35">
	&nbsp;
</div>
<div class="clr"></div>
<input id="quantityPurchased" type="hidden" value="<?php echo $quantityPurchased; ?>"/>

<?php bfauction_plusController::triggerBFAuctionEmail(); ?>

<script language="javascript" type="text/javascript">
<!--
process();
//-->
</script>
