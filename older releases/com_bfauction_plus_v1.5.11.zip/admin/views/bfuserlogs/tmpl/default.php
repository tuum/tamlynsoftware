<?php
/**
 * $Id: default.php 88 2014-02-02 11:55:57Z tuum $
 * BF User log Component for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF User Log is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access to this file
defined('_JEXEC') or die;
// load tooltip behavior
JHtml::_('behavior.tooltip');

$app = JFactory::getApplication();
$site_filter		= $app->getUserStateFromRequest( 'filter.site',					'filter_site',	'',			'string' );
$login_filter		= $app->getUserStateFromRequest( 'filter.login',				'filter_login',	'',			'string' );

$filter_date_from		= $app->getUserStateFromRequest( 'filter.date_from',		'filter_date_from',	'',		'string' );
$filter_date_to			= $app->getUserStateFromRequest( 'filter.date_to',			'filter_date_to',	'',		'string' );

$lists['site'] = bfauction_plusHelper::filterSite($site_filter);
$lists['login'] = bfauction_plusHelper::filterLogin($login_filter);

$this->header=""; // excel export
$this->data="";
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=bfuserlogs'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<div class="row-fluid">
		<!-- Begin Content -->
		<div class="span10">
			<div id="filter-bar" class="btn-toolbar">
				<div class="filter-search btn-group pull-left">
					<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('JSEARCH_FILTER_LABEL'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN'); ?>" />
				</div>
				<div class="btn-group pull-left">
					<button class="btn" rel="tooltip" type="submit" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
					<button class="btn" rel="tooltip" type="button" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';document.id('filter_date_from').value='';document.id('filter_date_to').value='';this.form.submit();"><i class="icon-remove"></i></button>
				</div>
				<div class="btn-group pull-right">
					<button class="btn" rel="tooltip" type="submit" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				</div>
				<div class="btn-group pull-right">
					<?php echo JHTML::calendar( $filter_date_to, "filter_date_to", "filter_date_to", '%Y-%m-%d %H:%M:%S', 'placeholder='.JText::_("COM_BFAUCTIONPLUS_FILTER_TO").': onclick=this.form.submit();' ); ?>
				</div>
				<div class="btn-group pull-right">
					<?php echo JHTML::calendar( $filter_date_from, "filter_date_from", "filter_date_from", '%Y-%m-%d %H:%M:%S', 'placeholder='.JText::_("COM_BFAUCTIONPLUS_FILTER_FROM").': onclick=this.form.submit();' ); ?>
				</div>
			</div>
			<div class="clearfix"> </div>
			<table class="table table-striped">
<?php
	} //end Joomla 3.x

	$version = new JVersion();
	if($version->RELEASE == '2.5') {
?>
	<table class="adminlist">
		<fieldset id="filter-bar">
			<div class="filter-search fltlft">
				<label class="filter-search-lbl" for="filter_search"><?php echo JText::_('JSEARCH_FILTER_LABEL'); ?></label>
				<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_BFAUCTIONPLUS_SEARCH_IN'); ?>" />
				<button type="submit"><?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?></button>
				<button type="button" onclick="document.id('filter_search').value='';this.form.submit();"><?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?></button>
			</div>

			<div class="filter-select fltrt">
				<label class="filter-search-lbl" for="filter_date_from"><?php echo JText::_("COM_BFAUCTIONPLUS_FILTER_FROM"); ?>:</label>
				<?php echo JHTML::calendar( $filter_date_from, "filter_date_from", "filter_date_from", '%Y-%m-%d %H:%M:%S' ); ?>

				<label class="filter-search-lbl" for="filter_date_to"><?php echo JText::_("COM_BFAUCTIONPLUS_FILTER_TO"); ?>:</label>
				<?php echo JHTML::calendar( $filter_date_to, "filter_date_to", "filter_date_to", '%Y-%m-%d %H:%M:%S' ); ?>

				<?php echo $lists['site']; ?>
				<?php echo $lists['login']; ?>

				<select name="filter_published" class="inputbox" onchange="this.form.submit()">
					<option value=""><?php echo JText::_('JOPTION_SELECT_PUBLISHED');?></option>
					<?php echo JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.state'), true);?>
				</select>

			</div>
		</fieldset>
<?php
	} //end Joomla 2.5
?>
			<thead><?php echo $this->loadTemplate('head');?></thead>
			<tfoot><?php echo $this->loadTemplate('foot');?></tfoot>
			<tbody><?php echo $this->loadTemplate('body');?></tbody>
		</table>
<?php
	if( floatval($version->RELEASE) >= 3 ) {
?>
		</div>
	</div>
<?php
	}
?>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<?php echo JHtml::_('form.token'); ?>
</form>

<?php
//dodgy way but it will do for now
   // excel export
   print '<form id="ExcelExport" name="ExcelExport" method="POST" action="./components/com_bfauction_plus/excelexport.php">';

   print '<input type=hidden name="myheader"  value="'.$this->header.'">';

   print '<DIV ID="ExcelDate" style="display:none;"><textarea name="mydata">'.$this->data.'</textarea></div>';

   ?>
   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTIONPLUS_BUTTON_EXPORT_TO_EXCEL' ); ?>" />
   <?php jimport('joomla.html.html'); ?>
   <?php echo JHTML::_( 'form.token' ); ?>
   <?php
   print "</form>";
		?>