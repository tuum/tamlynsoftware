-- <?php /* $Id$ */ defined('_JEXEC') or die() ?>;

SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_plus]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfsurvey_questions](
	[bfsurvey_question_id] [bigint] IDENTITY(1,1) NOT NULL,
	[bfsurvey_category_id] [bigint] NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[slug] [nvarchar](50) NOT NULL,
	[question_type] [nvarchar](255) NOT NULL,
	[parent] [bigint] NOT NULL,
	[option1] [nvarchar](255) NOT NULL,
	[option2] [nvarchar](255) NOT NULL,
	[option3] [nvarchar](255) NOT NULL,
	[option4] [nvarchar](255) NOT NULL,
	[option5] [nvarchar](255) NOT NULL,
	[option6] [nvarchar](255) NOT NULL,
	[option7] [nvarchar](255) NOT NULL,
	[option8] [nvarchar](255) NOT NULL,
	[option9] [nvarchar](255) NOT NULL,
	[option10] [nvarchar](255) NOT NULL,
	[option11] [nvarchar](255) NOT NULL,
	[option12] [nvarchar](255) NOT NULL,
	[option13] [nvarchar](255) NOT NULL,
	[option14] [nvarchar](255) NOT NULL,
	[option15] [nvarchar](255) NOT NULL,
	[option16] [nvarchar](255) NOT NULL,
	[option17] [nvarchar](255) NOT NULL,
	[option18] [nvarchar](255) NOT NULL,
	[option19] [nvarchar](255) NOT NULL,
	[option20] [nvarchar](255) NOT NULL,
	[prefix] [nvarchar](255) NOT NULL,
	[suffix] [nvarchar](255) NOT NULL,
	[field_name] [nvarchar](50) NOT NULL,
	[field_type] [nvarchar](50) NOT NULL,
	[fieldSize] [int] NOT NULL,
	[mandatory] [smallint] NOT NULL,
	[validation_rule] [nvarchar](50) NOT NULL,
	[helpText] [nvarchar](max) NOT NULL,
	[sql] [nvarchar](max) NOT NULL,
	[key_field] [nvarchar](25) NOT NULL,
	[value_field] [nvarchar](25) NOT NULL,
	[titles] [nvarchar](255) NOT NULL,
	[horizontal] [smallint] NOT NULL,
	[otherprefix] [nvarchar](255) NOT NULL,
	[othersuffix] [nvarchar](255) NOT NULL,
	[suppressQuestion] [smallint] NOT NULL,
	[hide_question] [int] NOT NULL,
	[hide_options] [nvarchar](max) NOT NULL,
	[show_question] [int] NOT NULL,
	[show_options] [nvarchar](max) NOT NULL,
	[terminate_options] [nvarchar](max) NOT NULL,
	[terminate_url] [nvarchar](255) NOT NULL,
	[default_value] [nvarchar](255) NOT NULL,
	[enabled] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
	[myclass] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfsurvey_questions_bfsurvey_question_id] PRIMARY KEY CLUSTERED
(
	[bfsurvey_question_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_categories]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfsurvey_categories](
	[bfsurvey_category_id] [bigint] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[slug] [nvarchar](50) NOT NULL,
	[access] [int] NOT NULL,
	[accessResults] [int] NOT NULL,
	[accessStats] [int] NOT NULL,
	[language] [nvarchar](50) NOT NULL,
	[ordering] [int] NOT NULL,
	[enabled] [smallint] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
	[surveyTitle] [nvarchar](255) NOT NULL,
	[introText] [nvarchar](max) NOT NULL,
	[thankyouText] [nvarchar](max) NOT NULL,
	[showTabs] [smallint] NOT NULL,
	[use_captcha] [smallint] NOT NULL,
	[footer_captcha] [smallint] NOT NULL,
	[footerTabname] [nvarchar](50) NOT NULL,
	[redirectURL] [nvarchar](255) NOT NULL,
	[showName] [smallint] NOT NULL,
	[showCompany] [smallint] NOT NULL,
	[showEmail] [smallint] NOT NULL,
	[showEmailConfirm] [smallint] NOT NULL,
	[nameText] [nvarchar](255) NOT NULL,
	[companyText] [nvarchar](255) NOT NULL,
	[emailText] [nvarchar](255) NOT NULL,
	[emailConfirmText] [nvarchar](255) NOT NULL,
	[submitText] [nvarchar](255) NOT NULL,
	[nextText] [nvarchar](255) NOT NULL,
	[previousText] [nvarchar](255) NOT NULL,
	[anonymous] [smallint] NOT NULL,
	[anonymousText] [nvarchar](255) NOT NULL,
	[anonymousYes] [nvarchar](10) NOT NULL,
	[anonymousNo] [nvarchar](10) NOT NULL,
	[preventMultiple] [smallint] NOT NULL,
	[preventMultipleEmail] [smallint] NOT NULL,
	[preventMultipleUID] [smallint] NOT NULL,
	[showReferenceNo] [smallint] NOT NULL,
	[customJS] [nvarchar](max) NOT NULL,
	[customCSS] [nvarchar](max) NOT NULL,
	[theme] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_#__bfsurvey_categories_bfsurvey_category_id] PRIMARY KEY CLUSTERED
(
	[bfsurvey_category_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_emailitems]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfsurvey_emailitems](
	[bfsurvey_emailitem_id] [bigint] IDENTITY(1,1) NOT NULL,
	[bfsurvey_category_id] [bigint] NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[sendTo] [nvarchar](max) NOT NULL,
	[sendToGroup] [bigint] NOT NULL,
	[subject] [nvarchar](255) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[showQuestions] [smallint] NOT NULL,
	[condition_trigger] [nvarchar](255) NOT NULL,
	[condition_field1] [nvarchar](255) NOT NULL,
	[condition_criteria1] [nvarchar](255) NOT NULL,
	[condition_value1] [nvarchar](255) NOT NULL,
	[access] [int] NOT NULL,
	[language] [nvarchar](50) NOT NULL,
	[ordering] [int] NOT NULL,
	[enabled] [smallint] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
  	[pdfEmail] [smallint] NOT NULL,
	[template] [nvarchar](max) NOT NULL,
  	[templateCoverpage] [nvarchar](max) NOT NULL,
  	[templateHeader] [nvarchar](max) NOT NULL,
  	[templateFooter] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_#__bfsurvey_emailitems_bfsurvey_emailitem_id] PRIMARY KEY CLUSTERED
(
	[bfsurvey_emailitem_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_reports]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfsurvey_reports](
	[bfsurvey_report_id] [bigint] IDENTITY(1,1) NOT NULL,
	[bfsurvey_category_id] [bigint] NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[fields] [nvarchar](max) NOT NULL,
	[since] [datetime] NOT NULL,
	[until] [datetime] NOT NULL,
	[condition_field1] [nvarchar](255) NOT NULL,
	[condition_criteria1] [nvarchar](255) NOT NULL,
	[condition_value1] [nvarchar](255) NOT NULL,
	[condition_operator1] [nvarchar](255) NOT NULL,
	[condition_field2] [nvarchar](255) NOT NULL,
	[condition_criteria2] [nvarchar](255) NOT NULL,
	[condition_value2] [nvarchar](255) NOT NULL,
	[template] [nvarchar](max) NOT NULL,
	[templateCoverpage] [nvarchar](max) NOT NULL,
	[templateHeader] [nvarchar](max) NOT NULL,
	[templateFooter] [nvarchar](max) NOT NULL,
	[rowsAsSeparatePages] [smallint] NOT NULL,
  	[customQuery] [nvarchar](max) NOT NULL,
	[filename] [nvarchar](255) NOT NULL,
	[access] [int] NOT NULL,
	[language] [nvarchar](50) NOT NULL,
	[ordering] [int] NOT NULL,
	[enabled] [smallint] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
 CONSTRAINT [PK_#__bfsurvey_reports_bfsurvey_report_id] PRIMARY KEY CLUSTERED
(
	[bfsurvey_report_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_storage]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfsurvey_storage](
	[tag] [nvarchar](255) NOT NULL,
	[lastupdate] [datetime] NOT NULL,
	[data] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_#__bfsurvey_storage_tag] PRIMARY KEY CLUSTERED
(
	[tag] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;