ALTER TABLE [#__bfsurvey_reports] ADD [customQuery] [nvarchar](max);
ALTER TABLE [#__bfsurvey_categories] ADD [customCSS] [nvarchar](max);