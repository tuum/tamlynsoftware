<?php
/**
 * $Id: controller.php 87 2013-12-15 09:51:52Z tuum $
 * bfauction_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

/**
 * bfauction_plus Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
//forwards compatibility for Joomla 3.0
//class bfauction_plusController extends JController
class bfauction_plusController extends JControllerLegacy
{
	protected $default_view = 'items';
	/**
	 * Method to display a view.
	 *
	 * @param	boolean			$cachable	If true, the view output will be cached
	 * @param	array			$urlparams	An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
	 *
	 * @return	JController		This object to support chaining.
	 * @since	1.5
	 */
	public function display($cachable = false, $urlparams = false)
	{
		require_once JPATH_COMPONENT.'/helpers/bfauction_plus.php';

		$view		= JRequest::getCmd('view', 'items');
		$layout 	= JRequest::getCmd('layout', 'default');
		$id			= JRequest::getInt('id');

		// Check for edit form.
		if ($view == 'item' && $layout == 'edit' && !$this->checkEditId('com_bfauction_plus.edit.item', $id)) {
			// Somehow the person just went to the form - we don't allow that.
			$this->setError(JText::sprintf('JLIB_APPLICATION_ERROR_UNHELD_ID', $id));
			$this->setMessage($this->getError(), 'error');
			$this->setRedirect(JRoute::_('index.php?option=com_bfauction_plus&view=bfauction_plus', false));

			return false;
		}

		parent::display();
		bfauction_plusHelper::displayVersion();

		return $this;
	}

	/**
	 * method to display the item view
	 */
	function item()
	{
		JRequest::setVar( 'view', 'item' );
		JRequest::setVar( 'layout', 'form'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	 * method to display the bid view
	 */
	function bid()
	{
		JRequest::setVar( 'view', 'bid' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	 * method to display the plugins view
	 */
	function plugins()
	{
		JRequest::setVar('view', 'plugins');
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	 * method to display the plugin view
	 */
	function plugin()
	{
		JRequest::setVar('view', 'plugin');
		JRequest::setVar('hidemainmenu', 1);
		JRequest::setVar('edit', true);
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfauction_plusController::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfauction_plusController::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_( 'COM_BFAUCTIONPRO_INVALID_TOKEN') );

		$db 		= JFactory::getDBO();
		$user 		= JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPRO_NO_ITEMS_SELECTED') );
			$mainframe->redirect( 'index.php?option='. $option );
		}

		$cids = implode( ',', $cid );

		$query = 'UPDATE #__bfauction_plus'
		. ' SET state = '.(int) $publish
		. ' WHERE id IN ( '. $cids .' )'
		. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )'
		;
		$db->setQuery( $query );
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg() );
		}

		$mainframe->redirect( 'index.php?option='. $option );
    }


	/**
	* Moves the record up one position
	*/
	function moveUpQuestion(  ) {
		bfauction_plusController::orderQuestion( -1 );
	}

	/**
	* Moves the record down one position
	*/
	function moveDownQuestion(  ) {
		bfauction_plusController::orderQuestion( 1 );
	}

	/**
	* Moves the order of a record
	* @param integer The direction to reorder, +1 down, -1 up
	*/
	function orderQuestion( $inc )
	{
		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

	    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction_plus/tables');
		$row = JTable::getInstance('item', 'Table');

		$db		= JFactory::getDBO();
		$cid	= JRequest::getVar('cid', array(0), '', 'array');
		$option = JRequest::getCmd('option');
		JArrayHelper::toInteger($cid, array(0));

		$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
		$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
		$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

		$row = JTable::getInstance( 'item', 'Table' );
		$row->load( $cid[0] );
		$row->move( $inc, 'catid = '.(int) $row->catid.' AND state != 0' );

		$mainframe->redirect( 'index.php?option='. $option );
	}

	/**
	 * saves the ordering of the items
	 */
	function saveOrder( )
	{
		$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_( 'COM_BFAUCTIONPRO_INVALID_TOKEN') );

		// Initialize variables
		$db			=& JFactory::getDBO();
		$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
		$total		= count( $cid );
		JArrayHelper::toInteger($order, array(0));

		$row =& JTable::getInstance('item', 'Table');
		$groupings = array();

		// 	update ordering values
		for( $i=0; $i < $total; $i++ ) {
			$row->load( (int) $cid[$i] );
			// track categories
			$groupings[] = $row->catid;

			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				if (!$row->store()) {
					JError::raiseError(500, $db->getErrorMsg() );
				}
			}
		}

		// execute updateOrder for each parent group
		$groupings = array_unique( $groupings );
		foreach ($groupings as $group){
			$row->reorder('catid = '.(int) $group);
		}

		$msg 	= JText::_( 'COM_BFAUCTIONPRO_NEW_ORDERING_SAVED');
		$mainframe->redirect( 'index.php?option=com_bfauction_plus', $msg );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'item' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$post['id'] = (int) $cid[0];
		$files  = JRequest::get( 'files' );

		$model = $this->getModel('item');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFAUCTIONPRO_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPRO_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		$config = JComponentHelper::getParams('com_bfauction_plus');

		$model->save($post,$files,$config,$model);

		$link = 'index.php?option=com_bfauction_plus';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('item');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFAUCTIONPRO_ERROR_DELETED' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPRO_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfauction_plus', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFAUCTIONPRO_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfauction_plus', $msg );
	}

	/**
	 * view to allow user to select css file to edit
	 * @return void
	 */
	function chooseCSS()
	{
		JToolBarHelper::title(   JText::_( 'COM_BFAUCTIONPRO_CHOOSE_CSS' ), 'bfauction_plus_toolbar_title');
		JToolBarHelper::custom( 'edit_css', 'edit', 'edit', 'Edit', true );
		JToolBarHelper::cancel();

	    global $mainframe;

		// Initialize some variables
		$option     = JRequest::getCmd('option');
		$template    = JRequest::getVar('id', '', 'method', 'cmd');
		$client        =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));

		// Determine CSS directory
		$dir = JPATH_SITE.'/components/com_bfauction_plus/css';

		// List .css files
		jimport('joomla.filesystem.folder');
		$files = JFolder::files($dir, '\.css$', false, false);

		// Set FTP credentials, if given
		jimport('joomla.client.helper');
		JClientHelper::setCredentialsFromRequest('ftp');

		require_once  (JPATH_ADMINISTRATOR.'/components/com_templates/admin.templates.html.php');
        TemplatesView::chooseCSSFiles($template, $dir, $files, $option, $client);

	}

	/**
	 * form to allow user to edit css file
	 * @return void
	 */
	function editCSS()
	      {
	      	  JToolBarHelper::title(   JText::_( 'COM_BFAUCTIONPRO_EDIT_CSS' ), 'bfauction_plus_toolbar_title');
	      	  JToolBarHelper::save( 'save_css' );
	      	  JToolBarHelper::cancel();

	          global $mainframe;

	          // Initialize some variables
	          $option        = JRequest::getCmd('option');
	          $client        =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfauction_plus";
	          $filename    = JRequest::getVar('filename', '', 'method', 'cmd');

	          jimport('joomla.filesystem.file');

	          if (JFile::getExt($filename) !== 'css') {
	              $msg = JText::_('COM_BFAUCTIONPRO_WRONG_FILE_TYPE_CSS');
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id.'&task=choose_css&id='.$template, $msg, 'error');
	          }

	          $content = JFile::read($client->path.'/components/'.$template.'/css/'.$filename);

	          if ($content !== false)
	          {
	              // Set FTP credentials, if given
	              jimport('joomla.client.helper');
	              $ftp =& JClientHelper::setCredentialsFromRequest('ftp');

	              $content = htmlspecialchars($content, ENT_COMPAT, 'UTF-8');

	              require_once  (JPATH_ADMINISTRATOR.'/components/com_templates/admin.templates.html.php');
	              TemplatesView::editCSSSource($template, $filename, $content, $option, $client, $ftp);
	          }
	          else
	          {
	              $msg = JText::sprintf('COM_BFAUCTIONPRO_OPERATION_FAILED_COULD_NOT_OPEN', $client->path.$filename);
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, $msg);
	          }
	      }

			/**
			* save css file changes
			* @return void
			*/
	      function saveCSS()
	      {
	          global $mainframe;

	          // Check for request forgeries
	          JRequest::checkToken() or jexit( 'Invalid Token' );

	          // Initialize some variables
	          $option            = JRequest::getCmd('option');
	          $client            =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfauction_plus";
	          $filename        = JRequest::getVar('filename', '', 'post', 'cmd');
	          $filecontent    = JRequest::getVar('filecontent', '', 'post', 'string', JREQUEST_ALLOWRAW);

	          if (!$template) {
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFAUCTIONPRO_OPERATION_FAILED').': '.JText::_('COM_BFAUCTIONPRO_NO_TEMPLATE_SPECIFIED'));
	          }

	          if (!$filecontent) {
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFAUCTIONPRO_OPERATION_FAILED').': '.JText::_('COM_BFAUCTIONPRO_CONTENT_EMPTY'));
	          }

	          // Set FTP credentials, if given
	          jimport('joomla.client.helper');
	          JClientHelper::setCredentialsFromRequest('ftp');
	          $ftp = JClientHelper::getCredentials('ftp');

	          $file = $client->path.'/components/'.$template.'/css/'.$filename;

	          // Try to make the css file writeable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0755')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFAUCTIONPRO_CSS_NOT_WRITABLE'));
	          }

	          jimport('joomla.filesystem.file');
	          $return = JFile::write($file, $filecontent);

	          // Try to make the css file unwriteable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0555')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFAUCTIONPRO_CSS_NOT_UNWRITABLE'));
	          }

			  if ($return)
			  {
			      $msg = JText::_( 'COM_BFAUCTIONPRO_FILE_SAVED' );
			  }else{
			  	  $msg = JText::_( 'COM_BFAUCTIONPRO_FAILED_OPEN_FILE' );
			  }


			  $this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=complete', false), $msg );
      }


    /**
     * gets the BF Auction Plus categories
     */
	function getCategory()
	{
		$db = &JFactory::getDBO();

		$query = 'SELECT a.id, a.title'
				. ' FROM #__categories AS a'
	  			. ' WHERE a.state = 1 and a.section="com_bfauction_plus"'
	  			. ' ORDER BY a.title'
	  			;


		$db->setQuery( $query );
		$options = $db->loadObjectList( );

		return $options;
	}

	/**
	 * method to display the email template view
	 */
	function emailtemplate()
	{
		JRequest::setVar( 'view', 'emailtemplate' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	/**
	 * method to display the list users view
	 */
	function listusers()
	{
		JRequest::setVar( 'view', 'listusers' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

    static function getHighBidDate($itemId)
    {
       	$db			= JFactory::getDBO();

		$query = 'SELECT *'
	  			. ' FROM #__bfauction_plus_bid AS a'
				. ' WHERE a.itemid ='.(int)$itemId
				. ' ORDER by id DESC'
	  			;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if($rows){
			return $rows[0]->bid_time;
		}else{
			return null;
		}
    }

     static function getNumBids($itemId)
    {
       	$db			= JFactory::getDBO();

		$query = 'SELECT count(id) AS numBids'
	  			. ' FROM #__bfauction_plus_bid AS a'
				. ' WHERE a.itemid ='.(int)$itemId
	  			;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if($rows){
			return $rows[0]->numBids;
		}else{
			return null;
		}
    }

    static function getNumRelisted($itemId)
    {
       	$db			= JFactory::getDBO();

		$query = 'SELECT count(a.relistid) AS numRelisted'
	  			. ' FROM #__bfauction_plus AS a'
				. ' WHERE a.relistid ='.(int)$itemId
	  			;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if($rows){
			return $rows[0]->numRelisted;
		}else{
			return null;
		}
    }


	/**
	 * Save plugin
	 *
	 */
	function save_plugin() {
		$model = & $this->getModel('plugin') ;
		$data = JRequest::get('post') ;
		$ret = $model->store($data);
		if ($ret) {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_SAVE_SUCCESS') ;
		} else {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_ERROR_SAVE') ;
		}
		$this->setRedirect( 'index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Install the plugin
	 *
	 */
	function install_plugin() {
		$model = & $this->getModel('plugin') ;
		$ret = $model->install();
		if ($ret) {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_INSTALLED');
		} else {
			$msg = JRequest::getVar('msg', JText::_('COM_BFAUCTIONPRO_PLUGIN_ERROR_INSTALL') ) ;
		}
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Uninstall the selected plugin
	 *
	 */
	function uninstall_plugin() {
		$model = & $this->getModel('plugin');
		$cid = JRequest::getVar('cid', array(), 'post', 'array') ;
		JArrayHelper::toInteger($cid);
		$ret = $model->uninstall($cid[0]);
		if ($ret) {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_REMOVE_SUCCESS');
		} else {
			$msg = JRequest::getVar('msg', JText::_('COM_BFAUCTIONPRO_PLUGIN_ERROR_UNINSTALL') ) ;
		}
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Publish selected plugins
	 *
	 */
	function plugins_publish() {
		$model = & $this->getModel('plugin') ;
		$cid = JRequest::getVar('cid', array(), 'post', 'array') ;
		JArrayHelper::toInteger($cid);
		$ret = $model->publish($cid, 1) ;
		if ($ret) {
			$msg =  JText::_('COM_BFAUCTIONPRO_PLUGIN_PUBLISH_SUCCESS');
		} else {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_PUBLISH_ERROR');
		}
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Unpublish selected plugins
	 *
	 */
	function plugins_unpublish() {
		$model = & $this->getModel('plugin') ;
		$cid = JRequest::getVar('cid', array(), 'post', 'array') ;
		JArrayHelper::toInteger($cid);
		$ret = $model->publish($cid, 0) ;
		if ($ret) {
			$msg =  JText::_('COM_BFAUCTIONPRO_PLUGIN_UNPUBLISH_SUCCESS');
		} else {
			$msg = JText::_('COM_BFAUCTIONPRO_PLUGIN_UNPUBLISH_ERROR');
		}
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Save ordering of the selected category
	 *
	 */
	function save_plugin_order() {
		$order = JRequest::getVar('order', array(), 'post') ;
		$cid = JRequest::getVar('cid', array(), 'post') ;
		JArrayHelper::toInteger($order);
		JArrayHelper::toInteger($cid);
		$model = & $this->getModel('plugin');
		$ret = $model->saveOrder($cid, $order);
		if ($ret) {
			$msg = JText::_('COM_BFAUCTIONPRO_ORDERING_SAVED') ;
		} else {
			$msg = JText::_('COM_BFAUCTIONPRO_ORDERING_ERROR') ;
		}
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins', $msg);
	}
	/**
	 * Order up a category
	 *
	 */
	function orderup_plugin() {
		$model =  $this->getModel('plugin');
		$model->move(-1);
		$msg = JText::_('COM_BFAUCTIONPRO_ORDERING_UPDATED');
		$url = 'index.php?option=com_bfauction_plus&task=show_plugins';
		$this->setRedirect($url, $msg);
	}
	/**
	 * Order down a category
	 *
	 */
	function orderdown_plugin() {
		$model =  $this->getModel('plugin');
		$model->move(1);
		$msg = JText::_('COM_BFAUCTIONPRO_ORDERING_UPDATED');
		$url = 'index.php?option=com_bfauction_plus&task=show_plugins';
		$this->setRedirect($url, $msg);
	}
	/**
	 * Redirect to plugin management homepage
	 *
	 */
	function cancel_plugin() {
		$this->setRedirect('index.php?option=com_bfauction_plus&task=show_plugins');
	}

	function export_csv(){
		$filename='export.csv';
		$sql_query="SELECT * FROM #__bfauction_plus";
		$app = JFactory::getApplication();
		$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);

	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    //$csv_enclosed = '"';
	    $csv_enclosed = '';
	    $csv_escaped = "\\";

		$host = $app->getCfg('host');
		$db = $app->getCfg('db');
		$user = $app->getCfg('user');
		$password = $app->getCfg('password');
		$dbtype = $app->getCfg('dbtype');

	    // Gets the data from the database
		if($dbtype == 'mysqli'){
			$link = mysqli_connect($host, $user, $password, $db);
			@mysqli_query($link, 'set character set "utf8"');
			$result = mysqli_query($link, $sql_query);
		}else{
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
	    	$result = mysql_query($sql_query);
	    	$fields_cnt = mysql_num_fields($result);
		}

	    $schema_insert = '';

		if($dbtype == 'mysqli'){
			$fields = mysqli_fetch_fields($result);
			$i=0;
			foreach ($fields as $field) {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes($field->name)) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		        $i++;
			}
			$fields_cnt = $i;
		}else{
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}

	    $out = trim(substr($schema_insert, 0, -1));
	    $out .= $csv_terminated;

	    // Format the data
	    $row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);

	    while ($row)
	    {
	        $schema_insert = '';
	        for ($j = 0; $j < $fields_cnt; $j++)
	        {
	            if ($row[$j] == '0' || $row[$j] != '')
	            {

	                if ($csv_enclosed == '')
	                {
	                    $schema_insert .= $row[$j];
	                } else
	                {
	                    $schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
	                }
	            } else
	            {
	                $schema_insert .= '';
	            }

	            if ($j < $fields_cnt - 1)
	            {
	                $schema_insert .= $csv_separator;
	            }
	        } // end for

	        $out .= $schema_insert;
	        $out .= $csv_terminated;

			$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
	    } // end while

	    header("Content-Length: " . strlen($out));
	    // Output to browser with appropriate mime type, you choose ;)
	    header('Content-Encoding: UTF-8');
		header('Content-type: text/csv; charset=UTF-8');
	   	header("Pragma: no-cache");
		header("Expires: 0");
	    header("Content-Disposition: attachment; filename=$filename");
	    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	    echo $out;
	    exit;
	}

	function importcsv()
	{
		require_once JPATH_COMPONENT.'/helpers/bfauction_plus.php';

		JRequest::setVar( 'view', 'importcsv' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
		bfauction_plusHelper::displayVersion();
	}

	function import_csv($filename=""){
		// Check for request forgeries
	    JRequest::checkToken() or jexit( 'Invalid Token' );
	    $app = JFactory::getApplication();

		$file = JRequest::getVar('file_source', null, 'files', 'array');
		$filename = $file['tmp_name'];

	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    $csv_enclosed = '';
	    $csv_escaped = "\\";

	   	$table = $app->getCfg('dbprefix')."bfauction_plus";

		$db	= JFactory::getDBO();
		$fields = $db->getTableFields( $table, true );
		$fieldnames = array();
		foreach( $fields[$table] as $field => $type ) {
				$fieldnames[]=$field;
		}

	    $query = "LOAD DATA LOCAL INFILE '".@mysql_escape_string($filename).
	             "' REPLACE INTO TABLE `".$table.
	             "` CHARACTER SET utf8 ".
	             " FIELDS TERMINATED BY '".@mysql_escape_string($csv_separator).
	             "' OPTIONALLY ENCLOSED BY '".@mysql_escape_string($csv_enclosed).
	             "' ESCAPED BY '".@mysql_escape_string($csv_escaped).
	             "' LINES TERMINATED BY '".@mysql_escape_string($csv_terminated).
	             "' ".
	             " IGNORE 1 LINES "
	             ."(`".implode("`,`", $fieldnames)."`)";

		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}else{
			$msg = JText::_('COM_BFAUCTIONPLUS_CSV_IMPORT_COMPLETE');
			$url = 'index.php?option=com_bfauction_plus';
			$this->setRedirect($url, $msg);
		}
	}

	function retractBid(){
		$cid = JRequest::getVar('cid', array(), 'post') ;
		$itemid = JRequest::getVar('itemid', array(), 'post') ;

		//get all the bids for this item
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_plus_bid');
		$query->where('itemid = '.$itemid);
		$query->order('bid_time DESC');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if(count($rows) > 1){
			//there is more than one bid one this item, need to roll back to previous one.

			//now is this the first bid?
			if($rows[0]->id == $cid){
				//This is the most recent bid for this item.

				//update item with second entry in bid history
				$query->clear();
				$query->update('#__bfauction_plus');
				$query->set('currentBid = '.(float)$rows[1]->bid);
				$query->set('highBidder = '.$db->quote( $db->escape($rows[1]->username), false ) );
				$query->set('tax = '.(float)$rows[1]->tax);
				$query->set('commission = '.(float)$rows[1]->commission);
				$query->set('saleType = 1');
				$query->set('quantityPurchased = '.(int)$rows[1]->quantity);
				$query->set('deliveryOption = '.$db->quote( $db->escape($rows[1]->deliveryOption), false ) );
				$query->where('id = '.(int)$itemid);

				$db->setQuery((string)$query);
				$db->query();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return;
				}

				//now delete the item from bidHistory
				$query->clear();
				$query->delete($db->quoteName('#__bfauction_plus_bid'));
				$query->where('id = '.$cid);

				$db->setQuery($query);
				$result = $db->query();

			}else{
				//Not the first item, just delete this entry in the bid table

				//now delete the item from bidHistory
				$query->clear();
				$query->delete($db->quoteName('#__bfauction_plus_bid'));
				$query->where('id = '.$cid);

				$db->setQuery($query);
				$result = $db->query();
			}
		}else{
			//this is the only bid on this item. Need to reset item.

			//reset the current item
			$query->clear();
			$query->update('#__bfauction_plus');
			$query->set('currentBid = 0');
			$query->set('highBidder = 0');
			$query->set('tax = 0');
			$query->set('commission = 0');
			$query->set('saleType = 0');
			$query->set('quantityPurchased = 0');
			$query->set('deliveryOption = ""');
			$query->set('winEmailSent = 0');
			$query->set('winEmailDate = "0000-00-00 00:00:00"');
			$query->where('id = '.(int)$itemid);

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//now delete the item from bidHistory
			$query->clear();
			$query->delete($db->quoteName('#__bfauction_plus_bid'));
			$query->where('id = '.$cid);

			$db->setQuery($query);
			$result = $db->query();
		}

		$msg = JText::_('COM_BFAUCTIONPLUS_RETRACT_BID_COMPLETE');
		$url = 'index.php?option=com_bfauction_plus&view=bidHistory&cid='.(int)$itemid;
		$this->setRedirect($url, $msg);
	}

}
?>
