<?php
/**
 * $Id: default.php 87 2013-12-15 09:51:52Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;
?>

<div id="cpanel" class="row-fluid">
	<div class="span10">

		<div class=icon>
			<a href="http://tamlynsoftware.com/products/bf-auction-plus/bf-auction-plus-user-guide.html" target="_blank">
				<div class="bfauction-icon-documentation"> </div>
				<span>User Guide</span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/contact-us/support-tickets.html" target="_blank">
				<div class="bfauction-icon-help"> </div>
				<span>Support Tickets</span>
			</a>
		</div>

	</div>
</div>