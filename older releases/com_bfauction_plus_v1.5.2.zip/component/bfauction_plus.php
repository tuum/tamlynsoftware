<?php
/**
 * $Id: bfauction_plus.php 87 2013-12-15 09:51:52Z tuum $
 * bfauction_plus entry point file for bfauction_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');
require_once JPATH_ROOT.'/administrator/components/com_bfauction_plus/helpers/bfauction_plus.php';

$jlang = JFactory::getLanguage();
$jlang->load('com_bfauction_plus', JPATH_SITE, 'en-GB', true);
$jlang->load('com_bfauction_plus', JPATH_SITE, $jlang->getDefault(), true);
$jlang->load('com_bfauction_plus', JPATH_SITE, null, true);

$document = JFactory::getDocument();
$cssFile = "./components/com_bfauction_plus/css/bfauction_plus.css";
$document->addStyleSheet($cssFile, 'text/css', null, array());

if (!class_exists('JControllerLegacy')) {
	require_once( JPATH_COMPONENT_ADMINISTRATOR.'/legacy.php' );
}
$controller	= JControllerLegacy::getInstance('bfauction_plus');
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();