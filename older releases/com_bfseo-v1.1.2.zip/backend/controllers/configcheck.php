<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerConfigcheck extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'configcheck';
	}

	public function execute($task)
	{
		if (!in_array($task, array('check'))) {
			$task = 'browse';
		}

		parent::execute($task);
	}

	function check()
	{				
		$model = $this->getThisModel();

		$result = $model->check();

		$url = 'index.php?option=com_bfseo&view=configcheck';
		if($result !== true) {
			$this->setRedirect($url, JText::_('COM_BFSEO_ERROR_CANT_CHECK_CONFIG'),'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSEO_CONFIG_CHECK_COMPLETE'));
		}

		$this->redirect();
	}
}
