CREATE TABLE IF NOT EXISTS `#__bfseo_xmlsitemap` (
  `bfseo_xmlsitemap_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sitemap_menus` text,
  PRIMARY KEY  (`bfseo_xmlsitemap_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;