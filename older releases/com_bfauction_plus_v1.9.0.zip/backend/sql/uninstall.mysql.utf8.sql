-- <?php /* $Id: uninstall.mysql.utf8.sql 43 2012-03-29 12:32:38Z tuum $ */ defined('_JEXEC') or die() ?>;

DROP TABLE IF EXISTS `#__bfauction_plus`;
DROP TABLE IF EXISTS `#__bfauction_plus_bid`;
DROP TABLE IF EXISTS `#__bfauction_plus_email`;
DROP TABLE IF EXISTS `#__bfauctionplus_payment_plugins`;
DROP TABLE IF EXISTS `#__bfauctionplus_watchlist`;
DELETE FROM `#__categories` WHERE extension="com_bfauction_plus";
