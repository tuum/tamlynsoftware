ALTER TABLE `#__bfauctionplus_watchlist` ADD `emailSent` tinyint(1) NOT NULL default '0';
ALTER TABLE `#__bfauctionplus_watchlist` ADD `emailDate` datetime NOT NULL default '0000-00-00 00:00:00';