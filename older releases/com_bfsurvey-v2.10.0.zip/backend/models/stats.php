<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelStats extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'questions';
	}

	public function buildQuery($overrideLimits = false)
	{
		$table = $this->getTable();
		$tableName = $table->getTableName();
		$tableKey = $table->getKeyName();
		$db = $this->getDbo();

		$query = $db->getQuery(true);

		// Call the behaviors
		$this->modelDispatcher->trigger('onBeforeBuildQuery', array(&$this, &$query));

		$alias = $this->getTableAlias();

		if ($alias)
		{
			$alias = ' AS ' . $db->qn($alias);
		}
		else
		{
			$alias = '';
		}

		$select = $this->getTableAlias() ? $db->qn($this->getTableAlias()) . '.*' : $db->qn($tableName) . '.*';

		$query->select($select)->from($db->qn($tableName) . $alias);
		$query->order('ordering');

		$app = JFactory::getApplication();
		if(!$app->isAdmin())
		{
			$params = JFactory::getApplication()->getParams();
			$catid=$params->get('slug');
		}
		else
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		if($catid){
			$query->where('bfsurvey_category_id = '.$catid);
		}
		$query->where('enabled = 1');

		// Call the behaviors
		$this->modelDispatcher->trigger('onAfterBuildQuery', array(&$this, &$query));

		return $query;
	}

	public function &getItemList($overrideLimits = false, $group = '')
	{
		if (empty($this->list))
		{
			$query = $this->buildQuery($overrideLimits);

			$this->list = $this->_getList((string) $query, 0, 0, $group);
		}

		return $this->list;
	}

	public static function getStats($question, $response, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
		$query->select('*');
		if($response!='' && $response != null){
			if($response == 1 || $response == 10 || $response[0] == 1){
				$query->where(trim($db->escape( $question )).' = '.$db->quote(trim($db->escape( $response, true ))) );
			}else{
				$query->where(trim($db->escape( $question )).' = '.$db->quote(trim( $response, true )) );
			}
			$query->where('enabled = 1');
		}else{
			return 0;
		}

		//this is require to allow percentage signs in the options
		//$query=preg_replace('/\\\\/','',$query);
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsCheckbox($question, $response, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
		$query->select('*');
		$query->where($db->escape( $question ) .' like '.$db->quote('%'.$db->escape( $response, true ).'%') );
		$query->where('enabled = 1');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsOther($question, $response, $catid){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
		$query->select('*');
		$query->where('enabled = 1');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$total = count($rows);

		$query->clear();
		//now get all the question
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('*');
		$query->where('field_name='.$db->quote($db->escape( $question )));
		$query->where('enabled = 1');

		$db->setQuery( $query);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}

		$count=0;
		foreach($rows2 as $qn){
			for($i=1; $i < 21; $i++){
				$tempoption="option".$i;
				if(JString::trim($db->escape( $qn->$tempoption, true ))){
					$query->clear();
					$query->select('*');
					$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
					$query->where( JString::trim($db->escape( $question ))."=". $db->quote(JString::trim($db->escape( $qn->$tempoption, true ))) );
					$query->where('enabled = 1');

					$db->setQuery( $query);
					$rows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						return false;
					}

					$count=$count+count($rows);
				}
			}
		}

		//now find out how many blank responses
		$query->clear();
		$query->select('*');
		$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
		$query->where( JString::trim($db->escape( $question ))."=''");
		$query->where('enabled = 1');
		$db->setQuery( $query);
		$rows4 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$count=$count+count($rows4);

		$num = $total-$count;
		if($num < 0){
			$num = 0;
		}

		return $num;
	}

	public static function getStatsText($field_name, $catid){

		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfsurvey_'.(int)$catid.'results'));
		$query->select($db->escape( $field_name ));
		$query->where('enabled = 1');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		return $rows;
	}
}