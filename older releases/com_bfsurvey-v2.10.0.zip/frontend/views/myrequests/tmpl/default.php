<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

$items = 0;
$limitstart = 0;
$limit = 0;

jimport('joomla.html.pagination');
$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="table table-striped" id="emailList">
    <thead>
        <tr>
            <th class="title">
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_DATE' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_REQUEST_NUMBER' ); ?>
            </th>
        </tr>
    </thead>

    <?php
    $k = 0;
    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row =& $this->items[$i];
        $link 		= JRoute::_( 'index.php?option=com_bfsurvey&view='.$row->catid.'result&layout=form&id='.(int)$row->id );
        $checked 	= JHTML::_('grid.id',   $i, $row->id );
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo JHTML::_('date',  $row->created_on, "d-m-Y H:i" ); ?></a>
			</td>
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo '#'; ?><?php echo str_pad($row->id, 4, '0', STR_PAD_LEFT); ?></a>
			</td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>

	<tfoot>
	    <tr>
	      <td colspan="4"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>
    </table>
</div>

<input type="hidden" name="option" value="com_bfsurvey" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />
<?php echo JHTML::_('form.token'); ?>
</form>