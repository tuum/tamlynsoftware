<?php
/**
 * $Id: controller.php 102 2015-03-14 00:18:43Z tuum $
 * bfauction_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

/**
 * bfauction_plus Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusController extends JControllerLegacy
{
    /**
     * __construct
     *
     * @param array $config
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }

    /**
     * display
     *
     * Method to display a view.
     *
     * @param	boolean			If true, the view output will be cached
     * @param	array			An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
     *
     * @return	JController		This object to support chaining.
     */
    public function display($cachable = false, $urlparams = false)
    {
        $cachable = true;

        $view		= JRequest::getCmd('view', 'bfauction_plus');
        JRequest::setVar('view', $view);
		$layout 	= JRequest::getCmd('layout', 'default');
		$id			= JRequest::getInt('id');
		$cid			= JRequest::getInt('cid');
		$grid			= JRequest::getInt('grid');
		if($view == "item"){
			$layout = "edit";
			JRequest::setVar( 'layout', 'edit'  );
		}

        $user = JFactory::getUser();

        if ($user->get('id') || $_SERVER['REQUEST_METHOD'] == 'POST') {
            $cachable = false;
        }

        $safeurlparams = array('catid'=>'INT','id'=>'INT','cid'=>'ARRAY','year'=>'INT','month'=>'INT','limit'=>'INT','limitstart'=>'INT',
            'showall'=>'INT','return'=>'BASE64','filter'=>'STRING','filter_order'=>'CMD','filter_order_Dir'=>'CMD','filter-search'=>'STRING','print'=>'BOOLEAN','lang'=>'CMD');

        parent::display($cachable, $safeurlparams);

        return $this;
    }

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFAUCTIONPLUS_OPERATION_CANCELLED' );

		$Itemid = JRequest::getVar('Itemid');
		$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=myitems', false), $msg );
	}

	function bid()
	{
		JRequest::setVar( 'view', 'bid' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function bidHistory()
	{
		JRequest::setVar( 'view', 'bidhistory' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/* bid now view to confirm that person wants to commit to buying item	 */
	function bidnow(){
		JRequest::setVar( 'view', 'bidnow' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function mybid()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'bid', 0, '', 'float' );
		$bidIncrement 	= JRequest::getVar( 'bidIncrement', 1, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );
		$quantityPurchased = JRequest::getVar( 'quantityPurchased', 1, '', 'int' );
		$deliveryOption = JRequest::getVar( 'deliveryOption', '', '', 'string' );

		$app		= JFactory::getApplication();
		$params		= $app->getParams();
		$allowEmail = $params->get('allowEmail');
		$bfcurrency = $params->get('bfcurrency');

		if($bfcurrency == ""){
			$bfcurrency = "$";
		}

		$dst_fix = $params->get('dst');
		$reverseAuction = $params->get('reverseAuction');
		$increaseEndTime = $params->get('increaseEndTime');
		$increaseEndTimeLastMinutes = $params->get('increaseEndTimeLastMinutes');
		$increaseEndTimeAmount = $params->get('increaseEndTimeAmount');
		$allowAutoBidding = $params->get( 'allowAutoBidding' );
		$allowOverBidding = $params->get( 'allowOverBidding' );
		$autobid = 0;

		if ($itemId==0 | $bid < $bidIncrement)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_PLUSCESSING_BID') );
			$msg="";
			$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=listItem', false), $msg );
		}else {
			$user = JFactory::getUser();
			$userusername = $user->username;
			$userid = $user->id;
			$useremail = $user->email;

			// is dst on on that particular date ?
			$now = JFactory::getDate();
			//forwards compatibility for Joomla 3.0
			//$date=$now->toFormat();
			$date=$now->format('Y-m-d H:i:s');
  			if (is_numeric( $date))
  			{
				$ts = $date;
  			} else {
    			$ts = strtotime( $date . ' UTC');
  			}
  			$dst = date( 'I', $ts);

  			$now = JFactory::getDate();
  			//if($dst_fix){
			//	$now->setOffset($app->getCfg('offset')+$dst);
  			//}else{
  			//	$now->setOffset($app->getCfg('offset'));
  			//}
  			//forwards compatibility for Joomla 3.0
			//$currentDate=$now->toFormat();
			$currentDate=$now->format('Y-m-d H:i:s');

			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_plus');
			$query->where('state = 1 and id = '.(int)$itemId);
			$query->order('title');
			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$myresult=$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=listItems', false), $msg );
			} elseif($allowOverBidding==0 && $userusername == $myresult->highBidder) {
				//when allow over bidding is turned off, don't allow user to out bid themselves
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_OVERBIDDING') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=listItems', false), $msg );
			} else {
				//-------------------------------------
				$maxbid=0;
				if($allowAutoBidding){
					//are there any automatic bids for this item?
					$db			= JFactory::getDBO();

					$query->clear();
					$query->select('a.username, a.uid, a.email, a.bid, a.maxbid, a.itemid, a.id');
					$query->from('#__bfauction_plus_bid AS a');
					$query->where('a.itemid='.(int)$itemId);
					$query->where('a.maxbid>0');
					$query->order('a.id DESC');
					$db->setQuery((string)$query);
					$autobidrows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						echo $db->stderr();
						return false;
					}
					if($autobidrows){
						$maxbid = $autobidrows[0]->maxbid;
					}
				}

				//-------------------------------------
				if (($bid >= ($myresult->currentBid + ((float)$bidIncrement)) & $reverseAuction==0) | ($reverseAuction & $bid <= ($myresult->currentBid - ((float)$bidIncrement))) | ($bid >= $myresult->currentBid & $reverseAuction==0 & $myresult->highBidder == '0' & $bid>=(float)$bidIncrement) )
				{
					if($allowAutoBidding){
						//need to check that current bid is greater than maxbid of previous bidder
						//this code doesn't support reverse auction
						//if($bid >= ($maxbid + (float)$bidIncrement) ){
						if($bid >= ($maxbid + (float)$bidIncrement) || ($bid >= $myresult->currentBid & $reverseAuction==0 & $myresult->highBidder == '0' & $bid>(float)$bidIncrement) ){
							//new bidder is now winning. Need to set bid to current bid, and set the max bid
							$maxbid = $bid;
							if(($maxbid >= ($myresult->currentBid + (float)$bidIncrement)) || ($myresult->highBidder == '0') ){
								//$bid = $myresult->currentBid + (float)$bidIncrement;
								$bid = $myresult->currentBid;
								if($bid == 0){
									$bid = (float)$bidIncrement;
								}

								//now check that bid is higher than previous maxbid
								if($bid > $autobidrows[0]->maxbid){
									//all good
								}else{
									$bid = $autobidrows[0]->maxbid + (float)$bidIncrement;
									if($bid > $maxbid && !($myresult->highBidder == '0')){
										JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_LOWER') );
										$this->setRedirect( 'index.php?option=com_bfauction_plus&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
									}
								}
							}else{
								JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_LOWER') );
								$this->setRedirect( 'index.php?option=com_bfauction_plus&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
							}

							//now proceed as per normal
							$msg = JText::_( 'COM_BFAUCTIONPLUS_BID_CONFIRMED' );
						}else{
							//current bid is lower. Need to write this bid to history, then automatically add new bid for person with automatic bid.
							$db			= JFactory::getDBO();
							$autobid = 1;

							//this bit is changed as of 22/09/2013, no longer write this bid to history, only put the next automatic bid
							//write new bid to db
							//$tempmaxbid = 0;
							//$query->clear();
							//if(is_callable(array('JDatabaseQuery', 'columns'))){
							//	$query->insert('#__bfauction_plus_bid');
							//	$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('uid'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
							//	$query->values( (int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$user->id.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(float)$tempmaxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
							//}else{
							//	//joomla 1.6
							//	$query = 'INSERT INTO #__bfauction_plus_bid (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
							//		. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$tempmaxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
				  			//		;
							//}
							//
							//$db->setQuery( $query );
							//if (!$db->query())
							//{
							//	echo $db->getErrorMsg();
							//	return false;
							//}

							//now set up automatic bid
							$userusername = $autobidrows[0]->username;
							$userid = $autobidrows[0]->uid;
							$useremail = $autobidrows[0]->email;
							$maxbid = $autobidrows[0]->maxbid;
							//now figure out what the current bid is
							//is maxbid greater than currentBid + increment
							if(($maxbid + (float)$bidIncrement) > $bid ){
								if($bid > $maxbid){
									$bid = $maxbid;
								}else{
									$bid = $bid;
								}
							}else{
								$bid = $maxbid;
								$maxbid = 0;
							}

				  			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_LOWER') );

						}
					}

					$db = JFactory::getDbo();
					$query	= $db->getQuery(true);

					$query->update('#__bfauction_plus');
					$query->set('currentBid = '.(float)$bid);
					$query->set('highBidder = '.$db->quote( $db->escape($userusername), false ) );
					$query->set('tax = '.(float)$tax);
					$query->set('commission = '.(float)$commission);
					$query->set('saleType = 1');
					$query->set('quantityPurchased = '.(int)$quantityPurchased);
					$query->set('deliveryOption = '.$db->quote( $db->escape($deliveryOption), false ) );
					$query->where('id = '.(int)$itemId);

					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}

					$query->clear();
					if(is_callable(array('JDatabaseQuery', 'columns'))){
						$query->insert('#__bfauction_plus_bid');
						$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('uid'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
						$query->values( (int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(float)$maxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
					}else{
						//joomla 1.6
						$query = 'INSERT INTO #__bfauction_plus_bid (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
						. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$maxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
	  					;
					}
					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}

					$bidId=$db->insertid();

					if($autobid == 1){
						// don't show bid confirmed message when automatic bid is being placed, but show the rest of the time.
						$msg = '';
					}else{
						$msg = JText::_( 'COM_BFAUCTIONPLUS_BID_CONFIRMED' );
					}

					//add item to watchlist
					$this->watchlist( (int)$itemId );

					//now see if time needs to be added to end time
					if($increaseEndTime){
						//how much time left?
						$secondsDiff = strtotime($myresult->endDate) - strtotime($currentDate);  //convert to unix time (number of seconds) and work out difference
						$remainingMinutes = floor(($secondsDiff)/60);

						if( ($remainingMinutes -1) < $increaseEndTimeLastMinutes ){
							$timestamp = strtotime($currentDate) + $increaseEndTimeAmount*60;
							$newEndTime = date('Y-m-d H:i:s', $timestamp);

							$db = JFactory::getDbo();
							$query	= $db->getQuery(true);

							$query->update('#__bfauction_plus');
							$query->set('endDate = '.$db->quote( $db->escape($newEndTime), false ));
							$query->where('id = '.(int)$itemId);
							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							$msg .= "<br>".JText::_( 'COM_BFAUCTIONPLUS_BID_TIMEINCREASED' );
						}

					}

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						bfauction_plusController::triggerEmails("BidConfirm", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						bfauction_plusController::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}
				} else {
					if($reverseAuction){
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_HIGHER') );
					}else{
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_LOWER') );
					}
					$msg="";
					$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=bid&cid='.$itemId, false), $msg );
				}
			}
		}

		$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&view=bid&cid='.$itemId, false), $msg );
	}

    static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
       $conf	= JFactory::getConfig();

       $mailfrom 	= $conf->get('config.mailfrom');
	   $fromname 	= $conf->get('config.fromname');

	   $emailBody = $body;
       $mode = 1;

       $mysendEmailTo = 	explode( ',', $sendEmailTo );
       foreach($mysendEmailTo AS $sendEmailTo)
       {
       		JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
       }
    }

    static function getEmailTemplate($title)
    {
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_plus_email');
		$query->where('state = 1 AND title='.$db->quote( $db->escape($title), false ));
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
    }

    static function getItem($itemId)
    {
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_plus');
		$query->where('id = '.(int)$itemId);
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
    }

	function myitems()
	{
		JRequest::setVar( 'view', 'myitems' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function item()
	{
		JRequest::setVar( 'view', 'item' );
		JRequest::setVar( 'layout', 'edit'  );

		parent::display();
	}

	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfauction_plusController::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfauction_plusController::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		$app = JFactory::getApplication();

		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$user 		= JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_NO_ITEMS_SELECTED') );
			$app->redirect( JRoute::_('index.php?option='. $option, false) );
		}

		$cids = implode( ',', $cid );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->update('#__bfauction_plus');
		$query->set('state = '.(int) $publish);
		$query->where('id IN ( '. $cids .' )');
		$query->where('( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )');
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$app->redirect( JRoute::_('index.php?option='. $option, false) );
    }


/**
* Moves the record up one position
*/
function moveUpQuestion(  ) {
	bfauction_plusController::orderQuestion( -1 );
}

/**
* Moves the record down one position
*/
function moveDownQuestion(  ) {
	bfauction_plusController::orderQuestion( 1 );
}

/**
* Moves the order of a record
* @param integer The direction to reorder, +1 down, -1 up
*/
function orderQuestion( $inc )
{
	$app = JFactory::getApplication();

	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction_plus/tables');
	$row = JTable::getInstance('item', 'Table');

	$db		= JFactory::getDBO();
	$cid	= JRequest::getVar('cid', array(0), '', 'array');
	$option = JRequest::getCmd('option');
	JArrayHelper::toInteger($cid, array(0));

	$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
	$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
	$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

	$row = JTable::getInstance( 'item', 'Table' );
	$row->load( $cid[0] );
	$row->move( $inc, 'catid = '.(int) $row->catid.' AND state != 0' );

	$app->redirect( JRoute::_('index.php?option='. $option, false) );
}

function saveOrder( )
{
	$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
	$app = JFactory::getApplication();

	// Check for request forgeries
	JRequest::checkToken() or jexit( 'Invalid Token' );

	// Initialize variables
	$db = JFactory::getDbo();
	$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
	$total		= count( $cid );
	JArrayHelper::toInteger($order, array(0));

	$row = JTable::getInstance('item', 'Table');
	$groupings = array();

	// update ordering values
	for( $i=0; $i < $total; $i++ ) {
		$row->load( (int) $cid[$i] );
		// track categories
		$groupings[] = $row->catid;

		if ($row->ordering != $order[$i]) {
			$row->ordering = $order[$i];
			if (!$row->store()) {
				JError::raiseError(500, $db->getErrorMsg() );
			}
		}
	}

	// execute updateOrder for each parent group
	$groupings = array_unique( $groupings );
	foreach ($groupings as $group){
		$row->reorder('catid = '.(int) $group);
	}

	$msg 	= JText::_( 'COM_BFAUCTIONPLUS_NEW_ORDERING_SAVED');
	$app->redirect( JRoute::_('index.php?option=com_bfauction_plus', false), $msg );
}


	/**
	  Copies one or more item
	 */
	function copy()
	{
		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus', false) );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db = JFactory::getDbo();

		$table	= JTable::getInstance('item', 'Table');

		$user	= JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->title				= JText::_( 'COM_BFAUCTIONPLUS_COPY_OF') . $table->title;
					$table->state 			= 0;
					$table->ordering 			= 0;

					$now = JFactory::getDate();
					$table->date			= $now->toMySQL();

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}else{
					return JError::raiseWarning( 500, $table->getError() );
			    }
			}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFAUCTIONPLUS_ITEMS_COPIED', $n ) );
	}

	/* buy now view to confirm that person wants to commit to buying item	 */
	function buynow(){
		JRequest::setVar( 'view', 'buynow' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/*
	 * buy item now
	 */
	function commitBuyNow(){
		$app = JFactory::getApplication();
		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'buyNowPrice', 0, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );
		$quantityPurchased = JRequest::getVar( 'quantityPurchased', 1, '', 'int' );
		$deliveryOption = JRequest::getVar( 'deliveryOption', '', '', 'string' );

		$app		= JFactory::getApplication();
		$params		= $app->getParams();
		$allowEmail = $params->get('allowEmail');
		$bfcurrency = $params->get('bfcurrency');

		if($bfcurrency == ""){
			$bfcurrency = "$";
		}
		$dst_fix = $params->get('dst');

		if ($itemId==0 | $bid < 0.01)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_PLUSCESSING_BID') );
			$msg="";
			$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=listItem', false), $msg );
		} else {
			$user = JFactory::getUser();

			// is dst on on that particular date ?
			$now = JFactory::getDate();
			//forwards compatibility for Joomla 3.0
			//$date=$now->toFormat();
			$date=$now->format('Y-m-d H:i:s');
  			if (is_numeric( $date))
  			{
				$ts = $date;
  			} else {
    			$ts = strtotime( $date . ' UTC');
  			}
  			$dst = date( 'I', $ts);

  			$now = JFactory::getDate();
  			//if($dst_fix){
			//	$now->setOffset($app->getCfg('offset')+$dst);
  			//}else{
  			//	$now->setOffset($app->getCfg('offset'));
  			//}
			//forwards compatibility for Joomla 3.0
			//$currentDate=$now->toFormat();
			$currentDate=$now->format('Y-m-d H:i:s');

			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_plus');
			$query->where('state = 1');
			$query->where('id = '.(int)$itemId);
			$query->order('title');
			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
			$myresult=&$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=listItems', false), $msg );
			}elseif($quantityPurchased > $myresult->quantity && $myresult->quantity != 0){
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_INCORRECT_QTY') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=listItems', false), $msg );
			}else{
				if ($bid > $myresult->currentBid )
				{
					$db = JFactory::getDbo();
					$query	= $db->getQuery(true);

					$query->update('#__bfauction_plus');
					$query->set('currentBid = '.(float)$bid);
					$query->set('highBidder = '.$db->quote( $db->escape($user->username), false ));
					$query->set('tax = '.(float)$tax);
					$query->set('commission = '.(float)$commission);
					$query->set('endDate = '.$db->quote($currentDate, false ));
					$query->set('saleType = 2');
					$query->set('quantityPurchased = '.(int)$quantityPurchased );
					$query->set('quantity = '.(int)$quantityPurchased );
					$query->set('deliveryOption = '.$db->quote($deliveryOption, false ) );

					$query->where('id = '.(int)$itemId);

					$db->setQuery((string)$query);
					$db->query();
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}

					$query->clear();
					if(is_callable(array('JDatabaseQuery', 'columns'))){
						$query->insert('#__bfauction_plus_bid');
						$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('uid'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('quantity'), $db->quoteName('deliveryOption')));
						$query->values((int)$itemId.', '.$db->quote( $db->escape($user->username), false ).', '.(int)$user->id.', '.$db->quote( $db->escape($user->email), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
					}else{
						//joomla 1.6
						$query = 'INSERT INTO #__bfauction_plus_bid (`itemid`, `username`, `email`, `bid`, `bidCurrency`, `bid_time`, `tax`, `commission`, `quantity`, `deliveryOption`)'
						. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($user->username), false ).', '.$db->quote( $db->escape($user->email), false ).', '.(float)$bid.', '.$db->quote($bfcurrency, false ).', "'.$currentDate.'", '.(float)$tax.', '.(float)$commission.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
	  					;
					}
					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}
					$bidId=$db->insertid();

					$msg = JText::_( 'COM_BFAUCTIONPLUS_BUY_NOW_PURCHASE' );

					$rightNow = JFactory::getDate();
					$db2 = JFactory::getDbo();
					$query2	= $db2->getQuery(true);
					$query2->update('#__bfauctionplus_watchlist');
					$query2->set('emailSent= 2');
					if(is_callable(array('JDate', 'toSql'))){
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toSql() ), false ));
					}else{
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toMySQL() ), false ));
					}
					$query2->where('itemid = '.(int)$itemId);

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						bfauction_plusController::triggerEmails("BuyNow", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						bfauction_plusController::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}

					//for multiple quantity items, is there still some available?
					$newQuantity = $myresult->quantity - $quantityPurchased;
					if($newQuantity > 1){
					    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction_plus/tables');
						$row = JTable::getInstance('item', 'Table');
        				$id = $myresult->id;

		            	$row->load((int) $id);
		            	//exitsting item is archived and new copy is created with unique id.
		            	$row->id			= "";
		            	$row->state     	= 1;
						$row->highBidder	= "";
						$row->currentBid	= 0;
						$row->ordering 		= 0;
						$row->winEmailSent	= 0;
						$row->winEmailDate = '0000-00-00 00:00:00';
						$row->saleType 	= 0;
						$row->endDate = $myresult->endDate;
						$row->quantityPurchased = 0;
						$row->deliveryOption = "";

						if($row->relistid == 0){
							$row->relistid = (int) $id;

							//Use images from original item.
							$row->imageShared = (int) $id;
						}
						$row->quantity		= (int)$newQuantity;

		            	if (!$row->check()) {
			                return JError::raiseWarning(500, $row->getError());
		            	}
		            	if (!$row->store()) {
			                return JError::raiseWarning(500, $row->getError());
		            	}
					}
				} else {
					JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_BID_NOT_ACCEPTED_LOWER') );
					$msg="";
					$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=listItems', false), $msg );
				}
			}
		}
		$this->setRedirect( JRoute::_('index.php?option=com_bfauction_plus&task=bid&cid='.$itemId, false), $msg );
	}

	static function triggerEmails($emailType, $id, $bidId){
		$app = JFactory::getApplication();
		$params = $app->getParams();
		$dateFormat = $params->get( 'dateFormat' );

		if($emailType == "Outbid" | $emailType == "LoosingBid"){
			//get previous high bidder from bid history
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_plus_bid');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			// if there is no previous bidder, don't send any outbid or loosing email.
			if($rows == null){
				return false;
			}

			// do not send outbid email if this is the first bid on an item
			if(count($rows)<2){
				return false;
			}

			//don't send outbid or loosing email if the same person bids twice in a row
			if($rows[0]->uid == $rows[1]->uid){
				return false;
			}

			//set bid id for loosing email so we send to the correct person
			if($emailType == "LoosingBid"){
				$bidId = $rows[1]->id;
			}
		}else if($emailType == "Watchlist"){
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('a.*');
			$query->from('#__bfauctionplus_watchlist AS a');
			$query->where('a.id = '.(int)$id);
			$query->select('c.email, c.username');
			$query->join('LEFT', '#__users AS c ON c.id = a.uid');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$id = (int)$rows[0]->itemid;
		}

		$myemail = bfauction_plusController::getEmailTemplate($emailType);
		$myitem =  bfauction_plusController::getItem($id);

		if($myemail == null){
		   //no email template found so don't send anything
		   return false;
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get bid details
		if($bidId == null){
			$query->select('*');
			$query->from('#__bfauction_plus_bid');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');
			//get the bid with the largest id
		}else{
			//get a sepecific bid
			$query->select('*');
			$query->from('#__bfauction_plus_bid');
			$query->where('itemid = '.(int)$id);
			$query->where('id = '.(int)$bidId);
			$query->order('bid_time desc');
		}

		$db->setQuery((string)$query);
		$bids = $db->loadObjectList();

		//get seller details
	   	$query->clear();
		$query->select('*');
		$query->from('#__users');
		$query->where('id = '.(int)$myitem[0]->uid);

		$db->setQuery((string)$query);
		$userdetail = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$sellername = $userdetail[0]->name; //get seller name
		$selleremail = $userdetail[0]->email; //get seller email

		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction_plus&task=bid&cid='. $myitem[0]->id.'">'.$myitem[0]->title.'</a>';

		//repace fields with actual data
		if($emailType != "Watchlist"){
			$myemail[0]->description=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->description); // insert bfcurrency
			$myemail[0]->description=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->description); // insert bid amount
			$myemail[0]->description=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->description); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->description); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->description); // insert user name
		}else{
			$myemail[0]->description=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->description); // insert user name
		}
		$myemail[0]->description=preg_replace('/{description}/', addcslashes($myitem[0]->description,'$') , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->description); // insert item title
		$myemail[0]->description=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->description); // insert item id
		$myemail[0]->description=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->description); // insert product id
		$myemail[0]->description=preg_replace('/{sellername}/', $sellername , $myemail[0]->description); // insert seller name
		$myemail[0]->description=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->description); // insert seller email
		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->description); // insert deliverymethod

		if($emailType != "Watchlist"){
			$myemail[0]->subject=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->subject); // insert bfcurrency
			$myemail[0]->subject=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->subject); // insert bid amount
			$myemail[0]->subject=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->subject); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->subject); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->subject); // insert user name
		}else{
			$myemail[0]->subject=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->subject); // insert user name
		}
		$myemail[0]->subject=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->subject); // insert item title
		$myemail[0]->subject=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->subject); // insert item id
		$myemail[0]->subject=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->subject); // insert product id
		$myemail[0]->subject=preg_replace('/{sellername}/', $sellername , $myemail[0]->subject); // insert seller name
		$myemail[0]->subject=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->subject); // insert seller email
		$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
		$myemail[0]->subject=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->subject); // insert url

		$subject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		if($emailType == "Outbid"){
			bfauction_plusController::sendHTMLNotificationEmail($body, $rows[1]->email, $subject);
		}else if($emailType == "Watchlist"){
			if($rows[0]->emailSent == 0){
				bfauction_plusController::sendHTMLNotificationEmail($body, $rows[0]->email, $subject);
			}
		}else if($emailType == "Seller"){
			if($rows[0]->email)
			{
				$selleremail = $selleremail.','.$rows[0]->email;
			}
			bfauction_plusController::sendHTMLNotificationEmail($body, $selleremail, $subject);
		}else{
			bfauction_plusController::sendHTMLNotificationEmail($body, $bids[0]->email, $subject);
		}

		return true;
	}

	public static function triggerBFAuctionEmail()
	{
		$app		= JFactory::getApplication();
		$params		= $app->getParams();
		$dst_fix = $params->get('dst');
		$allowEmail = $params->get('allowEmail');
		$allowAutoBidding = $params->get('allowAutoBidding');

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id');
		$query->select('endDate');
		$query->select('currentBid');
		$query->select('buyNowPrice');
		$query->select('reservePrice');
		$query->select('quantity');
		$query->select('quantityPurchased');
		$query->select('uid, tax, commission');
		$query->from('#__bfauction_plus');
		$query->where('winEmailSent = 0');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList( );

		// is dst on on that particular date ?
		$now = JFactory::getDate();
		//forwards compatibility for Joomla 3.0
		//$date=$now->toFormat();
		$date=$now->format('Y-m-d H:i:s');
		if (is_numeric( $date))
		{
			$ts = $date;
		} else {
	 		$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		$now = JFactory::getDate();
		//if($dst_fix){
		//	$now->setOffset($app->getCfg('offset')+$dst);
		//}else{
		//	$now->setOffset($app->getCfg('offset'));
		//}
		//forwards compatibility for Joomla 3.0
		//$currentDate=$now->toFormat();
		$currentDate=$now->format('Y-m-d H:i:s');

		//get date for watchlist
		$now->modify("+24 hours");
		$adjustedEndDate=$now->format('Y-m-d H:i:s');

		// Check if any auctions have finished since this last run
		foreach($rows as $row){
			if ($currentDate > $row->endDate){
				//mark winEmailSent as true
				$now = JFactory::getDate();
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);
				if( ($row->currentBid == $row->buyNowPrice) || !($allowEmail) ){
			   		//don't send emails for BuyNow purchase or when emails are turned off
			   		//but still set the flag winEmailSent so we know auction has finished.
					$query->update('#__bfauction_plus');
					$query->set('winEmailSent= 2');
					if(is_callable(array('JDate', 'toSql'))){
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toSql() ), false ));
					}else{
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toMySQL() ), false ));
					}
			   		$query->where('id = '.(int)$row->id);

			   		//send Seller email
			   		if($allowEmail)
			   		{
			   			bfauction_plusController::triggerEmails("Seller", (int)$row->id, NULL);
			   		}
				}else{
					//auction finished, trigger winning email

					//-------------------------------------
					$maxbid=0;
					if($allowAutoBidding){
						//are there any automatic bids for this item?
						$db			= JFactory::getDBO();

						$query->clear();
						$query->select('a.username, a.uid, a.email, a.bid, a.maxbid, a.itemid, a.id, a.bid_time, a.bidCurrency, a.deliveryOption');
						$query->from('#__bfauction_plus_bid AS a');
						$query->where('a.itemid='.(int)$row->id);
						$query->where('a.maxbid>0');
						$query->order('a.id DESC');
						$db->setQuery((string)$query);
						$autobidrows = $db->loadObjectList();
						if ($db->getErrorNum())
						{
							echo $db->stderr();
							return false;
						}
						if($autobidrows){
							$maxbid = $autobidrows[0]->maxbid;
						}
					}

					//-------------------------------------

					//is reserve price met?
					if($row->currentBid < $row->reservePrice){
						//reserve price not met, but is there an automatic bid?
						if($maxbid >= $row->reservePrice){
							//automatic bid is greater than reserve, so set current bid to be reserve price

							$db = JFactory::getDbo();
							$query	= $db->getQuery(true);

							// do we also need to recalcualte tax, commission etc?
							$query->update('#__bfauction_plus');
							$query->set('currentBid = '.(float)$row->reservePrice);
							//$query->set('tax = '.(float)$tax);
							//$query->set('commission = '.(float)$commission);
							$query->set('saleType = 1');
							//$query->set('quantityPurchased = '.(int)$quantityPurchased);
							//$query->set('deliveryOption = '.$db->quote( $db->escape($deliveryOption), false ) );
							$query->where('id = '.(int)$row->id);

							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							$query->clear();
							if(is_callable(array('JDatabaseQuery', 'columns'))){
								$query->insert('#__bfauction_plus_bid');
								$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('uid'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
								$query->values( (int)$row->id.', '.$db->quote( $db->escape($autobidrows[0]->username), false ).', '.(int)$row->uid.', '.$db->quote( $db->escape($autobidrows[0]->email), false ).', '.(float)$row->reservePrice.', '.$db->quote($autobidrows[0]->bid_time, false ).', '.$db->quote($autobidrows[0]->bidCurrency, false ).', '.(float)$row->tax.', '.(float)$row->commission.', '.(float)$autobidrows[0]->maxbid.', '.(int)$row->quantity.', '.$db->quote( $db->escape($autobidrows[0]->deliveryOption), false ) );
							}else{
								//joomla 1.6
								$query = 'INSERT INTO #__bfauction_plus_bid (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
										. ' VALUES ('.(int)$row->id.', '.$db->quote( $db->escape($autobidrows[0]->username), false ).', '.(int)$row->uid.', '.$db->quote( $db->escape($autobidrows[0]->email), false ).', '.(float)$row->reservePrice.',  "'.$autobidrows[0]->bid_time.'", "'.$autobidrows[0]->bidCurrency.'", '.(float)$row->tax.', '.(float)$row->commission.', '.(float)$autobidrows[0]->maxbid.', '.(int)$row->quantity.', '.$db->quote( $db->escape($autobidrows[0]->deliveryOption), false ).')'
												;
							}
							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							bfauction_plusController::triggerEmails("WinningBid", (int)$row->id, NULL);
							bfauction_plusController::triggerEmails("Seller", (int)$row->id, NULL);
						}else{
							//reserve not met, and no automatic bid
							bfauction_plusController::triggerEmails("ReserveNotMet", (int)$row->id, NULL);
						}
					}else{
						bfauction_plusController::triggerEmails("WinningBid", (int)$row->id, NULL);
						bfauction_plusController::triggerEmails("Seller", (int)$row->id, NULL);
					}
					bfauction_plusController::triggerEmails("LoosingBid", (int)$row->id, NULL);

					$query->clear();
					$query->update('#__bfauction_plus');
					$query->set('winEmailSent= 1');
					if(is_callable(array('JDate', 'toSql'))){
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toSql() ), false ));
						$query->set('quantity = '.(int)$row->quantityPurchased);
					}else{
						$query->set('winEmailDate='.$db->quote( $db->escape( $now->toMySQL() ), false ));
						$query->set('quantity = '.(int)$row->quantityPurchased);
					}
			   		$query->where('id = '.(int)$row->id);

					//for multiple quantity items, is there still some available?
					$newQuantity = $row->quantity - $row->quantityPurchased;
					if($newQuantity > 1){
					    JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction_plus/tables');
						$row2 = JTable::getInstance('item', 'Table');
        				$id = $row->id;

		            	$row2->load((int) $id);
		            	//exitsting item is archived and new copy is created with unique id.
		            	$row2->id			= "";
		            	$row2->state     	= 1;
						$row2->highBidder	= "";
						$row2->currentBid	= 0;
						$row2->ordering 		= 0;
						$row2->winEmailSent	= 0;
						$row2->winEmailDate = '0000-00-00 00:00:00';
						$row2->saleType 	= 0;
						$row2->quantityPurchased = 0;
						$row2->deliveryOption = "";

						if($row2->relistid == 0){
							$row2->relistid = (int) $id;

							//Use images from original item.
							$row2->imageShared = (int) $id;
						}
						$row2->quantity		= (int)$newQuantity;

						// set end date to be 7 days from now
						$date = JFactory::getDate();
						$date->modify("+7 days");

						if(is_callable(array('JDate', 'toSql'))){
							$row2->endDate = $date->toSql();
						}else{
							$row2->endDate = $date->toMySQL();
						}

		            	if (!$row2->check()) {
			                return JError::raiseWarning(500, $row2->getError());
		            	}
		            	if (!$row2->store()) {
			                return JError::raiseWarning(500, $row2->getError());
		            	}
					}
				}

				$db->setQuery((string)$query);
				$db->query();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return;
				}
			}

			// Check to see if any watchlist emails need to be sent for this item
			//is it less than 24 hours before auction ends
			if ($adjustedEndDate > $row->endDate){
				$db = JFactory::getDbo();
				$query	= $db->getQuery(true);

				$query->select('id');
				$query->from('#__bfauctionplus_watchlist');
				$query->where('itemid = '.$row->id);
				$query->where('emailSent = 0');

				$db->setQuery((string)$query);
				$rowsWatchlist = $db->loadObjectList( );

				foreach($rowsWatchlist as $rowWatch){
					bfauction_plusController::triggerEmails("Watchlist", (int)$rowWatch->id, NULL);

					$rightNow = JFactory::getDate();
					$db2 = JFactory::getDbo();
					$query2	= $db2->getQuery(true);
					$query2->update('#__bfauctionplus_watchlist');
					$query2->set('emailSent= 1');
					if(is_callable(array('JDate', 'toSql'))){
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toSql() ), false ));
					}else{
						$query2->set('emailDate='.$db2->quote( $db2->escape( $rightNow->toMySQL() ), false ));
					}
					$query2->where('id = '.(int)$rowWatch->id);

					$db2->setQuery((string)$query2);
					$db2->query();
					if ($db2->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db2->getErrorNum(), $db2->getErrorMsg()).'<br />';
						return;
					}
				}
			}
		}
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('item');

		$post	= JRequest::get( 'post' );
		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFAUCTIONPLUS_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFAUCTIONPLUS_ERROR_SAVING_RECORD' );
		}

		$Itemid = JRequest::getVar('Itemid');

		$link = 'index.php?option=com_bfauction_plus&view=myitems&Itemid='.(int)$Itemid;
		$this->setRedirect( JRoute::_($link, false), $msg);
	}


	/*
     * AJAX lookup of current bid for bid view
     */
    function luCurrentBid(){
    	$app = JFactory::getApplication();
    	$params = $app->getParams();
    	$dateFormat = $params->get( 'dateFormat' );

    	$itemid=JRequest::getVar( 'itemid');
    	$dst_fix=JRequest::getVar( 'dst_fix', 0);

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('currentBid');
		$query->from('#__bfauction_plus');
		$query->where('id='.(int)$itemid);
		$db->setQuery((string)$query);

		$currentBid=$db->loadResult();
		if($currentBid){
			//do nothing as returned value is ok
		}else{
		    $currentBid=JText::_('COM_BFAUCTIONPLUS_ERROR_LIST_NOT_EXIST');
		}

		$query->clear();
		$query->select('endDate');
		$query->from('#__bfauction_plus');
		$query->where('id='.(int)$itemid);
		$db->setQuery((string)$query);
		$endDate=$db->loadResult();

		$query->clear();
		$query->select('highBidder');
		$query->from('#__bfauction_plus');
		$query->where('id='.(int)$itemid);
		$db->setQuery((string)$query);
		$highBidder=$db->loadResult();

		$user = JFactory::getUser();
		if($highBidder == $user->username){
			$highBidder = JText::_('COM_BFAUCTIONPLUS_YOU_ARE_CURRENT_BIDDER');
		}else{
			$highBidder = substr($highBidder, 0, 1).'******'.substr($highBidder, -1);
		}

		// is dst on on that particular date ?
		$now = JFactory::getDate();
		//forwards compatibility for Joomla 3.0
		//$date=$now->toFormat();
		$date=$now->format('Y-m-d H:i:s');
		if (is_numeric( $date)) {
			$ts = $date;
		} else {
			$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		$app = JFactory::getApplication();
		$now = JFactory::getDate();
		//if($dst_fix){
		//	$now->setOffset($app->getCfg('offset')+$dst);
		//}else{
		//	$now->setOffset($app->getCfg('offset'));
		//}
		//forwards compatibility for Joomla 3.0
		//$currentDate=$now->toFormat();
		$currentDate=$now->format('Y-m-d H:i:s');

    	$secondsDiff = 0;
		if($currentDate > $endDate){
   			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_AUCTION_HAS_ENDED') );
		}else{
			$endDateAsSeconds = strtotime($endDate);
			$currentDateAsSeconds = strtotime($currentDate);

			$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
		}

		$remainingDay     = floor($secondsDiff/60/60/24);
		$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
		$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
		$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

		// we'll generate XML output
		header('Content-Type: text/xml');
		// generate XML header
		$return = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

		// create the <response> element
		$return .= "<response>";

		$return .= "<myBid>";
		// generate output
   		$return .= htmlentities($currentBid);
		$return .= "</myBid>";

		$return .= "<myBidder>";
   		$return .= htmlentities($highBidder);
		$return .= "</myBidder>";

		$return .= "<myDate>";
   		$return .= htmlentities( JHTML::_('date',  $endDate, $dateFormat ) );
		$return .= "</myDate>";

		$return .= "<myDay>";
   		$return .= htmlentities($remainingDay);
		$return .= "</myDay>";

		$return .= "<myHour>";
   		$return .= htmlentities($remainingHour);
		$return .= "</myHour>";

		$return .= "<myMin>";
   		$return .= htmlentities($remainingMinutes);
		$return .= "</myMin>";

		$return .= "<mySec>";
   		$return .= htmlentities($remainingSeconds);
		$return .= "</mySec>";

		// close the <response> element
		$return .= "</response>";

		echo $return;
      	$app->close();
    }

	function watchlist($id = null)
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user = JFactory::getUser();
		$userid = $user->id;

		if($id){
			$itemId = $id;
		}else{
			$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		}

		$Itemid = JRequest::getVar('Itemid');

		$db			= JFactory::getDBO();

		$query = 'INSERT INTO #__bfauctionplus_watchlist (`itemid`, `uid`)'
							. ' VALUES ('.(int)$itemId.', '.(int)$userid.')'
		  					;

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$msg = JText::_( 'COM_BFAUCTIONPLUS_WATCHLIST_CONFIRMED' );
		$this->setRedirect( 'index.php?option=com_bfauction_plus&task=bid&cid='.$itemId.'&Itemid='.$Itemid, $msg );
	}

	function watchlistDelete()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user = JFactory::getUser();
		$userid = $user->id;

		$itemId = JRequest::getVar( 'cid', 0, 'POST', 'int' );
		$Itemid = JRequest::getVar('Itemid');

		$db			= JFactory::getDBO();

		$query = 'DELETE FROM #__bfauctionplus_watchlist WHERE `itemid`='.(int)$itemId.' AND `uid`='.(int)$userid
		  					;

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$msg = JText::_( 'COM_BFAUCTIONPLUS_WATCHLIST_DELETED' );
		$this->setRedirect( 'index.php?option=com_bfauction_plus&view=watchlist&Itemid='.$Itemid, $msg );
	}


	static function getUserProfile($user_id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__user_profiles').' AS a');
		$query->select('a.profile_value AS address1');
		$query->select('b.profile_value AS address2');
		$query->select('c.profile_value AS city');
		$query->select('d.profile_value AS region');
		$query->select('e.profile_value AS postcode');
		$query->select('f.profile_value AS country');
		$query->select('g.profile_value AS phone');
		$query->join('LEFT', '#__user_profiles AS b ON b.user_id = a.user_id AND b.profile_key = \'profile.address2\'');
		$query->join('LEFT', '#__user_profiles AS c ON c.user_id = a.user_id AND c.profile_key = \'profile.city\'');
		$query->join('LEFT', '#__user_profiles AS d ON d.user_id = a.user_id AND d.profile_key = \'profile.region\'');
		$query->join('LEFT', '#__user_profiles AS e ON e.user_id = a.user_id AND e.profile_key = \'profile.postcode\'');
		$query->join('LEFT', '#__user_profiles AS f ON f.user_id = a.user_id AND f.profile_key = \'profile.country\'');
		$query->join('LEFT', '#__user_profiles AS g ON g.user_id = a.user_id AND g.profile_key = \'profile.phone\'');
		$query->where('a.user_id ='.$user_id.' AND a.profile_key = \'profile.address1\'');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		if($rows){
			return $rows[0];
		}else{
			return null;
		}
	}
}
?>