(function($)
{
	$(document).ready(function()
	{

		$("#bfsurvey_category_id").change(function() {
            var value = $(this).val();

            //reset all the options in the fields multi select box
            var select = document.getElementById("fields");
            select.options.length = 0;

            var condition_field1 = document.getElementById("condition_field1");
            condition_field1.options.length = 0;

            var condition_field2 = document.getElementById("condition_field2");
            condition_field2.options.length = 0;


            $.ajax({
            	type: "GET",
                url: "index.php?option=com_bfsurvey&view=report&task=fields&format=json",
                data: "id="+value,
                dataType: 'json',
                error: function (xhr, status, error) {
                	if(value>0){
                		alert(error);
                        alert(status);
                        alert(xhr.responseText);
                    }else{
                        // do nothing
                    }
                },
                success: function(data){
                    //now populate the new options
                	for (var i=1;i<Object.keys(data).length;i++)
                	{
                		select.options.add(new Option(data[i], data[i]));
                		condition_field1.options.add(new Option(data[i], data[i]));
                		condition_field2.options.add(new Option(data[i], data[i]));
                	}

                	$("#fields").val('').trigger("liszt:updated");
                	$("#condition_field1").val('').trigger("liszt:updated");
                	$("#condition_field2").val('').trigger("liszt:updated");
                }
            });

	    });

	});

})(jQuery);
