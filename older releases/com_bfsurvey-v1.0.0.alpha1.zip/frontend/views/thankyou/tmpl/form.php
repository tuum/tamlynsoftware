<?php
/**
 * @package		bfsurvey
 * @copyright	Copyright (c)2014 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

include_once JPATH_SITE.'/components/com_bfsurvey/models/thankyou.php';
$id = JRequest::getVar( 'id', 0, '', 'int' );
$result = BfsurveyModelThankyou::getThankyou();
$msg = $result->thankyouText;

$app = JFactory::getApplication();
if($result->redirectURL != "")
{
	$app->redirect( JRoute::_($result->redirectURL, false), $msg );
}

?>
<div class="hero-unit">
	<p><?php echo ($msg=='' ? JText::_('COM_BFSURVEY_THANKYOU_MSG_BODY'): $msg) ?></p>
	<?php if($result->showReferenceNo && $id>0){ ?>
		<p><?php echo JText::_('COM_BFSURVEY_THANKYOU_REFERENCE_NO').(int)$id; ?></p>
	<?php } ?>
</div>