<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

$params =& JFactory::getApplication()->getParams();
$slug=$params->get('slug');
?>
<?php if($slug):?>
<?php echo $this->loadAnyTemplate('site:com_bfsurvey/'.$slug.'result/form'); ?>
<?php endif; ?>

<?php echo $this->form ?>