<?php
/*
 * @package BF Survey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfsurveyModelSurvey extends FOFModel
{
	public static function getCategoryAccess($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('access');
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	public static function getCategoryAccessResults($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('accessResults');
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}
}