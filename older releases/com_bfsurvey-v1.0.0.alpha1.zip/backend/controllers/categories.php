<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class bfsurveyControllerCategories extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'categories';
	}

	public function fixDatabase()
	{
		$this->setRedirect( 'index.php?option=com_bfsurvey&view=categories' );
		require_once JPATH_COMPONENT.'/helpers/answertable.php';

		$errors = answerTable::buildAnswerTables();
		if($errors){
			JError::raiseWarning(100, $errors);
		}else{
			$this->setMessage( JText::_( 'COM_BFSURVEY_DATABASE_FIXED' ) );
		}
	}
}