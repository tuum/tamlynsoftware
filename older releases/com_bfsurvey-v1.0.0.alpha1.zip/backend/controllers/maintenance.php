<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class bfsurveyControllerMaintenance extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'maintenance';
	}

	public function execute($task) {
		if(!in_array($task, array('change', 'backup', 'import'))) $task = 'browse';
		parent::execute($task);
	}

	function change()
	{
		$model = $this->getThisModel();

		$result = $model->performChanges();
		$url = 'index.php?option=com_bfsurvey&view=maintenance';
		if($result !== true) {
			$this->setRedirect($url, $result, 'error');
		} else {
			$this->setRedirect($url, JText::sprintf('COM_BFSURVEY_FINISHED_DB_CLEANUP', ''));
		}

		$this->redirect();
	}

	function backup()
	{
		$model = $this->getThisModel();

		$result = $model->dbbackup();
	}

	function import()
	{
		$model = $this->getThisModel();

		$result = $model->import();
	}
}