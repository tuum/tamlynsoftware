<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class bfsurveyControllerQuestion extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'question';
	}

	public function save()
	{
		parent::save();

		$model = $this->getThisModel();

		$post	= JRequest::get('post');
		$cid	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$config = JComponentHelper::getParams( 'com_bfsurvey' );

		$files  = JRequest::get( 'files' );
		$model->saveImages($post,$files,$config,$model,$cid);

		return true;
	}
}