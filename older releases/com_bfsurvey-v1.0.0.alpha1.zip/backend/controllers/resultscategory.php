<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class bfsurveyControllerResultscategory extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'resultscategory';
	}
}