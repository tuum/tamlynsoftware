<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();
if (version_compare(JVERSION, '3.0.0', 'gt'))
{
	JHtml::_('formbehavior.chosen', 'select');
}
$viewTemplate = $this->getRenderedForm();
echo $viewTemplate;

?>