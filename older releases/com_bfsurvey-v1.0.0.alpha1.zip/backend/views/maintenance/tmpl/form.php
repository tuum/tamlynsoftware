<?php
/**
 * @package		bfsurvey
 * @copyright	Copyright (c)2014 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

//echo $this->renderLinkbar();
?>

<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSURVEY_DATABASE_CLEANUP_WARNING1'); ?></p>
	<p><?php echo JText::_('COM_BFSURVEY_DATABASE_CLEANUP_WARNING2'); ?></p>
</div>

<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="backup" />
	<input type="hidden" name="format" value="raw" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_BACKUP'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_BACKUP_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-primary btn-large" value="<?php echo JText::_('COM_BFSURVEY_DATABASE_BACKUP_BUTTON') ?>" />
	</div>
</form>

<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="change" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_CLEANUP'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_CLEANUP_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-warning btn-large" value="<?php echo JText::_('COM_BFSURVEY_AUTO_DATABASE_CLEANUP') ?>" />
	</div>
</form>

<?php
	//does jos_bfsurvey_plus table exist?
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);

	$app = JFactory::getApplication();

	$mytables = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfsurvey_plus", $mytables)) {
?>
<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="import" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_IMPORT'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_IMPORT_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-inverse" value="<?php echo JText::_('COM_BFSURVEY_IMPORT_BUTTON') ?>" />
	</div>
</form>
<?php } //end if ?>