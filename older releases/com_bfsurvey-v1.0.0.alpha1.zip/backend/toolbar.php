<?php
/**
 *  @package BFSurvey
*  @copyright Copyright (c)2014 Tamlyn Software
*  @license GNU General Public License version 3, or later
*/

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyToolbar extends FOFToolbar
{
	public function onQuestionsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolBarHelper::custom('copy', 'copy.png', 'copy_f2.png', 'JLIB_HTML_BATCH_COPY', false);
		JToolBarHelper::custom( 'fixDatabase', 'refresh', 'refresh', 'COM_BFSURVEY_TOOLBAR_FIX_DATABASE', false );
		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onQuestionsEdit()
	{
		parent::onEdit();

		$question=$this->input->getdata();

		JToolBarHelper::divider();
		JToolbarHelper::versions('com_bfsurvey.question', $question["id"]);
	}

	public function onCategoriesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolBarHelper::custom( 'fixDatabase', 'refresh', 'refresh', 'COM_BFSURVEY_TOOLBAR_FIX_DATABASE', false );
		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onEmailitemsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onReportsBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onResultscategoriesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function onMaintenancesBrowse()
	{
		$this->onBrowse();

		JToolBarHelper::divider();
		JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_bfsurvey&view=cpanels');
	}

	public function on1resultsEdit()
	{
		parent::onEdit();

		$result=$this->input->getdata();

		JToolBarHelper::divider();
		JToolbarHelper::versions('com_bfsurvey.1result', $result["id"]);
	}
}