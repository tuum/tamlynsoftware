<?php
defined('_JEXEC') or die();

class BfauctionViewConfirmbids extends F0FViewForm
{
	public function display($tpl = null)
	{
		$id = $this->input->get('cid');
		$this->cparams  = bfauctionHelper::getOptions($id);

		$model = $this->getModel();
		$this->lastbid	= $model->getLastBidData();

		$user = JFactory::getUser();
		$this->profile	= $model->getUserProfile($user->id);

		parent::display($tpl);
	}
}