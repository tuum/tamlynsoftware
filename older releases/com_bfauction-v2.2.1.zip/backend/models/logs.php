<?php
defined('_JEXEC') or die();

class BfauctionModelLogs extends F0FModel
{
	public function buildQuery($overrideLimits = false)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('a.bfauction_log_id as id, b.username, a.site, a.visitDate, a.login');
		/*
		$query->select("CONCAT_WS(',',
  IF(FIND_IN_SET('0', a.site), '".JText::_( 'COM_BFAUCTION_TITLE_INACTIVE' )."', NULL),
  IF(FIND_IN_SET('1', a.site), '".JText::_( 'COM_BFAUCTION_TITLE_BACKEND' )."', NULL),
  IF(FIND_IN_SET('2', a.site), '".JText::_( 'COM_BFAUCTION_TITLE_FRONTEND' )."' , NULL)
) AS site");
		$query->select("CONCAT_WS(',',
  IF(FIND_IN_SET('0', a.login), '".JText::_( 'COM_BFAUCTION_TITLE_INACTIVE' )."', NULL),
  IF(FIND_IN_SET('1', a.login), '".JText::_( 'COM_BFAUCTION_TITLE_LOGIN' )."', NULL),
  IF(FIND_IN_SET('2', a.login), '".JText::_( 'COM_BFAUCTION_TITLE_LOGOUT' )."' , NULL)
) AS login");
		*/
		$query->from('#__bfauction_logs AS a');
		$query->join('LEFT', '#__users AS b ON b.id = a.created_by');
		return $query;
	}
}