<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>

<form action="<?php echo JURI::base(); ?>index2.php?option=com_bfsurvey_pro&task=showlist" id="listForm" method="post" enctype="multipart/form-data" onsubmit="getFields()">

<?php
				$tempfield=$_SESSION['tempfield'];
				$query=$_SESSION['query'];

				$page_no=$_SESSION['page_no'];
				$page_no=$page_no-1;
				$fieldName=$_SESSION['field_name'.$page_no];


			    $mylists="";

		   	   if($query != ""){
   				   $mySQLitems =& BFSurveyProController::getSQL($query);

   				   $n2=count( $mySQLitems );
   				   for($z=0; $z < $n2; $z++)
   				   {
   				      $myoption = ereg_replace(" ", "_", $mySQLitems[$z]->$tempfield);
   				      $mylists.=$myoption."^";
   				   }

   				}else{
   				   for($z=0; $z < 10; $z++)
   				   {
   				       $tempvalue="option".($z+1);
   				       if($row->$tempvalue != ""){
   				           $mylists.=$row->$tempvalue."^";
   				       }
   	               }
 	            }

				?>

 	            <script language=javascript>

				// get variable from php
				var whatever = "<?php echo $mylists ?>";

				var from_array = new Array();
				from_array = whatever.split('^');

				var to_array = new Array(); 		  // this array has the values for the destination list(if any)
				</script>

				<script language=javascript>
				function moveoutid()
				{
					var sda = document.getElementById('xxx');;
					var len = sda.length;
					var sda1 = document.getElementById('yyy');

					for(var j=0; j<len; j++)
					{
						if(sda[j].selected)
						{
							var tmp = sda.options[j].text;
							var tmp1 = sda.options[j].value;
							sda.remove(j);
							j--;
							var y=document.createElement('option');
							y.text=tmp;
							y.value=tmp1;
							//alert(tmp1);
							try
							{sda1.add(y,null);
							}
							catch(ex)
							{
							sda1.add(y);
							}
						}

					}

				}

				function getFields(){
					var input = document.getElementById("<?php echo $fieldName; ?>");
					var sda1 = document.getElementById('yyy');
					var len = sda1.length;
					var temp = '';

					for(var j=0; j<len; j++)
					{
						if(j==0){
						   temp=sda1.options[j].value;
						}else{
						   temp=temp+", "+sda1.options[j].value;
						}
					}

					input.setAttribute("value", temp);
				}


				function moveinid()
				{
					var sda = document.getElementById('xxx');
					var sda1 = document.getElementById('yyy');
					var len = sda1.length;
					for(var j=0; j<len; j++)
					{
						if(sda1[j].selected)
						{
							var tmp = sda1.options[j].text;
							var tmp1 = sda1.options[j].value;
							sda1.remove(j);
							j--;
							var y=document.createElement('option');
							y.text=tmp;
				 			y.value=tmp1;
							try
							{
							sda.add(y,null);}
							catch(ex){
							sda.add(y);
							}

						}
					}
				}
				</script>

		        <table border=0 align=center valign=center>
				<tr><td><?php echo JText::_('COM_BFSURVEYPRO_AVAILABLE'); ?></td><td></td><td><?php echo JText::_('COM_BFSURVEYPRO_SELECTED'); ?></td></tr>
				<tr><td>
				<select id="xxx" name="xxx" multiple size=15 style="width:100;">
				<script language=javascript>
				for(var i=0;i<from_array.length;i++)
				{
					document.write('<option value='+from_array[i]+'>'+from_array[i]+'</option>');
				}
				</script>
				</select>
				</td>
				<td>
				<input type=button value=">>" onclick=moveoutid()>
				<input type=button value="<<" onclick=moveinid()>
				</td>
				<td>
				<select name="yyy" id="yyy" multiple size=15 style="width:100;">
				<script language=javascript>
				for(var j=0;j<to_array.length;j++)
				{
					document.write('<option value='+to_array[j]+'>'+to_array[j]+'</option>');
				}
				</script>

				</select>

				</td></tr>
				</table>

				<input name='<?php echo $fieldName; ?>' id='<?php echo $fieldName; ?>' type="hidden">

    <br>
	<center><input name="Submit" type="submit" id="Submit" value="<?php echo JText::_('COM_BFSURVEYPRO_NEXT'); ?>" /></center>
</form>
