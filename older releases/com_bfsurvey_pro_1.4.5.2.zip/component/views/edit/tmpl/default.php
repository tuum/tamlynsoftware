<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 4 2012-01-09 12:57:12Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
$row2 = &$this->items2[0];

$session =& JFactory::getSession();
if($session->has('readOnly')){
	$readOnly=$session->get('readOnly');
}else{
	$readOnly=1;  // default to yes
}

$config =& JComponentHelper::getParams( 'com_bfsurvey_pro' );

$introText = $config->get( 'introText' );
$surveyTitle = $config->get( 'surveyTitle' );
$thankyouText = $config->get( 'thankyouText' );
$emailText = $config->get( 'emailText' );
$nameText = $config->get( 'nameText' );
$allowEmail = $config->get( 'allowEmail' );
$sendEmailTo = $config->get( 'sendEmailTo' );
$_SESSION['sendEmailTo']=$sendEmailTo;

$emailSubject = $config->get( 'emailSubject' );
$emailBody = $config->get( 'emailBody' );
$submitText = $config->get( 'submitText' );

$anonymous = $config->get( 'anonymous' );
$anonymousText = $config->get( 'anonymousText' );
$anonymousYes = $config->get( 'anonymousYes' );
$anonymousNo = $config->get( 'anonymousNo' );
$nameText = $config->get( 'nameText' );
$companyText = $config->get( 'companyText' );
$emailText = $config->get( 'emailText' );

$showName = $config->get( 'showName' );
$showCompany = $config->get( 'showCompany' );
$showEmail = $config->get( 'showEmail' );

$errorText = $config->get( 'errorText' );
$use_captcha = $config->get( 'use_captcha' );

$redirectURL = $config->get( 'redirectURL' );

$registeredUsers = $config->get( 'registeredUsers' );
$preventMultiple = $config->get( 'preventMultiple' );
$preventMultipleEmail = $config->get( 'preventMultipleEmail' );

//initialise some variables
$user="";
$emailcount=0;
$summation_counter = 0;

if($anonymous == ""){
   $anonymous = "1";
}

if($showName == ""){
   $showName = "1";
}

if($showCompany == ""){
   $showCompany = "1";
}

if($showEmail == ""){
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );
$Itemid = JRequest::getVar( 'Itemid', 0, '', 'int' );


if($catid == 0){
   die( JText::_("COM_BFSURVEYPRO_ERROR_MUST_SELECT_CATEGORY"));
}

$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".$catid;

$ip = BFSurveyProController::getIP();
$ipcount = BFSurveyProController::checkIP($table,$ip);

$total_qns=count( $this->items );

?>

<script language="Javascript">
<!--
   // get variable from php
   var showName = "<?php echo $showName ?>";
   var showCompany = "<?php echo $showCompany ?>";
   var showEmail = "<?php echo $showEmail ?>";
   var toggle = 1;
   var othertoggle = 0;

   function ToggleDetails(){
   		if(toggle == 1){
   		   // hide details
   		   if(showName=="1"){
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		   }

		   if(showCompany=="1"){
		      document.getElementById("MyCompany").style.display = 'none';
              document.getElementById("company").className = 'none';
           }

           if(showEmail=="1"){
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1"){
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		   }

		   if(showCompany=="1"){
   		      document.getElementById("MyCompany").style.display = '';
              document.getElementById("company").className = 'required';
		   }

		   if(showEmail=="1"){
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
           }
		   toggle=1;
        }
   }

   function MakeOtherMandatory(fieldname, z){
      myid = fieldName + z +'_other';
      if(othertoggle == 1){
	      // hide details
	      document.getElementById(myid).className = 'none';
	      othertoggle=0;
	  }else{
	      document.getElementById(myid).className = 'required';
	      othertoggle=1;
	  }
   }

//-->
</script>



<?php
// Check that the class exists before trying to use it
if (class_exists('BFBehavior')) {
 BFBehavior::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f)) {
	    f.check='';
		f.check.value='<?php echo JUtility::getToken(); ?>';//send token
		return true;
	}
	else {
		alert( '<?php echo addslashes($errorText) ?>' );
	}
	return false;
}
function imposeMaxLength(Event, Object, MaxLen)
{
   return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40));
}
</script>

<?php
$user = &JFactory::getUser();
 if($registeredUsers == "1"){
    $emailcount = BFSurveyProController::checkEmail($table,$user->email);
 }

 if (($user->id) | $registeredUsers != "1") {  // test if registerd users only

 	if($ipcount < 1 | $preventMultiple != "1"){  // check if IP address has already completed survey

       if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed survey


?>

<form  method="POST" name="poll" id="poll" class="form-validate" onSubmit="return myValidate(this);">

<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="table" value="<?php echo $table ?>" />
<input type="hidden" name="preventMultipleEmail" value="<?php echo $preventMultipleEmail ?>" />
<input type="hidden" name="qid" value="<?php echo $row2->id ?>" />

<table >
	<thead>
		<tr>
			<th>
				<div class="bfsurvey_proTitle"><?php echo JText::_( $surveyTitle ); ?></div>
			</th>
		</tr>
	</thead>

<tr>
    <td>
    <div class="bfsurvey_proIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="bfsurvey_proQuestionFooter">
	</div>
    </td>
</tr>

<?php if($showName == "1" & $readOnly!=1){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table>
       <tr>
           <td>
               <div class="BFSurveyCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="BFSurveyCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table>
        <tr>
            <td width="70">
                <div class="BFSurveyCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="BFSurveyCustomerOptions">
                <?php if($readOnly){
                		echo $row2->Name;
                	}else{
                	?>
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $row2->Name; ?>' >
                <?php } ?>
                </div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php } ?>

<?php if($showCompany == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyCompany">
        <table>
	       <tr>
	           <td width="70">
	               <div class="BFSurveyCustomerQuestion">
	               <?php echo JText::_( $companyText ); ?>
	               </div>
	           </td>
	           <td>
	               <div class="BFSurveyCustomerOptions">
                	<?php if($readOnly){
                		echo $row2->Company;
                	}else{
                	?>
	               <input name="company" id="company" size='55' <?php echo 'class="required"'; ?> value='<?php echo $row2->Company; ?>' >
	               <?php } ?>
	               </div>
	           </td>
	       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php } ?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table>
		       <tr>
		           <td width="70">
		               <div class="BFSurveyCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="BFSurveyCustomerOptions">
                		<?php if($readOnly){
                			echo $row2->Email;
                		}else{
                		?>
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $row2->Email; ?>' >
		               <?php } ?>
		               </div>
		           </td>
		       </tr>
       </table>
       </DIV>
       <hr>
    </th>
</tr>
<?php } ?>

<tr>
<td>
<?php if ($use_captcha) {
	// Check that the class exists before trying to use it
	if (class_exists('plgSystemBigocaptcha')) {
	?>
	<!-- Bigo Captcha -->
	<img src="index.php?option=com_bfsurvey_pro&task=displaycaptcha&catid=<?php echo $catid; ?>&use_captcha=<?php echo $use_captcha; ?>">
	<br />
	<input type="text" name="word"/><br>
	<?php
	   echo JText::_("COM_BFSURVEYPRO_INPUT_WORD_FROM_IMAGE");
	}else{
	   echo JText::_( "COM_BFSURVEYPRO_ERROR_INSTALL_CAPTCHA");
	}
	?>
<?php } ?>
</td>
</tr>

<?php
$k = 0;

for ($i=0; $i < $total_qns; $i++)
{
	$row = &$this->items[$i];
	$fieldName = $row->field_name;

    if($fieldName != NULL){
    $tempanswer = $row2->$fieldName;
?>


    <input id="field_name" name="field_name" type="hidden" value="<?php echo $row->field_name; ?>">

	<tr>
	    <th>
	       <div class="bfsurvey_proQuestion"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<tr>
	    <th>
		   <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="bfsurvey_proOptions">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == ""){
	          // do nothing
	       }else{
	          echo JHTML::_('content.prepare', $row->helpText);
	          echo "<br>";
	       }

	       if(!isset($row->prefix)){
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix)){
	          $row->suffix = "";
	       }

	       $sequence = $row->id;

	       if($row->question_type == "0"){  //text
	           $mylength="65";
			   if($row->fieldSize < 65){
			      $mylength=$row->fieldSize;
	           }
	           if($row->mandatory){
	           	  if($row->suppressQuestion != "1"){
	           	  	if($readOnly){
	           	  		echo JText::_($row->prefix);
	           	  		echo JText::_($tempanswer);
	           	  		echo JText::_($row->suffix);
	           	  	}else{
	              		echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"required\" value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	           	  	}
	           	  }else{
	              	?>
		            <div class="BFSurveyProSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="BFSurveyProSuppressOptions">
	                <?php
	               	  	if($readOnly){
	           	  			echo JText::_($row->prefix);
	           	  			echo JText::_($tempanswer);
	           	  			echo JText::_($row->suffix);
	           	  		}else{
	        	      		echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"required\" value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	           	  		}
	                 ?>
	                 </div>
       			  <?php
	           	  }
	           }else{
	           	  if($row->suppressQuestion != "1"){
	           	  	if($readOnly){
	           	  		echo JText::_($row->prefix);
	           	  		echo JText::_($tempanswer);
	           	  		echo JText::_($row->suffix);
	           	  	}else{
	              		echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	           	  	}
	           	  }else{
	              	?>
	                <div class="BFSurveyProSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="BFSurveyProSuppressOptions">
	                <?php
	           		if($readOnly){
	           	  		echo JText::_($row->prefix);
	           	  		echo JText::_($tempanswer);
	           	  		echo JText::_($row->suffix);
	           	  	}else{
	              		echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." value='".JText::_($tempanswer)."'> ".JText::_($row->suffix);
	           	  	}
	                ?>
	                </div>
       			  <?php
	           	  }
	           }
	       }else if($row->question_type == "1"){  // Radio

			   $tempfield=$row->sqlfield;

		       if($row->sql != ""){
		   		   $mySQLitems =& BFSurveyProController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );
		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  $tempvalue="option".($z+1);
					  if($SQLrow->$tempfield != ""){
	                     if($row->mandatory & class_exists('BFBehavior')){
	                        ?>
					        <?php echo JText::_($row->prefix); ?>
					        <label for="<?php echo $fieldName; ?><?php echo $z; ?>" ><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($SQLrow->$tempfield); ?>" class="required validate-radio" <?php if(JText::_($SQLrow->$tempfield) == JText::_($tempanswer)) echo "CHECKED"; ?><?php if($readOnly) echo "disabled"; ?> >
					        <?php echo JText::_($SQLrow->$tempfield); ?></label>
					        <?php echo JText::_($row->suffix); ?>
					        <?php
					     }else{
					        ?>
					        <?php echo JText::_($row->prefix); ?>
					        <label for="<?php echo $fieldName; ?><?php echo $z; ?>"><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($SQLrow->$tempfield); ?>" <?php if(JText::_($SQLrow->$tempfield) == JText::_($tempanswer)) echo "CHECKED"; ?><?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($SQLrow->$tempfield); ?></label><?php echo JText::_($row->suffix); ?>
					        <?php
			  		     }
						 if($row->horizontal == "1"){
 				    	     echo "&nbsp;&nbsp;&nbsp;";
			   	    	 }else{
			   	    	     echo "<br>";
		   		   	 	 }
			  		  }
		   		   }

				}else{

					if($row->horizontal == "1"){
					   $myclass="bfradiohorizontal";
					}else{
					   $myclass="bfradio";
					}

					$myother=0;
					//figure out if other should be selected
					for($z=0; $z < 20; $z++)
	       		    {
	       		    	$tempvalue="option".($z+1);
	       		    	if($row->$tempvalue == $tempanswer) {
	       		    		$myother++;
	       		    	}
	       		    }
	       		    if($tempanswer == ""){
	       		    	$myother=0;
	       		    }

	       		    for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);
	       		        $tempfield=$row->field_name;
	       		        if($row->$tempvalue != ""){
	       		            if($row->$tempvalue == "_OTHER_"){
	       		               if($row->mandatory & class_exists('BFBehavior')){
	       		                  ?>
	       		                  <?php echo $row->prefix; ?>
	       		                  <label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo $row->$tempvalue; ?>" class="required validate-radio" onchange="MakeOtherMandatory('<?php echo $fieldName; ?>','<?php echo $z; ?>')" <?php if($myother == 0) echo "CHECKED"; ?><?php if($readOnly) echo "disabled"; ?> ><?php echo $row->otherprefix; ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>'_other" name="<?php echo $fieldName; ?>_OTHER_" value="<?php if($myother == 0) echo $row2->$tempfield; ?>"><?php echo $row->othersuffix; ?>
	       		                  <?php echo $row->suffix; ?>
	       		                  <?php
	       		               }else{
	       		                  ?>
	       		                  <?php echo $row->prefix; ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo $row->$tempvalue; ?>" <?php if($myother == 0) echo "CHECKED"; ?> ><?php echo $row->otherprefix; ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>_OTHER_" <?php if($readOnly) echo "disabled"; ?> value="<?php if($myother == 0) echo $row2->$tempfield; ?>"><?php echo $row->othersuffix; ?><?php echo $row->suffix; ?>
	       		                  <?php
	       		               }
	       		            }else{
				  				if($row->mandatory & class_exists('BFBehavior')){
				  				   ?>
	       		   				   <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName;?><?php echo $z;?>" class='<?php echo $myclass; ?>'><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
	       		   				   <?php
				  				}else{
				  				   ?>
				  				   <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "CHECKED"; ?><?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
				  				   <?php
				  				}
			  				}
							if($row->horizontal == "1"){
 					    	    echo "&nbsp;&nbsp;&nbsp;";
				   	    	}else{
				   	    	    echo "<br>";
			   		   	 	}
	       	        	}
	       	     	}
	           }

	       }else if($row->question_type == "2"){  // Checkbox
			   $tempfield=$row->sqlfield;

		       if($row->sql != ""){
		   		   $mySQLitems =& BFSurveyProController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );
		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  if($SQLrow->$tempfield != ""){
					  	if($row->mandatory & class_exists('BFBehavior')){
					  	   ?>
					  	   <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>"><input type="checkbox" name="<?php echo $fieldName;?>[]" value="<?php echo JText::_($SQLrow->$tempfield); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" class="required validate-checkbox" <?php if(strpos(JText::_($tempanswer),JText::_($SQLrow->$tempfield))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($SQLrow->$tempfield); ?></label><?php echo JText::_($row->suffix); ?>
					  	   <?php
					  	}else{
					  	   ?>
					  	   <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>"><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($SQLrow->$tempfield); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" <?php if(strpos(JText::_($tempanswer),JText::_($SQLrow->$tempfield))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($SQLrow->$tempfield); ?></label><?php echo JText::_($row->suffix); ?>
					  	   <?php
			  		  	}
						if($row->horizontal == "1"){
 				    	    echo "&nbsp;&nbsp;&nbsp;";
			   	    	}else{
			   	    	    echo "<br>";
		   		   	 	}
			  		  }
		   		   }

				}else{

					if($row->horizontal == "1"){
					   $myclass="bfradiohorizontal";
					}else{
					   $myclass="bfradio";
					}

			   	   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
	   	               if($row->$tempvalue != ""){
	   	                   if($row->$tempvalue == "_OTHER_"){
		                       if($row->mandatory & class_exists('BFBehavior')){
		                          ?>
					   	          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-checkbox" onchange="MakeOtherMandatory('<?php echo $fieldName; ?>','<?php echo $z; ?>')" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->otherprefix); ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>_other" name="<?php echo $fieldName; ?>_OTHER_"><?php echo JText::_($row->othersuffix); ?><?php echo JText::_($row->suffix); ?>
					   	          <?php
					   	       }else{
					   	          ?>
					   	          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->otherprefix); ?></label><input id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?>_OTHER_"><?php echo JText::_($row->othersuffix); ?><?php echo JText::_($row->suffix); ?>
					   	          <?php
					   	       }
	       		            }else{
				   	           if($row->mandatory & class_exists('BFBehavior')){
				   	              ?>
	   	                          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" class="required validate-checkbox" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
	   	                          <?php
				   		       }else{
				   		          ?>
	   	                          <?php echo JText::_($row->prefix); ?><label for="<?php echo $fieldName; ?><?php echo $z; ?>" class='<?php echo $myclass; ?>'><input type="checkbox" name="<?php echo $fieldName; ?>[]" value="<?php echo JText::_($row->$tempvalue); ?>" id="<?php echo $fieldName; ?><?php echo $z; ?>" <?php if(strpos(JText::_($tempanswer),JText::_($row->$tempvalue))!==FALSE) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->$tempvalue); ?></label><?php echo JText::_($row->suffix); ?>
	   	                          <?php
				   		       }
				   		    }
							if($row->horizontal == "1"){
	 				    	    echo "&nbsp;&nbsp;&nbsp;";
				   	    	}else{
				   	    	    echo "<br>";
			   		   	 	}
	   	               }
	   	           }
	           }
	       }else if($row->question_type == "3"){  // Textarea
	       	   if($readOnly){
	       	   		echo JText::_($row->prefix);
	       	   		echo JText::_($tempanswer);
	       	   		echo JText::_($row->suffix);
	       	   }else{
		           if($row->mandatory){
			          echo JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" class="'.$row->validation_type.'" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');">'.JText::_($tempanswer).'</textarea> '.JText::_($row->suffix);
			       }else{
		    	      echo JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');">'.JText::_($tempanswer).'</textarea> '.JText::_($row->suffix);
		           }
	       	   }
	       }else if($row->question_type == "5"){  // date

	       		if($readOnly){
                	echo $tempanswer;
                }else{
 					$document = &JFactory::getDocument();
   					$document->addScript("includes/js/joomla.javascript.js");

	            	JHTML::_('behavior.calendar');

	            	echo ''.$row->prefix.'<input class="inputbox" type="text" id="'.$fieldName.'" name="'.$fieldName.'" size="10" maxlength="25" value="'.$tempanswer.'" />';
					echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\''.$fieldName.'\',\'%d-%m-%Y\');" /> '.$row->suffix.'';
                }
	       }else if($row->question_type == "6"){  // dropdown

				$tempfield=$row->sqlfield;

				if($readOnly){
					echo ''.JText::_($row->prefix).'<select id="'.$fieldName.'" name="'.$fieldName.'" "disabled">';
				}else{
	            	echo ''.JText::_($row->prefix).'<select id="'.$fieldName.'" name="'.$fieldName.'" >';
				}
				?>

	            <option value="-1"><?php echo JText::_('COM_BFSURVEYPRO_PLEASE_SELECT'); ?></option>

				<?php
				if($row->sql != ""){
				   $mySQLitems =& BFSurveyProController::getSQL($row->sql);
				   $this->assignRef( 'SQLitems', $mySQLitems );
				   $n2=count( $mySQLitems );
				   for($z=0; $z < $n2; $z++)
				   {
				      $SQLrow = &$this->SQLitems[$z];
				      ?>
				      <option value="<?php echo JText::_($SQLrow->$tempfield); ?>" <?php if(JText::_($SQLrow->$tempfield) == JText::_($tempanswer)) echo "selected"; ?> ><?php echo JText::_($SQLrow->$tempfield); ?></option>
				      <?php
				   }

				}else{
				   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
				       if($row->$tempvalue != ""){
				       ?>
				           <option value="<?php echo JText::_($row->$tempvalue); ?>" <?php if(JText::_($row->$tempvalue) == JText::_($tempanswer)) echo "selected"; ?> ><?php echo JText::_($row->$tempvalue); ?></option>
				       <?php
				       }
 	               }
 	            }

				echo "</select> ".JText::_($row->suffix);
				}else if($row->question_type == "8"){  // Summation
				    $total = $row->sqlfield;
				    $tempsummation = explode("\n",$tempanswer);

					$num=0;
					echo "<table>";
				    for($z=0; $z < 20; $z++)
					{
					    $tempvalue="option".($z+1);
	   	                if($row->$tempvalue != ""){
				 	        echo '<tr><td>'.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'">'.JText::_($row->$tempvalue).'</td><td><input id="'.$fieldName.''.$z.'" name="'.$fieldName.'[]" size="5" value='.$tempsummation[$z].' onchange="updateTotal'.$summation_counter.'()"></label> '.JText::_($row->suffix).'</td></tr>';
				 	        $num++;
				 	    }
					}
					echo "<tr><td></td><td><input id='total".$summation_counter."' name='total' value='".$total."' size='5' READONLY></td></tr>";

					echo "</table>";

					$optionname = ''.$fieldName.'';

					?>

				    <script language="javascript" type="text/javascript">
					<!--
					// get variable from php
   					var total<?php echo $summation_counter; ?> = "<?php echo $total ?>";
   					var num<?php echo $summation_counter; ?> = "<?php echo $num ?>";
   					var optionname<?php echo $summation_counter; ?>="<?php echo $optionname ?>";


   					function updateTotal<?php echo $summation_counter; ?>(){
					   var i=0;
					   var temptotal=0;
					   for (i=0;i<num<?php echo $summation_counter; ?>;i++){
						  tempvalue=optionname<?php echo $summation_counter; ?> + i;
					      temptotal=temptotal + parseInt(document.getElementById(tempvalue).value);
	       			   }

	       				document.getElementById("total<?php echo $summation_counter; ?>").value=total<?php echo $summation_counter; ?>-temptotal;
					}

					updateTotal<?php echo $summation_counter; ?>();

					//-->
					</script>
					<?php
					$summation_counter++;
				}else if($row->question_type == "9"){  // Rating
				 	echo "<table>";
	       		    echo "<tr>";
	       		    echo "<td></td>";

					$mylabels = array();
	       		    if($row->titles == ""){
	       		       // do nothing
	       		    }else{
	       		       $mylabels = split(";",$row->titles);
	       		    }

	       		    for($y=1; $y < $row->sqlfield+1; $y++){
	       		       if($row->titles == ""){
 	       		          echo "<td align='center'>".$y."</td>";
 	       		       }else{
 	       		          if(isset($mylabels[$y-1])){
 	       		             echo "<td  width='50'><center>".JText::_($mylabels[$y-1])."</center></td>";
 	       		          }else{
 	       		             echo "<td align='center'>&nbsp;</td>";
 	       		          }
 	       		       }
	       		    }
	       		    echo "</tr>";

					for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);
						$tempanswer=$fieldName.($z+1);

	       		        if($row->$tempvalue != ""){
	       		           echo "<tr>";
	       		           echo '<td><label for="'.$fieldName.''.$z.'">'.JText::_($row->$tempvalue).'</label></td>';
			  			   if($row->mandatory & class_exists('BFBehavior')){
       		   			      for($y=1; $y < $row->sqlfield+1; $y++){
       		   			         if($row->titles == ""){
       		   			            ?>
       		   			            <td><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="<?php echo $y; ?>" <?php if($readOnly) echo "disabled"; ?> class="required validate-radio" <?php if($row2->$tempanswer == $y) echo "CHECKED"; ?>> <?php echo JText::_($row->suffix); ?></td>
       		   			            <?php
       		   			         }else{
       		   			            if(isset($mylabels[$y-1])){
       		   			               ?>
       		   			               <td><center><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="<?php echo JText::_($mylabels[$y-1]); ?>" <?php if($readOnly) echo "disabled"; ?> class="required validate-radio" <?php if(JText::_($row2->$tempanswer) == JText::_($mylabels[$y-1])) echo "CHECKED"; ?> ><?php echo JText::_($row->suffix); ?></center></td>
       		   			               <?php
       		   			            }else{
       		   			               ?>
       		   			               <td><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="" <?php if($readOnly) echo "disabled"; ?> class="required validate-radio"><?php echo JText::_($row->suffix); ?></td>
       		   			               <?php
       		   			            }
       		   			         }
			  			      }

			  			   }else{
							  for($y=1; $y < $row->sqlfield+1; $y++){

							     if($row->titles == ""){
							        ?>
 							   	    <td><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="<?php echo $y; ?>" <?php if($row2->$tempanswer == $y) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->suffix); ?></td>
 							   	    <?php
 							   	 }else{
 							   	    if(isset($mylabels[$y-1])){
 							   	       ?>
 							   	       <td><center><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="<?php echo JText::_($mylabels[$y-1]); ?>" <?php if(JText::_($row2->$tempanswer) == JText::_($mylabels[$y-1])) echo "CHECKED"; ?> <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->suffix); ?></center></td>
 							   	       <?php
 							   	    }else{
 							   	       ?>
 							   	          <td><?php echo JText::_($row->prefix); ?><input type="radio" id="<?php echo $fieldName; ?><?php echo $z; ?>" name="<?php echo $fieldName; ?><?php echo ($z+1); ?>" value="" <?php if($readOnly) echo "disabled"; ?> ><?php echo JText::_($row->suffix); ?></td>
 							   	       <?php
 							   	    }
 							   	 }
 							  }
		  				   }
		  				   echo "</tr>";
	       	        	}
	       	     	}

	       	     	echo "</table>";

				}

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
	       ?>
	       </div>
	       <div class="bfsurvey_proQuestionFooter">

	       </div>
	    </th>
	</tr>
	<?php


	} // end field is not NULL

	$k = 1 - $k;
}
?>
</table>

<?php
$num=count( $this->items );
?>

<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="Itemid" value="<?php echo $Itemid ?>" />
<input type="hidden" name="task" value="updateOnePage" />
<input type="hidden" name="thankyouText" value="<?php echo $thankyouText ?>" />
<input type="hidden" name="redirectURL" value="<?php echo $redirectURL ?>" />

<?php if($readOnly){
	// don't show submit button
}else{
?>
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
<?php }?>

<?php echo JHTML::_('form.token'); ?>
</form>

<?php

      }else{
  	     echo JText::_( "COM_BFSURVEYPRO_ERROR_EMAIL_ALREADY_COMPLETED");
      }

   }else{
      echo JText::_( "COM_BFSURVEYPRO_ERROR_IP_ALREADY_COMPLETED");
   }

}else{
   echo JText::_( "COM_BFSURVEYPRO_ERROR_YOU_MUST_LOG_IN");
}
?>
