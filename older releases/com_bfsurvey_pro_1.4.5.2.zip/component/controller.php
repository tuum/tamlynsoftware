<?php
/**
 * $Id: controller.php 2 2011-11-15 04:14:12Z tuum $
 * bfsurvey_pro default controller
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');
class BFSurveyProController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

	function attachment()
	{
		JRequest::setVar( 'view', 'Attachment' );
		JRequest::setVar( 'layout', 'default' );

		parent::display();
	}

	function mylist()
	{
		JRequest::setVar( 'view', 'List' );
		JRequest::setVar( 'layout', 'default' );

		parent::display();
	}

	function stats()
	{
		JRequest::setVar( 'view', 'stats' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function sayg()
	{
		JRequest::setVar( 'view', 'sayg' );
		JRequest::setVar( 'layout', 'default' );

		parent::display();
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFSURVEYPRO_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfsurvey_pro', $msg );
	}

	function getQuestions()
	{
	    $db =& JFactory::getDBO();
	    $catid	= JRequest::getVar( 'catid', 0, '', 'int' );

		// get questions
		if($catid == 0)
		{
			$query = 'SELECT b.*,  cc.title AS category_name'
								. ' FROM #__bfsurvey_pro AS b'
								. ' LEFT JOIN #__categories AS cc ON cc.id = b.catid'
								. ' WHERE b.published'
								. ' ORDER BY b.catid, b.ordering'
			;

		} else {
		    $query = "SELECT * FROM #__bfsurvey_pro where catid=".(int)$catid." and published ORDER BY parent, ordering";
		}

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		
		$children = array();
		// first pass - collect children
		foreach ($rows as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$mylist = array();
		foreach ($rows as $v )
		{
		   if ($v->parent==0)
		   {
		      array_push($mylist, $v);

		      //now are there any children
		      if (isset($children[$v->id]))
		      {
		         foreach ($children[$v->id] as $c )
		         {
		            array_push($mylist, $c);
		         }
		      }
		   }
		}

		return $mylist;
		
	}

	function getSQL($query)
	{
	    $db =& JFactory::getDBO();

 	    $db->setQuery( $query );
  		$rows = $db->loadObjectList();
   		if ($db->getErrorNum())
   		{
   			echo $db->stderr();
   			return false;
   		}
		return $rows;
	}

	function getAnswers($id, $catid)
	{
		    $db =& JFactory::getDBO();

			$query = "SELECT * FROM #__bfsurveypro_".(int)$catid." where id='".(int)$id."'";

			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			return $rows;
	}

	function getNextQuestion($question, $response)
	{
		$db =& JFactory::getDBO();

		// get questions
		$catid	= JRequest::getVar( 'catid', 0, '', 'int' );
		if ($catid == 0){
		   $query = "SELECT * FROM #__bfsurvey_pro where id=".(int)$question."";
		} else {
		   $query = "SELECT * FROM #__bfsurvey_pro where catid=".(int)$catid." and id=".(int)$question."";
		}
		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$next_question=0;

		if ($rows[0]->question_type == 0)	// textbox
		{
		   $next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->question_type == 3)	// textarea
		{
			$next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->question_type == 5)	// date
		{
			$next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->option1 == $response)
		{
		   $next_question = $rows[0]->next_question1;
		} else if ($rows[0]->option2 == $response){
		   $next_question = $rows[0]->next_question2;
		} else if ($rows[0]->option3 == $response){
		   $next_question = $rows[0]->next_question3;
		} else if ($rows[0]->option4 == $response){
		   $next_question = $rows[0]->next_question4;
		} else if ($rows[0]->option5 == $response){
		   $next_question = $rows[0]->next_question5;
		} else if ($rows[0]->option6 == $response){
		   $next_question = $rows[0]->next_question6;
		} else if ($rows[0]->option7 == $response){
		   $next_question = $rows[0]->next_question7;
		} else if ($rows[0]->option8 == $response){
		   $next_question = $rows[0]->next_question8;
		} else if ($rows[0]->option9 == $response){
		   $next_question = $rows[0]->next_question9;
		} else if ($rows[0]->option10 == $response){
		   $next_question = $rows[0]->next_question10;
		} else if ($rows[0]->option11 == $response){
		   $next_question = $rows[0]->next_question11;
		} else if ($rows[0]->option12 == $response){
		   $next_question = $rows[0]->next_question12;
		} else if ($rows[0]->option13 == $response){
		   $next_question = $rows[0]->next_question13;
		} else if ($rows[0]->option14 == $response){
		   $next_question = $rows[0]->next_question14;
		} else if ($rows[0]->option15 == $response){
		   $next_question = $rows[0]->next_question15;
		} else if ($rows[0]->option16 == $response){
		   $next_question = $rows[0]->next_question16;
		} else if ($rows[0]->option17 == $response){
		   $next_question = $rows[0]->next_question17;
		} else if ($rows[0]->option18 == $response){
		   $next_question = $rows[0]->next_question18;
		} else if ($rows[0]->option19 == $response){
		   $next_question = $rows[0]->next_question19;
		} else if ($rows[0]->option20 == $response){
		   $next_question = $rows[0]->next_question20;
		}

		if ($rows[0]->question_type == 9)	// rating
		{
			$next_question = $rows[0]->next_question1;
		}

		//for SQL lookup
		if($rows[0]->sql != "" & $rows[0]->sqlfield != ""){
   			$next_question = $rows[0]->next_question1;
		}
		
		//special case for checkbox
		//take the lowest next question id out of those selected
		$check_msg="";
		if ($rows[0]->question_type == 2 & $response != NULL)	// checkbox
		{
			if(isset($response)){
				foreach($response as $value)
         		{
            	   $check_msg .= "$value\n";
           		}
			}
       		$response = $check_msg;
			
			for($i=0; $i < 20; $i++){
	             $myoption="option".($i+1);
	             $mynextquestion="next_question".($i+1);

	             if($rows[0]->$myoption){
	                //does answer contain this option
	                $response=" ".$response;
	                if(strpos(strtoupper($response), strtoupper($rows[0]->$myoption) )){
						//is next question id lower than current?
	                	if($rows[0]->$mynextquestion < $next_question | $next_question==0){
							$next_question=$rows[0]->$mynextquestion;
						}
			  	    }
			  	 }
	          }       		  		
		}		
		
		return $next_question;
	}

	function getQuestion($question)
	{
		$db =& JFactory::getDBO();

		// get question
		$query = "SELECT question FROM #__bfsurvey_pro where id=".(int)$question."";

		$db->setQuery( $query);
		$result=$db->loadResult();

	    return $result;
    }

	function save($name, $company, $email, $table)
	{
	    $db =& JFactory::getDBO();

		// todays date
		$now =& JFactory::getDate();
		$dateReceived = $now->toMySQL();
		$ip = BFSurveyProController::getIP();

		// save data
		$query = "INSERT INTO ".$table." ( `id` , `Name`, `Company`, `Email`, `DateReceived`,`ip`) values ('',".$db->quote( $db->getEscaped( $name ), false ).",".$db->quote( $db->getEscaped( $company ), false ).",".$db->quote( $db->getEscaped( $email ), false ).",".$db->quote( $dateReceived, false).",'$ip')";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return $db->insertid();
	}

	function checkIP($table, $ip)
	{
	   $db =& JFactory::getDBO();

	   $query = "SELECT count(ip) from ".$table." where `ip`='".$ip."'";

	   $db->setQuery( $query);
	   $result=$db->loadResult();

	   return $result;
	}

	function checkEmail($table, $myemail)
	{
	   $db =& JFactory::getDBO();

	   if ($myemail == "")
	   {
	      // don't check anonymous responses
	      return 0;
	   } else {
	      $query = "SELECT count(Email) from ".$table." where `Email`=". $db->quote( $db->getEscaped( $myemail ), false );

	      $db->setQuery( $query);
	      $result=$db->loadResult();

	      return $result;
	   }
	}

	function getField($id, $field_name, $table)
	{
	    $db =& JFactory::getDBO();

		// get answer
		$query = "SELECT `".$field_name."` FROM ".$table." where id=".(int)$id."";

		$db->setQuery( $query);
		$result=$db->loadResult();

	    return $result;
	}

	function saveField($id, $field_name, $answer, $table)
	{
	    $db =& JFactory::getDBO();

		// save data
		$query = 'UPDATE '.$table.' SET `'.$field_name.'`='.$db->quote( $db->getEscaped( $answer ), false ).' where `id`='.(int)$id.'';

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

	function updateOnePage()
	{
	    JRequest::checkToken() or jexit( JText::_( 'COM_BFSURVEYPRO_ERROR_INVALID_TOKEN') );
		//get parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu =& JMenu::getInstance('site');
		$config = & $menu->getParams( $Itemid );

		$use_captcha = $config->get( 'use_captcha' );
		/**
		Captcha
		*/
		$correct=1;
		if ($use_captcha)
		{
	   		$correct=BFSurveyProController::_checkCaptcha();
	   		if (!$correct)
	   		{
	   			JError::raiseWarning("666", JText::_( 'COM_BFSURVEYPRO_ERROR_WRONG_CAPTCHA') );
	   			$page_no=1;
	   			$start_qn = -1;
	   			$end_qn = 0;
	   		} else {
	   		   // captcha is correct
			}
		}

		if ($correct)
		{
			$session =& JFactory::getSession();
		    $allowAuthorEmail = $config->get( 'authorEmail' );

			$fullname = JRequest::getVar( 'fullname', "", 'post', 'string' );
			$company = JRequest::getVar( 'company', "", 'post', 'string' );
			$email = JRequest::getVar( 'email', "", 'post', 'string' );
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".(int)$catid;

			$preventMultipleEmail = JRequest::getVar( 'preventMultipleEmail', "", 'post', 'string' );

			$emailcount = BFSurveyProController::checkEmail($table,$email);

			$user = &JFactory::getUser();

			if ($emailcount < 1 | $preventMultipleEmail != "1")	// check if email address has already completed survey
			{
			//are you using edit view?
			$qid = JRequest::getVar( 'qid', "", 'post', 'string' );
			$id=null;
			if (!empty($qid))
			{
				$id=$qid;
				BFSurveyProController::saveField($id, "Name", $fullname, $table);
				BFSurveyProController::saveField($id, "Company", $company, $table);
				BFSurveyProController::saveField($id, "Email", $email, $table);
			} else {
	    		// save basic details to db, and generate id
				$id = BFSurveyProController::save($fullname, $company, $email, $table);
			}

			//save uid
			BFSurveyProController::saveField($id,"uid", $user->id, $table);

			$items =& BFSurveyProController::getQuestions();

			$total_qns=count( $items );
			$emailBody="";

			for ($i=0; $i < $total_qns; $i++)
			{
		    	$check_msg = "";
				$row = $items[$i];
				$fieldName = $row->field_name;

				if ($row->question_type == 1)	// radio
				{
					if (JRequest::getVar($fieldName) == "_OTHER_")
					{
		         		$temp = $fieldName;
			      	    $temp .= '_OTHER_';
		         		$answer = JRequest::getVar($temp);
		      		} else {
		        	 	$answer = JRequest::getVar($fieldName);
		      		}
		    	} else if ($row->question_type == "2"){	// Checkbox
			   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );
					if ($name == "")
					{
					   //do nothing
					} else {
			   			foreach ($name as $value)
			   			{
			    		   	if ($value == "_OTHER_")
			    		   	{
			    		      	$temp = $fieldName;
			        	        $temp .= '_OTHER_';
						      	$value = JRequest::getVar($temp);
        				   	}
				 			$check_msg .= "$value\n";
				 		}
			   		}
				    $answer = $check_msg;
				} else if ($row->question_type == "8"){	// Summation
			   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );

			   		foreach ($name as $value)
			   		{
					   	$check_msg .= "$value\n";
			   		}
				    $answer = $check_msg;
				} else if ($row->question_type == "9"){   // Rating
				   $emailBody .= "<br>".$row->question.": <br>";
				   for ($z=0; $z < 20; $z++)
				   {
				      $field = $fieldName;
				      $field .= ($z+1);
				      $answer = JRequest::getVar($field);
				      $tempvalue="option".($z+1);

				      if ($answer != "" & $answer != "NULL"){
				         BFSurveyProController::saveField($id, $field, $answer, $table);
				         $emailBody .= "<br>".$row->$tempvalue.": <br>".JText::_("Answer").": ".$answer."<br>";
				      }
				   }

		    		// skip the next bit as we've already done it. '
		    		$answer="";
		    		$fieldName = "";
				} else {
				   $answer = JRequest::getVar($fieldName);
				}

				if ($answer == "")
				{
				    // do nothing
	 	    	} else {
				   $emailBody .= "<br>".$row->question.": <br>".JText::_("COM_BFSURVEYPRO_ANSWER").": ".$answer."<br>";
   				}

				if ($fieldName == "")
				{
				   // do nothing
				} else {
  				   BFSurveyProController::saveField($id, $fieldName, $answer, $table);
  				}
			}

			//------------------------------------ email ------------------------------------------------------------
			$adminEmail = BFSurveyProController::getEmailTemplate("Admin", $catid);
	
			//repace fields with actual data
			$adminEmail[0]->description=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->description); // insert category
			$adminEmail[0]->description=preg_replace('/{name}/', $fullname , $adminEmail[0]->description); // insert name
			$adminEmail[0]->description=preg_replace('/{email}/', $email , $adminEmail[0]->description); // insert email						
			$adminEmail[0]->description=preg_replace('/{company}/', $company , $adminEmail[0]->description); // insert company
			
			$adminEmail[0]->subject=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->subject); // insert category
			$adminEmail[0]->subject=preg_replace('/{name}/', $fullname , $adminEmail[0]->subject); // insert name
			$adminEmail[0]->subject=preg_replace('/{email}/', $email , $adminEmail[0]->subject); // insert email						
			$adminEmail[0]->subject=preg_replace('/{company}/', $company , $adminEmail[0]->subject); // insert company
			
			$subject = $adminEmail[0]->subject;
			$body = $adminEmail[0]->description;
			if($adminEmail[0]->showQuestions == 1){
				$body .= $emailBody;
			}

			$Itemid = JRequest::getVar('Itemid');
			$menu =& JMenu::getInstance('site');
			$config = & $menu->getParams( $Itemid );

   			$allowEmail = $config->get( 'allowEmail' );
   			$sendEmailTo = $config->get( 'sendEmailTo' );
	
   			if($allowEmail){
				BFSurveyProController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);
   			}		

			$authorEmail = BFSurveyProController::getEmailTemplate("Author", $catid);
	
			//repace fields with actual data
			$authorEmail[0]->description=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->description); // insert category
			$authorEmail[0]->description=preg_replace('/{name}/', $fullname , $authorEmail[0]->description); // insert name
			$authorEmail[0]->description=preg_replace('/{email}/', $email , $authorEmail[0]->description); // insert email						
			$authorEmail[0]->description=preg_replace('/{company}/', $company , $authorEmail[0]->description); // insert company
			
			$authorEmail[0]->subject=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->subject); // insert category
			$authorEmail[0]->subject=preg_replace('/{name}/', $fullname , $authorEmail[0]->subject); // insert name
			$authorEmail[0]->subject=preg_replace('/{email}/', $email , $authorEmail[0]->subject); // insert email						
			$authorEmail[0]->subject=preg_replace('/{company}/', $company , $authorEmail[0]->subject); // insert company
			
			$subject = $authorEmail[0]->subject;
			$body = $authorEmail[0]->description;
			if($authorEmail[0]->showQuestions == 1){
				$body .= $emailBody;
			}
   	
			if($allowAuthorEmail == "1" & $email!=""){
				BFSurveyProController::sendHTMLNotificationEmail($body, $email, $subject);
			}
			//------------------------------------ end email ------------------------------------------------------------	

			BFSurveyProController::myRedirect();

			} else {
			   echo JText::_( 'COM_BFSURVEYPRO_ERROR_EMAIL_ALREADY_COMPLETED' );
      		}
      	}
	}

	function myRedirect()
	{
	   $thankyouText = JRequest::getVar( 'thankyouText', "", 'post', 'string' );
	   $redirectURL = JRequest::getVar( 'redirectURL', "", 'post', 'string' );

	   $msg=JText::_( $thankyouText );

	   if ($redirectURL=="")
	   {
	      global $mainframe;
	      $mainframe->enqueueMessage($msg);
	   } else {
		   global $mainframe;
		   $mainframe->redirect( JRoute::_($redirectURL, false), $msg );
	   }
	}
    
	/**
     * Send the notification email at completion of survey
     * 
     * @param string	$body			contents of the email
     * @param string	$sendEmailTo	email address to send to
     * @param string	$emailSubject	subject of the email
     */
    function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
       $conf	=& JFactory::getConfig();

       $mailfrom 	= $conf->getValue('config.mailfrom');
	   $fromname 	= $conf->getValue('config.fromname');

	   $emailBody = $body;
       $mode = 1;

       JUtility::sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
    }        

	function showlist()
	{
		$page_no=$_SESSION['page_no'];
		$page_no=$page_no-1;
		$fieldName=$_SESSION['field_name'.$page_no];

		$input=JRequest::getVar($fieldName);

	    $_SESSION['listvalue']=$input;
	    $tempdisplay = ereg_replace("_", " ", $input);
		$tempdisplay = ereg_replace(", ", "<br>", $tempdisplay);
		echo "<center>";
		?>
		<strong><?php echo JText::_('COM_BFSURVEYPRO_YOU_HAVE_SELECTED'); ?></strong>
		<?php
		echo "<br> ".$tempdisplay."";
		echo "<br><br>";
		?>
		<i><?php echo JText::_('COM_BFSURVEYPRO_BROWSER_REFRESH'); ?></i><br><br>

		<button onClick="window.close();window.parent.location.reload(true);"><?php echo JText::_('Save'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;

		<button onClick="window.location.href='index2.php?option=com_bfsurvey_pro&task=list';"><?php echo JText::_('try again'); ?></button>

<?php
		echo "</center>";
	}

	function getIP()
	{
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip=$_SERVER['REMOTE_ADDR'];
	    }
		return $ip;
	}

	/**
		 * Upload a file
		 *
		 * @since 1.5
		 */
		function upload()
		{
		    $uploadlog = fopen('./upload.log', 'a');

			global $mainframe;

			// Check for request forgeries
			//JRequest::checkToken( 'request' ) or jexit( 'Invalid Token' );

			$file 		= JRequest::getVar( 'Filedata', '', 'files', 'array' );

			//create random folder name
			$folder = md5(time());
       		$folder= rand(0,9999);

			$err		= null;

			// Set FTP credentials, if given
			jimport('joomla.client.helper');
			JClientHelper::setCredentialsFromRequest('ftp');

			// Make the filename safe
			jimport('joomla.filesystem.file');
			$file['name']	= JFile::makeSafe($file['name']);

			if (isset($file['name'])) 
			{
				$filepath = JPath::clean(JPATH_ROOT.DS.'upload'.DS.$folder.DS.$file['name']);

				fputs($uploadlog, 'file: '.$filepath);

				if (!MediaHelper::canUpload( $file, $err )) 
				{
						jimport('joomla.error.log');
						$log = &JLog::getInstance('upload.error.php');
						$log->addEntry(array('comment' => 'Invalid: '.$filepath.': '.$err));
						fputs($uploadlog, 'Invalid: '.$filepath.': '.$err);
						header('HTTP/1.0 415 Unsupported Media Type');
						echo "Error. Unsupported Media Type!";
						//jexit('Error. Unsupported Media Type!');
				}

				if (JFile::exists($filepath)) 
				{
						jimport('joomla.error.log');
						$log = &JLog::getInstance('upload.error.php');
						$log->addEntry(array('comment' => 'File already exists: '.$filepath));
						fputs($uploadlog, 'File already exists: '.$filepath);
						header('HTTP/1.0 409 Conflict');
						echo "Error. File already exists";
						//jexit('Error. File already exists');
				}

				if (!JFile::upload($file['tmp_name'], $filepath)) 
				{
						jimport('joomla.error.log');
						$log = &JLog::getInstance('upload.error.php');
						$log->addEntry(array('comment' => 'Cannot upload: '.$filepath));
						fputs($uploadlog, 'Cannot upload: '.$filepath);
						header('HTTP/1.0 400 Bad Request');
						echo "Error. Unable to upload file";
						//jexit('Error. Unable to upload file');
				} else {
						jimport('joomla.error.log');
						$log = &JLog::getInstance();
						$log->addEntry(array('comment' => $folder));
						fputs($uploadlog, $folder);
						//jexit('Upload complete');
						echo "<br>Upload complete<br>";
						echo "<br>Filename=".$file['name'];
						echo "<br><br>";
						echo "After you close this window, please press your broswer refresh button.";

						$_SESSION['AttachmentName']=$file['name'];
						$_SESSION['AttachmentLocation']='/upload/'.$folder.'/';
				}
			} else {

				Echo "Error. No filename";
			}

		    fclose($uploadlog);
		}

	function getStatsCheckbox($question, $response, $catid)
	{
		$db =& JFactory::getDBO();
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".(int)$catid;

		$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."` like'%".$db->getEscaped( $response, true )."%'";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	function getStats($question, $response, $catid)
	{
			$db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".(int)$catid;

		  	$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."`='". $db->getEscaped( $response, true )."'";

			$db->setQuery( $query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}
			$n = count($rows);
			return $n;

	}

	/**
		Captcha functions!
	*/
	function displaycaptcha()
	{
		global $mainframe;

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 0, '', 'int');

		if ($use_captcha)
		{
			$Ok = null;
			$mainframe->triggerEvent('onCaptcha_Display', array($Ok));
			if (!$Ok)
			{
				echo JText::_('COM_BFSURVEYPRO_ERROR_DISPLAYING_CAPTCHA');
			}
		}
	}

	/**
	@return boolean
	*/
	function _checkCaptcha()
	{
		global $mainframe;

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 1, '', 'int');

		// not using captcha!
		if (!$use_captcha) 
		{
			return true;
		}
		$return = false;
		$word = JRequest::getVar('word', false, '', 'CMD');

		$mainframe->triggerEvent('onCaptcha_confirm', array($word, &$return));
		if ($return)
		{
			return true;
		} else return false;
	}

	function getNumChildren($pid)
	{
	    global $mainframe;
	    $db =& JFactory::getDBO();

		//find out how many children
		$query = 'SELECT COUNT(id) as count'
			. ' FROM #__bfsurvey_pro'
			. ' WHERE published AND parent='.(int)$pid
		;

		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->count;
	}

   function getOption($qid,$myoption)
   {
       $db =& JFactory::getDBO();
      // get data
      $query = "SELECT ".$db->quote( $db->getEscaped( $myoption ), false )." FROM #__bfsurvey_pro where `id`='".(int)$qid."'";
      $db->setQuery( $query );
      $rows = $db->loadObjectList();
      if ($db->getErrorNum())
      {
         echo $db->stderr();
         return false;
      }

      return $rows[0]->$myoption;
   }

	function sendEmailAuthor($body,$author)
	{
       $allowEmail = JRequest::getVar( 'allowEmail', "", 'post', 'string' );

      if ($allowEmail)
      {
          // Send email
         $sendEmailTo = $author;
         $emailSubject = JRequest::getVar( 'emailSubject', "", 'post', 'string' );
         $emailBody = JRequest::getVar( 'emailBody', "", 'post', 'string' );
         BFSurveyProController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
      } else {
         // do nothing
      }
    }

	/**
	* displays the results of completed quiz for currently logged in user
	*/
	function getmysurveys($uid)
	{
		$db =& JFactory::getDBO();

		//get all survey category id numbers
		$query = "SELECT id, title FROM `#__categories` WHERE `section`='com_bfsurvey_pro'";

		$db->setQuery( $query );
		$rows = $db->loadObjectList();

		$query2 = "";

		$i=0;
		foreach ($rows as $row){
		   if ($i==0)
		   {
		      $query2 .= "SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y %H:%i') as DateReceived, DateReceived as DateTimeReceived, '".$db->getEscaped( $row->title )."' AS title, '".(int)$row->id."' AS catid FROM #__bfsurveypro_".(int)$row->id." WHERE uid=".(int)$uid."";
		   } else {
		      $query2 .= " UNION SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y %H:%i') as DateReceived, DateReceived as DateTimeReceived, '".$db->getEscaped( $row->title )."' AS title, '".(int)$row->id."' AS catid FROM #__bfsurveypro_".(int)$row->id." WHERE uid=".(int)$uid."";
		   }
		$i++;
		}

		$query2.=" ORDER BY DateTimeReceived DESC";

		$db->setQuery( $query2);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}

		return $rows2;
	}

	function edit()
	{
		JRequest::setVar( 'view', 'edit' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}
	
	/**
	 * Get the email template based on the name
	 * 
	 * @param 	string 	$title	Name of the email template
	 * 
	 * @return	array	Data for that email tempalte
	 */
	function getEmailTemplate($title, $catid)
    {
       	$db			=& JFactory::getDBO();
			
		$query = 'SELECT a.*,  cc.title AS category_name'
	  			. ' FROM #__bfsurveypro_email AS a'
	  			. ' LEFT JOIN #__categories AS cc ON cc.id = a.catid'
				. ' WHERE a.published = 1 AND a.title="'.$title.'" AND a.catid='.(int)$catid
	  			. ' ORDER BY a.title'
	  			;
	  			
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}    
		
		if(!isset($rows[0])){
			//no email for that category, so just pick the first one
			$query = 'SELECT a.*,  cc.title AS category_name'
	  			. ' FROM #__bfsurveypro_email AS a'
	  			. ' LEFT JOIN #__categories AS cc ON cc.id = a.catid'
				. ' WHERE a.published = 1 AND a.title="'.$title.'"'
	  			. ' ORDER BY a.title'
	  			;
	  			
			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}			
		}

		return $rows;
    }
    
	/**
	 * Check to see if person with this user id (UNID) has completed the survey
	 * 
	 * @param string	$table	Answer table
	 * @param int		$myUID	User id number of the current user
	 * 
	 * @return	int		Number of times this user has completed the survey
	 */
	function checkUID($table,$myUID){
	   $db =& JFactory::getDBO();

	   if($myUID == "" | $myUID == 0){
	      // don't check anonymous responses
	      return 0;
	   }else{
	      $query = "SELECT count(uid) from ".$table." where `uid`='".(int)$myUID."'";

	      $db->setQuery( $query);
	      $result=$db->loadResult();

	      return $result;
	   }
	}    
		
}
?>
