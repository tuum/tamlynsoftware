<?php
/**
 * $Id: emailtemplate.php 2 2011-11-15 04:14:12Z tuum $
 * Email Template Controller for BF Survey Pro Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * Email Template Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfsurvey_proControlleremailtemplate extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}
	
	function emailtemplate()
	{
		JRequest::setVar( 'view', 'emailtemplate' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}		

	/**
	* email item view
	*/
	function emailitem()
	{
		JRequest::setVar( 'view', 'emailitem' );
		JRequest::setVar( 'layout', 'form'  );

		parent::display();
	}	

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'emailitem' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}	
	
	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfsurvey_proControlleremailtemplate::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfsurvey_proControlleremailtemplate::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$db 		=& JFactory::getDBO();
		$user 		=& JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPRO_ERROR_NO_ITEMS_SELECTED' ) );
			$mainframe->redirect( 'index.php?option='. $option.'&task=emailtemplate' );
		}

		$cids = implode( ',', $cid );

		$query = 'UPDATE #__bfsurveypro_email'
		. ' SET published = '.(int) $publish
		. ' WHERE id IN ( '. $cids .' )'
		. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )'
		;
		$db->setQuery( $query );
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg() );
		}

		$mainframe->redirect( 'index.php?option='. $option.'&task=emailtemplate' );
    }


	/**
	* Moves the record up one position
	*/
	function moveUpQuestion(  ) {
		bfsurvey_proControlleremailtemplate::orderQuestion( -1 );
	}

	/**
	* Moves the record down one position
	*/
	function moveDownQuestion(  ) {
		bfsurvey_proControlleremailtemplate::orderQuestion( 1 );
	}

	/**
	* Moves the order of a record
	* @param integer The direction to reorder, +1 down, -1 up
	*/
	function orderQuestion( $inc )
	{
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

	   	JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfsurveypro'.DS.'tables');
		$row =& JTable::getInstance('emailitem', 'Table');

		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar('cid', array(0), '', 'array');
		$option = JRequest::getCmd('option');
		JArrayHelper::toInteger($cid, array(0));

		$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
		$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
		$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

		$row =& JTable::getInstance( 'emailitem', 'Table' );
		$row->load( $cid[0] );
		$row->move( $inc, 'catid = '.(int) $row->catid.' AND published != 0' );

		$mainframe->redirect( 'index.php?option='. $option .'&task=emailtemplate&task=emailtemplate');
	}

	function saveOrder( )
	{
		$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
		global $mainframe;

		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_('COM_BFSURVEYPRO_ERROR_INVALID_TOKEN') );

		// Initialize variables
		$db			=& JFactory::getDBO();
		$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
		$total		= count( $cid );
		JArrayHelper::toInteger($order, array(0));

		$row =& JTable::getInstance('emailitem', 'Table');
		$groupings = array();

		// update ordering values
		for( $i=0; $i < $total; $i++ ) {
			$row->load( (int) $cid[$i] );
			// track categories
			$groupings[] = $row->catid;

			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				if (!$row->store()) {
					JError::raiseError(500, $db->getErrorMsg() );
				}
			}
		}

		// execute updateOrder for each parent group
		$groupings = array_unique( $groupings );
		foreach ($groupings as $group){
			$row->reorder('catid = '.(int) $group);
		}

		$msg 	= JText::_('COM_BFSURVEYPRO_NEW_ORDERING_SAVED');
		$mainframe->redirect( 'index.php?option=com_bfsurvey_pro&task=emailtemplate', $msg );
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('emailitem');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFSURVEYPRO_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFSURVEYPRO_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('emailitem');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFSURVEYPRO_ERROR_DELETING_EMAIL' );
		} else {
			$msg = JText::_( 'COM_BFSURVEYPRO_EMAIL_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfsurvey_pro&task=emailtemplate', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFSURVEYPRO_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfsurvey_pro&task=emailtemplate', $msg );
	}

	/**
	  Copies one or more item
	 */
	function copy()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( JText::_('COM_BFSURVEYPRO_ERROR_INVALID_TOKEN') );

		$this->setRedirect( 'index.php?option=com_bfsurvey_pro&task=emailtemplate' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();

		$table	=& JTable::getInstance('emailitem', 'Table');

		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->title				= JText::_('COM_BFSURVEYPRO_COPY_OF').' '. $table->title;
					$table->published 			= 0;
					$table->ordering 			= 0;

					$now =& JFactory::getDate();
					$table->date			= $now->toMySQL();

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}else{
					return JError::raiseWarning( 500, $table->getError() );
			    }
			}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPRO_ERROR_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFSURVEYPRO_ITEMS_COPIED', $n ) );
	}
	
	
}
?>