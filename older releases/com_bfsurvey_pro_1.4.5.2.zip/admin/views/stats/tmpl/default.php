<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
$rowX =& $this->items2[0];

?>

<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_ID' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_QUESTION' ); ?>
            </th>
        </tr>
    </thead>

    <?php
    $k = 0;
    for ($i=0, $n=count( $this->items2 ); $i < $n; $i++)
    {
		$row =& $this->items2[$i];

        ?>
  		<tr class="<?php echo "row$k"; ?>">
  		    <td>
  		       <?php echo $i+1; ?>
  		    </td>
  		    <td>
  		       <?php echo $row->question; ?>
  		    </td>
  		</tr>

  		<tr>
  		<td colspan=2>
		<?php
		$question_type = $row->question_type;
		$total = 0;
		$myOption = array();
		$myAnswer = array();
		echo JText::_('COM_BFSURVEYPRO_QUESTION_TYPE');

  		echo bfsurvey_proHelper::ShowQuestionType( $row->question_type );

  		?>


				<?php
					for ($i3=1; $i3 < 21; $i3++)
					{
						//$question=$row->id;
						$question=$row->field_name;
						$name = 'option'.$i3;
						$response=$row->$name;
						if($response==""){
						    // do nothing
						}else{
							if($question_type == 2){ //checkbox
							   $answer = bfsurvey_proController::getStatsCheckbox($question, $response, $this->catid);
							}else if($question_type == 0 | $question_type == 3 | $question_type == 5 | $question_type == 8 | $question_type == 9){
							   $answer="";
							}else{
							   if($response == "_OTHER_"){
							   		$answer = bfsurvey_proController::getStatsOther($question, $response, $this->catid);
							   }else{
							   		$answer = bfsurvey_proController::getStats($question, $response, $this->catid);
							   }							   
							}

							$myAnswer[$i3]=$answer;
							$myOption[$i3]=$response;

							if($answer > 0){
						       $total=$total + $answer;
						    }
						}
					}

		if($question_type == 0 | $question_type == 3 | $question_type == 5 | $question_type == 8){ //text or Textarea or date or summation or rating
		   echo JText::_('COM_BFSURVEYPRO_ERROR_NO_STATS');
		}else if($row->sql != ""){
		   echo JText::_('COM_BFSURVEYPRO_ERROR_NO_STATS_SQL');
		}else if($question_type == 9){ //rating

		   $mylabels = array();
	       if($row->titles == ""){
	          // do nothing
	       }else{
	          $mylabels = preg_split("/;/",$row->titles);
	       }

		   for($z=0; $z < 20; $z++)
	       {
	       		$total = 0;
		   		$myOption = array();
				$myAnswer = array();
	            $tempvalue="option".($z+1);

	       	    if($row->$tempvalue != ""){

		       	    $field=$row->field_name;
       				$question=$field.($z+1);

	       			for($y=1; $y < $row->sqlfield+1; $y++){
	       				if($row->titles == ""){
						   $response = $y;
						}else{
						   $response = $mylabels[$y-1];
						}
	       				$answer = bfsurvey_proController::getStats($question, $response, $this->catid);
	       				$myAnswer[$y]=$answer;
						$myOption[$y]=$response;
						if($answer > 0){
						   $total=$total + $answer;
						}
	       			}
					?>
					<table>
					<tr class="<?php echo "row$k"; ?>">
				    <td>
			 		    <?php echo $row->$tempvalue; ?>
				    </td>
	  				</tr>
					<tr>
			   			<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_OPTION'); ?></th>
						<th width="50"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_COUNT'); ?></th>
			   			<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_PERCENT'); ?></th>
						<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_GRAPH'); ?></th>
					</tr>
					<?php
						$colourCount=0;
						for ($z2=1; $z2 < count($myOption)+1; $z2++){
				    		$colourCount++;
							    if($colourCount > 5){
				      	 			$colourCount = 1;
				    			}
							    echo "<tr>";
								if($row->titles == ""){
							       echo "<td>".$myOption[$z2]."</td>";
							    }else{
								   if(isset($mylabels[$z2-1])){
 	       		             	      echo "<td>".$mylabels[$z2-1]."</td>";
 	       		          		   }else{
 	       		             		  echo "<td>&nbsp;</td>";
 	       		             	   }
							    }
							    echo "<td>".$myAnswer[$z2]."</td>";
					    		if($total > 0){
						       		echo "<td>".number_format((($myAnswer[$z2]/$total)*100),2)."%</td>";
								}else{
							   		echo "<td>0.00%</td>";
								}


							    $myclass = 'polls_color_'.$colourCount;
								?>
				   				<td width=300 >
				   				<?php
				   				if($total > 0){
				   					 ?>
			       				    <div class="<?php echo $myclass ?>" style="height:5px;width:<?php echo (($myAnswer[$z2]/$total)*100) ?>%"></div>
			       				    <?php
			       				 }else{
			       					 ?>
			       				    <div class="<?php echo $myclass ?>" style="height:5px;width:1%"></div>
			       					 <?php
			       				 }
			       		}
			       		?>
			       		</td>
				   		</tr>
					<?php
					?>
					</table>
					Total: <?php echo $total ?>
				<?php
	       		}
	       	}

		}else{
		?>

		<table>
		<tr>
			<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_OPTION'); ?></th>
			<th width="50"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_COUNT'); ?></th>
			<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_PERCENT'); ?></th>
			<th width="100"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_GRAPH'); ?></th>		   
		</tr>
		<?php
			$colourCount=0;
			for ($z=1; $z < count($myOption)+1; $z++){
			    $colourCount++;
			    if($colourCount > 5){
			       $colourCount = 1;
			    }
			    echo "<tr>";
			    echo "<td>".$myOption[$z]."</td>";
			    echo "<td>".$myAnswer[$z]."</td>";
			    if($total > 0){
			       echo "<td>".number_format((($myAnswer[$z]/$total)*100),2)."%</td>";
				}else{
				   echo "<td>0.00%</td>";
				}


			    $myclass = 'polls_color_'.$colourCount;
			?>
			    <td width=300 >
			    <?php
			    if($total > 0){
			    ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:<?php echo (($myAnswer[$z]/$total)*100) ?>%"></div>
		        <?php
		        }else{
		        ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:1%"></div>
		        <?php
		        }
		        ?>
		        </td>
			    </tr>
			<?php

			}

		?>
		</table>
		Total: <?php echo $total ?>

		<?php
		}
		?>

        </td>
        </tr>

        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>