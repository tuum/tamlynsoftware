<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
    global $mainframe;
    $user =& JFactory::getUser();
    $lists = 0;
    $items = 0;
    $limitstart = 0;
    $limit = 0;
    $disabled = 0;

	//Ordering allowed ?
	$ordering = ($lists['order'] == 'a.ordering');

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );

    $myFields[]="";

		$context="";
		$filter_order		= $mainframe->getUserStateFromRequest( $context.'filter_order',		'filter_order',		'cc.title',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( $context.'filter_order_Dir',	'filter_order_Dir',	'',			'word' );
		$filter_catid		= $mainframe->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
		$filter_state		= $mainframe->getUserStateFromRequest( $context.'filter_state',		'filter_state',		'',			'word' );

		$lists = array();

		// build list of categories
		$javascript		= 'onchange="document.adminForm.submit();"';
		$lists['catid'] = JHTML::_('list.category',  'filter_catid', 'com_bfsurvey_pro', (int) $filter_catid, $javascript );

		// state filter
		$lists['state']	= JHTML::_('grid.state',  $filter_state );	
		
		// table ordering
		$lists['order_Dir']	= $filter_order_Dir;
		$lists['order']		= $filter_order;
?>

<form action="index.php" method="post" name="adminForm">
<table>
	<tr>
		<td align="left" width="100%">
			&nbsp;
		</td>		
		<td nowrap="nowrap">
			<?php
			echo $lists['catid'];
			echo $lists['state'];
			?>
		</td>
	</tr>
</table>

<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'ID' ); ?>
			</th>
			<th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_QUESTION' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_TYPE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_CATEGORY' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_NEXT_QN' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_DB_FIELD_NAME' ); ?>
			</th>
			<th width="5%">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_FIELD_TYPE' ); ?>
			</th>
			<th width="15%">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_VALIDATION' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_PUBLISHED' ); ?>
			</th>
			<th width="5%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_MANDATORY' ); ?>
			</th>			
			<th width="10%" nowrap="nowrap">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TTTLE_ORDER' ); ?>
				<?php
				echo JHTML::_('grid.order',  $this->items );
				?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfsurvey_pro&controller=question&task=edit&cid[]='. $row->id );

        //$id = JHTML::_('grid.id', ++$i, $row->id);

		// show tick or cross
		$published		= JHTML::_('grid.published', $row, $i );

		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->question; ?></a>
			</td>
			<td>
				<?php echo bfsurvey_proHelper::ShowQuestionType( $row->question_type ); ?>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php
				    for($z=1; $z < 20; $z++){
				       $tempname = "next_question".$z;
				       if($row->$tempname <> 0){
				          echo $row->$tempname;
				          echo " ";
				       }
				    }
				?>
			</td>
			<td>
				<?php echo $row->field_name; ?>
				<?php if(!isset($myFields[$row->catid])){
				   $myFields[$row->catid] = "";
				}
				?>
				<?php $myFields[$row->catid].= "`".$row->field_name."` varchar($row->fieldSize) default NULL,";	?>
			</td>
			<td>
				<?php echo $row->field_type; ?>
			</td>
			<td>
				<?php echo $row->validation_type; ?>
			</td>
			<td align="center">
				<?php echo $published;?>
			</td>
			<td align="center">
				<?php
					if($row->mandatory){ 
						echo "<img src='./components/com_bfsurvey_pro/images/mandatory.gif' width='12'>";
					}
				?>
			</td>			
            <td class="order">
			    <span><?php echo $this->pagination->orderUpIcon($i, true, 'orderup', 'Move Up', isset($this->items[$i-1]) ); ?></span>
			    <span><?php echo $this->pagination->orderDownIcon($i, $n, true, 'orderdown', 'Move Down', isset($this->items[$i+1]) ); ?></span>

				<input type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="13"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="<?php echo $option;?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />

</form>

<?php

//echo '<br>';
//echo '<h3>Automatic Database Table Builder</h3>';

global $mainframe;
$database =& JFactory::getDBO();

$mycategory =& bfsurvey_proController::getCategory();

$db =& JFactory::getDBO();

if( sizeof( $mycategory ) ) {
    foreach( $mycategory as $mycat  ) {
	    $myid = $mycat->id;
	    $table=$mainframe->getCfg('dbprefix')."bfsurveypro_".$myid;

	    $result = $database->getTableList();
	    if (!in_array($mainframe->getCfg('dbprefix')."bfsurveypro_".$myid, $result)) {
	       //echo "Table ".$table." does not exist!<br>";


		   for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		   {
		    	$found=0;
		   		$row = &$this->items[$i];

				$myFieldsMissing="";
				if($row->catid == $myid){
				   if($row->question_type == 9){ //rating
			        	// don't add field for rating question
			       }else{
	 			      $myFieldsMissing.= "`".$row->field_name."` TEXT,";
	 			   }
				}
       		}


	       $query="CREATE TABLE `".$table."` (
  			    `id` int(11) NOT NULL auto_increment,
      			`Name` varchar(150) default NULL,
      			`Company` varchar(150) default NULL,
      			`Email` varchar(150) default NULL,
      			`uid` int(11) NOT NULL default 0,
      			`DateReceived` datetime NOT NULL,
      			`ip` varchar(50) default NULL,
      			`wfid` int(11) unsigned,
  				`wfcurrentTask` int(11) NOT NULL default '0',
  				`wfnextTaskApprove` int(11) NOT NULL default '0',
  				`wfnextTaskReject` int(11) NOT NULL default '0',  
  			    ".$myFieldsMissing."
      			PRIMARY KEY  (`id`)
	    	);";
	       //echo $query;

	       $db->setQuery( $query );
	       if (!$db->query())
	       {
	       	   echo $db->getErrorMsg();
	    	   return false;
	       }
	       //echo "<br>Table ".$table." created<br>";


	    }else{
	       //echo "Table ".$table." already exists!<br>";

		    $db =& JFactory::getDBO();
		    // Grab the fields for the selected table
		    $fields =& $db->getTableFields( $table, true );

		    if( sizeof( $fields[$table] ) ) {
		       // We found some fields so let's create the HTML list
		       $options = array();
		       foreach( $fields[$table] as $field => $type ) {
			           $options[] = JHTML::_( 'select.option', $field, $field );
		       }

			   //what type of field, eg VARCHAR, INT, DATETIME etc.
			   $fieldType=array();
		       foreach( $fields[$table] as $field ) {
			      $fieldType[] = $field;
		       }
		    }

			for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	 		{
 		    	$found=0;
			    $row = &$this->items[$i];
			    $myindex=0;
			    foreach( $fields[$table] as $field => $type ) {
		           if ($row->field_name == $field) {
			          $found=1;
			   	   }

			   	   if($found==0){
			   	      $myindex++;
			   	   }
			    }

			    if($found == 1){
			        if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type==""){
			           //do nothing
			        }else{
			           $mytype = $row->field_type;
			           if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
			              $mytype = "".$row->field_type."(".$row->fieldSize.")";
			           }
			           $query="ALTER TABLE `".$table."` CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
			           //echo "Field type has changed, running query=".$query."<br>";
		  	    	   $db->setQuery( $query );
		  	       	   if (!$db->query())
		  	       	   {
		  	       	      echo $db->getErrorMsg();
		  	    	      return false;
		  	       	   }
			        }
			    }

			    if($row->question_type == 9){ //rating
			        // don't add field for rating question
			        $found=1;
			    }

	 		    if($found == 0 & $row->catid == $myid){
			      //echo "Need to add the ".$row->field_name." field<br>";

			      $query="ALTER TABLE `".$table."`
		    			    ADD `".$row->field_name."` TEXT
  	  	    	  ;";

		  	       $db->setQuery( $query );
		  	       if (!$db->query())
		  	       {
		  	       	   echo $db->getErrorMsg();
		  	    	   return false;
		  	       }
			       //echo "Table ".$table." updated<br>";
			    }

			    // now special case for rating question
			    if($row->question_type == 9){   // rating question
			        for ($y=0, $x=20; $y < $x; $y++ ) {
			            $tempvalue="option".($y+1);
			            $tempfield=$row->field_name;
			            $tempfield.="".($y+1);

						$found=0;

			            if($row->$tempvalue == ""){
			                 //do nothing
			            }else{
			    			foreach( $fields[$table] as $field => $type ) {
				       			if ($tempfield == $field) {
					       		   	$found=1;
				  	   			}
				  			}

							if($found == 0 & $row->catid == $myid){
						       //echo "Need to add the ".$tempfield." field<br>";

						       $query="ALTER TABLE `".$table."`
					    			   ADD `".$tempfield."` TEXT
			  	  	    	   ;";
			 	  	           //echo $query;
			 	  	           //echo "<br>";

					  	       $db->setQuery( $query );
					  	       if (!$db->query())
					  	       {
					  	       	   echo $db->getErrorMsg();
					  	    	   return false;
					  	       }
						       //echo "Table ".$table." updated<br>";
						    }else if($found == 1){
			     				$mytype = $row->field_type;
			     			    if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT"){
			     			    	$mytype = "".$row->field_type."(".$row->fieldSize.")";
			    			    }
			        			$query="ALTER TABLE `".$table."` CHANGE `".$tempfield."` `".$tempfield."` ".$mytype.";";
		  	    	   			$db->setQuery( $query );
		  	       	   			if (!$db->query())
		  	       	   			{
		  	       	   			   echo $db->getErrorMsg();
		  	    	   			   return false;
		  	       	   			}
			    			}

				  		}

			    	}

			    }

			}

        }
   }

}

?>