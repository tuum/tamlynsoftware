<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: form.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
		<script language="javascript" type="text/javascript">
		<!--
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			// do field validation
			if (form.question.value == "") {
				alert( "<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_PLEASE_ENTER_QUESTION', true ); ?>" );
			} else if ( getSelectedValue('adminForm','question_type') == 1 & form.option1.value == "" & form.sql.value=="") {
				alert( "<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_RADIO_MUST_ENTER_SQL', true ); ?>" );
			} else if (form.field_name.value == "") {
				alert( "<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_PLEASE_ENTER_FIELD_NAME', true ); ?>" );
			} else if ( getSelectedValue('adminForm','catid') == 0 ) {
				alert( "<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_SELECT_CATEGORY', true ); ?>" );
			} else if(document.getElementById("field_name").value.match(" ") != null){  //can't have spaces in field names
		       alert("<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_FIELD_NAME_NO_SPACE', true ); ?>");
			} else if(document.getElementById("field_name").value.match("-") != null){  //can't have minus in field names
		       alert("<?php echo JText::_( 'COM_BFSURVEYPRO_VALIDATION_ALERT_FIELD_NAME_NO_MINUS', true ); ?>");
			} else {
				submitform( pressbutton );
			}
		}

		function showOptions(){
		   if(document.getElementById("sql").value == ""){  //show
			  var i=0;
			  for (i=1;i<21;i++){
		         document.getElementById("option"+i).style.display = '';
		         document.getElementById("optionText"+i).style.display = '';
		         document.getElementById("next_question"+i).style.display = '';
		         document.getElementById("next_questionText"+i).style.display = '';
		      }
		   }else{ //hide
		      var i=0;
			  for (i=2;i<21;i++){
		         document.getElementById("option"+i).style.display = 'none';
		         document.getElementById("optionText"+i).style.display = 'none';
		         document.getElementById("next_question"+i).style.display = 'none';
		         document.getElementById("next_questionText"+i).style.display = 'none';
		      }
		   }
		}

		function hideAllOptions(){
		   var i=0;
		   for (i=1;i<21;i++){
	          document.getElementById("option"+i).style.display = 'none';
	          document.getElementById("optionText"+i).style.display = 'none';
	          if(i>1){
	             document.getElementById("next_question"+i).style.display = 'none';
	             document.getElementById("next_questionText"+i).style.display = 'none';
	          }
	       }
		}

		function hideBranching(){
   		var i=0;
		   for (i=1;i<21;i++){
	          if(i>1){
	             document.getElementById("next_question"+i).style.display = 'none';
	             document.getElementById("next_questionText"+i).style.display = 'none';
	          }
	       }
		}

		function hideType(){
			updateValidation();
		    document.getElementById("sql").style.display = '';
		    document.getElementById("sqlText").style.display = '';
		    document.getElementById("totalText").style.display = 'none';
		    document.getElementById("sqlfield").style.display = '';
		    document.getElementById("sqlfieldText").style.display = '';
		    document.getElementById("next_question1").style.display = '';
		    document.getElementById("next_questionText1").style.display = '';
		    document.getElementById("horizontal_1").style.display = 'none';
 		    document.getElementById("horizontalText").style.display = 'none';
 		    document.getElementById("field_size").style.display = 'none';
 		    document.getElementById("fieldSize").style.display = 'none';

		    if(document.getElementById("question_type").value == 0){  //text
			   hideAllOptions();
		       document.getElementById("mandatory_1").style.display = '';
 		       document.getElementById("mandatoryText").style.display = '';
			   document.getElementById("sql").style.display = 'none';
		       document.getElementById("sqlText").style.display = 'none';
		       document.getElementById("sqlfield").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
		       document.getElementById("field_size").style.display = '';
 		       document.getElementById("fieldSize").style.display = '';
		    }else if(document.getElementById("question_type").value == 1){  //radio
			   document.getElementById("mandatory_1").style.display = '';
		       document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("horizontal_1").style.display = '';
 		       document.getElementById("horizontalText").style.display = '';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
		       showOptions();
		    }else if(document.getElementById("question_type").value == 2){  //checkbox
		       showOptions();
			   document.getElementById("mandatory_1").style.display = '';
		       document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("horizontal_1").style.display = '';
 		       document.getElementById("horizontalText").style.display = '';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
		    }else if(document.getElementById("question_type").value == 3){  //textarea
			   hideAllOptions();
			   document.getElementById("mandatory_1").style.display = '';
		       document.getElementById("mandatoryText").style.display = '';
			   document.getElementById("sql").style.display = 'none';
		       document.getElementById("sqlText").style.display = 'none';
		       document.getElementById("sqlfield").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
			   document.getElementById("field_size").style.display = '';
			   document.getElementById("fieldSize").style.display = '';
		    }else if(document.getElementById("question_type").value == 4){  //attachment
		       document.getElementById("sql").style.display = 'none';
			   document.getElementById("sqlText").style.display = 'none';
			   document.getElementById("sqlfield").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
			   document.getElementById("mandatory_1").style.display = 'none';
			   document.getElementById("mandatoryText").style.display = 'none';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
			   hideAllOptions();
		    }else if(document.getElementById("question_type").value == 5){  //date
		       document.getElementById("sql").style.display = 'none';
		       document.getElementById("sqlText").style.display = 'none';
		       document.getElementById("sqlfield").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
			   document.getElementById("mandatory_1").style.display = '';
			   document.getElementById("mandatoryText").style.display = '';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
			   hideAllOptions();
		    }else if(document.getElementById("question_type").value == 6){  //drop down
		       showOptions();
			   document.getElementById("mandatory_1").style.display = '';
			   document.getElementById("mandatoryText").style.display = '';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
		    }else if(document.getElementById("question_type").value == 7){  //list
		       hideAllOptions();
			   document.getElementById("mandatory_1").style.display = 'none';
			   document.getElementById("mandatoryText").style.display = 'none';
			   document.getElementById("next_question1").style.display = 'none';
		       document.getElementById("next_questionText1").style.display = 'none';
		       document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
		    }else if(document.getElementById("question_type").value == 8){  //summation
		       showOptions();
		       hideBranching();
			   document.getElementById("mandatory_1").style.display = '';
			   document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("sql").style.display = 'none';
		       document.getElementById("sqlText").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
		       document.getElementById("totalText").style.display = '';
			   document.getElementById("titlesText").style.display = 'none';
		       document.getElementById("titles").style.display = 'none';
			}else if(document.getElementById("question_type").value == 9){  //Rating
		       showOptions();
		       hideBranching();
			   document.getElementById("mandatory_1").style.display = '';
			   document.getElementById("mandatoryText").style.display = '';
		       document.getElementById("sql").style.display = 'none';
		       document.getElementById("sqlText").style.display = 'none';
		       document.getElementById("sqlfieldText").style.display = 'none';
		       document.getElementById("totalText").style.display = '';
		       document.getElementById("titlesText").style.display = '';
		       document.getElementById("titles").style.display = '';
		    }
		}

		var checkbox_array = new Array('required validate-checkbox','required validate-checkbox2','required validate-checkbox3','required validate-checkbox4','required validate-checkbox5','required validate-checkbox6','required validate-checkbox7','required validate-checkbox8','required validate-checkbox9','required validate-checkbox10');
		var text_array = new Array('required','required validate-numeric','required validate-email');
		var textarea_array = new Array('required','required validate-mintextarea');
		
		function updateValidation(){
		   //get var from php
		   var validation_type = "<?php echo isset($this->bfsurvey_pro->validation_type) ? $this->bfsurvey_pro->validation_type : ''; ?>";
		   
		   var sda = document.getElementById('validation_type');
		   var len = sda.length;
   		   if(document.getElementById("question_type").value == 2){  //checkbox
   			  //remove all options first
   			  sda.options.length=0;

			  var len2 = checkbox_array.length;
			  for(var i=0; i<len2; i++)
			  {
	          	//now add validate-checkbox
			  	var y=document.createElement('option');
			  	y.text=checkbox_array[i];
 			  	y.value=checkbox_array[i];
 			  	if(checkbox_array[i] == validation_type){
  			  	   y.selected = true;
  			  	}
			  	try
			  	{
			  	  sda.add(y,null);}
			  	  catch(ex){
			  	  sda.add(y);
			  	}
			  }

			  sda.setAttribute("value", checkbox_array[0]);

	       }else if(document.getElementById("question_type").value == 0){  //text
			  //remove all options first
   			  sda.options.length=0;

			  var len2 = text_array.length;
			  for(var i=0; i<len2; i++)
			  {
	          	//now add validate options
			  	var y=document.createElement('option');
			  	y.text=text_array[i];
 			  	y.value=text_array[i];
 			  	if(text_array[i] == validation_type){
 				   y.selected = true;
  			  	}
			  	try
			  	{
			  	  sda.add(y,null);}
			  	  catch(ex){
			  	  sda.add(y);
			  	}
			  }

			  sda.setAttribute("value", text_array[0]);
	       }else if(document.getElementById("question_type").value == 3){  //textarea
			  //remove all options first
   			  sda.options.length=0;

			  var len2 = textarea_array.length;
			  for(var i=0; i<len2; i++)
			  {
	          	//now add validate options
			  	var y=document.createElement('option');
			  	y.text=textarea_array[i];
 			  	y.value=textarea_array[i];
 			  	if(textarea_array[i] == validation_type){
 				   y.selected = true;
  			  	}
			  	try
			  	{
			  	  sda.add(y,null);}
			  	  catch(ex){
			  	  sda.add(y);
			  	}
			  }

			  sda.setAttribute("value", textarea_array[0]);			  
	       }else{
	          //default validation types
			  //remove all options first
   			  sda.options.length=0;

			  //now add validate options
			  var y=document.createElement('option');
			  y.text="default";
 			  y.value="default";
			  try
			  {
			    sda.add(y,null);}
			    catch(ex){
			    sda.add(y);
			  }
	       }
		}
		//-->
		</script>

<script language="javascript">
	function imposeMaxLength(Object, MaxLen)
	{
	  return (Object.value.length < MaxLen);
	}
</script>

<?php
// For popup help
JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<div class="col width-65">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td valign="top" align="right" class="key">
				<label for="catid">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_CATEGORY' ); ?>: *
				</label>
			</td>
			<td>
				<?php echo $this->lists['catid']; ?>
				&nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Category::This is the survey that your question will appear in">
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_QUESTION' ); ?>: *
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="question" id="question" size="60" maxlength="250" value="<?php echo $this->bfsurvey_pro->question;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<label name="suppressText" id="suppressText"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_SUPPRESS_QUESTION' ); ?>:</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->suppressQuestion)){
			          $this->bfsurvey_pro->suppressQuestion = 0;
			       }
			    ?>
				<label name="suppressQuestion_1" id="suppressQuestion_1"><?php echo JHTML::_( 'select.booleanlist',  'suppressQuestion', 'class="inputbox"', $this->bfsurvey_pro->suppressQuestion ); ?></label>
				&nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Suppress Question::This will hide the question, so you only see the options.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="helpText">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_HELP_TEXT' ); ?>:
				</label>
			</td>
			<td>
			   <img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title='Help text::This appears between the question and the options. It can contain HTML, and supports Allvideos tags eg. {youtube}Xr2mhMHhUMY{/youtube}.'>
			</td>
		</tr>
		<tr>
			<td colspan=2>
			    <?php
			       if(!isset($this->bfsurvey_pro->helpText)){
			          $this->bfsurvey_pro->helpText = "";
			       }
			    ?>
			    <?php $editor = JFactory::getEditor(); ?>
				<?php echo $editor->display( 'helpText',  $this->bfsurvey_pro->helpText, '400', '200', '60', '40', array()) ; ?>
			</td>
		</tr>
		</table class="admintable">

		<table>
		<tr>
			<td class="key">
				<label for="field_name">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_DB_FIELD_NAME' ); ?>: *
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->field_name)){
			          $this->bfsurvey_pro->field_name = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="field_name" id="field_name" size="30" value="<?php echo $this->bfsurvey_pro->field_name;?>"/>
			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Field Name::This is the name of the field in the mySQL table used to store reponses to this survey. Field name cannot use reserved words such as 'like' or 'where', must be unique, and must not contain spaces, dashes, slashes or any other special characters.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="field_type">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_DB_FIELD_TYPE' ); ?>: *
				</label>
			</td>
			<td>
			    <?php echo bfsurvey_proHelper::FieldType( $this->bfsurvey_pro->field_type );  ?>
			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Field Type::This is the data type of the mySQL field used to store responses to this question. If you are not sure, just use VARCHAR.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="field_size" id="field_size">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_MAX_ANSWER_LENGTH' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->fieldSize)){
			          $this->bfsurvey_pro->fieldSize = 255;
			       }
			    ?>
			    <input class="inputbox" type="text" name="fieldSize" id="fieldSize" maxlength="5" size="30" value="<?php echo $this->bfsurvey_pro->fieldSize;?>"/>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="question_type">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_TYPE' ); ?>:
				</label>
			</td>
			<td>
				<?php echo bfsurvey_proHelper::QuestionType( $this->bfsurvey_pro->question_type ); ?>
			</td>
		</tr>
		<tr>
			<td class="key">
				<label name="titlesText" id="titlesText">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_TITLES' ); ?>:
				</label>
			</td>
			<td>
				<?php
			       if(!isset($this->bfsurvey_pro->titles)){
			          $this->bfsurvey_pro->titles ="";
			       }
			    ?>
			    <input class="inputbox" type="text" name="titles" id="titles" size="100" value="<?php echo $this->bfsurvey_pro->titles;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_PUBLISHED' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->published)){
			          $this->bfsurvey_pro->published=0;
			       }
			    ?>
				<?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->bfsurvey_pro->published ); ?>
			</td>
		</tr>
		<tr>
			<td width="100" class="key">
				<label name="mandatoryText" id="mandatoryText"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_MANDATORY' ); ?>: *</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->mandatory)){
			          $this->bfsurvey_pro->mandatory = 0;
			       }
			    ?>
				<label name="mandatory_1" id="mandatory_1"><?php echo JHTML::_( 'select.booleanlist',  'mandatory', 'class="inputbox"', $this->bfsurvey_pro->mandatory ); ?></label>
				&nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Mandatory::For radio & checkbox, you must install and publish BF Validate plugin.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="validation_type">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_VALIDATION_TYPE' ); ?>: *
				</label>
			</td>
			<td>
				<?php
			    if($this->bfsurvey_pro->question_type == 2){  //checkbox
			       echo bfsurvey_proHelper::ValidationTypeCheckbox( $this->bfsurvey_pro->validation_type );
			    }else{
			       echo bfsurvey_proHelper::ValidationType( $this->bfsurvey_pro->validation_type );
			    }
			    ?>

			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Validation Type::This is the validation type for this question.">
			</td>
		</tr>
		<tr>
			<td class="key" align="right" valign="top">
				<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_PARENT_ITEM' ); ?>:
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->parent)){
			          $this->bfsurvey_pro->parent = 0;
			       }
			    ?>
				<?php echo bfsurvey_proHelper::Parent( $this->bfsurvey_pro ); ?>
			</td>
		</tr>

		<tr>
		   <td class="key" colspan=2>
		   &nbsp;
		   </td>
		</tr>
		<tr>
			<td class="key">
				<label name="sqlText" id="sqlText">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_SQL_COMMAND' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->sql)){
			          $this->bfsurvey_pro->sql = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="sql" id="sql" size="100" value="<?php echo $this->bfsurvey_pro->sql;?>" onchange='hideOptions()'/>
			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="SQL Command(optional)::This can be used when you need more than 20 options. You can populate options via a mySQL lookup.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label name="sqlfieldText" id="sqlfieldText">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_SQL_FIELD' ); ?>:
				</label>
				<label name="totalText" id="totalText">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_TOTAL' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->sqlfield)){
			          $this->bfsurvey_pro->sqlfield = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="sqlfield" id="sqlfield" size="100" value="<?php echo $this->bfsurvey_pro->sqlfield;?>" />
			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="SQL Field(optional)::This defines which field from your select command above will be populated into the option.">
			</td>
		</tr>
		<tr>
			<td class="key">
				<label for="ordering">
					<?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_ORDERING' ); ?>:
				</label>
			</td>
			<td>
			    <?php
			       if(!isset($this->bfsurvey_pro->ordering)){
			          $this->bfsurvey_pro->ordering = "";
			       }
			    ?>
			    <input class="inputbox" type="text" name="ordering" id="ordering" size="6" value="<?php echo $this->bfsurvey_pro->ordering;?>" />
			    &nbsp;<img src="./components/com_bfsurvey_pro/images/con_info.png" class="hasTip" title="Ordering::Don't change this unless you know what you are doing.">
			</td>
		</tr>
	</table>
	</fieldset>
</div>
<div class="col width-35">
	<fieldset class="adminform">
	<legend><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_OPTIONS' ); ?></legend>
	<table class="admintable">
		<tr>
		    <td>
		    </td>
		    <td>
		    </td>
		    <td colspan=2><strong><?php echo JText::_('COM_BFSURVEYPRO_TITLE_CONDITIONAL_BRANCHING'); ?></strong>
		    </td>
		</tr>

		<?php for ($i=0, $n=20; $i < $n; $i++ ) { ?>
		<tr>
			<td width="50" class="key">
				<label name="optionText<?php echo ($i+1); ?>" id="optionText<?php echo ($i+1); ?>"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_OPTION' ); ?> <?php echo ($i+1); ?></label>
			</td>
			<td>
			    <?php $tempvalue="option".($i+1); ?>
			    <?php
			       if(!isset($this->bfsurvey_pro->$tempvalue)){
			          $this->bfsurvey_pro->$tempvalue = "";
			       }
			    ?>
				<input class="text_area" type="text" name="option<?php echo ($i+1); ?>" id="option<?php echo ($i+1); ?>" size="45" maxlength="150" value="<?php echo $this->bfsurvey_pro->$tempvalue;?>" />
			</td>
			<td width="80">
			   <label name="next_questionText<?php echo ($i+1); ?>" id="next_questionText<?php echo ($i+1); ?>"><?php echo JText::_( 'COM_BFSURVEYPRO_TITLE_NEXT_QUESTION_ID'); ?></label>
			</td>
			<td>
			   <?php $tempnext="next_question".($i+1); ?>
			   <?php
			      if(!isset($this->bfsurvey_pro->$tempnext)){
			         $this->bfsurvey_pro->$tempnext = "";
			      }
			   ?>
				<input class="text_area" type="text" name="next_question<?php echo ($i+1); ?>" id="next_question<?php echo ($i+1); ?>" size="4" maxlength="150" value="<?php echo $this->bfsurvey_pro->$tempnext;?>" />
			</td>
		</tr>
		<?php } ?>

	</table>
	<table class="admintable">
	<tr>
	   <td width="50" class="key">
	      <label name="horizontalText" id="horizontalText"><?php echo JText::_('COM_BFSURVEYPRO_TITLE_HORIZONTAL'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfsurvey_pro->horizontal)){
	            $this->bfsurvey_pro->horizontal = 0;
	         }
	      ?>
	      <label name="horizontal_1" id="horizontal_1"><?php echo JHTML::_( 'select.booleanlist',  'horizontal', 'class="inputbox"', $this->bfsurvey_pro->horizontal ); ?></label>
	   </td>
	</tr>
	<tr>
	   <td width="50" class="key">
	      <label name="prefixText" id="prefixText"><?php echo JText::_('COM_BFSURVEYPRO_TITLE_ANSWER_PREFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfsurvey_pro->prefix)){
	            $this->bfsurvey_pro->prefix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="prefix" id="prefix" size="20" value="<?php echo $this->bfsurvey_pro->prefix;?>" />
	   </td>
	</tr>
	<tr>
	   <td width="50" class="key">
	      <label name="suffixText" id="suffixText"><?php echo JText::_('COM_BFSURVEYPRO_TITLE_ANSWER_SUFFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfsurvey_pro->suffix)){
	            $this->bfsurvey_pro->suffix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="suffix" id="suffix" size="20" value="<?php echo $this->bfsurvey_pro->suffix;?>" />
	   </td>
	</tr>
	<tr>
	   <td width="50" class="key">
	      <label name="otherPrefix" id="otherPrefix"><?php echo JText::_('COM_BFSURVEYPRO_TITLE_OTHER_PREFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfsurvey_pro->otherprefix)){
	            $this->bfsurvey_pro->otherprefix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="otherprefix" id="otherprefix" size="20" value="<?php echo $this->bfsurvey_pro->otherprefix;?>" />
	   </td>
	</tr>
	<tr>
	   <td width="50" class="key">
	      <label name="otherSuffix" id="otherSuffix"><?php echo JText::_('COM_BFSURVEYPRO_TITLE_OTHER_SUFFIX'); ?></label>
	   </td>
	   <td>
	      <?php
	         if(!isset($this->bfsurvey_pro->othersuffix)){
	            $this->bfsurvey_pro->othersuffix = "";
	         }
	      ?>
	      <input class="inputbox" type="text" name="othersuffix" id="othersuffix" size="20" value="<?php echo $this->bfsurvey_pro->othersuffix;?>" />
	   </td>
	</tr>
	</table>
	</fieldset>


</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="id" value="<?php echo $this->bfsurvey_pro->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="question" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>


<script language="javascript" type="text/javascript">
<!--

hideType();

//-->
</script>