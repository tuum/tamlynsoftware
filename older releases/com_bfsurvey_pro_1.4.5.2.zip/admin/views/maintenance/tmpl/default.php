<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php 
/**
 * $Id: default.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<form method="post" name="adminForm">

<div class="adminlist">
<?php echo JText::_( 'COM_BFSURVEYPRO_CLICK_BUTTON_BACKUP'); ?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="task" value="dbbackup" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPRO_BACKUP_DATABASE' ); ?>" />

</form>

<br><br>

<form method="post" name="adminForm">

<div class="adminlist">
<?php echo JText::_( 'COM_BFSURVEYPRO_DATABASE_CLEANUP'); ?>
<?php echo JText::_( 'COM_BFSURVEYPRO_DATABASE_CLEANUP_DETAIL'); ?>
<br>
<?php echo JText::_( 'COM_BFSURVEYPRO_DATABASE_CLEANUP_WARNING1'); ?>
<?php echo JText::_( 'COM_BFSURVEYPRO_DATABASE_CLEANUP_WARNING2'); ?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="task" value="dbcleanup" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPRO_AUTO_DATABASE_CLEANUP' ); ?>" />

</form>

<br><br>

<form method="post" name="adminForm">

<div class="adminlist">
<?php 
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS1');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS2');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS3');
?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="task" value="importquestions" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPRO_IMPORT_ALL_QUESTIONS' ); ?>" />

</form>
<br><br>
<form method="post" name="adminForm">

<div class="adminlist">
<?php 
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS1_TRIAL');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS2_TRIAL');
	echo "<br><br>";
	echo JText::_( 'COM_BFSURVEYPRO_IMPORT_DETAILS3');
?>
<br><br>
</div>

<input type="hidden" name="option" value="com_bfsurvey_pro" />
<input type="hidden" name="task" value="importquestionsTrial" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPRO_IMPORT_ALL_QUESTIONS_TRIAL' ); ?>" />

</form>