<?php
/**
 * $Id: admin.bfsurvey_pro.php 2 2011-11-15 04:14:12Z tuum $
 *
 * bfsurvey_pro entry point file for BF Survey Pro component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once JPATH_COMPONENT.DS.'controller.php';

// Set the table directory
JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfsurvey_pro'.DS.'tables');

// Require specific controller if requested
if ($controller = JRequest::getCmd('controller')) {
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    if (file_exists($path)) {
        require_once $path;
    } else {
        $controller = '';
    }
}

if (JRequest::getCmd('task') == 'report') {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');
} else if (JRequest::getCmd('task') == 'category') {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');
} else if (JRequest::getCmd('task') == 'stats' | JRequest::getCmd('task') == 'show') {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');
} else if ($controller == 'results' | $controller == 'response' | $controller == 'resultscategory' ) {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');
} else if (JRequest::getCmd('task') == 'maintenance' | JRequest::getCmd('task') == 'dbcleanup' | JRequest::getCmd('task') == 'dbbackup') {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance', true);
} else if (JRequest::getCmd('task') == 'emailtemplate' | JRequest::getCmd('task') == 'emailitem') {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');   
} else {
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_QUESTIONS'), 'index.php?option=com_bfsurvey_pro&controller=controller', true);
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_CATEGORIES'), 'index.php?option=com_categories&section=com_bfsurvey_pro');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_REPORT'), 'index.php?option=com_bfsurvey_pro&task=category');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_STATS'), 'index.php?option=com_bfsurvey_pro&task=stats');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_RESULTS'), 'index.php?option=com_bfsurvey_pro&controller=resultscategory&task=resultscategory');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_EMAIL_TEMPLATE'), 'index.php?option=com_bfsurvey_pro&task=emailtemplate&controller=emailtemplate');
    JSubMenuHelper::addEntry(JText::_('COM_BFSURVEYPRO_TITLE_MAINTENANCE'), 'index.php?option=com_bfsurvey_pro&task=maintenance');
}

$document =& JFactory::getDocument();
$cssFile = './components/com_bfsurvey_pro/css/bfsurvey.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

require_once JPATH_COMPONENT.DS.'helpers'.DS.'helper.php';

// Create the controller
$classname	= 'bfsurvey_proController'.$controller;
$controller = new $classname( );

// Check the task parameter and execute appropriate function
switch( JRequest::getCmd('task')) {
    case "cancel":
        $controller->cancel();
        break;
    case "edit":
        $controller->edit();
        break;
    case "add":
        $controller->edit();
        break;
    case "save":
        $controller->save();
        break;
    case 'remove':
        $controller->remove();
        break;
    case 'publish':
        $controller->publishQuestion();
        break;
    case 'unpublish':
        $controller->unPublishQuestion();
        break;
    case 'orderup':
        $controller->moveUpQuestion();
        break;
    case 'orderdown':
        $controller->moveDownQuestion();
        break;
    case 'saveorder':
        $controller->saveOrder();
        break;
    case 'choose_css':
        $controller->chooseCSS( );
        break;
    case 'edit_css':
        $controller->editCSS();
        break;
    case 'save_css':
        $controller->saveCSS();
        break;
    case 'report':
        $controller->report();
        break;
    case 'csvexport':
        $controller->csvExport();
        break;
    case 'category':
        $controller->category();
        break;
    case 'copy':
        $controller->copy();
        break;
    case 'copyCategory':
        $controller->copyCategory();
        break;                
    case "show":
        $controller->show();
        break;
    case "stats":
        $controller->stats();
        break;
    case "import":
        $controller->import();
        break;
    case "maintenance":
        $controller->maintenance();
        break;
    case 'dbcleanup':
        $controller->dbcleanup();
        break;
    case 'dbbackup':
        $controller->dbbackup();
    	break;
    case "importquestions":
        $controller->importquestions();
        break;
    case "importquestionsTrial":
        $controller->importquestionsTrial();
        break;        
	case 'saveorder':
		saveOrder();
		break;
    case "emailtemplate":
        $controller->emailtemplate();
        break;    
    case "saveemailitem":
        $controller->saveemailitem();
        break;		
    default:
        $controller->display();
        break;
}

// Redirect if set by the controller
$controller->redirect();

?>
