<?php
/**
 * $Id: controller.php 4 2012-01-09 12:57:12Z tuum $
 * bfsurvey_pro default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

/**
 * bfsurvey_pro Component Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfsurvey_proController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

	function stats()
	{
		JRequest::setVar( 'view', 'statscategory' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function show()
	{
		JRequest::setVar( 'view', 'stats' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Used to import Question from BF Survey Pro Free
	*/
	function import()
	{
		JRequest::setVar( 'view', 'import' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Used for DB Clean up and other maintenance
	*/
	function maintenance()
	{
		JRequest::setVar( 'view', 'maintenance' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	function csvExport()
	{
		JRequest::setVar( 'view', 'csvexport' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	* Publishes one or more modules
	*/
	function publishQuestion(  ) {
		bfsurvey_proController::changePublishQuestion( 1 );
	}

	/**
	* Unpublishes one or more modules
	*/
	function unPublishQuestion(  ) {
		bfsurvey_proController::changePublishQuestion( 0 );
	}

	/**
	* Publishes or Unpublishes one or more modules
	* @param integer 0 if unpublishing, 1 if publishing
	*/
	function changePublishQuestion( $publish )
	{
		global $mainframe;

		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

		$db 		=& JFactory::getDBO();
		$user 		=& JFactory::getUser();

		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_('COM_BFSURVEYPRO_ERROR_NO_ITEMS_SELECTED') );
			$mainframe->redirect( 'index.php?option='. $option );
		}

		$cids = implode( ',', $cid );

		$query = 'UPDATE #__bfsurvey_pro'
		. ' SET published = '.(int) $publish
		. ' WHERE id IN ( '. $cids .' )'
		. ' AND ( checked_out = 0 OR ( checked_out = '.(int) $user->get('id') .' ) )'
		;
		$db->setQuery( $query );
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg() );
		}

		$mainframe->redirect( 'index.php?option='. $option );
    }


/**
* Moves the record up one position
*/
function moveUpQuestion(  ) {
	bfsurvey_proController::orderQuestion( -1 );
}

/**
* Moves the record down one position
*/
function moveDownQuestion(  ) {
	bfsurvey_proController::orderQuestion( 1 );
}

/**
* Moves the order of a record
* @param integer The direction to reorder, +1 down, -1 up
*/
function orderQuestion( $inc )
{
	global $mainframe;

	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

    JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_bfsurvey_pro'.DS.'tables');
	$row =& JTable::getInstance('question', 'Table');

	$db		=& JFactory::getDBO();
	$cid	= JRequest::getVar('cid', array(0), '', 'array');
	$option = JRequest::getCmd('option');
	JArrayHelper::toInteger($cid, array(0));

	$limit 		= JRequest::getVar( 'limit', 0, '', 'int' );
	$limitstart = JRequest::getVar( 'limitstart', 0, '', 'int' );
	$catid 		= JRequest::getVar( 'catid', 0, '', 'int' );

	$row =& JTable::getInstance( 'question', 'Table' );
	$row->load( $cid[0] );
	$row->move( $inc, 'catid = '.(int) $row->catid.' AND published != 0' );

	$mainframe->redirect( 'index.php?option='. $option );
}

/**
* displays the results of completed survey
*/
function results()
{
	global $option, $mainframe;
	$limit = JRequest::getVar('limit',
				$mainframe->getCfg('list_limit'));
	$limitstart = JRequest::getVar('limitstart', 0);
	$db =& JFactory::getDBO();
	$query = "SELECT count(*) FROM #__bfsurvey_pro_data";
	$db->setQuery( $query );
	$total = $db->loadResult();
	$query = "SELECT * FROM #__bfsurvey_pro_data";
	$db->setQuery( $query, $limitstart, $limit );
	$rows = $db->loadObjectList();
	if ($db->getErrorNum())
	{
		echo $db->stderr();
		return false;
	}
	jimport('joomla.html.pagination');
	$pageNav = new JPagination($total, $limitstart, $limit);
	BFSurveysViewBFSurveys::showResults( $option, $rows, $pageNav );
}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'question' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * display the report form
	 * @return void
	 */
	function report()
	{
		JRequest::setVar( 'view', 'report' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * display the category form
	 * @return void
	 */
	function category()
	{
		JRequest::setVar( 'view', 'category' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('question');

		if ($model->store($post)) {
			$msg = JText::_( 'COM_BFSURVEYPRO_RECORD_SAVED' );
		} else {
			$msg = JText::_( 'COM_BFSURVEYPRO_ERROR_SAVING_RECORD' );
		}

		$msg = $cid[0];

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_bfsurvey_pro';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('question');
		if(!$model->delete()) {
			$msg = JText::_( 'COM_BFSURVEYPRO_ERROR_QUESTION_NOT_DELETED' );
		} else {
			$msg = JText::_( 'COM_BFSURVEYPRO_ERROR_QUESTIONS_DELETED' );
		}

		$this->setRedirect( 'index.php?option=com_bfsurvey_pro', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'COM_BFSURVEYPRO_OPERATION_CANCELLED' );
		$this->setRedirect( 'index.php?option=com_bfsurvey_pro', $msg );
	}

	/**
	  Copies one or more questions
	 */
	function copy()
	{
		// Check for request forgeries
		//JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_bfsurvey_pro' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();

		$table	=& JTable::getInstance('question', 'Table');

		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{
			foreach ($cid as $id)
			{
				if ($table->load( (int)$id ))
				{
				   $table->id					= "";
					$table->question			= JText::_('Copy of ') . $table->question;
					$table->published 			= 0;

					$now =& JFactory::getDate();
					$table->date			= $now->toMySQL();
					$table->field_name 			="";

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}
				else {
					return JError::raiseWarning( 500, $table->getError() );
				}
			}
		}
		else {
			return JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPRO_ERROR_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFSURVEYPRO_ITEMS_COPIED', $n ) );
	}

	/**
	  Copies one or more surveys
	 */
	function copyCategory()
	{
		$this->setRedirect( 'index.php?option=com_bfsurvey_pro' );

		$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );
		$db		=& JFactory::getDBO();

		$table	=& JTable::getInstance('question', 'Table');

		$user	= &JFactory::getUser();
		$n		= count( $cid );

		if ($n > 0)
		{

			//get the category id for the first question we are looking at
			$query = 'SELECT *'
			. ' FROM #__bfsurvey_pro'
			. ' WHERE id='.(int)$cid[0]
			;

			$db->setQuery( $query );
			$result = $db->loadObjectList( );

			//now get all the questions for that category
			$query = 'SELECT *'
			. ' FROM #__bfsurvey_pro'
			. ' WHERE catid='.(int)$result[0]->catid
			;

			$db->setQuery( $query );
			$result = $db->loadObjectList( );

			//now get the category name
			$query = 'SELECT title'
						. ' FROM #__categories'
						. ' WHERE id='.$result[0]->catid
						;

			$db->setQuery( $query );
			$result2 = $db->loadObjectList( );

			//now create a new category
			$query = "INSERT INTO `#__categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
				('', 0, ".$db->quote( $db->getEscaped('copy of '.$result2[0]->title), false ).", '', ".$db->quote( $db->getEscaped($result2[0]->title), false ).", '', 'com_bfsurvey_pro', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '')";

				$db->setQuery( $query);
				if (!$db->query())
				{
					echo $db->getErrorMsg();
					return false;
				}

			//now get the new category id number
			$query = "SELECT max(id) as catid from `#__categories`";
			$db->setQuery( $query);
			if (!$db->query())
			{
				echo $db->getErrorMsg();
				return false;
			}
			$newCatid = $db->loadObjectList( );


			foreach ($result as $myquestion)
			{
				//for child questions, get new parent id
				if( ($myquestion->parent) > 0){
					$newParent = bfsurvey_proController::getNewParent($myquestion->parent);
				}

				if ($table->load( (int)$myquestion->id ))
				{
				   $table->id					= "";
					$table->question			= $table->question;
					$table->catid				= $newCatid[0]->catid;
					if($myquestion->parent > 0){
						$table->parent			= $newParent;
					}

					$now =& JFactory::getDate();
					$table->date			= $now->toMySQL();

					if (!$table->store()) {
						return JError::raiseWarning( $table->getError() );
					}
				}
				else {
					return JError::raiseWarning( 500, $table->getError() );
				}
			}

		}
		else {
			return JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPRO_ERROR_NO_ITEMS_SELECTED' ) );
		}
		$this->setMessage( JText::sprintf( 'COM_BFSURVEYPRO_ITEMS_COPIED', $n ) );
	}

	function getNewParent($parent){
		$db		=& JFactory::getDBO();

		//now get the questions of the original parent
		$query = 'SELECT question'
			. ' FROM #__bfsurvey_pro'
			. ' WHERE id='.(int)$parent
		;

		$db->setQuery( $query );
		$result = $db->loadObjectList( );

		//now get new parent id of the new parent question
		$query2 = 'SELECT id'
			. ' FROM #__bfsurvey_pro'
			. ' WHERE `question`="'.$result[0]->question.'" AND `id`<>'.(int)$parent
		;

		$db->setQuery( $query2 );
		$result2 = $db->loadObjectList( );
		$newid = $result2[0]->id;

		return $newid;
	}	
	
	/**
	 * view to allow user to select css file to edit
	 * @return void
	 */
	function chooseCSS()
	{
		JToolBarHelper::title(   JText::_( 'COM_BFSURVEYPRO_CHOOSE_CSS' ), 'bfsurvey_pro_toolbar_title');
		JToolBarHelper::custom( 'edit_css', 'edit', 'edit', 'Edit', true );
		JToolBarHelper::cancel();

	    global $mainframe;

		// Initialize some variables
		$option     = JRequest::getCmd('option');
		$template    = JRequest::getVar('id', '', 'method', 'cmd');
		$client        =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));

		// Determine CSS directory
		$dir = JPATH_SITE.DS.'components'.DS.'com_bfsurvey_pro'.DS.'css';

		// List .css files
		jimport('joomla.filesystem.folder');
		$files = JFolder::files($dir, '\.css$', false, false);

		// Set FTP credentials, if given
		jimport('joomla.client.helper');
		JClientHelper::setCredentialsFromRequest('ftp');

		require_once  (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_templates'.DS.'admin.templates.html.php');
        TemplatesView::chooseCSSFiles($template, $dir, $files, $option, $client);

	}

	/**
	 * form to allow user to edit css file
	 * @return void
	 */
	function editCSS()
	      {
	      	  JToolBarHelper::title(   JText::_( 'COM_BFSURVEYPRO_EDIT_CSS' ), 'bfsurvey_pro_toolbar_title');
	      	  JToolBarHelper::save( 'save_css' );
	      	  JToolBarHelper::cancel();

	          global $mainframe;

	          // Initialize some variables
	          $option        = JRequest::getCmd('option');
	          $client        =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfsurvey_pro";
	          $filename    = JRequest::getVar('filename', '', 'method', 'cmd');

	          jimport('joomla.filesystem.file');

	          if (JFile::getExt($filename) !== 'css') {
	              $msg = JText::_('COM_BFSURVEYPRO_WRONG_FILE_TYPE');
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id.'&task=choose_css&id='.$template, $msg, 'error');
	          }

	          $content = JFile::read($client->path.DS.'components'.DS.$template.DS.'css'.DS.$filename);

	          if ($content !== false)
	          {
	              // Set FTP credentials, if given
	              jimport('joomla.client.helper');
	              $ftp =& JClientHelper::setCredentialsFromRequest('ftp');

	              $content = htmlspecialchars($content, ENT_COMPAT, 'UTF-8');

	              require_once  (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_templates'.DS.'admin.templates.html.php');
	              TemplatesView::editCSSSource($template, $filename, $content, $option, $client, $ftp);
	          }
	          else
	          {
	              $msg = JText::sprintf( JText::_('COM_BFSURVEYPRO_ERROR_COULD_NOT_OPEN'), $client->path.$filename);
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, $msg);
	          }
	      }

			/**
			* save css file changes
			* @return void
			*/
	      function saveCSS()
	      {
	          global $mainframe;

	          // Check for request forgeries
	          JRequest::checkToken() or jexit( JText::_('COM_BFSURVEYPRO_ERROR_INVALID_TOKEN') );

	          // Initialize some variables
	          $option            = JRequest::getCmd('option');
	          $client            =& JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
	          $template    = "com_bfsurvey_pro";
	          $filename        = JRequest::getVar('filename', '', 'post', 'cmd');
	          $filecontent    = JRequest::getVar('filecontent', '', 'post', 'string', JREQUEST_ALLOWRAW);

	          if (!$template) {
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFSURVEYPRO_OPERATION_FAILED').': '.JText::_('COM_BFSURVEYPRO_NO_TEMPLATE_SPECIFIED'));
	          }

	          if (!$filecontent) {
	              $mainframe->redirect('index.php?option='.$option.'&client='.$client->id, JText::_('COM_BFSURVEYPRO_OPERATION_FAILED').': '.JText::_('COM_BFSURVEYPRO_CONTENT_EMPTY'));
	          }

	          // Set FTP credentials, if given
	          jimport('joomla.client.helper');
	          JClientHelper::setCredentialsFromRequest('ftp');
	          $ftp = JClientHelper::getCredentials('ftp');

	          $file = $client->path.DS.'components'.DS.$template.DS.'css'.DS.$filename;

	          // Try to make the css file writeable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0755')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFSURVEYPRO_COULD_NOT_MAKE_WRITABLE'));
	          }

	          jimport('joomla.filesystem.file');
	          $return = JFile::write($file, $filecontent);

	          // Try to make the css file unwriteable
	          if (!$ftp['enabled'] && JPath::isOwner($file) && !JPath::setPermissions($file, '0555')) {
	              JError::raiseNotice('SOME_ERROR_CODE', JText::_('COM_BFSURVEYPRO_COULD_NOT_MAKE_UNWRITABLE'));
	          }

			  if ($return)
			  {
			      $msg = JText::_( 'COM_BFSURVEYPRO_FILE_SAVED' );
			  }else{
			  	  $msg = JText::_( 'COM_BFSURVEYPRO_FAILED_TO_OPEN_FOR_WRITING' );
			  }


			  $this->setRedirect( JRoute::_('index.php?option=com_bfsurvey_pro&task=complete', false), $msg );
      }


      function getCategory()
	  	{
	  		$db = &JFactory::getDBO();

	  			$query = 'SELECT a.id, a.title'
	  			. ' FROM #__categories AS a'
	  			. ' WHERE a.published = 1 and a.section="com_bfsurvey_pro"'
	  			. ' ORDER BY a.title'
	  			;


	  		$db->setQuery( $query );
	  		$options = $db->loadObjectList( );

	  	    return $options;
	}


		function getQuestions($catid)
		{
		    $db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfsurvey_pro";

		    // get questions
			$query = "SELECT * FROM ".$table." where `catid`=".$catid." AND `published`=1 ORDER BY ordering";


			$db->setQuery( $query );
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			return $rows;

		}

	function getStatsCheckbox($question, $response, $catid){

		$db =& JFactory::getDBO();
		global $mainframe;
		$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".$catid;

		$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."` like'%".$db->getEscaped( $response, true )."%'";

		$db->setQuery( $query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;

	}

	function getStats($question, $response, $catid){

			$db =& JFactory::getDBO();
			global $mainframe;
			$table=$mainframe->getCfg('dbprefix')."bfsurveypro_".(int)$catid;

		  	$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."`='". $db->getEscaped( $response, true )."'";

			$db->setQuery( $query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}
			$n = count($rows);
			return $n;
	}
	
	function getStatsOther($question, $response, $catid){
			$db =& JFactory::getDBO();

			$table="#__bfsurveypro_".(int)$catid;

			//how many records in the table
			$query = "SELECT * FROM ".$table;
			$db->setQuery( $query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}
			$total = count($rows);

			//now get all the question
			$query = 'SELECT *'
						. ' FROM #__bfsurvey_pro AS b'
						. ' WHERE b.field_name="'.$question.'"';
			$db->setQuery( $query);
			$rows2 = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}

			$count=0;
			foreach($rows2 as $qn){
				for($i=1; $i < 21; $i++){
					$tempoption="option".$i;
					$query = "SELECT * FROM ".$table." where `".$db->getEscaped( $question )."`='". $db->getEscaped( $qn->$tempoption, true )."'";

					$db->setQuery( $query);
					$rows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						return false;
					}

					$count=$count+count($rows);
				}
			}

			$num = $total-$count;

			return $num;
	}	

    function importquestions(){
	   $db =& JFactory::getDBO();
	   global $mainframe;
	   $table1=$mainframe->getCfg('dbprefix')."bfsurvey_profree";
	   $table2=$mainframe->getCfg('dbprefix')."bfsurvey_pro";
	   $table3=$mainframe->getCfg('dbprefix')."bfsurvey_pro_old";
	   $table4=$mainframe->getCfg('dbprefix')."categories";
	   
	   // Rename jos_bfsurvey_pro to jos_bfsurvey_pro_old
	   $query = "RENAME TABLE `".$table2."` TO `".$table3."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }

	   // Rename jos_bfsurvey_profree to jos_bfsurvey_pro
	   $query = "RENAME TABLE `".$table1."` TO `".$table2."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   
	   //Move categores from BF Survey Pro Free to BF Survey Pro
	   $query = "UPDATE ".$table4." set `section` = 'com_bfsurvey_pro' where `section` = 'com_bfsurvey_profree'";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   
	   echo JText::_( 'Update complete!' );

	}
	
    function importquestionsTrial(){
	   $db =& JFactory::getDBO();
	   global $mainframe;
	   $table1=$mainframe->getCfg('dbprefix')."bfsurvey_protrial";
	   $table2=$mainframe->getCfg('dbprefix')."bfsurvey_pro";
	   $table3=$mainframe->getCfg('dbprefix')."bfsurvey_pro_old";
	   $table4=$mainframe->getCfg('dbprefix')."categories";
	   
	   // Rename jos_bfsurvey_pro to jos_bfsurvey_pro_old
	   $query = "RENAME TABLE `".$table2."` TO `".$table3."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }

	   // Rename jos_bfsurvey_profree to jos_bfsurvey_pro
	   $query = "RENAME TABLE `".$table1."` TO `".$table2."`";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   
	   //Move categores from BF Survey Pro Free to BF Survey Pro
	   $query = "UPDATE ".$table4." set `section` = 'com_bfsurvey_pro' where `section` = 'com_bfsurvey_protrial'";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   
	   echo JText::_( 'Update complete!' );

	}	

	function getQuestion($field_name,$catid)
	{
		$db =& JFactory::getDBO();

		// get question
		$query = "SELECT question FROM #__bfsurvey_pro where catid=".$catid." AND field_name='".$field_name."'";

		$db->setQuery( $query);
		//$rows = $db->loadObjectList();
		$result=$db->loadResult();

	    return $result;
    }

	function getRatingQuestion($field_name,$catid)
	{
		$db =& JFactory::getDBO();

		//see if last two digits are a number
		if(is_numeric (substr($field_name, -2))){
		   $myfield_name = substr($field_name, 0, -2);
		   $option = "option".(int)substr($field_name, -2);
		}else if(is_numeric (substr($field_name, -1))){ //is last digit numeric
		   $myfield_name = substr($field_name, 0, -1);
		   $option = "option".(int)substr($field_name, -1);
		}else{
		   $field_name = ""; // not a rating question
		}

		if($field_name != ""){
		   // get question
		   $query = "SELECT `".$option."` FROM #__bfsurvey_pro where catid=".$catid." AND field_name='".$myfield_name."'";

		   $db->setQuery( $query);
		   $rows = $db->loadObjectList();
		   $result=$db->loadResult();

	       return $result;
	    }else{
	       return "";
	    }

    }

	function exportMysqlToCsv($sql_query,$filename = 'export.csv')
	{
	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    $csv_enclosed = '"';
	    $csv_escaped = "\\";

		$app = JFactory::getApplication();
		$host = $app->getCfg('host');
		$db = $app->getCfg('db');
		$user = $app->getCfg('user');
		$password = $app->getCfg('password');
		$dbtype = $app->getCfg('dbtype');

	    // Gets the data from the database		
		if($dbtype == 'mysqli'){
			$link = mysqli_connect($host, $user, $password, $db);
			@mysqli_query($link, 'set character set "utf8"');
			$result = mysqli_query($link, $sql_query);
		}else{
	    	$result = mysql_query($sql_query);
	    	$fields_cnt = mysql_num_fields($result);
		}

	    $schema_insert = '';

		if($dbtype == 'mysqli'){
			$fields = mysqli_fetch_fields($result);
			$i=0;
			foreach ($fields as $field) {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes($field->name)) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		        $i++;
			}
			$fields_cnt = $i;			
		}else{	
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}

	    $out = trim(substr($schema_insert, 0, -1));
	    $out .= $csv_terminated;

	    // Format the data
	    while ( $row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result))
	    {
	        $schema_insert = '';
	        for ($j = 0; $j < $fields_cnt; $j++)
	        {
	            if ($row[$j] == '0' || $row[$j] != '')
	            {

	                if ($csv_enclosed == '')
	                {
	                    $schema_insert .= $row[$j];
	                } else
	                {
	                    $schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
	                }
	            } else
	            {
	                $schema_insert .= '';
	            }

	            if ($j < $fields_cnt - 1)
	            {
	                $schema_insert .= $csv_separator;
	            }
	        } // end for

	        $out .= $schema_insert;
	        $out .= $csv_terminated;
	    } // end while

	    header("Content-Length: " . strlen($out));
	    // Output to browser with appropriate mime type, you choose ;)
	    header('Content-Encoding: UTF-8');
		header('Content-type: text/csv; charset=UTF-8');	    
	   	header("Pragma: no-cache");
		header("Expires: 0");
	    header("Content-Disposition: attachment; filename=$filename");
	    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	    echo $out;
	    exit;

   }

function saveOrder( )
{
	$cid 	= JRequest::getVar('cid', array(0), 'post', 'array');
	global $mainframe;

	// Check for request forgeries
	//JRequest::checkToken() or jexit( 'Invalid Token' );

	// Initialize variables
	$db			=& JFactory::getDBO();
	$total		= count( $cid );
	$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
	JArrayHelper::toInteger($order, array(0));

	$row =& JTable::getInstance('question', 'Table');
	$groupings = array();

	// update ordering values
	for( $i=0; $i < $total; $i++ ) {
		$row->load( (int) $cid[$i] );
		// track categories
		$groupings[] = $row->catid;

		if ($row->ordering != $order[$i]) {
			$row->ordering = $order[$i];
			if (!$row->store()) {
				JError::raiseError(500, $db->getErrorMsg() );
			}
		}
	}

	// execute updateOrder for each parent group
	$groupings = array_unique( $groupings );
	foreach ($groupings as $group){
		$row->reorder('catid = '.(int) $group);
	}

	$msg 	= JText::_('COM_BFSURVEYPRO_NEW_ORDERING_SAVED');
	$mainframe->redirect( 'index.php?option=com_bfsurvey_pro', $msg );
}


   /**********************************************************************************
    * This function will search through your answer table for fields that don't have
    * associated questions, and will automatically detele them.
    * Used by maintenance view.
    **********************************************************************************/
	function dbcleanup(){
	   $db =& JFactory::getDBO();
	   global $mainframe;
	   $table=$mainframe->getCfg('dbprefix')."bfsurvey_pro";

	   //first get all the categories
	   $query = "SELECT DISTINCT catid FROM `".$table."`;";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   $rows1 = $db->loadObjectList();

	   // get field names and categories
	   $query = "SELECT field_name, catid, question_type FROM `".$table."`;";

	   $db->setQuery( $query );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   $rows = $db->loadObjectList();

       for($n=0;$n < count($rows1); $n++){
          $row1 = &$rows1[$n];
          $table2=$mainframe->getCfg('dbprefix')."bfsurveypro_".$row1->catid;

          echo $table2."<br>";

          //now get the fields for the selected table
		  $fields =& $db->getTableFields( $table2, true );

		  if(!$fields){
	         global $mainframe;
		     JError::raiseWarning( 500, JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_TABLE').' '.$table2.' '.JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_DOES_NOT_EXIST') );
		     JError::raiseNotice( 500, JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_IGNORE_WARNING') );
		     return null;
	      }

   	      if( sizeof( $fields[$table2] ) ) {
            // We found some fields so let's create the list
            $options = array();
            foreach( $fields[$table2] as $field => $type ) {
            	$options[] = $field;

            	//now is there a question associated with this field?
            	$found=0;
            	for($i=0;$i < count($rows); $i++){
					$row = &$rows[$i];

				 	if($row->catid == $row1->catid){ // is this question in the same category
						if($row->field_name == $field | $field == "id" | $field == "Name" | $field == "Company" | $field == "Email" | $field == "DateReceived" | $field == "ip" | $field == "uid"){
						   $found=1;
						   $i=count($rows);
						}
					}

					//rating question
					if($row->question_type == 9){
					   if(strlen($row->field_name) > strlen($field)){
					      $mylen=strlen($field);
					   }else{
					      $mylen=strlen($row->field_name);
					   }

					   if($row->field_name == substr($field, 0, $mylen)){
					      $found=1;
					   }
					}
	      		}

	      		if($found==0){
	      		   echo JText::_( "COM_BFSURVEYPRO_ERROR_CANT_FIND_FIELD");
	      		   echo " ";
	      		   echo $field;
	      		   $query="ALTER TABLE ".$table2." DROP `".$field."`";
	      		   $db->setQuery( $query );
				   if (!$db->query())
				   {
				   	   echo $db->getErrorMsg();
				   	   return false;
				   }
				   ?>
				   <br>
				   <?php
	               echo JText::_( "COM_BFSURVEYPRO_ERROR_FIELD");
	               echo " ";
	               echo $field;
	               echo " ";
	               echo JText::_( "COM_BFSURVEYPRO_ERROR_HAS_BEEN_DELETED");
	               echo " ";
	               echo $table2;
	               ?>
	               <br>
	               <?php
	      		}

      		}
   		  }

	   }

	   echo JText::_( "COM_BFSURVEYPRO_FINISHED_DB_CLEANUP");
	}

   /**********************************************************************************
    * This function will backup your BF Survey Pro tables
    **********************************************************************************/
	function dbbackup(){
	   global $mainframe;
	   $table=$mainframe->getCfg('dbprefix')."bfsurvey_pro";

	   $myExport = bfsurvey_proController::exportMyTable($table);

	   $db =& JFactory::getDBO();

	   //get all survey category id numbers
	   $query = "SELECT id, title FROM `#__categories` WHERE `section`='com_bfsurvey_pro'";

	   $db->setQuery( $query );
	   $rows = $db->loadObjectList();

	   foreach($rows as $row){
	      $table=$mainframe->getCfg('dbprefix')."bfsurveypro_".$row->id;
	      $myExport .= "\n";
	      $myExport .= bfsurvey_proController::exportMyTable($table);
	   }

	   echo JText::_( 'COM_BFSURVEYPRO_BACKUP_PREPARED' );
	   echo "<br>";

	   // excel export
	   print '<form id="mySQLExport" name="mySQLExport" method="POST" action="./components/com_bfsurvey_pro/mysqlexport.php">';

	   print '<DIV ID="myExport" style="display:none;"><textarea name="myExport">'.$myExport.'</textarea></div>';

	   ?>
	   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'Save backup to file' ); ?>" />
	   <?php
	   print "</form>";

	   echo "<br>";
	   echo $myExport;
   }


   function exportMyTable($table){
	   $db =& JFactory::getDBO();
       // Get the structure of the question table
	   $mytable =& $db->getTableCreate( $table );

	   if(!$mytable){
	      global $mainframe;
		  JError::raiseWarning( 500, JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_TABLE').' '.$table.' '.JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_CANNOT_BE_FOUND') );
		  JError::raiseNotice( 500, JText::_('COM_BFSURVEYPRO_ERROR_MYSQL_IGNORE_WARNING') );
		  return null;
	   }

	   // Grab the fields for the selected table
	   $fields =& $db->getTableFields( $table, true );

	   //now get the question data
	   $query2='SELECT * FROM ' . $table;
	   $db->setQuery( $query2 );
	   if (!$db->query())
	   {
	      echo $db->getErrorMsg();
	      return false;
	   }
	   $rows = $db->loadRowList();

	   $myfields=array_values($fields[$table]);

	   $d=null;
	   foreach($rows as $cr){
	      $d .= "INSERT INTO `" . $table . "` VALUES (";
	      for($i=0; $i<sizeof($cr); $i++){
	         $myfield=$myfields[$i];
	         if($cr[$i] == ''){
	            if($myfield == "tinyint" | $myfield == "int"){
	               $d .= "0,";
	            }else{
	               $d .= "'',";
	            }
	         }else{
	            //add delimited before apostrophe
	            $d .= "'".addcslashes($cr[$i],"'")."',";
	         }
	      }

	      $d = substr($d, 0, strlen($d) - 1);
	      $d .= ");\n";
	   }

	   $myexport= $mytable[$table];
	   $myexport.=";\n\n";
	   $myexport .=$d;

	   return $myexport;
   }
   
	function emailtemplate()
	{
		JRequest::setVar( 'view', 'emailtemplate' );
		JRequest::setVar( 'layout', 'default'  );

		parent::display();
	}   
}
?>
