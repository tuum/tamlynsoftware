DROP TABLE IF EXISTS `#__bfsurvey_pro`;
DROP TABLE IF EXISTS `#__bfsurvey_pro_example`;
DROP TABLE IF EXISTS `#__bfsurveypro_email`;
DELETE FROM `#__categories` WHERE section="com_bfsurvey_pro";