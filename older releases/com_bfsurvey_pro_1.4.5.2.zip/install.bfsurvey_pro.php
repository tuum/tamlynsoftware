<?php
/**
 * $Id: install.bfsurvey_pro.php 2 2011-11-15 04:14:12Z tuum $
 * 
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Survey Pro is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Pro is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Pro.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Pro from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_install()
{
	$db	= &JFactory::getDBO();
	
	//check if upgrade required
	global $mainframe;
	$table=$mainframe->getCfg('dbprefix')."bfsurvey_pro";
	$fields =& $db->getTableFields( $table, true );
	if( sizeof( $fields[$table] ) ) {
		// We found some fields so let's create the HTML list
		$options = array();
		foreach( $fields[$table] as $field => $type ) {
			$options[] = JHTML::_( 'select.option', $field, $field );
		}
	}	
	
	//CHECK FOR V1.2.6 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "field_type") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER table `#__bfsurvey_pro` ADD `validation_type` varchar(50) NOT NULL,
	ADD `field_type` varchar(50) NOT NULL
		    	   ;";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
		
		//ALSO NEED TO -
		//For all answer tables in the form jos_bfsurveypro_xx (where xx is your category id number)
		//ALTER table `jos_bfsurveypro_xx` ADD `uid` int(11) NOT NULL default 0;
	}	
	
	//CHECK FOR V1.2.3 UPGRADE
	$found=0;
	foreach( $fields[$table] as $field => $type ) {
		if ($field == "suppressQuestion") {
			$found=1;
		}
	}

	if($found == 0){
		$query="ALTER table `#__bfsurvey_pro` ADD `suppressQuestion` tinyint(1),
	ADD `otherprefix` varchar(255) NOT NULL, 
	ADD `othersuffix` varchar(255) NOT NULL
  	  	    	   ;";

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
	   		return false;
		}
	}	
	
	//check for sample data
	$db->setQuery('SELECT `id` FROM `#__bfsurvey_pro`');
	$result=$db->loadResult();
	
	if($result){
		//no need for sample data
	}else{
		//install sample data		
		$query = "INSERT INTO `#__categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES 
			('', 0, 'Example', '', 'example', '', 'com_bfsurvey_pro', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '')";
		
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	      
		$query = "SELECT @catid := max(id) from `#__categories`";
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$query = "INSERT INTO `#__bfsurvey_pro` (`id`, `catid`, `question`, `question_type`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`, `parent`, `option1`, `option2`, `option3`, `option4`, `option5`, `option6`, `option7`, `option8`, `option9`, `option10`, `next_question1`, `next_question2`, `next_question3`, `next_question4`, `next_question5`, `next_question6`, `next_question7`, `next_question8`, `next_question9`, `next_question10`, `prefix`, `suffix`, `field_name`, `mandatory`, `helpText`, `sql`, `sqlfield`,`fieldSize`) VALUES 
(1, @catid, 'Is this the first time you have used us?', '1', '2008-10-29 23:32:11', 0, '0000-00-00 00:00:00', 1, 1, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'firstTime', 1, '', '', '',255),
(2, @catid, 'How did you hear about us?', '1', '2008-10-24 01:15:30', 0, '0000-00-00 00:00:00', 1, 2, 0, 'Word of Mouth', 'Advertisement', 'Internet', 'Other', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'howDidYouHear', 1, '', '', '',255),
(3, @catid, 'Why did you choose to use us?', '2', '2008-10-29 02:42:06', 0, '0000-00-00 00:00:00', 1, 3, 0, 'Price', 'Quality', 'Service', 'Recommendation', 'Referral', 'Location', 'Other', '', '', '', 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, '', '', 'whyUs', 0, '', '', '',255),
(4, @catid, 'Why did you choose to use us again?', '2', '2008-10-24 01:19:18', 0, '0000-00-00 00:00:00', 1, 4, 0, 'Price', 'Quality', 'Service', 'Convenience', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whyAgain', 0, '', '', '',255),
(5, @catid, 'How would you rate our service?', '6', '2008-10-24 01:15:34', 0, '0000-00-00 00:00:00', 1, 5, 0, 'Very good', 'Good', 'Acceptable', 'Poor', 'Very poor', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'rateService', 1, '', '', '',255),
(6, @catid, 'How would you rate the quality of our work?', '1', '2008-11-02 00:07:17', 0, '0000-00-00 00:00:00', 1, 6, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'rateQualityOfWork', 0, '', 'select * from jos_bfsurvey_pro_example', 'choices',255),
(7, @catid, 'Would you use us again?', '1', '2008-11-02 00:01:58', 0, '0000-00-00 00:00:00', 1, 7, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'useAgain', 1, '', '', '',255),
(8, @catid, 'When are you likely to use our services next?', '5', '2008-11-02 00:01:38', 0, '0000-00-00 00:00:00', 1, 8, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whenNextUse', 0, 'An approximate date will be fine.', '', '',255),
(9, @catid, 'Do you have any other comments?', '3', '2008-10-24 02:14:38', 0, '0000-00-00 00:00:00', 1, 9, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'comments', 0, '', '', '',255)";
		
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}
	
	//check for sample data
	$db->setQuery('SELECT `id` FROM `#__bfsurvey_pro_example`');
	$result=$db->loadResult();

	if($result){
		//no need for sample data
	}else{
		//install sample data		
		$query = "INSERT INTO `#__bfsurvey_pro_example` (`id`, `choices`) VALUES 
(1, 'High'),
(2, 'Acceptable'),
(3, 'Low')";		
		
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}	
	
	//check for email sample data
	$db->setQuery('SELECT `id` FROM `#__bfsurveypro_email`');
	$result=$db->loadResult();
	
	if($result){
		//no need for sample email data
	}else{		
		//install email data		
		$query = "INSERT INTO `#__bfsurveypro_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `published`, `ordering`, `showQuestions`) VALUES
(1, @catid, 'Admin', 'Automated BF Survey Pro Notification - {name}', '<p>{name} ({email}) has completed the {category} survey', '2010-06-19 11:43:53', 0, '0000-00-00 00:00:00', 1, 0, 1),
(2, @catid, 'Author', 'Automated BF Survey Pro Notification', '<p>Thank you {name} for completing the {category} survey.</p>\r\n<p> </p>', '2010-06-19 11:00:31', 0, '0000-00-00 00:00:00', 1, 2, 1)";
		
		$db->setQuery( $query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}
	}	
	
?>

<div class="header"><strong>BF Survey Pro</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

		<img src="./components/com_bfsurvey_pro/images/bflogo.jpg"><br/>

        <br/>  Copyright &copy; 2011 - Tamlyn Creative Pty Ltd. All rights reserved.
        <br />

                <br/>This Joomla! 1.5.x Component is released under the GNU GPL.
                <br/>
                <br/>Congratulations, you have successfully installed BF Survey Pro!
        </p>
    </td>
  </tr>
  <tr>
    <td>
    </td>
    <td>
            <strong><code>I N S T A L L :</code></strong>

                <br/>

                <br/>

                STEP 1 : <font color = "Green">Succesfull</font>
                <br>
                <br>
                STEP 2 : Navigate to Components, BF Survey Pro->Questions, and setup questions as required.
                <br>
                <br>
                STEP 3 : Add a "BF Survey Pro" menu item. Make sure you configure email address in "Parameters - Component", and select Category in "Parameters - Basic".
				<br>
                <br>
                STEP 4 : (optional) If you wish to make radio or checkbox fields mandatory, you need to install <a href="http://www.tamlyncreative.com.au/software/downloads.html" target="_blank">BF Validate</a> plugin.
				<br>
                <br>
                STEP 5 : (optional) If you wish to use CAPTCHA, you need to install <a href="http://www.joomla.com.br/downloads/doc_details/50-bigo-captcha-12.html" target="_blank">Bigo CAPTCHA</a> plugin.
                <br>
                <br>
                STEP 6 : (optional) If you wish to use Video or audio, you need to install <a href="http://extensions.joomla.org/extensions/multimedia/video-players-&-gallery/812/details" target="_blank">AllVideos</a> plugin.
				<br>
                <br>

    </td>
  </tr>
    </table>
</center>

<?php
}
?>