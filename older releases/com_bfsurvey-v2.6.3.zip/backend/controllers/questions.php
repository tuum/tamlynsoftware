<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyControllerQuestions extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'questions';

		//redirect to categories view if none exist
		require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfsurvey.php';
		$numCategories = BFSurveyHelperBfsurvey::getNumberCategoires();
		if ($numCategories == 0)
		{
			$url = 'index.php?option=com_bfsurvey&view=categories';
			$this->setRedirect($url, JText::sprintf('COM_BFSURVEY_WARNING_NO_CATEGORIES', ''));
			$this->redirect();
		}
	}

	public function fixDatabase()
	{
		$this->setRedirect( 'index.php?option=com_bfsurvey&view=questions' );
		require_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/answertable.php';

		$errors = answerTable::buildAnswerTables();
		if($errors){
			JError::raiseWarning(100, $errors);
		}else{
			$this->setMessage( JText::_( 'COM_BFSURVEY_DATABASE_FIXED' ) );
		}
	}

	// Tim's note: this next bit doesn't work yet
	/**
	 * Method to load a row from version history
	 *
	 * @return  mixed  True if the record can be added, a error object if not.
	 *
	 * @since   3.2
	 */
	public function loadhistory()
	{
		$app = JFactory::getApplication();
		$lang  = JFactory::getLanguage();
		$model = $this->getModel();
		$table = $model->getTable();
		$historyId = $app->input->get('version_id', null, 'integer');
		$context = "$this->option.edit.$this->context";

		if (!$model->loadhistory($historyId, $table))
		{
			$this->setMessage($model->getError(), 'error');

			$this->setRedirect(
					JRoute::_(
							'index.php?option=' . $this->option . '&view=' . $this->view_list
							. $this->getRedirectToListAppend(), false
					)
			);

			return false;
		}

		// Determine the name of the primary key for the data.
		if (empty($key))
		{
			$key = $table->getKeyName();
		}

		$recordId = $table->$key;

		// To avoid data collisions the urlVar may be different from the primary key.
		$urlVar = empty($this->urlVar) ? $key : $this->urlVar;

		// Access check.
		if (!$this->allowEdit(array($key => $recordId), $key))
		{
			$this->setError(JText::_('JLIB_APPLICATION_ERROR_EDIT_NOT_PERMITTED'));
			$this->setMessage($this->getError(), 'error');

			$this->setRedirect(
					JRoute::_(
							'index.php?option=' . $this->option . '&view=' . $this->view_list
							. $this->getRedirectToListAppend(), false
					)
			);
			$table->checkin();

			return false;
		}

		$table->store();
		$this->setRedirect(
				JRoute::_(
						'index.php?option=' . $this->option . '&view=' . $this->view_item
						. $this->getRedirectToItemAppend($recordId, $urlVar), false
				)
		);

		$this->setMessage(JText::sprintf('JLIB_APPLICATION_SUCCESS_LOAD_HISTORY', $model->getState('save_date'), $model->getState('version_note')));

		// Invoke the postSave method to allow for the child class to access the model.
		$this->postSaveHook($model);

		return true;
	}

	public function copy()
	{
		$model = $this->getThisModel();

		if (!$model->getId())
		{
			$model->setIDsFromRequest();
		}

		if (!$model->getId())
		{
			JError::raiseWarning(100, JText::_('JLIB_HTML_PLEASE_MAKE_A_SELECTION_FROM_THE_LIST'));
			$this->setRedirect(
					JRoute::_('index.php?option=com_bfsurvey&view=questions', false)
			);
			return false;
		}

		parent::copy();

		return true;
	}
}