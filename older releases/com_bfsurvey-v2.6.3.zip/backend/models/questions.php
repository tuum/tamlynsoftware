<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelQuestions extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'questions';
	}

	public function save($data)
	{
		if($this->task != 'saveorder'){
			//sanatize field_name so that only contains letters, numbers or underscores, and make it lowercase
			$data['field_name'] = preg_replace('/[^a-zA-Z0-9_]/', '', strtolower($data['field_name']));

			if(is_array($data['hide_options'])){
				$data['hide_options'] = implode(",", $data['hide_options']);
			}

			if(is_array($data['show_options'])){
				$data['show_options'] = implode(",", $data['show_options']);
			}

			if(is_array($data['terminate_options'])){
				$data['terminate_options'] = implode(",", $data['terminate_options']);
			}

			for($i = 1; $i < 21; $i++){
				$data['option'.$i]=preg_replace('/\"/', '&quot;' , $data['option'.$i]);
			}

			if (empty($data['ordering']) && empty($data['bfsurvey_question_id'])) {
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__bfsurvey_questions');
				$max = $db->loadResult();

				$data['ordering'] = $max+1;
			}
		}

		parent::save($data);

		return true;
	}

	public function buildQuery($overrideLimits = false)
	{
		$table = $this->getTable();
		$tableName = $table->getTableName();
		$tableKey = $table->getKeyName();
		$db = $this->getDbo();

		$query = $db->getQuery(true);

		// Call the behaviors
		$this->modelDispatcher->trigger('onBeforeBuildQuery', array(&$this, &$query));

		$alias = $this->getTableAlias();

		if ($alias)
		{
			$alias = ' AS ' . $db->qn($alias);
		}
		else
		{
			$alias = '';
		}

		$select = $this->getTableAlias() ? $db->qn($this->getTableAlias()) . '.*' : $db->qn($tableName) . '.*';

		$query->select($select)->from($db->qn($tableName) . $alias);

		if (!$overrideLimits)
		{
			$order = $this->getState('filter_order', null, 'cmd');

			if (!in_array($order, array_keys($table->getData())))
			{
				$order = 'ordering';
			}

			if ($alias)
			{
				$order = $db->qn($this->getTableAlias()) . '.' . $order;
			}

			$dir = $this->getState('filter_order_Dir', 'ASC', 'cmd');
			$query->order($order . ' ' . $dir);
		}

		//this is used by parent drop down on question form
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		$showhide = JRequest::getVar( 'showhide', 0, '', 'int' );
		if($catid && $showhide < 2)
		{
			$bfsurvey_question_id = JRequest::getVar( 'bfsurvey_question_id', 0, '', 'int' );

			$query->where('bfsurvey_category_id = '.$catid);
			if($showhide)
			{
				//do nothing
			}
			else
			{
				$query->where('parent = 0');
			}
			$query->where('bfsurvey_question_id<>'.(int) $bfsurvey_question_id);
		}

		// Call the behaviors
		$this->modelDispatcher->trigger('onAfterBuildQuery', array(&$this, &$query));

		return $query;
	}

	/**
	 * Method to get a list of questions.
	 * Overridden to cater for parent-child grouping.
	 */
	public function &getItemList($overrideLimits = false, $group = '')
	{
		$items	= parent::getItemList();

		// establish the hierarchy of the questions
		$children = array();
		// first pass - collect children
		foreach ($items as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$mylist = array();
		foreach ($items as $v )
		{
			if($v->parent==0){
				array_push($mylist, $v);

				//now are there any children
				if(isset($children[$v->bfsurvey_question_id])){
					foreach ($children[$v->bfsurvey_question_id] as $c ){
						$c->title = ' -- '.$c->title;
						array_push($mylist, $c);
					}
				}
			}
		}

		//if there are no parent items, just show original list with everything indented
		if(count($mylist)==0 & count($items)>0){
			foreach ($items as $v )
			{
				$v->title = ' -- '.$v->title;
				array_push($mylist, $v);
			}
		}

		return $mylist;
	}
}