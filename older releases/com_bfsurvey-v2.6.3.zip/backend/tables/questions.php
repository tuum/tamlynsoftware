<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyTableQuestions extends F0FTable
{
	function __construct( $table, $key, &$db )
	{
		$this->key = 'bfsurvey_question_id';
		parent::__construct('#__bfsurvey_questions', $this->key, $db);
		$this->typeAlias = 'com_bfsurvey.question';
	}

	// The rest of this stuff is for the content version history
	// Most functions borrowed from /libraries/cms/table/contenthistory.php
	// Except for the store function which is a hacked version of the one in /libraries/cms/helper/contenthistory.php
	/**
	 * Method to save a version snapshot to the content history table.
	 *
	 * @param   JTable  $table  JTable object being versioned
	 *
	 * @return  boolean  True on success, otherwise false.
	 *
	 * @since   3.2
	 */
	public function store($updateNulls = false)
	{
		parent::store($updateNulls);

		if(version_compare(JVERSION, '3.2', 'ge')) {
			$historyTable = JTable::getInstance('Contenthistory', 'JTable');
			$typeTable = JTable::getInstance('Contenttype', 'JTable');
			$typeTable->load(array('type_alias' => $this->typeAlias));
			$historyTable->set('ucm_type_id', $typeTable->type_id);

			$data = $this->input->getdata();
			$historyTable->set('ucm_item_id', $data['id']);

			// Don't store unless we have a non-zero item id
			if (!$historyTable->ucm_item_id)
			{
				return true;
			}

			$historyTable->set('version_data', json_encode($data));
			$input = JFactory::getApplication()->input;
			$versionName = false;

			if (isset($data['version_note']))
			{
				$versionName = JFilterInput::getInstance()->clean($data['version_note'], 'string');
				$historyTable->set('version_note', $versionName);
			}

			// Don't save if hash already exists and same version note
			$historyTable->set('sha1_hash', $historyTable->getSha1(json_encode($data), $typeTable));

			if ($historyRow = $historyTable->getHashMatch())
			{
				if (!$versionName || ($historyRow->version_note == $versionName))
				{
					return true;
				}
				else
				{
					// Update existing row to set version note
					$historyTable->set('version_id', $historyRow->version_id);
				}
			}

			$result = $historyTable->store();

			if ($maxVersions = JComponentHelper::getParams('com_bfsurvey')->get('history_limit', 0))
			{
				$historyTable->deleteOldVersions($maxVersions);
			}
		}

		return $result;
	}

	/**
	 * Utility method to get the hash after removing selected values. This lets us detect changes other than
	 * modified date (which will change on every save).
	 *
	 * @param   mixed              $jsonData   Either an object or a string with json-encoded data
	 * @param   JTableContenttype  $typeTable  Table object with data for this content type
	 *
	 * @return  string  SHA1 hash on sucess. Empty string on failure.
	 *
	 * @since   3.2
	 */
	public function getSha1($jsonData, JTableContenttype $typeTable)
	{
		$object = (is_object($jsonData)) ? $jsonData : json_decode($jsonData);

		if (isset($typeTable->content_history_options) && (is_object(json_decode($typeTable->content_history_options))))
		{
			$options = json_decode($typeTable->content_history_options);
			$this->ignoreChanges = isset($options->ignoreChanges) ? $options->ignoreChanges : $this->ignoreChanges;
			$this->convertToInt = isset($options->convertToInt) ? $options->convertToInt : $this->convertToInt;
		}

		foreach ($this->ignoreChanges as $remove)
		{
			if (property_exists($object, $remove))
			{
				unset($object->$remove);
			}
		}

		// Convert integers, booleans, and nulls to strings to get a consistent hash value
		foreach ($object as $name => $value)
		{
			if (is_object($value))
			{
				// Go one level down for JSON column values
				foreach ($value as $subName => $subValue)
				{
					$object->$subName = (is_int($subValue) || is_bool($subValue) || is_null($subValue)) ? (string) $subValue : $subValue;
				}
			}
			else
			{
				$object->$name = (is_int($value) || is_bool($value) || is_null($value)) ? (string) $value : $value;
			}
		}

		// Work around empty values
		foreach ($this->convertToInt as $convert)
		{
			if (isset($object->$convert))
			{
				$object->$convert = (int) $object->$convert;
			}
		}

		if (isset($object->review_time))
		{
			$object->review_time = (int) $object->review_time;
		}

		return sha1(json_encode($object));
	}

	/**
	 * Utility method to get a matching row based on the hash value and id columns.
	 * This lets us check to make sure we don't save duplicate versions.
	 *
	 * @return  string  SHA1 hash on sucess. Empty string on failure.
	 *
	 * @since   3.2
	 */
	public function getHashMatch()
	{
		$db = $this->_db;
		$query = $db->getQuery(true);
		$query->select('*')
			->from($db->quoteName('#__ucm_history'))
			->where($db->quoteName('ucm_item_id') . ' = ' . $this->get('ucm_item_id'))
			->where($db->quoteName('ucm_type_id') . ' = ' . $this->get('ucm_type_id'))
			->where($db->quoteName('sha1_hash') . ' = ' . $db->quote($this->get('sha1_hash')));
		$db->setQuery($query, 0, 1);

		return $db->loadObject();
	}

	/**
	 * Utility method to remove the oldest versions of an item, saving only the most recent versions.
	 *
	 * @param   integer  $maxVersions  The maximum number of versions to save. All others will be deleted.
	 *
	 * @return  boolean   true on sucess, false on failure.
	 *
	 * @since   3.2
	 */
	public function deleteOldVersions($maxVersions)
	{
		$result = true;

		// Get the list of version_id values we want to save
		$db = $this->_db;
		$query = $db->getQuery(true);
		$query->select($db->quoteName('version_id'))
			->from($db->quoteName('#__ucm_history'))
			->where($db->quoteName('ucm_item_id') . ' = ' . (int) $this->ucm_item_id)
			->where($db->quoteName('ucm_type_id') . ' = ' . (int) $this->ucm_type_id)
			->where($db->quoteName('keep_forever') . ' != 1')
			->order($db->quoteName('save_date') . ' DESC ');
		$db->setQuery($query, 0, (int) $maxVersions);
		$idsToSave = $db->loadColumn(0);

		// Don't process delete query unless we have at least the maximum allowed versions
		if (count($idsToSave) == (int) $maxVersions)
		{
			// Delete any rows not in our list and and not flagged to keep forever.
			$query = $db->getQuery(true);
			$query->delete($db->quoteName('#__ucm_history'))
				->where($db->quoteName('ucm_item_id') . ' = ' . (int) $this->ucm_item_id)
				->where($db->quoteName('ucm_type_id') . ' = ' . (int) $this->ucm_type_id)
				->where($db->quoteName('version_id') . ' NOT IN (' . implode(',', $idsToSave) . ')')
				->where($db->quoteName('keep_forever') . ' != 1');
			$db->setQuery($query);
			$result = (boolean) $db->execute();
		}

		return $result;
	}

	/**
	 * Copy (duplicate) one or more records
	 *
	 * @param   integer|array  $cid  The primary key value (or values) or the record(s) to copy
	 *
	 * @return  boolean  True on success
	 */
	public function copy($cid = null)
	{
		//We have to cast the id as array, or the helper function will return an empty set
		if($cid)
		{
			$cid = (array) $cid;
		}

		JArrayHelper::toInteger($cid);
		$k = $this->_tbl_key;

		if (count($cid) < 1)
		{
			if ($this->$k)
			{
				$cid = array($this->$k);
			}
			else
			{
				$this->setError("No items selected.");

				return false;
			}
		}

		$created_by  = $this->getColumnAlias('created_by');
		$created_on  = $this->getColumnAlias('created_on');
		$modified_by = $this->getColumnAlias('modified_by');
		$modified_on = $this->getColumnAlias('modified_on');

		$locked_byName = $this->getColumnAlias('locked_by');
		$checkin       = in_array($locked_byName, $this->getKnownFields());

		foreach ($cid as $item)
		{
			// Prevent load with id = 0

			if (!$item)
			{
				continue;
			}

			$this->load($item);

			if ($checkin)
			{
				// We're using the checkin and the record is used by someone else

				if ($this->isCheckedOut($item))
				{
					continue;
				}
			}

			// TODO Should we notify the user that we had a problem with this record?
			if (!$this->onBeforeCopy($item))
			{
				continue;
			}

			$this->$k           = null;
			$this->$created_by  = null;
			$this->$created_on  = null;
			$this->$modified_on = null;
			$this->$modified_by = null;

			$this->title = JText::_('COM_BFSURVEY_COPY_OF').' '. $this->title;
			$this->enabled = 0;
			$this->field_name = $this->field_name."_".(int) $item;

			// Let's fire the event only if everything is ok
			// TODO Should we notify the user that we had a problem with this record?
			if ($this->store())
			{
				// TODO Should we notify the user that we had a problem with this record?
				$this->onAfterCopy($item);
			}

			$this->reset();
		}

		return true;
	}
}