ALTER TABLE [#__bfauction_plus] ADD [url] [nvarchar](250) NOT NULL DEFAULT '';
ALTER TABLE [#__bfauction_plus] ADD [created_by_alias] [nvarchar](255) NOT NULL DEFAULT '';