jQuery('load', function() {	
	jQuery('textarea').keyup(function(e) {
		var id = jQuery(this).attr('id');
		var len = 0;
		
		if (id.indexOf("title") >= 0){
			//title metatag
			if (this.value.length < minTitleLength) {
				jQuery(this).css('border-color', 'DarkViolet');
				len = minTitleLength - this.value.length;
				jQuery('#warning'+id).html(minWarningText+' <br>'+this.value.length+' chars');
				jQuery('#warning'+id).css('color', 'DarkViolet');
			} else if (this.value.length > maxTitleLength) {
				jQuery(this).css('border-color', 'DeepPink');
				len = this.value.length - maxTitleLength;
				jQuery('#warning'+id).html(maxWarningText+' (-'+len+') <br>'+this.value.length+' chars');
				jQuery('#warning'+id).css('color', 'DeepPink');
			} else {
				jQuery(this).css('border-color', '');
				jQuery('#warning'+id).text('');
				jQuery('#warning'+id).css('color', 'black');
			}			
		}
		else
		{
			//description metatag
			if (this.value.length < minDescLength) {
				jQuery(this).css('border-color', 'DarkViolet');
				len = minDescLength - this.value.length;
				jQuery('#warning'+id).html(minWarningText+' <br>'+this.value.length+' chars');
				jQuery('#warning'+id).css('color', 'DarkViolet');
			} else if (this.value.length > maxDescLength) {
				jQuery(this).css('border-color', 'DeepPink');
				len = this.value.length - maxDescLength;
				jQuery('#warning'+id).html(maxWarningText+' (-'+len+') <br>'+this.value.length+' chars');
				jQuery('#warning'+id).css('color', 'DeepPink');
			} else {
				jQuery(this).css('border-color', '');
				jQuery('#warning'+id).text('');
				jQuery('#warning'+id).css('color', 'black');
			}
		}
	});
});
