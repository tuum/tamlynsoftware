<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelK2MetaCats extends F0FModel
{
	public function __construct($config = array()) {
		$config['table'] = 'k2_categories';
		parent::__construct($config);
	}

	static function getMenuItems()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('id,  name, params');
		$query->from('#__k2_categories');
		$query->where('published = 1');
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		return $rows;
	}

	static function updateMeta($param, $id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->clear();
		$query->update('#__k2_categories');
		$query->set("`params`='".$param."'");
		$query->where('id='.(int)$id);
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}

		return true;
	}

	static function getParams($id){
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('params');
		$query->from('#__k2_categories');
		$query->where("id=".$id);
		$db->setQuery($query);
		$db->query();

		$result_string = $db->loadColumn();
		$result_string = $result_string["0"];
		$result = json_decode($result_string, true);

		return $result;
	}
}
