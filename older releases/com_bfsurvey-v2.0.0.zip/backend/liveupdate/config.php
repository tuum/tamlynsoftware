<?php
/**
 * @package LiveUpdate
 * @copyright Copyright ©2014 Tim Plummer / TamlynSoftware.com
 * @copyright Copyright ©2011 Nicholas K. Dionysopoulos / AkeebaBackup.com
 * @license GNU LGPLv3 or later <http://www.gnu.org/copyleft/lesser.html>
 */

defined('_JEXEC') or die();

/**
 * Configuration class for your extension's updates. Override to your liking.
 */
class LiveUpdateConfig extends LiveUpdateAbstractConfig
{
	var $_extensionName			= 'com_bfsurvey';
	var $_versionStrategy		= 'vcompare';
	var $_updateURL				= 'http://www.tamlynsoftware.com/index.php?option=com_ars&view=update&format=ini&id=4';
	var $_extensionTitle 		= 'BF Survey';
	var $_requiresAuthorization = true;
	var $_storageConfig			= array(
			'extensionName'	=> 'com_bfsurvey',
			'key'			=> 'liveupdate'
	);

	public function __construct() {
		JLoader::import('joomla.filesystem.file');
	
		// Load the component parameters, not using JComponentHelper to avoid conflicts ;)
		JLoader::import('joomla.html.parameter');
		JLoader::import('joomla.application.component.helper');
		$db = JFactory::getDbo();
		$sql = $db->getQuery(true)
		->select($db->quoteName('params'))
		->from($db->quoteName('#__extensions'))
		->where($db->quoteName('type').' = '.$db->quote('component'))
		->where($db->quoteName('element').' = '.$db->quote('com_bfsurvey'));
		$db->setQuery($sql);
		$rawparams = $db->loadResult();
		$params = new JRegistry();
		if(version_compare(JVERSION, '3.0', 'ge')) {
			$params->loadString($rawparams, 'JSON');
		} else {
			$params->loadJSON($rawparams);
		}
	
		$this->_updateURL = 'http://www.tamlynsoftware.com/index.php?option=com_ars&view=update&format=ini&id=4';
		$this->_extensionTitle = 'BF Survey';
	
		// Dev releases use the "newest" strategy
		if(substr($this->_currentVersion,1,2) == 'ev') {
			$this->_versionStrategy = 'newest';
		} else {
			$this->_versionStrategy = 'vcompare';
		}
	
		// Get the minimum stability level for updates
		$this->_minStability = $params->get('minstability', 'stable');
	
		// Do we need authorized URLs?
		$this->_requiresAuthorization = true;
	
		parent::__construct();
	}	
}