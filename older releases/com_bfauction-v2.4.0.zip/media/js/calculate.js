function calculateTotalPrice() {

	isTaxableItem = document.getElementsByName('taxableItem');
	taxableItem = false;
	for (var i = 0, length = isTaxableItem.length; i < length; i++) {
		if (isTaxableItem[i].checked && isTaxableItem[i].value == 1) {
			taxableItem = true;
			break;
		}
	}

	currentBid = document.getElementById('currentBid');
	if (currentBid != null) {
		currentBid = parseFloat(currentBid.value);
	} else {
		return;
	}

	commission = 0;
	commissionAmount = document.getElementById('commissionAmount');
	if (commissionAmount != null) {
		commission = (parseFloat(commissionAmount.value) / 100) * currentBid;
		commission = (commission).toFixed(2);
		document.getElementById('commission').value = commission;
	}

	tax = 0;
	taxAmount = document.getElementById('taxAmount');
	if (taxAmount != null) {
		taxPercent = parseFloat(taxAmount.value / 100);
		if (taxableItem) {
			tax = taxPercent * (parseFloat(commission) + currentBid);
		} else {
			tax = taxPercent * parseFloat(commission);
		}
		tax = (tax).toFixed(2);
		document.getElementById('tax').value = tax;
	}

	shipping = document.getElementById('shipping')
	if (shipping != null) {
		shipping = parseFloat(shipping.value)
	}

	totalPrice = document.getElementById('totalPrice')
	if (totalPrice != null) {
		totalPrice.value = (parseFloat(currentBid) + parseFloat(commission) + parseFloat(tax) + parseFloat(shipping)).toFixed(2)
	}
}