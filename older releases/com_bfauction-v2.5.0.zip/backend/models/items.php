<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelItems extends F0FModel
{
	public function buildQuery($overrideLimits = false)
	{
		$user   = JFactory::getUser();

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_items');
		if (!F0FPlatform::getInstance()->isBackend())
		{
			$query->where('created_by='.$user->id);
		}

		if (!$overrideLimits)
		{
			$order = $this->getState('filter_order', null, 'cmd');

			$dir = $this->getState('filter_order_Dir', 'ASC', 'cmd');
			if(isset($order))
			{
				$query->order($order . ' ' . $dir);
			}
		}

		return $query;
	}

	public function isValidUser($itemId)
	{
		$user   = JFactory::getUser();

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_items');
		if (!F0FPlatform::getInstance()->isBackend())
		{
			$query->where('created_by='.$user->id);
		}
		$query->where('bfauction_item_id='.$itemId);
		$db->setQuery($query);
		$db->query();

		return $db->loadResult();
	}

	/**
	 * This method runs before the $data is saved to the $table. Return false to
	 * stop saving.
	 *
	 * @param   array     &$data   The data to save
	 * @param   F0FTable  &$table  The table to save the data to
	 *
	 * @return  boolean  Return false to prevent saving, true to allow it
	 */
	protected function onBeforeSave(&$data, &$table)
	{
		$uid = JFactory::getUser()->get('id');
		$date	= JFactory::getDate();

		if(is_callable(array('JDate', 'toSql'))){
			$currentDate		= $date->toSql();
		}else{
			$currentDate		= $date->toMySQL();
		}

		try
		{
			// Do I have a new record?
			$key = $table->getKeyName();

			$pk = (!empty($data[$key])) ? $data[$key] : 0;

			$this->_isNewRecord = $pk <= 0;

			if($this->_isNewRecord)
			{
				$data['created_by'] = $uid;
				$data['created'] = $currentDate;
			}
			else
			{
				$data['modified_by'] = $uid;
				$data['modified'] = $currentDate;
			}

			if (empty($data['ordering']) && empty($data['bfauction_item_id'])) {
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__bfauction_items');
				$max = $db->loadResult();

				$data['ordering'] = $max+1;
			}

		}
		catch (Exception $e)
		{
			// Oops, an exception occured!
			$this->setError($e->getMessage());

			return false;
		}

		return true;
	}

	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	function saveImages($post,$files,$config,$model,$cid)
	{
		$app = JFactory::getApplication();

		$conf = new stdClass();
		$conf->max_width = $config->get('max_width');
		$conf->max_height = $config->get('max_height');
		$conf->max_width_t = $config->get('max_width_t');
		$conf->max_height_t = $config->get('max_height_t');
		$conf->max_image_size = $config->get('max_image_size');
		$conf->thumbMethod = $config->get('thumbMethod', 1);
		$id = $post['bfauction_item_id'];

		for($i = 1; $i < 21; $i++){
			// image delete
			if ( $post['d_img'.$i] == "delete") {
				$pict = JPATH_SITE."/images/com_bfauction/".$id."img".$i.".jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
				$pict = JPATH_SITE."/images/com_bfauction/".$id."img".$i."_t.jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
			}

			if (isset( $files['img'.$i])) {
				if ( $files['img'.$i]['size'] > $conf->max_image_size) {
					$app->redirect("index.php?option=com_bfauction&view=items", JText::_('COM_BFAUCTION_IMAGETOOBIG'));
					return;
				}
			}

			// image5 upload
			if (isset( $files['img'.$i]) and !$files['img'.$i]['error'] ) {
				$path= JPATH_SITE."/images/com_bfauction/";
				$model->createImageAndThumb($files['img'.$i]['tmp_name'],
						$id."img".$i.".jpg",
						$id."img".$i."_t.jpg",
						$conf->max_width,
						$conf->max_height,
						$conf->max_width_t,
						$conf->max_height_t,
						"",
						$path,
						$files['img'.$i]['name'],
						$conf->thumbMethod);
			}
		}

		//$app->redirect("index.php?option=com_bfauction&view=items");
	}

	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	function createImageAndThumb($src_file,$image_name,$thumb_name,
			$max_width,
			$max_height,
			$max_width_t,
			$max_height_t,
			$tag,
			$path,
			$orig_name,
			$thumbMethod)
	{
		if (intval(ini_get('memory_limit')) < 64)
			ini_set('memory_limit', '64M');

		$src_file = urldecode($src_file);

		$orig_name = strtolower($orig_name);
		$findme  = '.jpg';
		$pos = strpos($orig_name, $findme);
		if ($pos === false)
		{
			$findme  = '.jpeg';
			$pos = strpos($orig_name, $findme);
			if ($pos === false)
			{
				$findme  = '.gif';
				$pos = strpos($orig_name, $findme);
				if ($pos === false)
				{
					$findme  = '.png';
					$pos = strpos($orig_name, $findme);
					if ($pos === false)
					{
						return;
					}
					else
					{
						$type = "png";
					}
				}
				else
				{
					$type = "gif";
				}
			}
			else
			{
				$type = "jpeg";
			}
		}
		else
		{
			$type = "jpeg";
		}

		if($thumbMethod != 0){
			//GD image library
			$max_h = $max_height;
			$max_w = $max_width;
			$max_thumb_h = $max_height_t;
			$max_thumb_w = $max_width_t;

			if ( file_exists( "$path/$image_name")) {
				unlink( "$path/$image_name");
			}

			if ( file_exists( "$path/$thumb_name")) {
				unlink( "$path/$thumb_name");
			}

			$read = 'imagecreatefrom' . $type;
			$write = 'image' . $type;

			$src_img = $read($src_file);

			// height/width
			$imginfo = getimagesize($src_file);
			$src_w = $imginfo[0];
			$src_h = $imginfo[1];

			$zoom_h = $max_h / $src_h;
			$zoom_w = $max_w / $src_w;
			$zoom   = min($zoom_h, $zoom_w);
			$dst_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
			$dst_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

			$zoom_h = $max_thumb_h / $src_h;
			$zoom_w = $max_thumb_w / $src_w;
			$zoom   = min($zoom_h, $zoom_w);
			$dst_thumb_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
			$dst_thumb_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

			$dst_img = imagecreatetruecolor($dst_w,$dst_h);
			$white = imagecolorallocate($dst_img,255,255,255);
			imagefill($dst_img,0,0,$white);
			imagecopyresampled($dst_img,$src_img, 0,0,0,0, $dst_w,$dst_h,$src_w,$src_h);
			if($type == 'jpeg'){
				$desc_img = $write($dst_img,"$path/$image_name", 75);
			}else{
				$desc_img = $write($dst_img,"$path/$image_name", 2);
			}

			imagedestroy($dst_img);

			$dst_t_img = imagecreatetruecolor($dst_thumb_w,$dst_thumb_h);
			$white = imagecolorallocate($dst_t_img,255,255,255);
			imagefill($dst_t_img,0,0,$white);
			imagecopyresampled($dst_t_img,$src_img, 0,0,0,0, $dst_thumb_w,$dst_thumb_h,$src_w,$src_h);
			if($type == 'jpeg'){
				$desc_img = $write($dst_t_img,"$path/$thumb_name", 75);
			}else{
				$desc_img = $write($dst_t_img,"$path/$thumb_name", 2);
			}

			imagedestroy($dst_t_img);
		}else{
			//Use JImage instead of GD
			jimport('joomla.image.image');
			jimport('joomla.filesystem.folder');
			jimport('joomla.filesystem.file');

			//now generate large thumbnail
			$thumbFileName = $path.'/'.$image_name;
			$creationMethod = 2;

			$sourceImage = new JImage($src_file);
			if(JFile::exists($src_file)){
				$thumb = $sourceImage->resize($max_width, $max_height, true, $creationMethod);
				$thumb->toFile($thumbFileName, $type);
			}

			//now generate small thumbnail
			$thumbFileName = $path.'/'.$thumb_name;
			$creationMethod = 2;

			$sourceImage = new JImage($src_file);
			if(JFile::exists($src_file)){
				$thumb = $sourceImage->resize($max_width_t, $max_height_t, true, $creationMethod);
				$thumb->toFile($thumbFileName, $type);
			}
		}
	}
}