<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<script language="javascript" type="text/javascript">
<!--

function numberWithCommas(x) {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function round(n,dec) {
	n = parseFloat(n);
	if(!isNaN(n)){
		if(!dec) var dec= 0;
		var factor= Math.pow(10,dec);
		var result = Math.floor(n*factor+((n*factor*10)%10>=5?1:0))/factor;
		return result.toFixed(2);
	}else{
		return n;
	}
}

function process()
{
	includeCommission = <?php echo $this->cparams->includeCommission ? $this->cparams->includeCommission : 0; ?>;
	commissionAmount = <?php echo $this->cparams->commissionAmount; ?>;
	includeTax = <?php echo $this->cparams->includeTax ? $this->cparams->includeTax : 0; ?>;
	taxableItem = <?php echo $this->cparams->taxableItem; ?>;
	taxAmount = <?php echo $this->cparams->taxAmount; ?>;
	userId = <?php echo $user->id; ?>;
	showTotalPrice = <?php echo $this->cparams->showTotalPrice ? $this->cparams->showTotalPrice : 0; ?>;
	currentBid = <?php echo $item->currentBid ? $item->currentBid : 0; ?>;

	nextBid = <?php echo $nextBid ? $nextBid : 0; ?>;
	quantity = parseInt(<?php echo $item->quantity ? $item->quantity : 1; ?>);

	if(includeCommission == "1"){
		commission = round( ( parseFloat(nextBid) * parseFloat(commissionAmount) ) / 100, 2 );
		$commission = document.getElementById("divCommission");
		if ($commission != null) {
			$commission.innerHTML = commission;
		}
		//document.getElementById("commission").value = commission;

		commissionCurrent = round( ( parseFloat(currentBid) * parseFloat(commissionAmount) ) / 100, 2 );
		divCommissionCurrent = document.getElementById("divCommissionCurrent");
		if (divCommissionCurrent != null) {
			divCommissionCurrent.innerHTML = numberWithCommas(commissionCurrent);
		}

	}else{
		commission = 0;
		commissionCurrent = 0;
	}

	if(includeTax){
		if(taxableItem){
			tax = round( ( ( parseFloat(nextBid) + parseFloat(commission) ) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( ( parseFloat(currentBid) + parseFloat(commissionCurrent) ) * parseFloat(taxAmount) ) / 100, 2 );
		}else{
			/* tax commission only */
			tax = round( ( parseFloat(commission) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( parseFloat(commissionCurrent) * parseFloat(taxAmount) ) / 100, 2 );
		}

		divTax = document.getElementById("divTax");
		if (divTax != null) {
			divTax.innerHTML = numberWithCommas(tax);
		}
		//document.getElementById("tax").value = tax;
		//document.getElementById("divTaxCurrent").innerHTML = taxCurrent;
	}else{
		tax = 0;
		taxCurrent = 0;
	}

	if(showTotalPrice){
		shipping = numberWithCommas(<?php echo $this->cparams->shipping ;?>);

		totalPrice = round( (parseFloat(nextBid) + parseFloat(shipping) + parseFloat(commission) + parseFloat(tax) ) ,2 );

		qtyPurchased = document.getElementById("quantityPurchased");

		if (qtyPurchased != null) {
			quantityPurchased = qtyPurchased.value;
			if (quantityPurchased > quantity) {
				qtyPurchased.value = quantity;
				quantityPurchased = quantity;
			}
			if (quantityPurchased > 1){
				totalPrice = totalPrice * parseFloat(quantityPurchased);
			}
			divTotalPrice  = document.getElementById("divTotalPrice");
			if (divTotalPrice != null) {
				divTotalPrice.innerHTML = numberWithCommas(round(totalPrice));
			}
		}

	}

	/* restart sequence (runs every 10 seconds) */
	setTimeout('process()', 10000);
}

//-->
</script>