<?php

defined('_JEXEC') or die();

jimport ('joomla.html.html.bootstrap');

// Todo: get names from plugin
$gateways = array(
	'paypal' => 'Paypal',
	'cod'   => 'Cash On Delivery',
);

$orderStatus = array(
	'C' => 'Paid',
	'P' => 'Pending',
	'E' => 'Failed',
	'D' => 'Denied',
	'RF' => 'Refunded',
	'CRV' => 'Cancelled Reversal',
	'RV' => 'Reversed',
);

$item = $this->item;

$statusText = isset($orderStatus[$item->orderStatus]) ? $orderStatus[$item->orderStatus] : '-';

$commission  = $item->currentBid * ($item->commissionAmount/100);
$tax 		 = ($item->currentBid + $commission) * ($item->taxAmount/100);
$quantity 	 = $item->quantity > 1 ? $item->quantity : 1;
$totalAmount = ($item->currentBid + $item->shipping + $tax + $commission) * $quantity;
$delivery	 = $item->deliveryOption;

$options = Bfauctionhelper::getOptions($item->bfauction_item_id);

?>

	<!-- check why this 3 divs are not loaded -->
	<div class="joomla-version-3 joomla-version-34">
		<div class="akeeba-bootstrap">
			<div class="row-fluid">
				<!-- -->

				<div class="row-fluid">
					<legend>Payment Status</legend>
					<div class="bfauction_Introtext">Information about your purchase:</div>
				</div>


				<div class="row-fluid">
					<div class="span7 form-horizontal">

						<fieldset>
							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="gateway"><?php echo JText::_('COM_BFAUCTION_FIELD_ORDERID_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->orderId; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="gateway"><?php echo JText::_('COM_BFAUCTION_FIELD_GATEWAY_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $gateways[$item->processor]; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="status"><?php echo JText::_('COM_BFAUCTION_FIELD_STATUS_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><b><?php echo $statusText; ?></b></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_TITLE_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->title; ?></div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_PRICE_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($item->currentBid) ?></div>
								</div>
							</div>

							<?php if ($item->commissionAmount > 0): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_COMMISSION_LABEL'); ?>:</label>
									</div>
									<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($commission) ?> (<?php echo $item->commissionAmount ?>%)</div>
									</div>
								</div>
							<?php endif; ?>

							<?php if ($item->taxAmount > 0): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_TAX_LABEL'); ?>:</label>
									</div>
									<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($tax) ?> (<?php echo $item->taxAmount ?>%)</div>
									</div>
								</div>
							<?php endif; ?>

							<?php if ($item->shipping > 0): ?>
							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_SHIPPING_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo bfauctionHelper::toCurrency($item->shipping) ?></div>
								</div>
							</div>
							<?php endif; ?>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_QUANTITY_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div class="bfauction_ItemTitle"><?php echo $item->quantity; ?></div>
								</div>
							</div>

							<?php if ($options->showDeliveryOptions): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_DELIVERY_LABEL'); ?>:</label>
									</div>
									<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><?php echo $item->deliveryOption == COM_BFAUCTION_DELIVERY_DIRECT ?  JText::_('COM_BFAUCTION_DELIVERY_OPTION2') : JText::_('COM_BFAUCTION_DELIVERY_OPTION1') ?></div>
									</div>
								</div>
							<?php endif; ?>

							<?php
							$plugin = JPluginHelper::getPlugin('user', 'profile');
							$user = JFactory::getUser();
							$userProfile = JUserHelper::getProfile($user->id);
							if ($plugin && $userProfile) {
								$address1 = $userProfile->profile['address1'];
								$address2 = $userProfile->profile['address2'];
								$city = $userProfile->profile['city'];
								$region = $userProfile->profile['region'];
								$country = $userProfile->profile['country'];
								$postal = $userProfile->profile['postal_code'];
							}
							?>

							<?php if ($item->deliveryOption == COM_BFAUCTION_DELIVERY_DIRECT): ?>
								<div class="control-group">
									<div class="control-label bfauction_Label">
										<label for="title"><?php echo JText::_('COM_BFAUCTION_DELIVERY_ADDRESS'); ?>:</label>
									</div>
									<div class="controls bfauction_Details address">
									<?php if ($plugin && $user): ?>
										<p><?echo $user->name ?></p>
										<p><?echo @$address1 ?></p>
										<p><?echo @$address2 ?></p>
										<p><?echo @$city ?></p>
										<p><?echo @$region ?></p>
										<p><?echo @$country ?></p>
										<p><?echo @$postal1 ?></p>
									<?php else: ?>
										<span class='warning'><?php echo JText::_('COM_BFAUCTION_USER_PROFILE_PLUGIN_ERROR'); ?></span>
									<?php endif ?>
									</div>
								</div>
							<?php endif ?>

							<div class="control-group">
								<div class="control-label bfauction_Label">
									<label for="title"><?php echo JText::_('COM_BFAUCTION_FIELD_AMOUNT_LABEL'); ?>:</label>
								</div>
								<div class="controls bfauction_Details">
									<div><strong><?php echo bfauctionHelper::toCurrency($item->totalAmount) ?></strong>
									</div>
								</div>
							</div>

							<?php if (isset($this->paymentButton)): ?>
								<div class="control-group">
										<div class="controls bfauction_Details">
										<div class="bfauction_ItemTitle"><strong><?php echo $this->paymentButton; ?></strong>
										</div>
									</div>
								</div>
							<?php endif; ?>

						</fieldset>
					</div>
				</div>


			</div>
		</div>
	</div>


