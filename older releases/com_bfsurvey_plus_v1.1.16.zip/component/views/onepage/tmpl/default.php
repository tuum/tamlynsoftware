<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 57 2013-11-16 01:18:17Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php
$introText = $this->params->get( 'introText' );
$surveyTitle = $this->params->get( 'surveyTitle' );
$thankyouText = $this->params->get( 'thankyouText' );
$emailText = $this->params->get( 'emailText' );
$nameText = $this->params->get( 'nameText' );
$allowEmail = $this->params->get( 'allowEmail' );
$submitText = $this->params->get( 'submitText' );

$anonymous = $this->params->get( 'anonymous' );
$anonymousText = $this->params->get( 'anonymousText' );
$anonymousYes = $this->params->get( 'anonymousYes' );
$anonymousNo = $this->params->get( 'anonymousNo' );
$nameText = $this->params->get( 'nameText' );
$companyText = $this->params->get( 'companyText' );
$emailText = $this->params->get( 'emailText' );
$showName = $this->params->get( 'showName' );
$showCompany = $this->params->get( 'showCompany' );
$showEmail = $this->params->get( 'showEmail' );
$errorText = $this->params->get( 'errorText' );
$use_captcha = $this->params->get( 'use_captcha' );
$redirectURL = $this->params->get( 'redirectURL' );

$registeredUsers = $this->params->get( 'registeredUsers' );
$preventMultiple = $this->params->get( 'preventMultiple' );
$preventMultipleEmail = $this->params->get( 'preventMultipleEmail' );
$preventMultipleUID = $this->params->get( 'preventMultipleUID' );
$showReferenceNo = $this->params->get( 'showReferenceNo' );

//initialise some variables
$user="";
$emailcount=0;

/* Load Recaptcha if Bigo Captcha not on site */
if (!class_exists('plgSystemBigocaptcha')) {
	JPluginHelper::importPlugin('captcha');

	$plugin = JPluginHelper::getPlugin('captcha');
	if($plugin){
	    $pluginParams = new JRegistry();
	    $pluginParams->loadString($plugin[0]->params);
	    $pubkey = $pluginParams->get('public_key', '');

		if ($pubkey == null || $pubkey == '')
		{
			//do nothing as ReCaptcha public key not set
		}else{
			$dispatcher = JDispatcher::getInstance();
			$dispatcher->trigger('onInit','dynamic_recaptcha_1');
		}
	}
}
/* End Recaptcha */

if($anonymous == ""){
   $anonymous = "1";
}

if($showName == ""){
   $showName = "1";
}

if($showCompany == ""){
   $showCompany = "1";
}

if($showEmail == ""){
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );
$Itemid = JRequest::getVar( 'Itemid', 0, '', 'int' );


if($catid == 0){
   echo JText::_("COM_BFSURVEYPLUS_ERROR_MUST_SELECT_CATEGORY");
}

$table="#__bfsurveyplus_".(int)$catid;

$ip = BFSurveyPlusController::getIP();
$ipcount = BFSurveyPlusController::checkIP($table,$ip);
$summation_counter = 0;

$total_qns=count( $this->items );

?>

<script language="Javascript">
<!--
   // get variable from php
   var showName = "<?php echo $showName ?>";
   var showCompany = "<?php echo $showCompany ?>";
   var showEmail = "<?php echo $showEmail ?>";
   var toggle = 1;
   var othertoggle = 0;

   function ToggleDetails(){
   		if(toggle == 1){
   		   // hide details
   		   if(showName=="1"){
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		      document.getElementById("fullname").removeClass('invalid');
		      document.getElementById("fullname").set('aria-invalid', 'false');
		      document.getElementById("fullname").set('aria-required', 'false');
		      document.getElementById("fullname").set('required', '');
		      document.getElementById("fullname").set('disabled', 'disabled');
		   }

		   if(showCompany=="1"){
		      document.getElementById("MyCompany").style.display = 'none';
              document.getElementById("company").className = 'none';
              document.getElementById("company").removeClass('invalid');
		      document.getElementById("company").set('aria-invalid', 'false');
		      document.getElementById("company").set('aria-required', 'false');
		      document.getElementById("company").set('required', '');
		      document.getElementById("company").set('disabled', 'disabled');
           }

           if(showEmail=="1"){
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
              document.getElementById("email").removeClass('invalid');
		      document.getElementById("email").set('aria-invalid', 'false');
		      document.getElementById("email").set('aria-required', 'false');
		      document.getElementById("email").set('required', '');
		      document.getElementById("email").set('disabled', 'disabled');
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1"){
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		      document.getElementById("fullname").set('disabled', '');
		   }

		   if(showCompany=="1"){
   		      document.getElementById("MyCompany").style.display = '';
              document.getElementById("company").className = 'required';
              document.getElementById("company").set('disabled', '');
		   }

		   if(showEmail=="1"){
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
              document.getElementById("email").set('disabled', '');
           }
		   toggle=1;
        }
   }

   function MakeOtherMandatory(fieldname, z){
      myid = fieldName + z +'_other';
      if(othertoggle == 1){
	      // hide details
	      document.getElementById(myid).className = 'none';
	      othertoggle=0;
	  }else{
	      document.getElementById(myid).className = 'required';
	      othertoggle=1;
	  }
   }

//-->
</script>



<?php
// Check that the class exists before trying to use it
if (class_exists('plgBFValidatePlus'))
{
   plgBFValidatePlus::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f)) {
	    f.check='';
		f.check.value='<?php echo JSession::getFormToken(); ?>';//send token
		return true;
	}
	else {
		alert('<?php echo $errorText ?>');
	}
	return false;
}
function imposeMaxLength(Event, Object, MaxLen)
{
   return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40));
}
</script>

<?php
$user = JFactory::getUser();
 if($registeredUsers == "1"){
    $emailcount = BFSurveyPlusController::checkEmail($table,$user->email);
    $uidcount = BFSurveyPlusController::checkUID($table,$user->id);
 }else{
 	$emailcount = 0;
 	$uidcount = 0;
 }

 if (($user->id) | $registeredUsers != "1") {  // test if registerd users only

 	if($ipcount < 1 | $preventMultiple != "1"){  // check if IP address has already completed survey

       if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed survey

       	   	if($uidcount < 1 | $preventMultipleUID != "1"){  // check if UID has already completed survey

?>

<form  method="POST" name="survey" id="survey" class="form-validate" onSubmit="return myValidate(this);">

<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="table" value="<?php echo $table ?>" />
<input type="hidden" name="preventMultipleEmail" value="<?php echo $preventMultipleEmail ?>" />

<table width="100%" cellspacing="0">
	<thead>
		<tr>
			<th>
				<div class="bfsurvey_plusTitle"><?php echo JText::_( $surveyTitle ); ?></div>
			</th>
		</tr>
	</thead>

<tr>
    <td>
    <div class="bfsurvey_plusIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="bfsurvey_plusQuestionFooter">
	</div>
    </td>
</tr>

<?php if($showName == "1"){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table>
       <tr>
           <td>
               <div class="BFSurveyCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="BFSurveyCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table>
        <tr>
            <td width="70">
                <div class="BFSurveyCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="BFSurveyCustomerOptions">
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $user->name; ?>' >
                </div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php }else{ ?>
<input type="hidden" name="fullname" id="fullname" size='55' value='<?php echo $user->name; ?>' >
<?php } ?>

<?php if($showCompany == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyCompany">
        <table>
	       <tr>
	           <td width="70">
	               <div class="BFSurveyCustomerQuestion">
	               <?php echo JText::_( $companyText ); ?>
	               </div>
	           </td>
	           <td>
	               <div class="BFSurveyCustomerOptions">
	               <input name="company" id="company" size='55' <?php echo 'class="required"'; ?>>
	               </div>
	           </td>
	       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php } ?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table>
		       <tr>
		           <td width="70">
		               <div class="BFSurveyCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="BFSurveyCustomerOptions">
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $user->email; ?>' >
		               </div>
		           </td>
		       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php }else{ ?>
<input type="hidden" name="email" id="email" size='55' value='<?php echo $user->email; ?>' >
<?php } ?>

<tr>
<td>
<?php if ($use_captcha) {
	// Check that the class exists before trying to use it
	if (class_exists('plgSystemBigocaptcha')) {
	?>
	<!-- Bigo Captcha -->
	<img src="index.php?option=com_bfsurvey_plus&task=displaycaptcha&catid=<?php echo $catid; ?>&use_captcha=<?php echo $use_captcha; ?>">
	<br />
	<input type="text" name="word"/><br>
	<?php
	   echo JText::_("COM_BFSURVEYPLUS_INPUT_WORD_FROM_IMAGE");
	}else{
		// Recaptcha
		echo '<div id="dynamic_recaptcha_1"></div>';
	}
	?>
<?php } ?>
</td>
</tr>

<?php
$k = 0;

for ($i=0; $i < $total_qns; $i++)
{
	$row = &$this->items[$i];
	$fieldName = $row->field_name;

    if($fieldName != NULL){
?>


    <input id="field_name" name="field_name" type="hidden" value="<?php echo $row->field_name; ?>">

	<?php if($row->suppressQuestion != "1"){ ?>
	<tr>
	    <th>
	       <div class="bfsurvey_plusQuestion"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<?php } ?>
	<tr class="bfsurvey_plusTableRow">
	    <th>
		   <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="bfsurvey_plusOptions">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == ""){
	          // do nothing
	       }else{
	          ?>
	          <div class="bfsurvey_helptext">
	          <?php echo JHTML::_('content.prepare', $row->helpText); ?>
	          </div>
	          <?php
	       }

	       if(!isset($row->prefix)){
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix)){
	          $row->suffix = "";
	       }

	       $sequence = $row->id;

	       if($row->question_type == "0"){  //text
	           $mylength="65";
			   if($row->fieldSize < 65){
			      $mylength=$row->fieldSize;
	           }
	           if($row->mandatory){
	              if($row->suppressQuestion != "1"){
	              	echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
	              }else{
	              	?>
		            <div class="BFSurveyPlusSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="BFSurveyPlusSuppressOptions">
	                <?php
	              		echo "<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
	                ?>
	                </div>
       			  	<?php
	              }
	           }else{
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	              }else{
	              	?>
		            <div class="BFSurveyPlusSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="BFSurveyPlusSuppressOptions">
	                <?php
	              		echo "<input id='".$fieldName."' name='".$fieldName."' size='$mylength' MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	                ?>
	                </div>
       			  	<?php
	          	  }
	          }
	       }else if($row->question_type == "1"){  // Radio

			   $tempfield=$row->sqlfield;

		       if($row->sql != ""){
		   		   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );
		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  $tempvalue="option".($z+1);
					  if($SQLrow->$tempfield != ""){
	                     if($row->mandatory & class_exists('plgBFValidatePlus')){
					        echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'"><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($SQLrow->$tempfield).'" class="required validate-radio">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix).'"';
					     }else{
					        echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'"><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($SQLrow->$tempfield).'">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix);
			  		     }
						 if($row->horizontal == "1"){
 				    	     echo "&nbsp;&nbsp;&nbsp;";
			   	    	 }else{
			   	    	     echo "<br>";
		   		   	 	 }
			  		  }
		   		   }

				}else{

					if($row->horizontal == "1"){
					   $myclass="bfradiohorizontal";
					}else{
					   $myclass="bfradio";
					}

	       		    for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != ""){
	       		            if($row->$tempvalue == "_OTHER_"){
	       		               if($row->mandatory & class_exists('plgBFValidatePlus')){
	       		                  echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($row->$tempvalue).'" class="required validate-radio" onchange="MakeOtherMandatory('.$fieldName.','.$z.')">'.JText::_($row->otherprefix).'</label><input id="'.$fieldName.''.$z.'_other" name="'.$fieldName.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       		               }else{
	       		                  echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->otherprefix).'</label><input id="'.$fieldName.''.$z.'" name="'.$fieldName.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       		               }
	       		            }else{
				  				if($row->mandatory & class_exists('plgBFValidatePlus')){
	       		   				   echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($row->$tempvalue).'" class="required validate-radio">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				  				}else{
				  				   echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="radio" id="'.$fieldName.''.$z.'" name="'.$fieldName.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				  				}
			  				}
							if($row->horizontal == "1"){
 					    	    echo "&nbsp;&nbsp;&nbsp;";
				   	    	}else{
				   	    	    echo "<br>";
			   		   	 	}
	       	        	}
	       	     	}
	           }

	       }else if($row->question_type == "2"){  // Checkbox
			   $tempfield=$row->sqlfield;

		       if($row->sql != ""){
		   		   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
		   		   $this->assignRef( 'SQLitems', $mySQLitems );
		   		   $n2=count( $mySQLitems );
		   		   for($z=0; $z < $n2; $z++)
		   		   {
		   		      $SQLrow = &$this->SQLitems[$z];

					  if($SQLrow->$tempfield != ""){
					  	if($row->mandatory & class_exists('plgBFValidatePlus')){
					  	   echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'"><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($SQLrow->$tempfield).'" id="'.$fieldName.''.$z.'" class="'.$row->validation_type.'">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix);
					  	}else{
					  	   echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'"><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($SQLrow->$tempfield).'" id="'.$fieldName.''.$z.'">'.JText::_($SQLrow->$tempfield).'</label> '.JText::_($row->suffix);
			  		  	}
						if($row->horizontal == "1"){
 				    	    echo "&nbsp;&nbsp;&nbsp;";
			   	    	}else{
			   	    	    echo "<br>";
		   		   	 	}
			  		  }
		   		   }

				}else{

					if($row->horizontal == "1"){
					   $myclass="bfradiohorizontal";
					}else{
					   $myclass="bfradio";
					}

			   	   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
	   	               if($row->$tempvalue != ""){
	   	                   if($row->$tempvalue == "_OTHER_"){
		                       if($row->mandatory & class_exists('plgBFValidatePlus')){
					   	           echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($row->$tempvalue).'" id="'.$fieldName.''.$z.'" value="'.JText::_($row->$tempvalue).'" class="'.$row->validation_type.'" onchange="MakeOtherMandatory('.$fieldName.','.$z.')">'.JText::_($row->otherprefix).'</label><input id="'.$fieldName.''.$z.'_other" name="'.$fieldName.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
					   	       }else{
					   	          echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($row->$tempvalue).'" id="'.$fieldName.''.$z.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->otherprefix).'</label><input id="'.$fieldName.''.$z.'" name="'.$fieldName.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
					   	       }
	       		            }else{
				   	           if($row->mandatory & class_exists('plgBFValidatePlus')){
	   	                          echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($row->$tempvalue).'" id="'.$fieldName.''.$z.'" class="'.$row->validation_type.'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				   		       }else{
	   	                          echo ''.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'" class='.$myclass.'><input type="checkbox" name="'.$fieldName.'[]" value="'.JText::_($row->$tempvalue).'" id="'.$fieldName.''.$z.'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				   		       }
				   		    }
							if($row->horizontal == "1"){
	 				    	    echo "&nbsp;&nbsp;&nbsp;";
				   	    	}else{
				   	    	    echo "<br>";
			   		   	 	}
	   	               }
	   	           }
	           }
	       }else if($row->question_type == "3"){  // Textarea
	           if($row->mandatory){
		          echo ''.JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" class="required" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');"></textarea> '.JText::_($row->suffix);
		       }else{
		          echo ''.JText::_($row->prefix).'<textarea id="'.$fieldName.'" name="'.$fieldName.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(event, this, '.$row->fieldSize.');"></textarea> '.JText::_($row->suffix);
		       }
	       }else if($row->question_type == "5"){  // date
				$document = JFactory::getDocument();
   				$document->addScript(JURI::root() . "/components/com_bfsurvey_plus/includes/calendar.js");

	            JHTML::_('behavior.calendar');

	            if($row->mandatory){
	            	echo ''.$row->prefix.'<input class="inputbox required" type="text" id="'.$fieldName.'" name="'.$fieldName.'" size="10" maxlength="25" value="" />';
	            }else{
	            	echo ''.$row->prefix.'<input class="inputbox" type="text" id="'.$fieldName.'" name="'.$fieldName.'" size="10" maxlength="25" value="" />';
	            }

				echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\''.$fieldName.'\',\'%d-%m-%Y\');" /> '.$row->suffix.'';
	       }else if($row->question_type == "6"){  // dropdown

				$tempfield=$row->sqlfield;

	       		if($row->mandatory & class_exists('plgBFValidatePlus'))
				{
					echo "".JText::_($row->prefix)."<select id='".$fieldName."' name='".$fieldName."' class='required validate-dropdown'>";
				}else{
					echo "".JText::_($row->prefix)."<select id='".$fieldName."' name='".$fieldName."'>";
				}

				?>

	            <option value="-1"><?php echo JText::_('COM_BFSURVEYPLUS_PLEASE_SELECT'); ?></option>

				<?php
				if($row->sql != ""){
				   $mySQLitems =& BFSurveyPlusController::getSQL($row->sql);
				   $this->assignRef( 'SQLitems', $mySQLitems );
				   $n2=count( $mySQLitems );
				   for($z=0; $z < $n2; $z++)
				   {
				      $SQLrow = &$this->SQLitems[$z];
				      echo '<option value="'.JText::_($SQLrow->$tempfield).'">'.JText::_($SQLrow->$tempfield).'</option>';
				   }

				}else{
				   for($z=0; $z < 20; $z++)
				   {
				       $tempvalue="option".($z+1);
				       if($row->$tempvalue != ""){
				           echo '<option value="'.JText::_($row->$tempvalue).'">'.JText::_($row->$tempvalue).'</option>';
				       }
 	               }
 	            }

				echo "</select> ".$row->suffix."";
				}else if($row->question_type == "8"){  // Summation
				    $total = $row->sqlfield;

					$num=0;
					echo "<table>";
				    for($z=0; $z < 20; $z++)
					{
					    $tempvalue="option".($z+1);
	   	                if($row->$tempvalue != ""){
				 	        echo '<tr><td>'.JText::_($row->prefix).'<label for="'.$fieldName.''.$z.'">'.JText::_($row->$tempvalue).'</td><td><input id="'.$fieldName.''.$z.'" name="'.$fieldName.'[]" size="5" value=0 onchange="updateTotal'.$summation_counter.'()"></label> '.JText::_($row->suffix).'</td></tr>';
				 	        $num++;
				 	    }
					}
					echo "<tr><td></td><td><input id='total".$summation_counter."' name='total' value='".$total."' size='5' READONLY></td></tr>";

					echo "</table>";

					$optionname = ''.$fieldName.'';

					?>

				    <script language="javascript" type="text/javascript">
					<!--
					// get variable from php
   					var total<?php echo $summation_counter; ?> = "<?php echo $total ?>";
   					var num<?php echo $summation_counter; ?> = "<?php echo $num ?>";
   					var optionname<?php echo $summation_counter; ?>="<?php echo $optionname ?>";

   					function updateTotal<?php echo $summation_counter; ?>(){
					   var i=0;
					   var temptotal=0;
					   for (i=0;i<num<?php echo $summation_counter; ?>;i++){
					      tempvalue=optionname<?php echo $summation_counter; ?> + i;
					      temptotal=temptotal + parseInt(document.getElementById(tempvalue).value);
	       			   }

	       			document.getElementById("total<?php echo $summation_counter; ?>").value=total<?php echo $summation_counter; ?>-temptotal;
					}

					//-->
					</script>
					<?php
					$summation_counter++;
				}else if($row->question_type == "9"){  // Rating
				 	echo "<table>";
	       		    echo "<tr>";
	       		    echo "<td></td>";

					$mylabels = array();
	       		    if($row->titles == ""){
	       		       // do nothing
	       		    }else{
	       		       $mylabels = explode(";",$row->titles);
	       		    }

	       		    for($y=1; $y < $row->sqlfield+1; $y++){
	       		       if($row->titles == ""){
 	       		          echo "<td align='center'>".$y."</td>";
 	       		       }else{
 	       		          if(isset($mylabels[$y-1])){
 	       		             echo "<td  width='50'><center>".JText::_($mylabels[$y-1])."</center></td>";
 	       		          }else{
 	       		             echo "<td align='center'>&nbsp;</td>";
 	       		          }
 	       		       }
	       		    }
	       		    echo "</tr>";

					for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != ""){
	       		           echo "<tr>";
	       		           echo '<td><label for="'.$fieldName.''.($z+1).'">'.JText::_($row->$tempvalue).'</label></td>';
			  			   if($row->mandatory & class_exists('plgBFValidatePlus')){
       		   			      for($y=1; $y < $row->sqlfield+1; $y++){
       		   			         if($row->titles == ""){
       		   			            echo '<td>'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value="'.$y.'" class="required validate-radio"> '.JText::_($row->suffix).'</td>';
       		   			         }else{
       		   			            if(isset($mylabels[$y-1])){
       		   			               echo '<td align="center">'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value="'.JText::_($mylabels[$y-1]).'" class="required validate-radio"> '.JText::_($row->suffix).'</center></td>';
       		   			            }else{
       		   			               echo '<td>'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value="" class="required validate-radio"> '.JText::_($row->suffix).'</td>';
       		   			            }
       		   			         }
			  			      }

			  			   }else{
							  for($y=1; $y < $row->sqlfield+1; $y++){
							     if($row->titles == ""){
 							   	    echo '<td>'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value="'.$y.'"> '.JText::_($row->suffix).'</td>';
 							   	 }else{
 							   	    if(isset($mylabels[$y-1])){
 							   	       echo '<td align="center">'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value="'.JText::_($mylabels[$y-1]).'"> '.JText::_($row->suffix).'</center></td>';
 							   	    }else{
 							   	          echo '<td>'.JText::_($row->prefix).'<input type="radio" id="'.$fieldName.''.($z+1).'" name="'.$fieldName.''.($z+1).'" value=""> '.JText::_($row->suffix).'</td>';
 							   	    }
 							   	 }
 							  }
		  				   }
		  				   echo "</tr>";
	       	        	}
	       	     	}

	       	     	echo "</table>";

				}

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
	       ?>
	       </div>
	       <div class="bfsurvey_plusQuestionFooter">

	       </div>
	    </th>
	</tr>
	<?php


	} // end field is not NULL

	$k = 1 - $k;
}
?>
</table>

<?php
$num=count( $this->items );
?>

<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfsurvey_plus" />
<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="Itemid" value="<?php echo $Itemid ?>" />
<input type="hidden" name="task" value="updateOnePage" />
<input type="hidden" name="thankyouText" value="<?php echo $thankyouText ?>" />
<input type="hidden" name="redirectURL" value="<?php echo $redirectURL ?>" />
<input type="hidden" name="allowEmail" value="<?php echo $allowEmail ?>" />
<input type="hidden" name="showReferenceNo" value="<?php echo $showReferenceNo ?>" />
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
<?php echo JHTML::_('form.token'); ?>
</form>

<?php
	      }else{
	  	     echo JText::_( "COM_BFSURVEYPLUS_ERROR_UID_ALREADY_COMPLETED");
	      }

      }else{
  	     echo JText::_( "COM_BFSURVEYPLUS_ERROR_EMAIL_ALREADY_COMPLETED");
      }

   }else{
      echo JText::_( "COM_BFSURVEYPLUS_ERROR_IP_ALREADY_COMPLETED");
   }

}else{
   echo JText::_( "COM_BFSURVEYPLUS_ERROR_YOU_MUST_LOG_IN");
}
?>
