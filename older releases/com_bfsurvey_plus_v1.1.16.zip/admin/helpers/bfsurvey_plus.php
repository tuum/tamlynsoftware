<?php
/**
 * $Id: bfsurvey_plus.php 56 2013-11-15 11:08:33Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die;

/**
 * @package		Joomla
 * @subpackage	Components
 */
class bfsurvey_plusHelper
{

	/**
	* build the select list for question type
	*/
	function QuestionType( &$question_type )
	{

		$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXT' ) );
		$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RADIO' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_CHECKBOX' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXTAREA' ) );
		//$click[] = JHTML::_('select.option',  '4', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_ATTACHMENT' ) );
		$click[] = JHTML::_('select.option',  '5', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DATE' ) );
		$click[] = JHTML::_('select.option',  '6', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DROPDOWN' ) );
		//$click[] = JHTML::_('select.option',  '7', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_LIST' ) );
		$click[] = JHTML::_('select.option',  '8', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_SUMMATION' ) );
		$click[] = JHTML::_('select.option',  '9', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RATING' ) );
		$click[] = JHTML::_('select.option',  '10', JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_HEADING' ) );

		if($question_type == null){
		   $question_type=1;
		}

		$target = JHTML::_('select.genericlist',   $click, 'question_type', 'class="inputbox" size="9" onchange="hideType()"', 'value', 'text',  intval( $question_type ) );

		return $target;
	}

	/**
	* Show question type
	*/
	public static function ShowQuestionType( &$question_type ) {
	   switch($question_type){
	      case 0:	echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXT' );
	      			break;
	      case 1:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RADIO' );
	      			break;
	      case 2:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_CHECKBOX' );
	      			break;
	      case 3:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_TEXTAREA' );
	      			break;
	      case 4:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_ATTACHMENT' );
	      			break;
	      case 5:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DATE' );
	      			break;
	      case 6:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_DROPDOWN' );
	      			break;
  		  case 7:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_LIST' );
	      			break;
	      case 8:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_SUMMATION' );
	      			break;
	      case 9:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_RATING' );
	      			break;
	      case 10:   echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_HEADING' );
	      			break;
	      default:  echo JText::_( 'COM_BFSURVEYPLUS_QUESTION_TYPE_UNKNOWN' );
	   }
	}

    /**
	 * Build the select list for precondition question item
	 */
	function Parent( &$row )
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		// If a not a new item, lets set the question item id
		if ( $row->id ) {
			$id = ' AND id != '.(int) $row->id;
		} else {
			$id = null;
		}

		// In case the parent was null
		if (!$row->parent) {
			$row->parent = 0;
		}

		// get a list of the question items
		// excluding the current question item and all child elements
		$query->select('*');
		$query->from('#__bfsurvey_plus');
		$query->where('parent = 0');
		$query->where('id <> '.$row->id);
		$query->order('parent, ordering');
		$db->setQuery((string)$query);
		$mitems = $db->loadObjectList();

		// establish the hierarchy of the menu
		$children = array();

		if ( $mitems )
		{
			// first pass - collect children
			foreach ( $mitems as $v )
			{
				$pt 	= $v->parent;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}

		// second pass - get an indent list of the items
		//$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );

		// assemble menu items to the array
		$mitems 	= array();
		$mitems[] 	= JHTML::_('select.option',  '0', JText::_( 'COM_BFSURVEYPLUS_TOP' ) );

		if(isset($list)){
		    foreach ( $list as $item ) {
			    $mitems[] = JHTML::_('select.option',  $item->id, '&nbsp;&nbsp;&nbsp;'. $item->question . ' ' . $item->id );
		    }
		}

		$output = JHTML::_('select.genericlist',   $mitems, 'parent', 'class="inputbox" size="10"', 'value', 'text', $row->parent );

		return $output;
	}

	/**
	* build the select list for question type
	*/
	function alignType( &$imageAlign )
	{

		$click[] = JHTML::_('select.option',  'left', JText::_( 'COM_BFSURVEYPLUS_LEFT' ) );
		$click[] = JHTML::_('select.option',  'center', JText::_( 'COM_BFSURVEYPLUS_CENTER' ) );
		$click[] = JHTML::_('select.option',  'right', JText::_( 'COM_BFSURVEYPLUS_RIGHT' ) );

		if($imageAlign == null){
		   $imageAlign="left";
		}

		$target = JHTML::_('select.genericlist',   $click, 'imageAlign', 'class="inputbox" size="3"', 'value', 'text',  $imageAlign );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function FieldType( &$field_type )
	{

		$click[] = JHTML::_('select.option',  'VARCHAR', JText::_( 'VARCHAR' ) );
		$click[] = JHTML::_('select.option',  'TEXT', JText::_( 'TEXT' ) );
		$click[] = JHTML::_('select.option',  'DATE', JText::_( 'DATE' ) );
		$click[] = JHTML::_('select.option',  'INT', JText::_( 'INT' ) );
		$click[] = JHTML::_('select.option',  'TINYINT', JText::_( 'TINYINT' ) );
		$click[] = JHTML::_('select.option',  'FLOAT', JText::_( 'FLOAT' ) );
		$click[] = JHTML::_('select.option',  'DOUBLE', JText::_( 'DOUBLE' ) );

		if($field_type == null){
		   $field_type='TEXT';
		}

		$target = JHTML::_('select.genericlist',   $click, 'field_type', 'class="inputbox" size="1"', 'value', 'text',  $field_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationType( &$validation_type )
	{

		$click[] = JHTML::_('select.option',  'required', JText::_( 'required' ) );
		$click[] = JHTML::_('select.option',  'required validate-numeric', JText::_( 'required validate-numeric' ) );
		$click[] = JHTML::_('select.option',  'required validate-email', JText::_( 'required validate-email' ) );

		if($validation_type == null){
		   $validation_type='required';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}

	/**
	* build the select list for field type
	*/
	function ValidationTypeCheckbox( &$validation_type )
	{
		$click[] = JHTML::_('select.option',  'required validate-checkbox', JText::_( 'required validate-checkbox' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox2', JText::_( 'required validate-checkbox2' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox3', JText::_( 'required validate-checkbox3' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox4', JText::_( 'required validate-checkbox4' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox5', JText::_( 'required validate-checkbox5' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox6', JText::_( 'required validate-checkbox6' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox7', JText::_( 'required validate-checkbox7' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox8', JText::_( 'required validate-checkbox8' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox9', JText::_( 'required validate-checkbox9' ) );
	    $click[] = JHTML::_('select.option',  'required validate-checkbox10', JText::_( 'required validate-checkbox10' ) );

		if($validation_type == null | strpos($validation_type,"checkbox")==FALSE){
		   $validation_type='required validate-checkbox';
		}

		$target = JHTML::_('select.genericlist',   $click, 'validation_type', 'class="inputbox" size="1"', 'value', 'text',  $validation_type );

		return $target;
	}

	/**
	* build the select list for email type
	*/
	function emailType( &$title )
	{
		$click[] = JHTML::_('select.option',  'Admin', JText::_( 'COM_BFSURVEYPLUS_EMAIL_TYPE_ADMIN' ) );
		$click[] = JHTML::_('select.option',  'Author', JText::_( 'COM_BFSURVEYPLUS_EMAIL_TYPE_AUTHOR' ) );

		if($title == null){
		   $title="Admin";
		}

		$target = JHTML::_('select.genericlist',   $click, 'title', 'class="inputbox" size="2"', 'value', 'text',  $title );

		return $target;
	}

	/**
	 * Configure the Linkbar.
	 *
	 * @param	string	The name of the active view.
	 * @since	1.6
	 */
	public static function addSubmenu($vName = 'bfsurvey_plus')
	{
		JSubMenuHelper::addEntry(
			JText::_('COM_BFSURVEYPLUS_TITLE_QUESTIONS'),
			'index.php?option=com_bfsurvey_plus',
			$vName == 'questions'
		);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_CATEGORIES'),
    		'index.php?option=com_categories&extension=com_bfsurvey_plus',
    		$vName == 'categories'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_REPORT'),
    		'index.php?option=com_bfsurvey_plus&view=category',
    		$vName == 'report'
    	);

   		JSubMenuHelper::addEntry(
   			JText::_('COM_BFSURVEYPLUS_TITLE_STATS'),
   			'index.php?option=com_bfsurvey_plus&view=statscategory',
   			$vName == 'stats'
   		);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_RESULTS'),
    		'index.php?option=com_bfsurvey_plus&view=resultscategory',
    		$vName == 'results'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_EMAIL_TEMPLATE'),
    		'index.php?option=com_bfsurvey_plus&view=emailitems',
    		$vName == 'emailitems'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_MAINTENANCE'),
    		'index.php?option=com_bfsurvey_plus&view=maintenance',
    		$vName == 'maintenance'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFSURVEYPLUS_TITLE_HELP'),
    		'index.php?option=com_bfsurvey_plus&view=help',
    		$vName == 'help'
    	);

	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @param	int		The category ID.
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_bfsurvey_plus';
		} else {
			$assetName = 'com_bfsurvey_plus.category.'.(int) $categoryId;
		}

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}

	/**
	 * Display Copyright information
	 *
	 */
	public static function displayVersion() {
		global $bfsurveyplus_version ;
		echo '<div class="clr"> </div>';
		echo '<div class="copyright" style="text-align:center;margin-top: 5px; display:block; width:100%; float:left;">'.JText::_( 'COM_BFSURVEYPLUS_VERSION').' <strong>'.$bfsurveyplus_version.'</strong></div>' ;
	}

}