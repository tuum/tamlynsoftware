<?php
/**
 * $Id: questions.php 56 2013-11-15 11:08:33Z tuum $
 * bfsurvey_plus Controller for BF Survey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');

/**
 * BF Survey Plus list controller class.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_bfsurvey_plus
 * @since		1.6
 */
class bfsurvey_plusControllerQuestions extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function getModel($name = 'Question', $prefix = 'bfsurvey_plusModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

    /**
     * Method to copy questions
     *
     */
    public function copy()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Question', 'Table');

        $this->setRedirect( 'index.php?option=com_bfsurvey_plus' );

        $n		= count( $cid );

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	$row->question		= JText::_('COM_BFSURVEYPLUS_COPY_OF').' '. $row->question;
            	$row->id            = 0;
            	$row->state     	= 0;
            	$now =& JFactory::getDate();
				if(is_callable(array('JDate', 'toSql'))){
					$row->date	= $now->toSql();
				}else{
					$row->date 	= $now->toMySQL();
				}
            	$row->field_name	= "";

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::sprintf( 'COM_BFSURVEYPLUS_ITEMS_COPIED', $n ) );

        return true;
    }

    /**
     * Method to copy all the questions in a category
     *
     */
    public function copyCategory()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Question', 'Table');

        $this->setRedirect( 'index.php?option=com_bfsurvey_plus' );

        $n		= count( $cid );

		if ($n > 0)
		{
			// Create a new query object.
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			//get the category id for the first question we are looking at
			$query->select('a.*');
			$query->from('#__bfsurvey_plus AS a');
			$query->where('a.id='.(int)$cid[0]);
			$db->setQuery((string)$query);
			$result = $db->loadObjectList( );

			//now get all the questions for that category
			$query->clear();
			$query->select('a.*');
			$query->from('#__bfsurvey_plus AS a');
			$query->where('a.catid='.(int)$result[0]->catid);
			$db->setQuery((string)$query);
			$result = $db->loadObjectList( );

			//now get the category name
			$query->clear();
			$query->select('cc.title');
			$query->from('#__categories AS cc');
			$query->where('cc.id='.$result[0]->catid);
			$db->setQuery((string)$query);
			$result2 = $db->loadObjectList( );

			//now create a new category
			$query->clear();
			$query->insert('#__categories');
			if(is_callable(array('JDatabaseQuery', 'columns'))){
	            $query->columns(array($db->quoteName('parent_id'), $db->quoteName('title'), $db->quoteName('alias'), $db->quoteName('extension'), $db->quoteName('published'), $db->quoteName('level'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('metadesc'), $db->quoteName('metakey'), $db->quoteName('metadata'), $db->quoteName('lft'), $db->quoteName('rgt') ));
				$query->values('1, '.$db->quote( $db->escape('copy of '.$result2[0]->title), false ).', '.$db->quote( $db->escape($result2[0]->title), false ).', '.$db->quote('com_bfsurvey_plus').', 1, 1, 1, '.$db->quote('*').', '.$db->quote('').' , '.$db->quote('').' ,'.$db->quote('{"page_title":"","author":"","robots":""}').', 1, 2' );
			}else{
				//joomla 1.6 support
				$query->set('`parent_id` = 0');
	            $query->set('`title` = '.$db->quote( $db->escape('copy of '.$result2[0]->title), false ));
	            $query->set('`alias` = '.$db->quote( $db->escape($result2[0]->title), false ));
	            $query->set('`extension` = '.$db->quote('com_bfsurvey_plus'));
	            $query->set('`published` = 1');
	            $query->set('`level` = 1');
				$query->set('`lft` = 1');
				$query->set('`rgt` = 2');
			}
			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//now get the new category id number
			$query->clear();
			$query->select('max(id) as catid');
			$query->from('#__categories');
			$db->setQuery((string)$query);
			$newCatid = $db->loadObjectList( );

        	foreach ($result as $myquestion)
        	{
            	// load the row from the db table
            	$row->load((int) $myquestion->id);
            	$row->id            = 0;
            	$row->catid		= $newCatid[0]->catid;

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFSURVEYPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::sprintf( 'COM_BFSURVEYPLUS_ITEMS_COPIED', $n ) );

        return true;
    }

	/**
	 * view to allow user to select css file to edit
	 * @return void
	 */
	function chooseCSS()
	{
		require_once JPATH_COMPONENT.DS.'models'.DS.'questions.php';
		$this->files	= bfsurvey_plusModelQuestions::getFiles();
		?>

	    <fieldset class="adminform" id="template-manager-css">
			<legend><?php echo JText::_('COM_BFSURVEYPLUS_CSS');?></legend>

			<?php if (!empty($this->files['css'])) : ?>
			<ul>
				<?php foreach ($this->files['css'] as $file) : ?>
				<li>
					<a href="<?php echo JRoute::_('index.php?option=com_templates&task=source.edit&id='.$file->id);?>">

						<?php echo JText::sprintf('COM_BFSURVEYPLUS_EDIT_CSS', $file->name);?>
					</a>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	/**
	 * Internal method to get file properties.
	 *
	 * @param	string The base path.
	 * @param	string The file name.
	 * @return	object
	 * @since	1.6
	 */
	function getFile($path, $name)
	{
		$temp = new stdClass;

		$temp->name = $name;
		$temp->exists = file_exists($path.$name);
		$temp->id = urlencode(base64_encode($name));
		return $temp;
	}

    public function fixDatabase()
    {
    	$this->setRedirect( 'index.php?option=com_bfsurvey_plus' );
    	require_once JPATH_ROOT.'/administrator/components/com_bfsurvey_plus/controller.php';

    	$errors = bfsurvey_plusController::buildAnswerTables();
		if($errors){
			return JError::raiseWarning(500, $errors);
		}else{
    		$this->setMessage( JText::_( 'COM_BFSURVEYPLUS_DATABASE_FIXED' ) );
		}
    }

	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   3.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}
}