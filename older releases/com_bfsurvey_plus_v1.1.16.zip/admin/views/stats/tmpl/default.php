<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 56 2013-11-15 11:08:33Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// establish the hierarchy of the questions
	$children = array();
	// first pass - collect children
	foreach ($this->items as $v )
	{
		//get the parent id
		$pt = $v->parent;
		// @ symbol tests to see if $children[parentid] is blank
		// ? ternary operator if first part is true, then $children[$pt] otherwise array()
		$list = @$children[$pt] ? $children[$pt] : array();
		//add current row element to the bottom of list array
		array_push( $list, $v );
		$children[$pt] = $list;
	}

	//second pass - reorder elements
	$mylist = array();
	foreach ($this->items as $v )
	{
	   if($v->parent==0){
	      array_push($mylist, $v);

	      //now are there any children
	      if(isset($children[$v->id])){
	         foreach ($children[$v->id] as $c ){
	            array_push($mylist, $c);
	         }
	      }
	   }
	}
	$this->items = 	$mylist;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
$listOrder	= $this->state->get('list.ordering');
$listDirn	= $this->state->get('list.direction');
$catid	= JRequest::getVar( 'cid', 0, '', 'int' );
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey_plus&view=stats&cid='.$catid); ?>" method="post" name="adminForm" id="adminForm">

<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'COM_BFSURVEYPLUS_TITLE_ID' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEYPLUS_TITLE_QUESTION' ); ?>
            </th>
        </tr>
    </thead>
	<tfoot>
		<tr>
			<td colspan="4">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<tbody>
    <?php
    $k = 0;
    foreach ($this->items as $i => $row) :
		if($row->question_type == 10){
			//do nothing
		}else{
        ?>
  		<tr class="<?php echo "row$k"; ?>">
  		    <td>
  		       <?php //echo $i+1+$this->pagination->limitstart; ?>
  		    </td>
  		    <td>
  		       <?php echo $row->question; ?>
  		    </td>
  		</tr>

  		<tr>
  		<td colspan=2>
		<?php
		$question_type = $row->question_type;
		$total = 0;
		$myOption = array();
		$myAnswer = array();

		echo JText::_( 'COM_BFSURVEYPLUS_FIELD_QUESTION_TYPE_LABEL' )." = ";
  		echo bfsurvey_plusHelper::ShowQuestionType( $row->question_type );

  		?>


				<?php
					for ($i3=1; $i3 < 21; $i3++)
					{
						//$question=$row->id;
						$question=$row->field_name;
						$name = 'option'.$i3;
						$response=$row->$name;
						if($response==""){
						    // do nothing
						}else{
							if($question_type == 2){ //checkbox
								if($response == "_OTHER_"){
							   		$answer = BFSurveyPlusController::getStatsOther($question, $response, $this->catid);
							   		$response = $row->otherprefix;
							   	}else{
									$answer = bfsurvey_plusController::getStatsCheckbox($question, $response, $this->catid);
							   	}
							}else if($question_type == 0 | $question_type == 3 | $question_type == 5 | $question_type == 8 | $question_type == 9){
							   $answer="";
							}else{
								if($response == "_OTHER_"){
							    	$answer = bfsurvey_plusController::getStatsOther($question, $response, $this->catid);
							    	$response = trim($row->otherprefix." ".$row->othersuffix);
								}else{
									$answer = bfsurvey_plusController::getStats($question, $response, $this->catid);
								}
							}

							$myAnswer[$i3]=$answer;
							$myOption[$i3]=$response;

							if($answer > 0){
						       $total=$total + $answer;
						    }
						}
					}

		if($question_type == 0 | $question_type == 3 ){ //text or Textarea
			$answers = bfsurvey_plusController::getStatsText($row->field_name, $this->catid);
			$field_name = $row->field_name;
			echo "<hr>";
			foreach($answers AS $answer){
				if($answer->$field_name){
					echo trim($answer->$field_name)."<br>";
				}
			}
			echo "<hr>";
		}else if($question_type == 5 | $question_type == 8){ //date or summation or rating
		   echo JText::_('COM_BFSURVEYPLUS_ERROR_NO_STATS');
		}else if($row->sql != ""){
		   echo JText::_('COM_BFSURVEYPLUS_ERROR_NO_STATS_SQL');
		}else if($question_type == 9){ //rating

		   $mylabels = array();
	       if($row->titles == ""){
	          // do nothing
	       }else{
	          $mylabels = preg_split("/;/",$row->titles);
	       }

		   for($z=0; $z < 20; $z++)
	       {
	       		$total = 0;
		   		$myOption = array();
				$myAnswer = array();
	            $tempvalue="option".($z+1);

	       	    if($row->$tempvalue != ""){

		       	    $field=$row->field_name;
       				$question=$field.($z+1);

	       			for($y=1; $y < $row->sqlfield+1; $y++){
	       				if($row->titles == ""){
						   $response = $y;
						}else{
						   $response = $mylabels[$y-1];
						}
	       				$answer = bfsurvey_plusController::getStats($question, $response, $this->catid);
	       				$myAnswer[$y]=$answer;
						$myOption[$y]=$response;
						if($answer > 0){
						   $total=$total + $answer;
						}
	       			}
					?>
					<table>
					<tr class="<?php echo "row$k"; ?>">
				    <td>
			 		    <?php echo $row->$tempvalue; ?>
				    </td>
	  				</tr>
					<tr>
			   		<th width="100">Option</th>
					   <th width="50">Count</th>
			   		<th width="100">Percent</th>
					   <th width="100">Graph</th>
					</tr>
					<?php
						$colourCount=0;
						for ($z2=1; $z2 < count($myOption)+1; $z2++){
				    		$colourCount++;
							    if($colourCount > 5){
				      	 			$colourCount = 1;
				    			}
							    echo "<tr>";
								if($row->titles == ""){
							       echo "<td>".$myOption[$z2]."</td>";
							    }else{
								   if(isset($mylabels[$z2-1])){
 	       		             	      echo "<td>".$mylabels[$z2-1]."</td>";
 	       		          		   }else{
 	       		             		  echo "<td>&nbsp;</td>";
 	       		             	   }
							    }
							    echo "<td>".$myAnswer[$z2]."</td>";
					    		if($total > 0){
						       		echo "<td>".number_format((($myAnswer[$z2]/$total)*100),2)."%</td>";
								}else{
							   		echo "<td>0.00%</td>";
								}


							    $myclass = 'polls_color_'.$colourCount;
								?>
				   				<td width=300 >
				   				<?php
				   				if($total > 0){
				   					 ?>
			       				    <div class="<?php echo $myclass ?>" style="height:5px;width:<?php echo (($myAnswer[$z2]/$total)*100) ?>%"></div>
			       				    <?php
			       				 }else{
			       					 ?>
			       				    <div class="<?php echo $myclass ?>" style="height:5px;width:1%"></div>
			       					 <?php
			       				 }
			       		}
			       		?>
			       		</td>
				   		</tr>
					<?php
					?>
					</table>
					Total: <?php echo $total ?>
				<?php
	       		}
	       	}

		}else{
		?>

		<table>
		<tr>
		   <th width="100">Option</th>
		   <th width="50">Count</th>
		   <th width="100">Percent</th>
		   <th width="100">Graph</th>
		</tr>
		<?php
			$colourCount=0;
			for ($z=1; $z < count($myOption)+1; $z++){
			    $colourCount++;
			    if($colourCount > 5){
			       $colourCount = 1;
			    }
			    echo "<tr>";
			    echo "<td>".$myOption[$z]."</td>";
			    echo "<td>".$myAnswer[$z]."</td>";
			    if($total > 0){
			       echo "<td>".number_format((($myAnswer[$z]/$total)*100),2)."%</td>";
				}else{
				   echo "<td>0.00%</td>";
				}


			    $myclass = 'polls_color_'.$colourCount;
			?>
			    <td width=300 >
			    <?php
			    if($total > 0){
			    ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:<?php echo (($myAnswer[$z]/$total)*100) ?>%"></div>
		        <?php
		        }else{
		        ?>
		           <div class="<?php echo $myclass ?>" style="height:5px;width:1%"></div>
		        <?php
		        }
		        ?>
		        </td>
			    </tr>
			<?php

			}

		?>
		</table>
		Total: <?php echo $total ?>

		<?php
		}
		?>

        </td>
        </tr>

        <?php $k = 1 - $k; ?>
        <?php } ?>
    <?php endforeach; ?>
    </tbody>
    </table>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</div>
</form>