<?php
/**
 * $Id: edit.php 56 2013-11-15 11:08:33Z tuum $
 * Email Item form for BF Survey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
 defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'emailitem.cancel' || document.formvalidator.isValid(document.id('emailitem-form'))) {
			Joomla.submitform(task, document.getElementById('emailitem-form'));
		}
		else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey_plus&view=emailitem&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="emailitem-form" class="form-validate">
<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<!-- Begin Emailitem -->
	<div class="span10 form-horizontal">

	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFSURVEYPLUS_TITLE_DETAILS') : JText::sprintf('COM_BFSURVEYPLUS_TITLE_EMAIL_TEMPLATE', $this->item->id); ?></a></li>
		</ul>
		<div class="tab-content">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<div class="width-60 fltlft">
		<fieldset class="adminform">
<?php } ?>
			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('catid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('catid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('subject'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('subject'); ?></div>
				</div>
				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
				</div>
				<?php } ?>
				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
				<?php } ?>
				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('description'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('description'); ?>
				<?php } ?>
			</div>

		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
		<?php } ?>

		</div>
		<input type="hidden" name="task" value="emailitem.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</fieldset>

	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
	</div>
	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('state'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('state'); ?>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('showQuestions'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('showQuestions'); ?></div>
				</div>
			</div>
		</fieldset>
	</div>
	<?php } ?>

	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
	<div class="width-40 fltrt">
		<fieldset class="adminform">
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('showQuestions'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('showQuestions'); ?></div>
			</div>
			<div class="clr"></div>
	<?php } ?>

	<div class="span2">
		<?php if( floatval($version->RELEASE) >= 3 ) { ?>
		<h4><?php echo JText::_( 'COM_BFSURVEYPLUS_HELP_FIELDS_REPLACED' ); ?></h4>
		<hr />
		<?php } ?>
		<fieldset class="form-vertical">
			<div class="control-group">
				<?php echo JText::_( 'COM_BFSURVEYPLUS_FIELDS_REPLACED' ); ?><br>
				<ul class="adminformlist">

					<li>{category}
					<?php echo JText::_( 'COM_BFSURVEYPLUS_HELP_CATEGORY' ); ?></li>

					<li>{name}
					<?php echo JText::_( 'COM_BFSURVEYPLUS_HELP_NAME' ); ?></li>

					<li>{email}
					<?php echo JText::_( 'COM_BFSURVEYPLUS_HELP_EMAIL' ); ?></li>

				</ul>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
	</div>
	<?php } ?>
</form>