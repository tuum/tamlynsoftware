<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/backend.css');
//F0FTemplateUtils::addJS('media://com_bfsurvey/js/question.js');
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey&view=emailitem&id='.(int) $this->item->bfsurvey_emailitem_id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
	<input type="hidden" name="bfsurvey_emailitem_id" value="<?php echo $this->item->bfsurvey_emailitem_id ?>" />

	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->bfsurvey_emailitem_id) ? JText::_('COM_BFSURVEY_TITLE_DETAILS') : JText::sprintf('COM_BFSURVEY_TITLE_EMAIL_TEMPLATE', $this->item->bfsurvey_emailitem_id); ?></a></li>
			<li><a href="#trigger" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_EMAILITEM_FIELD_CONDITION_TRIGGER_LABEL'); ?></a></li>
		</ul>
		<div class="tab-content">

			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bfsurvey_category_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bfsurvey_category_id'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sendTo'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sendTo'); ?></div>
				</div>
				<?php if (version_compare(JVERSION, '3.1.6', 'gt')){ //usergrouplist was added in Joomla 3.2 ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sendToGroup'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sendToGroup'); ?></div>
				</div>
				<?php } ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('subject'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('subject'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
			</div>

			<div class="tab-pane" id="trigger">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('condition_trigger'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('condition_trigger'); ?></div>
				</div>
			</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('enabled'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('enabled'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<div class="span2">
		<h4><?php echo JText::_( 'COM_BFSURVEY_HELP_FIELDS_REPLACED' ); ?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<?php echo JText::_( 'COM_BFSURVEY_FIELDS_REPLACED' ); ?><br>
				<ul class="adminformlist">
					<li>{Name}
					<?php echo JText::_( 'COM_BFSURVEY_HELP_NAME' ); ?></li>

					<li>{Email}
					<?php echo JText::_( 'COM_BFSURVEY_HELP_EMAIL' ); ?></li>

					<li>{url}
					<?php echo JText::_( 'COM_BFSURVEY_HELP_URL' ); ?></li>

					<li>{uurl}
					<?php echo JText::_( 'COM_BFSURVEY_HELP_UURL' ); ?></li>

				</ul>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
</form>