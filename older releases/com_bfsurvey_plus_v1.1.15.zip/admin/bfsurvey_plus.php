<?php
/**
 * $Id: bfsurvey_plus.php 56 2013-11-15 11:08:33Z tuum $
 *
 * bfsurvey_plus entry point file for BF Survey Plus component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die;
global $bfsurveyplus_version;
$bfsurveyplus_version =  '1.1.15';

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_bfsurvey_plus')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Handle Live Update requests
if(!class_exists('LiveUpdate')) {
	require_once JPATH_COMPONENT_ADMINISTRATOR.'/liveupdate/liveupdate.php';
	if(JRequest::getCmd('view','') == 'liveupdate') {
		LiveUpdate::handleRequest();
		return true;
	}
}

// Include dependancies
jimport('joomla.application.component.controller');

$jlang = JFactory::getLanguage();
$jlang->load('com_bfsurvey_plus', JPATH_COMPONENT, 'en-GB', true);
$jlang->load('com_bfsurvey_plus', JPATH_COMPONENT, $jlang->getDefault(), true);
$jlang->load('com_bfsurvey_plus', JPATH_COMPONENT, null, true);

$document = JFactory::getDocument();
$cssFile = './components/com_bfsurvey_plus/css/bfsurvey.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

if (!class_exists('JControllerLegacy')) {
	require_once( JPATH_COMPONENT_ADMINISTRATOR.'/legacy.php' );
}
$controller	= JControllerLegacy::getInstance('bfsurvey_plus');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();