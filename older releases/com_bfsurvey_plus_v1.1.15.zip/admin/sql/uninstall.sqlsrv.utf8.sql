-- <?php /* $Id: uninstall.sqlsrv.utf8.sql 16 2012-01-02 12:56:58Z tuum $ */ defined('_JEXEC') or die() ?>;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurvey_plus]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurvey_plus]
END;	
	
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfsurveyplus_plus_email]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfsurveyplus_plus_email]		
END;

DELETE FROM [#__categories] WHERE extension='com_bfsurveyplus_plus';
