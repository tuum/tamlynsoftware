<?php
/**
 * $Id: file.script.php 57 2013-11-16 01:18:17Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

class Com_bfsurvey_plusInstallerScript {

function install($parent) {
	$db = JFactory::getDbo();
	$app = JFactory::getApplication();
	$query	= $db->getQuery(true);

	//check for sample data
	$tablelist = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfsurvey_plus", $tablelist)) {
		$query->clear();
		$query->select('id');
		$query->from('#__bfsurvey_plus');
		$db->setQuery((string)$query);
		$result=$db->loadResult();
	}else{
		$result = 0;
	}

	if($result){
		//no need for sample data
	}else{
		//install sample data
		$query->clear();
		$query->insert('#__categories');
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			//new way of doing this to support multiple database types such as SQL Server
			$query->columns(array($db->quoteName('parent_id'), $db->quoteName('title'), $db->quoteName('alias'), $db->quoteName('extension'), $db->quoteName('published'), $db->quoteName('level'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('metadesc'), $db->quoteName('metakey'), $db->quoteName('metadata'), $db->quoteName('lft'), $db->quoteName('rgt'), $db->quoteName('description'), $db->quoteName('params') ));
			$query->values('1, '.$db->quote( $db->escape('Example'), false ).', '.$db->quote( $db->escape('example'), false ).', '.$db->quote('com_bfsurvey_plus').', 1, 1, 1, '.$db->quote('*').', '.$db->quote('').' , '.$db->quote('').' ,'.$db->quote('{"page_title":"","author":"","robots":""}').', 1, 2, '.$db->quote('Example Category').', '.$db->quote('') );
		}else{
			//the following is required to support Joomla 1.6. Remove this when we drop 1.6 support.
			$query->set('`parent_id` = 1');
	        $query->set('`title` = '.$db->quote( $db->escape('Example'), false ));
	        $query->set('`alias` = '.$db->quote( $db->escape('example'), false ));
	        $query->set('`extension` = '.$db->quote('com_bfsurvey_plus'));
	        $query->set('`published` = 1');
	        $query->set('`level` = 1');
	        $query->set('`access` = 1');
			$query->set('`lft` = 1');
			$query->set('`rgt` = 2');
		}

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query->select('max(id) AS id');
		$query->from('#__categories');
		$db->setQuery((string)$query);
		$catid=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->insert('#__bfsurvey_plus');
			$query->columns(array($db->quoteName('catid'),
				$db->quoteName('question'),
				$db->quoteName('question_type'),
				$db->quoteName('date'),
				$db->quoteName('checked_out'),
				$db->quoteName('checked_out_time'),
				$db->quoteName('state'),
				$db->quoteName('ordering'),
				$db->quoteName('parent'),
				$db->quoteName('option1'),
				$db->quoteName('option2'),
				$db->quoteName('option3'),
				$db->quoteName('option4'),
				$db->quoteName('option5'),
				$db->quoteName('option6'),
				$db->quoteName('option7'),
				$db->quoteName('option8'),
				$db->quoteName('option9'),
				$db->quoteName('option10'),
				$db->quoteName('next_question1'),
				$db->quoteName('next_question2'),
				$db->quoteName('next_question3'),
				$db->quoteName('next_question4'),
				$db->quoteName('next_question5'),
				$db->quoteName('next_question6'),
				$db->quoteName('next_question7'),
				$db->quoteName('next_question8'),
				$db->quoteName('next_question9'),
				$db->quoteName('next_question10'),
				$db->quoteName('prefix'),
				$db->quoteName('suffix'),
				$db->quoteName('field_name'),
				$db->quoteName('mandatory'),
				$db->quoteName('helpText'),
				$db->quoteName('sql'),
				$db->quoteName('sqlfield'),
				$db->quoteName('fieldSize'),
				$db->quoteName('publish_down'),
				$db->quoteName('archived'),
				$db->quoteName('approved'),
				$db->quoteName('access'),
				$db->quoteName('language'),
				$db->quoteName('created'),
				$db->quoteName('created_by'),
				$db->quoteName('modified'),
				$db->quoteName('modified_by'),
				$db->quoteName('publish_up'),
				$db->quoteName('field_type'),
				$db->quoteName('validation_type'),
				$db->quoteName('titles'),
				$db->quoteName('horizontal'),
				$db->quoteName('otherprefix'),
				$db->quoteName('othersuffix'),
				$db->quoteName('suppressQuestion'),
				$db->quoteName('alias') ));
			$query->values($catid.", 'Is this the first time you have used us?', '1', '', 0, '', 1, 1, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'firstTime', 1, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'How did you hear about us?', '1', '', 0, '', 1, 2, 0, 'Word of Mouth', 'Advertisement', 'Internet', 'Other', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'howDidYouHear', 1, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'Why did you choose to use us?', '2', '', 0, '', 1, 3, 0, 'Price', 'Quality', 'Service', 'Recommendation', 'Referral', 'Location', 'Other', '', '', '', 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, '', '', 'whyUs', 0, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'Why did you choose to use us again?', '2', '', 0, '', 1, 4, 0, 'Price', 'Quality', 'Service', 'Convenience', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whyAgain', 0, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'How would you rate our service?', '6', '', 0, '', 1, 5, 0, 'Very good', 'Good', 'Acceptable', 'Poor', 'Very poor', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'rateService', 1, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'Would you use us again?', '1', '', 0, '', 1, 7, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'useAgain', 1, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'When are you likely to use our services next?', '5', '', 0, '', 1, 8, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whenNextUse', 0, 'An approximate date will be fine.', '', '',255, '','','','','*','','','','','','','','','','','','',''");
			$query->values($catid.", 'Do you have any other comments?', '3', '', 0, '', 1, 9, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'comments', 0, '', '', '',255, '','','','','*','','','','','','','','','','','','',''");
		}else{
			//the following is required to support Joomla 1.6. Remove this when we drop 1.6 support.
			$query = "INSERT INTO `#__bfsurvey_plus` (`id`, `catid`, `question`, `question_type`, `date`, `checked_out`, `checked_out_time`, `state`, `ordering`, `parent`, `option1`, `option2`, `option3`, `option4`, `option5`, `option6`, `option7`, `option8`, `option9`, `option10`, `next_question1`, `next_question2`, `next_question3`, `next_question4`, `next_question5`, `next_question6`, `next_question7`, `next_question8`, `next_question9`, `next_question10`, `prefix`, `suffix`, `field_name`, `mandatory`, `helpText`, `sql`, `sqlfield`,`fieldSize`) VALUES
				(1, ".$catid.", 'Is this the first time you have used us?', '1', '2008-10-29 23:32:11', 0, '0000-00-00 00:00:00', 1, 1, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'firstTime', 1, '', '', '',255),
				(2, ".$catid.", 'How did you hear about us?', '1', '2008-10-24 01:15:30', 0, '0000-00-00 00:00:00', 1, 2, 0, 'Word of Mouth', 'Advertisement', 'Internet', 'Other', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'howDidYouHear', 1, '', '', '',255),
				(3, ".$catid.", 'Why did you choose to use us?', '2', '2008-10-29 02:42:06', 0, '0000-00-00 00:00:00', 1, 3, 0, 'Price', 'Quality', 'Service', 'Recommendation', 'Referral', 'Location', 'Other', '', '', '', 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, '', '', 'whyUs', 0, '', '', '',255),
				(4, ".$catid.", 'Why did you choose to use us again?', '2', '2008-10-24 01:19:18', 0, '0000-00-00 00:00:00', 1, 4, 0, 'Price', 'Quality', 'Service', 'Convenience', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whyAgain', 0, '', '', '',255),
				(5, ".$catid.", 'How would you rate our service?', '6', '2008-10-24 01:15:34', 0, '0000-00-00 00:00:00', 1, 5, 0, 'Very good', 'Good', 'Acceptable', 'Poor', 'Very poor', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'rateService', 1, '', '', '',255),
				(6, ".$catid.", 'Would you use us again?', '1', '2008-11-02 00:01:58', 0, '0000-00-00 00:00:00', 1, 7, 0, 'Yes', 'No', '', '', '', '', '', '', '', '', 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'useAgain', 1, '', '', '',255),
				(7, ".$catid.", 'When are you likely to use our services next?', '5', '2008-11-02 00:01:38', 0, '0000-00-00 00:00:00', 1, 8, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'whenNextUse', 0, 'An approximate date will be fine.', '', '',255),
				(8, ".$catid.", 'Do you have any other comments?', '3', '2008-10-24 02:14:38', 0, '0000-00-00 00:00:00', 1, 9, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'comments', 0, '', '', '',255)";
		}
		$db->setQuery( $query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

	//check for email sample data
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);
	$query->clear();
	$query->select('id');
	$query->from('#__bfsurveyplus_email');
	$db->setQuery((string)$query);
	$result=$db->loadResult();

	if($result){
		//no need for sample email data
	}else{
		//install email data
		$query->clear();
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->insert('#__bfsurveyplus_email');
			$query->columns(array($db->quoteName('catid'), $db->quoteName('title'), $db->quoteName('subject'), $db->quoteName('description'), $db->quoteName('date'), $db->quoteName('checked_out'), $db->quoteName('checked_out_time'), $db->quoteName('state'), $db->quoteName('ordering'), $db->quoteName('publish_down'), $db->quoteName('archived'), $db->quoteName('approved'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('created'), $db->quoteName('created_by'), $db->quoteName('modified'), $db->quoteName('modified_by'), $db->quoteName('parent'), $db->quoteName('publish_up'), $db->quoteName('showQuestions') ));
			$query->values($catid.", 'Admin', 'Automated BF Survey Plus Notification - {name}', '<p>{name} ({email}) has completed the {category} survey</p>', '', 0, '', 1, 1, '','','','','*','','','','',0,'',0");
			$query->values($catid.", 'Author', 'Automated BF Survey Plus Notification', '<p>Thank you {name} for completing the {category} survey.</p>\r\n<p> </p>', '', 0, '', 1, 2, '','','','','*','','','','',0,'',0");
		}else{
			$query = "INSERT INTO `#__bfsurveyplus_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `state`, `ordering`, `showQuestions`) VALUES
			(1, ".$catid.", 'Admin', 'Automated BF Survey Plus Notification - {name}', '<p>{name} ({email}) has completed the {category} survey', '2010-06-19 11:43:53', 0, '0000-00-00 00:00:00', 1, 0, 1),
			(2, ".$catid.", 'Author', 'Automated BF Survey Plus Notification', '<p>Thank you {name} for completing the {category} survey.</p>\r\n<p> </p>', '2010-06-19 11:00:31', 0, '0000-00-00 00:00:00', 1, 2, 1)";
		}
		$db->setQuery( $query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

?>

<div><strong>BF Survey Plus</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

		<img src="./components/com_bfsurvey_plus/images/bflogo.jpg"><br/>

        <br/>  Copyright &copy; 2013 - Tamlyn Software. All rights reserved.
        <br />

                <br/>This Joomla! 2.5.x / 3.x Component is released under the GNU GPL.
                <br/>
                <br/>Congratulations, you have successfully installed BF Survey Plus!
        </p>
    </td>
  </tr>
  <tr>
    <td>
    </td>
    <td>
            <strong><code>I N S T A L L :</code></strong>

                <br/>

                <br/>

                STEP 1 : <font color = "Green">Succesfull</font>
                <br>
                <br>
                STEP 2 : Navigate to Components, BF Survey Plus->Questions, and setup questions as required.
                <br>
                <br>
                STEP 3 : Add a "BF Survey Plus" menu item. Make sure you select a Category in "Required Settings", and adjust title etc. in "Survey Options".
				<br>
                <br>
                STEP 4 : (optional) If you wish to make radio or checkbox fields mandatory, you need to install <a href="http://tamlynsoftware.com/download/free-downloads.html" target="_blank">BF Validate Plus</a> plugin.

    </td>
  </tr>
    </table>
</center>
<?php
	}

	function uninstall($parent) {
		?>
		<div>BF Survey Plus has now been removed from your system.</div>
		<p>
		We're sorry to see you go! Please feel free to post reasons on our forum to help us to improve our product.<br>
		<br>
		Don't forget to delete any BF Survey Plus menu items.
		<br>
		<br>
		</p>
		<?php
	}

	function update($parent) {
		//not implemented yet
	}

	function preflight($type, $parent) {
		//not implemented
	}

	/**
	* method to run after an install/update/uninstall method
	*
	* @return void
	*/
	function postflight($type, $parent)  {
        // define the following parameters only if it is an original install
        if ( $type == 'install' ) {
                $params['allowEmail'] = '0';
				$params['sendEmailTo'] = 'insertemail@youremailaddress.com';
				$params['authorEmail'] = '0';
				$params['anonymous'] = '0';
				$params['anonymousText'] = 'I prefer to respond anonymously:';
				$params['anonymousYes'] = 'Yes';
				$params['anonymousNo'] = 'No';
				$params['showName'] = '1';
				$params['showCompany'] = '1';
				$params['showEmail'] = '1';
				$params['nameText'] = 'Name';
				$params['companyText'] = 'Company';
				$params['emailText'] = 'Email';
				$params['surveyTitle'] = 'Business Feedback Survey';
				$params['introText'] = 'Please take a moment to complete this survey. We would like to know how successful our recent work for you was, and if there is anything we could do differently next time to improve our service.';
				$params['thankyouText'] = 'Thank you again for working with us. I hope we have the opportunity to serve you again.';
				$params['showReferenceNo'] = '0';
				$params['submitText'] = 'Next';
				$params['errorText'] = 'Some values are not acceptable. Please retry.';
				$params['use_captcha'] = '0';
				$params['redirectURL'] = '';
				$params['useCSS'] = '1';
				$params['registeredUsers'] = '0';
				$params['preventMultiple'] = '0';
				$params['preventMultipleEmail'] = '0';
				$params['preventMultipleUID'] = '0';

				$this->setParams( $params );
        }
	}

    function setParams($param_array) {
            if ( count($param_array) > 0 ) {
                    // read the existing component value(s)
                    $db = JFactory::getDbo();
                    $db->setQuery('SELECT params FROM #__extensions WHERE name = "com_bfsurvey_plus"');
                    $params = json_decode( $db->loadResult(), true );
                    // add the new variable(s) to the existing one(s)
                    foreach ( $param_array as $name => $value ) {
                            $params[ (string) $name ] = (string) $value;
                    }
                    // store the combined new and existing values back as a JSON string
                    $paramsString = json_encode( $params );
                    $db->setQuery('UPDATE #__extensions SET params = ' .
                            $db->quote( $paramsString ) .
                            ' WHERE name = "com_bfsurvey_plus"' );
                            $db->query();
            }
    }
}
