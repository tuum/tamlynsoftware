ALTER TABLE `#__bfsurvey_emailitems` ADD `pdfEmail` tinyint(1) NOT NULL;
ALTER TABLE `#__bfsurvey_emailitems` ADD `template` text;
ALTER TABLE `#__bfsurvey_emailitems` ADD `templateCoverpage` text;
ALTER TABLE `#__bfsurvey_emailitems` ADD `templateHeader` text;
ALTER TABLE `#__bfsurvey_emailitems` ADD `templateFooter` text;