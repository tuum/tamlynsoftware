<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class
 */
class JFormFieldquestiontype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'questiontype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

        		$options[] = JHtml::_('select.option',  '0', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_TEXT' ) );
				$options[] = JHtml::_('select.option',  '1', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_RADIO' ) );
				$options[] = JHtml::_('select.option',  '2', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_CHECKBOX' ) );
				$options[] = JHtml::_('select.option',  '3', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_TEXTAREA' ) );
				$options[] = JHtml::_('select.option',  '4', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_ATTACHMENT' ) );
				$options[] = JHtml::_('select.option',  '5', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_DATE' ) );
				$options[] = JHtml::_('select.option',  '6', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_DROPDOWN' ) );
				$options[] = JHtml::_('select.option',  '7', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_USERLIST' ) );
				//$options[] = JHtml::_('select.option',  '8', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_SUMMATION' ) );
				$options[] = JHtml::_('select.option',  '9', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_RATING' ) );
        		$options[] = JHtml::_('select.option',  '10', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_HEADING' ) );
        		$options[] = JHtml::_('select.option',  '11', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_SQL' ) );
        		$options[] = JHtml::_('select.option',  '12', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_URL' ) );
        		$options[] = JHtml::_('select.option',  '13', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_HELPTEXT' ) );
        		$options[] = JHtml::_('select.option',  '14', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_DATEMOBILE' ) );
        		//$options[] = JHtml::_('select.option',  '15', JText::_( 'COM_BFSURVEY_QUESTION_TYPE_DATEBOX' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }

        /**
         * Get the rendering of this field type for a repeatable (grid) display,
         * e.g. in a view listing many item (typically a "browse" task)
         *
         * @since 2.0
         *
         * @return  string  The field HTML
         */
        public function getRepeatable()
        {
        	$show_link         = false;
        	$link_url          = '';

        	$class = $this->element['class'] ? (string) $this->element['class'] : '';

        	if ($this->element['show_link'] == 'true')
        	{
        		$show_link = true;
        	}

        	if ($this->element['url'])
        	{
        		$link_url = $this->element['url'];
        	}
        	else
        	{
        		$show_link = false;
        	}

        	if ($show_link && ($this->item instanceof F0FTable))
        	{
        		// Replace [ITEM:ID] in the URL with the item's key value (usually:
        		// the auto-incrementing numeric ID)
        		$keyfield = $this->item->getKeyName();
        		$replace  = $this->item->$keyfield;
        		$link_url = str_replace('[ITEM:ID]', $replace, $link_url);

        		// Replace other field variables in the URL
        		$fields = $this->item->getFields();

        		foreach ($fields as $fielddata)
        		{
        			$fieldname = $fielddata->Field;
        			$search    = '[ITEM:' . strtoupper($fieldname) . ']';
        			$replace   = $this->item->$fieldname;
        			$link_url  = str_replace($search, $replace, $link_url);
        		}
        	}
        	else
        	{
        		$show_link = false;
        	}

        	$html = '<span class="' . $this->id . ' ' . $class . '">';

        	if ($show_link)
        	{
        		$html .= '<a href="' . $link_url . '">';
        	}

        	$html .= htmlspecialchars(self::getOptionName($this->getOptions(), $this->value), ENT_COMPAT, 'UTF-8');

        	if ($show_link)
        	{
        		$html .= '</a>';
        	}

        	$html .= '</span>';

        	return $html;
        }

        /**
         * Gets the active option's label given an array of JHtml options
         *
         * @param   array   $data      The JHtml options to parse
         * @param   mixed   $selected  The currently selected value
         * @param   string  $optKey    Key name
         * @param   string  $optText   Value name
         *
         * @return  mixed   The label of the currently selected option
         */
        public static function getOptionName($data, $selected = null, $optKey = 'value', $optText = 'text')
        {
        	$ret = null;

        	foreach ($data as $elementKey => &$element)
        	{
        		if (is_array($element))
        		{
        			$key = $optKey === null ? $elementKey : $element[$optKey];
        			$text = $element[$optText];
        		}
        		elseif (is_object($element))
        		{
        			$key = $optKey === null ? $elementKey : $element->$optKey;
        			$text = $element->$optText;
        		}
        		else
        		{
        			// This is a simple associative array
        			$key = $elementKey;
        			$text = $element;
        		}

        		if (is_null($ret))
        		{
        			$ret = $text;
        		}
        		elseif ($selected == $key)
        		{
        			$ret = $text;
        		}
        	}

        	return $ret;
        }
}
