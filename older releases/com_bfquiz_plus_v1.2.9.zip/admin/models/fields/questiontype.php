<?php
/**
 * $Id: questiontype.php 59 2013-11-16 01:17:24Z tuum $
 * Question_Type feild for bfquiz_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class for the BF Quiz Plus component
 */
class JFormFieldquestiontype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'questiontype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

				$options[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXT' ) );
				$options[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_RADIO' ) );
				$options[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_CHECKBOX' ) );
				$options[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_TEXTAREA' ) );
				$options[] = JHTML::_('select.option',  '10', JText::_( 'COM_BFQUIZPLUS_QUESTION_TYPE_HEADING' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
