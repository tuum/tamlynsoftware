<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 59 2013-11-16 01:17:24Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php

$rowX =& $this->items2[0];
$row2X =& $this->items3[0];

$header=""; // excel export
$data="";

$Submit	= JRequest::getVar( 'Submit' );
$condition1_1	= JRequest::getVar( 'condition1_1' );
$condition1_2	= JRequest::getVar( 'condition1_2' );
$condition1_3	= JRequest::getVar( 'condition1_3' );
$operation_1	= JRequest::getVar( 'operation_1' );
$condition2_1	= JRequest::getVar( 'condition2_1' );
$condition2_2	= JRequest::getVar( 'condition2_2' );
$condition2_3	= JRequest::getVar( 'condition2_3' );
$input	= JRequest::getVar( 'input' );
$input = trim($input);

$input2	= explode(", ", $input);

$datefrom	= JRequest::getVar( 'datefrom' );
$dateto	= JRequest::getVar( 'dateto' );
$daterange	= JRequest::getVar( 'daterange' );

?>

<?php

// Tim to change to Joomla date command
if($daterange=="30"){
   // last 30 days
   $dateto = date("Y-m-d");
   $datefrom = date("Y-m-d",mktime(0, 0, 0, date("m"), date("d")-30, date("Y") ));
}

if($daterange=="120"){
   // last 120 days
   $dateto = date("Y-m-d");
   $datefrom = date("Y-m-d",mktime(0, 0, 0, date("m"), date("d")-120, date("Y") ));
}

   $myFields="";

   $catid	= JRequest::getVar( 'cid', 0, '', 'int' );

   $db = JFactory::getDBO();
   $table="#__bfquizplus_".$this->poolid."_pool";

   // Grab the fields for the selected table
   $fields = $db->getTableColumns($table, true );
   if(!$fields){
      JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_ERROR_NO_ANSWER_TABLE') );
	  $app = JFactory::getApplication();
	  $app->redirect( 'index.php?option=com_bfquiz_plus' );
   }
   if( sizeof( $fields ) ) {
      // We found some fields so let's create the list
      $options = array();
      foreach( $fields as $field => $type ) {
          $options[] = $field;
          if($myFields == ""){ // first one
             $myFields = "'".$field."'";
          }else{
             $myFields .= ",'".$field."'";
          }
      }
   }

   if($input==""){
      $input2=$options;
   }

?>

<script language=javascript>

//need to populate this dynamically
var from_array = new Array(<?php echo $myFields ?>);
var to_array = new Array(); 		  // this array has the values for the destination list(if any)
</script>

<script language=javascript>
function moveoutid()
{
	var sda = document.getElementById('xxx');;
	var len = sda.length;
	var sda1 = document.getElementById('yyy');

	for(var j=0; j<len; j++)
	{
	    if(sda[j].selected)
		{
			var tmp = sda.options[j].text;
			var tmp1 = sda.options[j].value;
			sda.remove(j);
			j--;
			len--;
			var y=document.createElement('option');
			y.text=tmp;
			y.value=tmp1;
			try
			{sda1.add(y,null);
			}
			catch(ex)
			{
			sda1.add(y);
			}
		}

	}

}

function getFields(){
	var input = document.getElementById("input");
	var sda1 = document.getElementById('yyy');
	var len = sda1.length;
	var temp = '';

	for(var j=0; j<len; j++)
	{
		if(j==0){
		   temp=sda1.options[j].value;
		}else{
		   temp=temp+", "+sda1.options[j].value;
		}
	}

	input.setAttribute("value", temp);
}


function moveinid()
{
	var sda = document.getElementById('xxx');
	var sda1 = document.getElementById('yyy');
	var len = sda1.length;
	for(var j=0; j<len; j++)
	{
		if(sda1[j].selected)
		{
			var tmp = sda1.options[j].text;
			var tmp1 = sda1.options[j].value;
			sda1.remove(j);
			j--;
			len--;
			var y=document.createElement('option');
			y.text=tmp;
 			y.value=tmp1;
			try
			{
			sda.add(y,null);}
			catch(ex){
			sda.add(y);
			}

		}
	}
}
</script>

<script language="Javascript">
<!--

function ShowHideCustomDate(){

   var mydaterange = ""
   len = document.Report1.daterange.length

   for (i = 0; i <len; i++) {
      if (document.Report1.daterange[i].checked) {
         mydaterange = document.Report1.daterange[i].value
      }
   }

   if(mydaterange == "Custom"){
      // show date
      document.getElementById("CustomDate").style.display = '';
   }else{
      // hide date
      document.getElementById("CustomDate").style.display = 'none';
   }
}

//-->
</script>

<?php

if($Submit==null){ // if clicked on Submit button.

?>

<fieldset><legend><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_DYNAMIC_REPORT' ); ?></legend>

   <form id="Report1" name="Report1" method="POST" onsubmit="getFields()">

<table>
<tr>
<td>

<center>
<?php echo JText::_( 'COM_BFQUIZPLUS_PLEASE_SELECT_FEILDS' ); ?>
</center>
<table border=0 align=center valign=center>
<tr><td><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_AVAILABLE_FIELDS' ); ?></td><td></td><td><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_TO_USE' ); ?></td></tr>
<tr><td>
<select id=xxx name="xxx" multiple size=10 style="width:150px">
<script language=javascript>
for(var i=0;i<from_array.length;i++)
{
	document.write('<option value='+from_array[i]+'>'+from_array[i]+'</option>');
}
</script>
</select>
</td>
<td>
<input type=button value=">>" onclick=moveoutid()>
<input type=button value="<<" onclick=moveinid()>
</td>
<td>
<select name="yyy" id=yyy multiple size=10 style="width:150px">
<script language=javascript>
for(var j=0;j<to_array.length;j++)
{
	document.write('<option value='+to_array[j]+'>'+to_array[j]+'</option>');
}
</script>

</select>

</td></tr>
</table>

</td>
<td width="100">&nbsp;</td>
<td>

   <?php echo JText::_( 'COM_BFQUIZPLUS_DATE_RANGE' ); ?><br>

   <label for="daterange1" class="left-radio"><input type="radio" name="daterange" id="daterange1" value="All" checked onclick="ShowHideCustomDate()"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_ALL_AVAILABLE' ); ?></label>
   <label for="daterange2" class="left-radio"><input type="radio" name="daterange" id="daterange2" value="30" onclick="ShowHideCustomDate()"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_LAST_30_DAYS' ); ?></label>
   <label for="daterange3" class="left-radio"><input type="radio" name="daterange" id="daterange3" value="120" onclick="ShowHideCustomDate()"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_LAST_120_DAYS' ); ?></label>
   <label for="daterange4" class="left-radio"><input type="radio" name="daterange" id="daterange4" value="Custom" onclick="ShowHideCustomDate()"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_CUSTOM_DATE_RANGE' ); ?></label>

	<?php
	$document = JFactory::getDocument();
   	$document->addScript(JURI::root() . "/components/com_bfquiz_plus/includes/calendar.js");
    JHTML::_('behavior.calendar');
    ?>

	<div class="clr"></div>

   <DIV ID="CustomDate" style="display:none;">
   <table>
   <tr>
   <td>

   <?php

   echo '<input class="inputbox" type="text" id="datefrom" name="datefrom" size="10" maxlength="25" value="" />';
   echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\'datefrom\',\'%Y-%m-%d\');" />';

   ?>

   </td>
   <td><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_TO' ); ?></td>
   <td>

   <?php

      echo '<input class="inputbox" type="text" id="dateto" name="dateto" size="10" maxlength="25" value="" />';
      echo '<input type="reset" class="button" value="..." onclick="return showCalendar(\'dateto\',\'%Y-%m-%d\');" />';

   ?>
   </td>
   </tr>
   </table>
   </div>

</td>
</tr>
</table>

<br>
<?php echo JText::_( 'COM_BFQUIZPLUS_PLEASE_SELECT_CRITERIA' ); ?><br>
<input name='input' id='input' type="hidden">

   <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_CONDITION' ); ?> 1<br>
   <select name="condition1_1">

   <option value="0"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PLEASE_SELECT' ); ?></option>
   <?php
   if( sizeof( $options ) ) {
      // We found some fields so let's create the list
      foreach( $options as $field) {
         echo '<option value="'.$field.'">'.$field.'</option>';
      }
   }
   print '</select>';

   ?>
   <select name="condition1_2">
   <option value="0"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PLEASE_SELECT' ); ?></option>
   <option value="1"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_LESS_THAN' ); ?></option>
   <option value="2"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_EQUAL_TO' ); ?></option>
   <option value="3"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_GREATER_THAN' ); ?></option>
   <option value="4"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_NOT_EQUAL_TO' ); ?></option>
   </select>

   <?php

   print '<input name="condition1_3"><br><br>';
   ?>

   <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_OPERATOR' ); ?>
   <br>
   <?php
   print "<select name=\"operation_1\">";
   ?>
   <option value="0"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PLEASE_SELECT' ); ?></option>
   <option value="AND"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_AND' ); ?></option>
   <option value="OR"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_OR' ); ?></option>
   </select><br><br>

   <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_REPORT_CONDITION' ); ?> 2<br>
   <select name="condition2_1">

   <option value="0"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PLEASE_SELECT' ); ?></option>
   <?php
   if( sizeof( $options ) ) {
      // We found some fields so let's create the list
      foreach( $options as $field) {
         echo '<option value="'.$field.'">'.$field.'</option>';
      }
   }
   print '</select>';

   ?>

   <select name="condition2_2">
   <option value="0"><?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_PLEASE_SELECT' ); ?></option>
   <option value="1"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_LESS_THAN' ); ?></option>
   <option value="2"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_EQUAL_TO' ); ?></option>
   <option value="3"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_GREATER_THAN' ); ?></option>
   <option value="4"><?php echo JText::_( 'COM_BFQUIZPLUS_REPORT_IS_NOT_EQUAL_TO' ); ?></option>
   </select>

   <?php

   print '<input name="condition2_3"><br><br>';


?>



   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFQUIZPLUS_BUTTON_SUBMIT' ); ?>" />

<?php

   print "</form>";

   print '</fieldset>';


}else{

  if($input == ""){
      $input=str_replace("'", "", $myFields);
  }

  $sql='Select '.$input.' FROM '.$table.' ';

  if($condition1_1=="0"){

     if($daterange!="All"){
         $sql.=" where date(DateReceived)>=str_to_date('".$datefrom."','%Y-%m-%d') and date(DateReceived)<=str_to_date('".$dateto."','%Y-%m-%d')    order by id;";
     }else{
         $sql.=' order by id;';
     }

  }else{

     $sql.='where '.$condition1_1.'';
     switch($condition1_2){
     case 1: 	$sql.='<';
  			break;
     case 2:  	$sql.='=';
  			break;
     case 3:  	$sql.='>';
			break;
     case 4:  	$sql.='<>';
  			break;

     }

     if($condition1_1=="Time"){
        $sql.="".$condition1_3."";
     }else{
        $sql.='"'.$condition1_3.'"';
     }


     if($condition2_1=="0" or $operation_1=="0"){
        // do nothing
     }else{
        $sql.=' '.$operation_1.' ';
        $sql.=''.$condition2_1.'';
        switch($condition2_2){
        case 1: 	$sql.='<';
  			break;
        case 2:  	$sql.='=';
  			break;
        case 3:  	$sql.='>';
			break;
        case 4:  	$sql.='<>';
     			break;

        }

        $sql.='"'.$condition2_3.'"';
     }

     if($daterange!="All"){
         $sql.=" and DateReceived>=str_to_date('".$datefrom."','%Y-%m-%d') and DateReceived<=str_to_date('".$dateto."','%Y-%m-%d')    order by id;";
     }else{
         $sql.=' order by id;';
     }
  }

   $db 		= JFactory::getDBO();
   $db->setQuery( $sql );
   if (!$db->query()) {
      JError::raiseError(500, $db->getErrorMsg() );
   }
   $result = $db->loadObjectList( );

  $numrows= count( $result );

  if($numrows == 0) {
       //print "Your query did not return any results.";
     }else {

     	for ($i=0, $n=count( $result ); $i < $n; $i++){

			$row =& $result[$i];

			for ($z=0, $n2=count( $options ); $z < $n2; $z++){
			    $row2 =& $options[$z];
 	    		if(strpos($input,$row2) !== FALSE){
 	    		   $tempvalue="".$row2."".($i+1);
 	    		   if(isset($row->$row2)){
   	    		      $$tempvalue = $row->$row2;
   	    		   }else{
   	    		      $$tempvalue = "";
   	    		   }
	    		}
	    	}
        }
   }

  $header=""; // excel export

  print '<table>';
  print '<tr>';

  for ($z2=0, $n3=count( $input2 ); $z2 < $n3; $z2++){
     $row3 =& $input2[$z2];

     for ($z=0, $n2=count( $options ); $z < $n2; $z++){
	    $row2 =& $options[$z];

         if($row3==$row2){
      	    print '<td class="bfquiz_plusReportHeader">'.$row2.'</td>';
            $header .= "".$row2."" . "\t";
         }
     }

  }

  print '</tr>';


  $data="";

  for($z=0; $z < $numrows; $z++){
     $line = '';
     $value="";
     print '<tr>';

   	for ($z3=0, $n3=count( $input2 ); $z3 < $n3; $z3++){
		$row3 =& $input2[$z3];
		for ($z2=0, $n2=count( $options ); $z2 < $n2; $z2++){
        $row2 =& $options[$z2];
        	if($row3==$row2){
     		   $tempname="".$row2."".($z+1);
     		   print '<td class="bfquiz_plusReportBody">'.$$tempname.'</td>';
     		   $value = str_replace( '"' , '""' , $$tempname );
     		   $value = str_replace( chr(10) , ' ' , $value );   // this will get rid of newline for summation
			   $value = str_replace( '\"' , '' , $value );  // this will get rid of \"
			   $value = str_replace( '\'' , '' , $value );  // this will get rid of \"
     		   $value = ''.$value.'' . "\t";
     		   $line .= $value;
     		}
     	}
     }

     print '</tr>';
     $data .= trim( $line ) . "\n";
  }

  print '</table>';

  // for excel export
  $data = str_replace( "\r" , "" , $data );

  if ( $data == "" )
  {
    $data = "\n(0) Records Found!\n";
  }

   // excel export
   print '<form id="ExcelExport" name="ExcelExport" method="POST" action="./components/com_bfquiz_plus/excelexport.php">';

   print '<input type=hidden name="myheader"  value="'.$header.'">';

   print '<DIV ID="ExcelDate" style="display:none;"><textarea name="mydata">'.$data.'</textarea></div>';

   ?>
   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFQUIZPLUS_BUTTON_EXPORT_TO_EXCEL' ); ?>" />
   <?php jimport('joomla.html.html'); ?>
   <?php echo JHTML::_( 'form.token' ); ?>
   <?php
   print "</form>";
?>
   <br>
   <form action="index.php?option=com_bfquiz_plus&view=csvexport" method="post" name="csvForm">
   <input name="sql" type="hidden" id="sql" value="<?php echo $sql; ?>" />
   <input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFQUIZPLUS_BUTTON_EXPORT_TO_CSV' ); ?>" />
   <?php echo JHTML::_( 'form.token' ); ?>
   </form>

<?php
}
?>