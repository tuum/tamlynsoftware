<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 59 2013-11-16 01:17:24Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_ID' ); ?>
            </th>
            <th width="10">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
			</th>
            <th>
                <?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_NAME' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_EMAIL' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_UID' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_DATE' ); ?>
            </th>
            <th>
				<?php echo JText::_( 'COM_BFQUIZPLUS_TITLE_SCORE' ); ?>
            </th>
        </tr>
    </thead>
    <?php
    $k = 0;

    $catid = $this->catid;
    $randomid = $this->randomid;

    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row =& $this->items[$i];
        $link 		= JRoute::_( 'index.php?option=com_bfquiz_plus&view=resultpool&cid='. (int)$row->id.'&catid='.(int)$catid.'&randomid='. (int)$randomid );
        $checked 	= JHTML::_('grid.id',   $i, $row->id );
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td>
                <a href="<?php echo $link; ?>"><?php echo $row->id; ?></a>
            </td>
            <td>
				<?php echo $checked; ?>
			</td>
            <td>
                <a href="<?php echo $link; ?>">
                <?php
                   if(!isset($row->Name )){
                      $row->Name  = "";
                   }

                   if($row->Name == ""){
                      echo JText::_( 'COM_BFQUIZPLUS_BLANK');
                   }else{
                      echo $row->Name;
                   }
                ?>
                </a>
            </td>
            <td>
				<?php
                   if(!isset($row->Email)){
                      $row->Email = "";
                   }
                ?>
			    <?php echo $row->Email; ?>
            </td>
            <td>
				<?php
                   if(!isset($row->uid)){
                      $row->uid = "";
                   }
                ?>
			    <?php echo $row->uid; ?>
            </td>
            <td>
			    <?php
			        $version = new JVersion();
			        if( floatval($version->RELEASE) >= 3 ) {
						$tz = new DateTimeZone(JFactory::getApplication()->getCfg('offset'));
						$date = new JDate($row->DateReceived);
						$date->setTimezone($tz);
						echo JHTML::_('date',  $date, 'd-m-Y H:i' );
					}else{
						$user = JFactory::getUser();
						$dateReceived = JFactory::getDate($row->DateReceived);
						$dateReceived->setOffset($user->getParam('timezone'));
			        	//echo $dateReceived->format();
			        	echo JHTML::_('date',  $dateReceived, 'd-m-Y H:i' );
			        }
			    ?>
			</td>
            <td>
				<?php
                   if(!isset($row->score)){
                      $row->score = "";
                   }
                ?>
			    <?php echo $row->score; ?>
            </td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>

  	<tfoot>
    <tr>
      <td colspan="7"><?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
  	</tfoot>

    </table>
</div>


<input type="hidden" name="option" value="com_bfquiz_plus" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="resultpools" />
<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="randomid" value="<?php echo $randomid ?>" />

</form>