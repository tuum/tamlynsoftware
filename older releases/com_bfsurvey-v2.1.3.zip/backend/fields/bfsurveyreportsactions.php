<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

/**
 * Renders the price of a subscription level and its optional sign-up fee
 */
class F0FFormFieldBFSurveyreportsactions extends F0FFormFieldText
{
	/**
	 * Get the rendering of this field type for a repeatable (grid) display,
	 * e.g. in a view listing many item (typically a "browse" task)
	 *
	 * @return  string  The field HTML
	 */
	public function getRepeatable()
	{
		$html = '';

		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=read&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8') .
			'&tmpl=component" class="btn btn-info modal" rel="{handler: \'iframe\', size: {x: 800, y: 500}}" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_PREVIEW') . '"><span class="icon icon-file icon-white"></span></a>' .
			"\n";
		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=download&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8') .
			'" class="btn btn-primary" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_DOWNLOAD')
			. '"><span class="icon icon-download-alt icon-white"></span></a>' . "\n";
		$html .= '<a href="index.php?option=com_bfsurvey&view=reports&task=read&id=' .
			htmlspecialchars($this->item->bfsurvey_report_id, ENT_COMPAT, 'UTF-8').'&format=csv' .
			'" class="btn btn-success" title="' .
			JText::_('COM_BFSURVEY_REPORTS_ACTION_EXPORT') .
			'"><span class="icon icon-file icon-white"></span></a>'
			. "\n";

		return $html;
	}
}
