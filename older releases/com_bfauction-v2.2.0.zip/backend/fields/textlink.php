<?php
defined('F0F_INCLUDED') or die;

JFormHelper::loadFieldClass('text');

class F0FFormFieldTextlink extends F0FFormFieldText
{
	public function getRepeatable()
	{
		$app = JFactory::getApplication();

		$menu = $app->getMenu()->getActive();

		$html = "<a href='index.php?option=com_bfauction&view=auction&id={$this->item->bfauction_item_id}&Itemid={$menu->id}'>{$this->item->title}</a>";

		return $html;
	}

}

