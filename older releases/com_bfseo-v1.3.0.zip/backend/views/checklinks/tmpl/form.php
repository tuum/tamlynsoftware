<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

$session = JFactory::getSession();
$results = $session->get('results','');
//now clear the session for next time
$session->set('results','');
?>

<div>
	<?php if (isset($results) && $results != ''): ?>

		<h3>Links check of <a href="<?php echo $results['url'] ?>"><?php echo $results['url'] ?></a></h3>

		<table class='table table-bordered checklinks'>

			<?php if (isset($results['pages']) && !empty($results['pages'])): ?>
			<tr>
				<td class='title'>Pages</td>
				<td>
				<?php
				foreach ($results['pages'] as $page) {
					list($status, $url) = explode('|', $page);
					echo "<p><span class='status{$status}'>$status</span>&nbsp;&nbsp;<span><a href='$url'>".htmlspecialchars($url)."</a></span></p>";
				}?>
				</td>
			</tr>
			<?php endif ?>

			<?php if (isset($results['images']) && !empty($results['images'])): ?>
			<tr>
				<td class='title'>Images</td>
				<td>
				<?php
				foreach ($results['images'] as $page) {
					list($status, $url) = explode('|', $page);
					echo "<p><span class='status{$status}'>$status</span>&nbsp;&nbsp;<span><a href='$url'>".htmlspecialchars($url)."</a></span></p>";
				}?>
				</td>
			</tr>
			<?php endif ?>

			<?php if (isset($results['links']) && !empty($results['links'])): ?>
				<tr>
				<td class='title'>Stylesheets</td>
				<td>
				<?php
				foreach ($results['links'] as $page) {
					list($status, $url) = explode('|', $page);
					echo "<p><span class='status{$status}'>$status</span>&nbsp;&nbsp;<span><a href='$url'>".htmlspecialchars($url)."</a></span></p>";
				}?>
				</td>
				</tr>
			<?php endif ?>

			<?php if (isset($results['scripts']) && !empty($results['scripts'])): ?>
				<tr>
				<td class='title'>Scripts</td>
				<td>
				<?php
				foreach ($results['scripts'] as $page) {
					list($status, $url) = explode('|', $page);
					echo "<p><span class='status{$status}'>$status</span>&nbsp;&nbsp;<span><a href='$url'>".htmlspecialchars($url)."</a></span></p>";
				}?>
				</td>
				</tr>
			<?php endif ?>

		</table>

	<?php endif ?>

	<div class="span12">
		<div><span class="status200">200</span> <?php echo JText::_('COM_BFSEO_200'); ?></div>
		<div><span class="status301">301</span> <?php echo JText::_('COM_BFSEO_301'); ?></div>
		<div><span class="status302">302</span> <?php echo JText::_('COM_BFSEO_302'); ?></div>
		<div><span class="status403">403</span> <?php echo JText::_('COM_BFSEO_403'); ?></div>
		<div><span class="status404">404</span> <?php echo JText::_('COM_BFSEO_404'); ?></div>
		<div><span class="status500">500</span> <?php echo JText::_('COM_BFSEO_500'); ?></div>
		<div>&nbsp;</div>
	</div>

	<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfseo"/>
	<input type="hidden" name="view" value="checklinks"/>
	<input type="hidden" name="task" value="check"/>
	<?php echo JHtml::_( 'form.token' ); ?>

	<p><b><?php echo JText::_('COM_BFSEO_SITE_CHECK_DETAIL'); ?></b></p>
	<p><input type='text' id='url' name='url' value='<?php echo JURI::root() ?>' /> <input class='btn btn-warning' type='submit'  value='Check Page' /></p>

</div>