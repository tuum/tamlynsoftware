<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

$session = JFactory::getSession();
$results = $session->get('results','');
//now clear the session for next time
$session->set('results','');

?>

<div>
	<?php if(isset($results) && $results != ''): ?>
		<?php
		$url = $results['url'];
		unset($results['url']);
		$pagetitle = $results['pagetitle'];
		unset($results['pagetitle']);
		?>
		<h3>Page analysis of <a href="<?php echo $url ?>"><?php echo $url ?></a></h3>
		<h3><?php echo $pagetitle; ?></h3>
		<table class='table table-bordered'>
			<?php foreach ($results as $result): ?>
				<tr><?php $status = $result['status'] ? 'success' : 'fail' ?>
					<td id='title'><b><?php echo $result['title'] ?></b></td>
					<td><i class='<?php echo 'bfseo-icon-'.$status ?>'></i><?php echo $result['msg'] ?>
						<?php
						if (isset($result['text'])) {
							$textArray = $result['text'];
							if (is_array($textArray)) {
								foreach ($textArray as $text) {
									echo "<p class='text'><i>&rightarrow; $text</i></p>";
								}
							} else {
								echo "<p class='text'><i>&rightarrow; $textArray</i></p>";
							}
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php endif ?>

	<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfseo"/>
	<input type="hidden" name="view" value="pagecheck"/>
	<input type="hidden" name="task" value="check"/>
	<?php echo JHtml::_( 'form.token' ); ?>
	
	<p><b><?php echo JText::_('COM_BFSEO_SITE_CHECK_DETAIL'); ?></b></p>
	<p><input type='text' id='url' name='url' value='<?php echo JURI::root() ?>' /> <input class='btn btn-warning' type='submit'  value='Check Page' /></p>

</div>