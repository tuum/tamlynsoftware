<?php
/*
 * @package		BF SEO
 * @copyright	Copyright (c)2016 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');

$config = JFactory::getConfig();

$sefCheck = $config->get( 'sef' );
$rewriteCheck = $config->get( 'sef_rewrite' );

jimport( 'joomla.filesystem.file' );
$htaccessCheck = file_exists(JPATH_ROOT. "/.htaccess") ? 1 : 0;

$serverCheck = substr(php_uname(), 0, 7) == 'Windows' ? 0 : 1;

$webconfigCheck = file_exists(JPATH_ROOT. "/web.config") ? 1 : 0;

$suffixCheck = $config->get( 'sef_suffix' );

$metaDescriptionCheck = $config->get( 'MetaDesc' ) == '' ? 1 : 0;

$metaKeywordCheck = $config->get( 'MetaKeys' ) == '' ? 1 : 0;


switch($config->get( 'robots' )){
	case 'noindex, nofollow': 	$robotsCheck = 2;
								break;
	case 'index, nofollow':     $robotsCheck = 3;
								break;
	case 'noindex, follow':     $robotsCheck = 4;
								break;
	default: 					$robotsCheck = 1;
}

?>

<div class="configcheck">
<table>
<thead>
<tr>
	<th><?php echo JText::_('COM_BFSEO_TITLE_CHECK'); ?></th>
	<th><?php echo JText::_('COM_BFSEO_TITLE_DETAILS'); ?></th>
</tr>
</thead>
<tbody>
<tr>
	<td><i class="bfseo-icon-<?php echo $sefCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_SEFCHECK_TITLE'); ?></td>
	<td><?php echo $sefCheck == 1 ? JText::_('COM_BFSEO_SEFCHECK_PASS') : JText::_('COM_BFSEO_SEFCHECK_FAIL'); ?></td>
</tr>
<tr>
	<td><i class="bfseo-icon-<?php echo $rewriteCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_REWRITECHECK_TITLE'); ?></td>
	<td><?php echo $rewriteCheck == 1 ? JText::_('COM_BFSEO_REWRITECHECK_PASS') : JText::_('COM_BFSEO_REWRITECHECK_FAIL'); ?></td>
</tr>
<?php if($serverCheck){ ?>
<tr>
	<td><i class="bfseo-icon-<?php echo $htaccessCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_HTACCESSCHECK_TITLE'); ?></td>
	<td><?php echo $htaccessCheck == 1 ? JText::_('COM_BFSEO_HTACCESSCHECK_PASS') : JText::_('COM_BFSEO_HTACCESSCHECK_FAIL'); ?></td>
</tr>
<?php }else{ ?>
<tr>
	<td><i class="bfseo-icon-<?php echo $webconfigCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_WEBCONFIGCHECK_TITLE'); ?></td>
	<td><?php echo $webconfigCheck == 1 ? JText::_('COM_BFSEO_WEBCONFIGCHECK_PASS') : JText::_('COM_BFSEO_WEBCONFIGCHECK_FAIL'); ?></td>
</tr>
<?php } ?>
<tr>
	<td><i class="bfseo-icon-<?php echo $suffixCheck == 0 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_SUFFIXCHECK_TITLE'); ?></td>
	<td><?php echo $suffixCheck == 0 ? JText::_('COM_BFSEO_SUFFIXCHECK_PASS') : JText::_('COM_BFSEO_SUFFIXCHECK_FAIL'); ?></td>
</tr>
<tr>
	<td><i class="bfseo-icon-<?php echo $metaDescriptionCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_METADESCRIPTIONCHECK_TITLE'); ?></td>
	<td><?php echo $metaDescriptionCheck == 1 ? JText::_('COM_BFSEO_METADESCRIPTIONCHECK_PASS') : JText::_('COM_BFSEO_METADESCRIPTIONCHECK_FAIL'); ?></td>
</tr>
<tr>
	<td><i class="bfseo-icon-<?php echo $metaKeywordCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_METAKEYWORDCHECK_TITLE'); ?></td>
	<td><?php echo $metaKeywordCheck == 1 ? JText::_('COM_BFSEO_METAKEYWORDCHECK_PASS') : JText::_('COM_BFSEO_METAKEYWORDCHECK_FAIL'); ?></td>
</tr>
<tr>
	<td><i class="bfseo-icon-<?php echo $robotsCheck == 1 ? 'success' : 'fail'?>"></i><?php echo JText::_('COM_BFSEO_ROBOTSCHECK_TITLE'); ?></td>
	<td>
	<?php
	switch($robotsCheck){
		case 2: echo JText::_('COM_BFSEO_ROBOTSCHECK_FAIL1');
				break;
		case 3: echo JText::_('COM_BFSEO_ROBOTSCHECK_FAIL2');
				break;
		case 4: echo JText::_('COM_BFSEO_ROBOTSCHECK_FAIL3');
				break;
		default: echo JText::_('COM_BFSEO_ROBOTSCHECK_PASS');
	}
	?>
	</td>
</tr>
</tbody>
</table>
</div>