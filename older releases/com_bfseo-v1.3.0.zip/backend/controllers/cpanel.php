<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 *
 */

defined('_JEXEC') or die();

class BfseoControllerCpanel extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$component = JComponentHelper::getComponent('com_bfseo');
		$dlid = $component->params->get('downloadid', '');

		if (empty($dlid)) return;

		$extra_query = "'dlid=$dlid'";

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->update('#__update_sites')
			->set('extra_query = '.$extra_query)
			->where('name = "BF SEO"');
		$db->setQuery($query);
		$db->execute();

	}

}