<?php
/**
 * @package		bfsurvey
 * @copyright	Copyright (c)2014 Tamlyn Software
 * @license		GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BFSurveyControllerSurvey extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		//this needs to be dynamic based on menu item options
		//$this->modelName = '1results';
		//$this->viewName = '1results';

		$params = JFactory::getApplication()->getParams();
		$slug=$params->get('slug');

		$this->modelName = $slug.'results';
		$this->viewName = $slug.'results';
	}
}