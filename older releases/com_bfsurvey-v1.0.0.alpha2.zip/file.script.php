<?php
/**
 * @package BF Survey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3, or later
 *
 */
defined('_JEXEC') or die();

JLoader::import('joomla.filesystem.folder');
JLoader::import('joomla.filesystem.file');

class Com_BFSurveyInstallerScript
{
	/**
	 * Joomla! pre-flight event
	 *
	 * @param string $type Installation type (install, update, discover_install)
	 * @param JInstaller $parent Parent object
	 */
	public function preflight($type, $parent)
	{
		// Only allow to install on Joomla! 2.5.0 or later with PHP 5.3.0 or later
		if (defined('PHP_VERSION'))
		{
			$version = PHP_VERSION;
		}
		elseif (function_exists('phpversion'))
		{
			$version = phpversion();
		}
		else
		{
			$version = '5.0.0'; // all bets are off!
		}

		if (!version_compare(JVERSION, '2.5.6', 'ge'))
		{
			$msg = "<p>You need Joomla! 2.5.6 or later to install this component</p>";

			JError::raiseWarning(100, $msg);

			return false;
		}

		if (!version_compare($version, '5.3.1', 'ge'))
		{
			$msg = "<p>You need PHP 5.3.1 or later to install this component</p>";

			if (version_compare(JVERSION, '3.0', 'gt'))
			{
				JLog::add($msg, JLog::WARNING, 'jerror');
			}
			else
			{
				JError::raiseWarning(100, $msg);
			}

			return false;
		}

		return true;
	}

	/**
	 * Runs after install, update or discover_update
	 * @param string $type install, update or discover_update
	 * @param JInstaller $parent
	 */
	function postflight($type, $parent)
	{
		// Install FOF
		$fofStatus = $this->_installFOF($parent);

		// Install Akeeba Straper
		$straperStatus = $this->_installStraper($parent);

		// Show the post-installation page
		$this->_renderPostInstallation($fofStatus, $straperStatus);

		// Clear FOF's cache
		if (!defined('FOF_INCLUDED'))
		{
			@include_once JPATH_LIBRARIES . '/fof/include.php';
		}

		if (defined('FOF_INCLUDED'))
		{
			$platform = FOFPlatform::getInstance();
			if (method_exists($platform, 'clearCache'))
			{
				FOFPlatform::getInstance()->clearCache();
			}
		}

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			$table = JTable::getInstance('Contenttype', 'JTable');
			if(!$table->load(array('type_alias' => 'com_bfsurvey.question')))
			{
				$common = new stdClass;
				$common->core_content_item_id = 'bfsurvey_question_id';
				$common->core_title = 'title';
				$common->core_state = 'enabled';
				$common->core_alias = 'slug';
				$common->core_created_time = 'created_on';
				$common->core_modified_time = 'modified_on';
				//$common->core_access = 'access';
				$common->core_ordering = 'ordering';
				$common->core_catid = 'bfsurvey_category_id';
				$common->asset_id = null;
				$field_mappings = new stdClass;
				$field_mappings->common[] = $common;
				$field_mappings->special = array();
				$special = new stdClass;
				$special->dbtable = '#__bfsurvey_questions';
				$special->key = 'bfsurvey_question_id';
				$special->type = 'MyQuestion';
				$special->prefix = 'BFSurveyTable';
				$special->config = 'array()';
				$table_object = new stdClass;
				$table_object->special = $special;
				$contenttype['type_title'] = 'BFSurvey';
				$contenttype['type_alias'] = 'com_bfsurvey.question';
				$contenttype['table'] = json_encode($table_object);
				$contenttype['rules'] = '';
				$contenttype['router'] = 'BFSurveyHelperRoute::getBFSurveyRoute';
				$contenttype['field_mappings'] = json_encode($field_mappings);
				$contenttype['formFile'] = 'administrator\\/components\\/com_bfsurvey\\/views\\/question\\/tmpl\\/form.form.xml';
				$contenttype['hideFields'] = '["locked_by","locked_on"]';
				$contenttype['ignoreChanges'] = '["modified_by", "modified_on", "locked_by","locked_on"]';
				$contenttype['convertToInt'] = '["ordering"]';
				$contenttype['displayLookup'] = '[{"sourceColumn":"bfsurvey_category_id","targetTable":"#__bfsurvey_categories","targetColumn":"bfsurvey_category_id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]';

				$table->save($contenttype);
			}
		}
	}

	/**
	 * Renders the post-installation message
	 */
	private function _renderPostInstallation($fofStatus, $straperStatus)
	{
		?>
			<?php $rows = 1; ?>

			<h2>Welcome to BF Survey!</h2>

			<?php if (!version_compare(PHP_VERSION, '5.3.0', 'ge')): ?>
				<div style="margin: 1em; padding: 1em; background: #ffff00; border: thick solid red; color: black; font-size: 14pt;" id="notfixedperms">
					<h1 style="margin: 1em 0; color: red; font-size: 22pt;">OUTDATED PHP VERSION</h1>
					<p>You are using an outdated version of PHP which is not properly supported by BF Auction Plus. Please upgrade to PHP 5.3 or later as soon as possible. Future versions of BF Survey will not work at all on PHP 5.2.</p>
				</div>
			<?php endif; ?>

			<table class="adminlist table table-striped" width="100%">
				<thead>
					<tr>
						<th class="title" colspan="2">Extension</th>
						<th width="30%">Status</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="3"></td>
					</tr>
				</tfoot>
				<tbody>
					<tr class="row0">
						<td class="key" colspan="2">BF Survey component</td>
						<td><strong style="color: green">Installed</strong></td>
					</tr>
					<tr class="row1">
						<td class="key" colspan="2">
							<strong>Framework on Framework (FOF) <?php echo $fofStatus['version'] ?></strong> [<?php echo $fofStatus['date'] ?>]
						</td>
						<td><strong>
								<span style="color: <?php echo $fofStatus['required'] ? ($fofStatus['installed'] ? 'green' : 'red') : '#660' ?>; font-weight: bold;">
			<?php echo $fofStatus['required'] ? ($fofStatus['installed'] ? 'Installed' : 'Not Installed') : 'Already up-to-date'; ?>
								</span>
							</strong></td>
					</tr>
					<tr class="row0">
						<td class="key" colspan="2">
							<strong>Akeeba Strapper <?php echo $straperStatus['version'] ?></strong> [<?php echo $straperStatus['date'] ?>]
						</td>
						<td><strong>
								<span style="color: <?php echo $straperStatus['required'] ? ($straperStatus['installed'] ? 'green' : 'red') : '#660' ?>; font-weight: bold;">
					<?php echo $straperStatus['required'] ? ($straperStatus['installed'] ? 'Installed' : 'Not Installed') : 'Already up-to-date'; ?>
								</span>
							</strong></td>
					</tr>
				</tbody>
			</table>

			<?php
		}

		private function _installFOF($parent)
		{
			$src = $parent->getParent()->getPath('source');

			// Install the FOF framework
			JLoader::import('joomla.filesystem.folder');
			JLoader::import('joomla.filesystem.file');
			JLoader::import('joomla.utilities.date');
			$source = $src . '/fof';

			if (!defined('JPATH_LIBRARIES'))
			{
				$target = JPATH_ROOT . '/libraries/fof';
			}
			else
			{
				$target = JPATH_LIBRARIES . '/fof';
			}

			$haveToInstallFOF = false;

			if (!JFolder::exists($target))
			{
				$haveToInstallFOF = true;
			}
			else
			{
				$fofVersion = array();

				if (JFile::exists($target . '/version.txt'))
				{
					$rawData				 = JFile::read($target . '/version.txt');
					$info					 = explode("\n", $rawData);
					$fofVersion['installed'] = array(
							'version'	 => trim($info[0]),
							'date'		 => new JDate(trim($info[1]))
					);
				}
				else
				{
					$fofVersion['installed'] = array(
							'version'	 => '0.0',
							'date'		 => new JDate('2011-01-01')
					);
				}

				$rawData				 = JFile::read($source . '/version.txt');
				$info					 = explode("\n", $rawData);

				$fofVersion['package']	 = array(
						'version'	 => trim($info[0]),
						'date'		 => new JDate(trim($info[1]))
				);

				$haveToInstallFOF = $fofVersion['package']['date']->toUNIX() > $fofVersion['installed']['date']->toUNIX();

				// Do not install FOF on Joomla! 3.2.0 beta 1 or later
				if (version_compare(JVERSION, '3.1.999', 'gt'))
				{
					$haveToInstallFOF = false;
				}
			}

			$installedFOF = false;

			if ($haveToInstallFOF)
			{
				$versionSource	 = 'package';
				$installer		 = new JInstaller;
				$installedFOF	 = $installer->install($source);
			}
			else
			{
				$versionSource = 'installed';
			}

			if (!isset($fofVersion))
			{
				$fofVersion = array();

				if (JFile::exists($target . '/version.txt'))
				{
					$rawData				 = JFile::read($target . '/version.txt');
					$info					 = explode("\n", $rawData);
					$fofVersion['installed'] = array(
							'version'	 => trim($info[0]),
							'date'		 => new JDate(trim($info[1]))
					);
				}
				else
				{
					$fofVersion['installed'] = array(
							'version'	 => '0.0',
							'date'		 => new JDate('2011-01-01')
					);
				}

				$rawData				 = JFile::read($source . '/version.txt');
				$info					 = explode("\n", $rawData);

				$fofVersion['package']	 = array(
						'version'	 => trim($info[0]),
						'date'		 => new JDate(trim($info[1]))
				);

				$versionSource			 = 'installed';
			}

			if (!($fofVersion[$versionSource]['date'] instanceof JDate))
			{
				$fofVersion[$versionSource]['date'] = new JDate();
			}

			return array(
					'required'	 => $haveToInstallFOF,
					'installed'	 => $installedFOF,
					'version'	 => $fofVersion[$versionSource]['version'],
					'date'		 => $fofVersion[$versionSource]['date']->format('Y-m-d'),
			);
		}

		private function _installStraper($parent)
		{
			$src = $parent->getParent()->getPath('source');

			// Install the FOF framework
			JLoader::import('joomla.filesystem.folder');
			JLoader::import('joomla.filesystem.file');
			JLoader::import('joomla.utilities.date');
			$source	 = $src . '/strapper';
			$target	 = JPATH_ROOT . '/media/akeeba_strapper';

			$haveToInstallStraper = false;

			if (!JFolder::exists($target))
			{
				$haveToInstallStraper = true;
			}
			else
			{
				$straperVersion = array();

				if (JFile::exists($target . '/version.txt'))
				{
					$rawData					 = JFile::read($target . '/version.txt');
					$info						 = explode("\n", $rawData);
					$straperVersion['installed'] = array(
							'version'	 => trim($info[0]),
							'date'		 => new JDate(trim($info[1]))
					);
				}
				else
				{
					$straperVersion['installed'] = array(
							'version'	 => '0.0',
							'date'		 => new JDate('2011-01-01')
					);
				}

				$rawData					 = JFile::read($source . '/version.txt');
				$info						 = explode("\n", $rawData);
				$straperVersion['package']	 = array(
						'version'	 => trim($info[0]),
						'date'		 => new JDate(trim($info[1]))
				);

				$haveToInstallStraper = $straperVersion['package']['date']->toUNIX() > $straperVersion['installed']['date']->toUNIX();
			}

			$installedStraper = false;

			if ($haveToInstallStraper)
			{
				$versionSource		 = 'package';
				$installer			 = new JInstaller;
				$installedStraper	 = $installer->install($source);
			}
			else
			{
				$versionSource = 'installed';
			}

			if (!isset($straperVersion))
			{
				$straperVersion = array();

				if (JFile::exists($target . '/version.txt'))
				{
					$rawData					 = JFile::read($target . '/version.txt');
					$info						 = explode("\n", $rawData);
					$straperVersion['installed'] = array(
							'version'	 => trim($info[0]),
							'date'		 => new JDate(trim($info[1]))
					);
				}
				else
				{
					$straperVersion['installed'] = array(
							'version'	 => '0.0',
							'date'		 => new JDate('2011-01-01')
					);
				}
				$rawData					 = JFile::read($source . '/version.txt');
				$info						 = explode("\n", $rawData);
				$straperVersion['package']	 = array(
						'version'	 => trim($info[0]),
						'date'		 => new JDate(trim($info[1]))
				);
				$versionSource				 = 'installed';
			}

			if (!($straperVersion[$versionSource]['date'] instanceof JDate))
			{
				$straperVersion[$versionSource]['date'] = new JDate();
			}

			return array(
					'required'	 => $haveToInstallStraper,
					'installed'	 => $installedStraper,
					'version'	 => $straperVersion[$versionSource]['version'],
					'date'		 => $straperVersion[$versionSource]['date']->format('Y-m-d'),
			);
		}
}