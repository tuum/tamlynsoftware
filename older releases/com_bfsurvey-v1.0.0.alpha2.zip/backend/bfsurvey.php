<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();
global $bfsurvey_version;
$bfsurvey_version =  '1.0.0 Alpha2';

// Load FOF
if (!defined('FOF_INCLUDED'))
{
	include_once JPATH_LIBRARIES . '/fof/include.php';
}
if(!defined('FOF_INCLUDED')) {
	JError::raiseError ('500', 'FOF is not installed');
}

FOFDispatcher::getTmpInstance('com_bfsurvey')->dispatch();