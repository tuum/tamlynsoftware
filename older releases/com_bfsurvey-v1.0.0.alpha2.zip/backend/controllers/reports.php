<?php

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyControllerReports extends FOFController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->cacheableTasks = array();
	}

	public function execute($task) {
		if(!in_array($task, array('fields')));
		parent::execute($task);
	}

	function fields()
	{
		// Initialize variables.
		$options = array();
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$id=JRequest::getInt('id', 0);

		$table = '#__bfsurvey_'.(int)$id.'results';

		// Grab the fields for the selected table
		$fields = $db->getTableColumns( $table, true );
		if(!$fields){
			JError::raiseWarning( 500, JText::_('COM_BFSURVEY_ERROR_NO_ANSWER_TABLE') );
		}else{
			if( sizeof( $fields ) ) {
				// We found some fields so let's create the list
				foreach( $fields as $field => $type ) {
					$options[] = $field;
				}
			}
		}

		echo json_encode($options);
	}

	public function download($cachable = false, $urlparams = false)
	{
		// Load the model
		$model = $this->getThisModel();
		if(!$model->getId()) $model->setIDsFromRequest();

		// Make sure we have a valid item
		$item = $model->getItem();
		if (!is_object($item) || empty($item->bfsurvey_report_id))
		{
			return false;
		}

		// Check that this is the item's owner or an administrator
		//$user = JFactory::getUser();
		//$sub = FOFModel::getTmpInstance('Subscriptions', 'BFSurveyModel')->getItem($item->bfsurvey_report_id);
		//if (!$this->checkACL('core.manage') && ($sub->user_id != $user->id))
		//{
		//	return false;
		//}

		// Make sure we have a PDF file or try to generate one
		JLoader::import('joomla.filesystem.file');
		$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';
		$filename = $item->filename;

		if(!JFile::exists($path . $filename))
		{
			$id = JRequest::getVar( 'id', 0, '', 'int' );
			$reportDetails = $model->getReport($id);
			$report = $model->createReport($reportDetails);

			$filename = $model->createPDF($reportDetails[0], $report);
			if ($filename == false)
			{
				return false;
			}
		}

		// Clear any existing data
		while (@ob_end_clean());

		//$basename = 'report_' . $item->bfsurvey_report_id;
		$basename = preg_replace('/\s+/', '', $item->title) . '.pdf';

		// Add extension
		//$basename .= '.pdf';

		if (isset($_SERVER['HTTP_USER_AGENT']) && strstr($_SERVER['HTTP_USER_AGENT'], 'MSIE')) {
			$header_file = preg_replace('/\./', '%2e', $filename, substr_count($basename, '.') - 1);

			if (ini_get('zlib.output_compression'))  {
				ini_set('zlib.output_compression', 'Off');
			}
		}
		else {
			$header_file = $basename;
		}

		// Get the PDF file's data
		@clearstatcache();
		$fileData = JFile::read($path . $filename);

		// Disable caching
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: public", false);

		// Send MIME headers
		header("Content-Description: File Transfer");
		header('Content-Type: application/pdf');
		header("Accept-Ranges: bytes");
		header('Content-Disposition: attachment; filename="'.$header_file.'"');
		header('Content-Transfer-Encoding: binary');
		header('Connection: close');

		error_reporting(0);
		if ( ! ini_get('safe_mode') ) {
			set_time_limit(0);
		}

		echo $fileData;

		JFactory::getApplication()->close();
	}

	public function generate($cachable = false, $urlparams = false)
	{
		// Load the model
		$model = $this->getThisModel();
		if(!$model->getId()) $model->setIDsFromRequest();

		// Make sure we have a valid item
		$item = $model->getItem();
		if (!is_object($item) || empty($item->bfsurvey_report_id))
		{
			return false;
		}

		// Check that this is an administrator
		if (!$this->checkACL('core.manage'))
		{
			return false;
		}

		// (Re-)generate the report
		$id = JRequest::getVar( 'id', 0, '', 'int' );
		$reportDetails = $model->getReport($id);
		$report = $model->createReport($reportDetails);

		//$status = ($model->createInvoice($sub) === true);
		$status = $model->createPDF($reportDetails[0], $report);

		// Post-action redirection
		if($customURL = $this->input->get('returnurl','','string')) $customURL = base64_decode($customURL);
		$url = !empty($customURL) ? $customURL : 'index.php?option='.$this->component.'&view='.FOFInflector::pluralize($this->view);

		if($status === false)
		{
			$this->setRedirect($url, JText::_('COM_BFSURVEY_REPORTS_MSG_NOTGENERATED'), 'error');
		} else {
			$this->setRedirect($url, JText::_('COM_BFSURVEY_REPORTS_MSG_GENERATED') );
		}
	}
}