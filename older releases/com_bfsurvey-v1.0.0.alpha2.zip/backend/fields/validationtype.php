<?php
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class
 */
class JFormFieldvalidationtype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'validationtype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

        		$options[] = JHtml::_('select.option',  'required', JText::_( 'required' ) );
				$options[] = JHtml::_('select.option',  'required validate-numeric', JText::_( 'required validate-numeric' ) );
				$options[] = JHtml::_('select.option',  'required validate-email', JText::_( 'required validate-email' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
