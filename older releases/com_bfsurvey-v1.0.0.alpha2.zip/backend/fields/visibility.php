<?php
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Visibility Form Field class
 */
class JFormFieldVisibility extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'parent';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        // Initialize variables.
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$id = $this->form->getValue('bfsurvey_question_id');

		$query->select('a.bfsurvey_question_id AS value, a.title AS text');
		$query->from('#__bfsurvey_questions AS a');
		$query->where('a.bfsurvey_question_id<>'.(int) $id);
		$query->where('a.enabled=1');
		$query->order('a.parent, a.ordering');

		// Get the options.
		$db->setQuery($query);

		$options = $db->loadObjectList();

		// Check for a database error.
		if ($db->getErrorNum()) {
			JError::raiseWarning(500, $db->getErrorMsg());
		}

       	// Pad the option text with spaces using depth level as a multiplier.
		for ($i = 0, $n = count($options); $i < $n; $i++) {
			$options[$i]->text = '- '.$options[$i]->text;
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}