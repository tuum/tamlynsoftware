<?php
defined('_JEXEC') or die;

class answerTable
{
	public static function getCategory()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('a.bfsurvey_category_id AS id, a.title, '
						.'a.surveyTitle, a.showTabs, a.introText, a.use_captcha, '
						.'a.showName, a.showCompany, a.showEmail, '
						.'a.nameText, a.companyText, a.emailText, a.submitText, '
						.'a.anonymous, a.anonymousText, a.anonymousYes, a.anonymousNo');
		$query->from($db->quoteName('#__bfsurvey_categories').' AS a');
		$query->where('a.enabled');
		$query->order('a.title');

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		return $result;
	}

	static function buildAnswerTables()
	{
		$somethingChanged=0;

		$db = JFactory::getDBO();
		$app = JFactory::getApplication();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('*');
		$query->where('enabled = 1');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		//exit if there are no questions yet
		if(!count($myitems)){
			return;
		}

		$mycategory = answerTable::getCategory();
		$db = JFactory::getDBO();
		$database = JFactory::getDBO();
		$app = JFactory::getApplication();

		if( sizeof( $mycategory ) )
		{

			foreach( $mycategory as $mycat  )
			{
				$myid = $mycat->id;
				$table="#__bfsurvey_".$myid."results";

				$result = $database->getTableList();
				if (!in_array($app->getCfg('dbprefix')."bfsurvey_".$myid."results", $result))
				{
					for ($i=0, $n=count( $myitems ); $i < $n; $i++)
					{
						$found=0;
						$row = &$myitems[$i];

						$myFieldsMissing="";
						if($row->bfsurvey_category_id == $myid)
						{
							$myFieldsMissing.= "`".$row->field_name."` TEXT,";
						}
					}

					$query="CREATE TABLE `".$table."` (
		  			    `bfsurvey_".$myid."result_id` int(11) NOT NULL auto_increment,
			      		`Name` varchar(150) default NULL,
		  			    `Company` varchar(150) default NULL,
			      		`Email` varchar(150) default NULL,
						`enabled` tinyint(3) NOT NULL DEFAULT '1',
						`ordering` int(10) NOT NULL DEFAULT '0',
  						`created_by` bigint(20) NOT NULL DEFAULT '0',
  						`created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  						`modified_by` bigint(20) NOT NULL DEFAULT '0',
  						`modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  						`locked_by` bigint(20) NOT NULL DEFAULT '0',
  						`locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		      			`ip` varchar(50) default NULL,
		  			    `status` varchar(150) default NULL,
		  				".$myFieldsMissing."
			  		    		PRIMARY KEY  (`bfsurvey_".$myid."result_id`)
			    	);";

					$db->setQuery( $query );
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}
				}
				else
				{
					//table already exists

					$db = JFactory::getDBO();
					// Grab the fields for the selected table
					$fields = $db->getTableColumns( $table, true );

					if( sizeof( $fields ) )
					{
						// We found some fields so let's create the HTML list
						$options = array();
						foreach( $fields as $field => $type )
						{
							$options[] = JHTML::_( 'select.option', $field, $field );
						}

						//what type of field, eg VARCHAR, INT, DATETIME etc.
						$fieldType=array();
						foreach( $fields as $field )
						{
							$fieldType[] = $field;
						}
					}

					for ($i=0, $n=count( $myitems ); $i < $n; $i++)
					{
						$found=0;
						$row = &$myitems[$i];
						$myindex=0;
						foreach( $fields as $field => $type )
						{
							if ($row->field_name == $field)
							{
								$found=1;
							}

							if($found==0)
							{
								$myindex++;
							}
						}

						if($found == 1)
						{
							if(strtoupper($row->field_type) == strtoupper($fieldType[$myindex]) | $row->field_type=="")
							{
								//do nothing
							}
							else
							{
								$mytype = $row->field_type;
								if(strtoupper($row->field_type) == "VARCHAR" | $row->field_type == "INT")
								{
									if($row->fieldSize=='')
									{
										$row->fieldSize = 10;
									}
									$mytype = $row->field_type."(".$row->fieldSize.")";
								}
								$query="ALTER TABLE `".$table."` CHANGE `".$row->field_name."` `".$row->field_name."` ".$mytype.";";
								//Field type has changed
								$db->setQuery( $query );
								if (!$db->query())
								{
									echo $db->getErrorMsg();
									return false;
								}
								$somethingChanged=1;
							}
						}

						if($found == 0 & $row->bfsurvey_category_id == $myid)
						{
							//Need to add field
							$query="ALTER TABLE `".$table."`
								ADD `".$row->field_name."` TEXT
								;";

							$db->setQuery( $query );
							if (!$db->query())
							{
								echo $db->getErrorMsg();
								return false;
							}
							$somethingChanged=1;
						}
					}
				}
			}
		}

		//debug, force somethingChanged to be always true
		$params = JComponentHelper::getParams('com_bfsurvey');
		$debug = $params->get('debug');

		if($debug){
			$somethingChanged=1;
		}

		if(JRequest::getVar( 'view' ) == 'categories'){
			$somethingChanged=1;
		}

		//end debug
		answerTable::createViewFiles($somethingChanged);
	}

	static function createViewFiles($somethingChanged)
	{
		// This function creates the files required for the dynamic form
		$mycategory = answerTable::getCategory();

		jimport( 'joomla.filesystem.file' );
		$alert='';

		if( sizeof( $mycategory ) )
		{
			foreach( $mycategory as $mycat  )
			{
				$myview=(int)$mycat->id."result";
				$myviews=(int)$mycat->id."results";
				$buffer='';

				//========== backend ===================

				//edit view
				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myview."/")){
					JFolder::create(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/");
					$alert.="Creating folder ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/index.html");
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/index.html<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myview."/skip.xml")){
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/skip.xml", $buffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/skip.xml<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myview."/tmpl/")){
					JFolder::create(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/");
					$alert.="Creating folder ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/index.html");
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/index.html<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.form.xml")){
						JFile::delete(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.form.xml");
					}
				}
				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.form.xml")){
					$mybuffer = answerTable::dynamicForm((int)$mycat->id, $mycat);
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.form.xml", $mybuffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.form.xml<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.php")){
						JFile::delete(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.php");
					}
				}
				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.php")){
					$mybuffer = answerTable::createTabbedForm((int)$mycat->id, $mycat->surveyTitle, $mycat->showTabs, $mycat->introText);
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.php", $mybuffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myview."/tmpl/form.php<br>";
				}

				//list view

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myviews."/")){
					JFolder::create(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/");
					$alert.="Creating folder ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/index.html");
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/index.html<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myviews."/skip.xml")){
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/skip.xml", $buffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/skip.xml<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/views/".$myviews."/tmpl/")){
					JFolder::create(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/");
					$alert.="Creating folder ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/index.html");
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/index.html<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/form.default.xml")){
						JFile::delete(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/form.default.xml");
					}
				}
				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/form.default.xml")){
					$mybuffer = answerTable::dynamicList((int)$mycat->id);
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/form.default.xml", $mybuffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/views/".$myviews."/tmpl/form.default.xml<br>";
				}

				if(!file_exists(JPATH_COMPONENT_ADMINISTRATOR . "/tables/my".(int)$mycat->id."result.php")){
					$mybuffer = answerTable::createTable((int)$mycat->id);
					JFile::write(JPATH_COMPONENT_ADMINISTRATOR. "/tables/my".(int)$mycat->id."result.php", $mybuffer);
					$alert.="Creating file ".JPATH_COMPONENT_ADMINISTRATOR. "/tables/my".(int)$mycat->id."result.php<br>";
				}

				//========== end backend ===============

				//========== frontend ===================

				//edit view
				if(!file_exists(JPATH_SITE . "/components/com_bfsurvey/views/".$myview."/")){
					JFolder::create(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/");
					$alert.="Creating folder ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/index.html");
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/index.html<br>";
				}

				if(!file_exists(JPATH_SITE . "/components/com_bfsurvey/views/".$myview."/tmpl/")){
					JFolder::create(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/");
					$alert.="Creating folder ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/index.html");
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/index.html<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.form.xml")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.form.xml");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.form.xml")){
					$mybuffer = answerTable::dynamicForm((int)$mycat->id, $mycat);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.form.xml", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.form.xml<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.php")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.php");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.php")){
					$mybuffer = answerTable::createTabbedForm((int)$mycat->id, $mycat->surveyTitle, $mycat->showTabs, $mycat->introText);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.php", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/tmpl/form.php<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/metadata.xml")){
					$mybuffer = answerTable::dynamicMetadata((int)$mycat->id);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/metadata.xml", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myview."/metadata.xml<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/controllers/".$myviews.".php")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/controllers/".$myviews.".php");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/controllers/".$myviews.".php")){
					$mybuffer = answerTable::createController((int)$mycat->id);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/controllers/".$myviews.".php", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/controllers/".$myviews.".php<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/models/".$myviews.".php")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/models/".$myviews.".php");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/models/".$myviews.".php")){
					$mybuffer = answerTable::createModel((int)$mycat->id, $mycat);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/models/".$myviews.".php", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/models/".$myviews.".php<br>";
				}

				//list view
				if(!file_exists(JPATH_SITE . "/components/com_bfsurvey/views/".$myviews."/")){
					JFolder::create(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/");
					$alert.="Creating folder ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/index.html");
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/index.html<br>";
				}

				if(!file_exists(JPATH_SITE . "/components/com_bfsurvey/views/".$myviews."/tmpl/")){
					JFolder::create(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/");
					$alert.="Creating folder ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/index.html")){
					JFile::copy(JPATH_COMPONENT_ADMINISTRATOR."/views/question/index.html",JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/index.html");
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/index.html<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/form.default.xml")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/form.default.xml");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/form.default.xml")){
					$mybuffer = answerTable::dynamicList((int)$mycat->id);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/form.default.xml", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/form.default.xml<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/default.php")){
						JFile::delete(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/default.php");
					}
				}
				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/default.php")){
					$mybuffer = answerTable::createResultsForm((int)$mycat->id);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/default.php", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/tmpl/default.php<br>";
				}

				if(!file_exists(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/metadata.xml")){
					$mybuffer = answerTable::dynamicListMetadata((int)$mycat->id);
					JFile::write(JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/metadata.xml", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/components/com_bfsurvey/views/".$myviews."/metadata.xml<br>";
				}

				if($somethingChanged){
					if(file_exists(JPATH_SITE. "/media/com_bfsurvey/js/".(int)$mycat->id."result.js")){
						JFile::delete(JPATH_SITE. "/media/com_bfsurvey/js/".(int)$mycat->id."result.js");
					}
				}
				if(!file_exists(JPATH_SITE. "/media/com_bfsurvey/js/".(int)$mycat->id."result.js")){
					$mybuffer = answerTable::dynamicJavascript((int)$mycat->id, $mycat);
					JFile::write(JPATH_SITE. "/media/com_bfsurvey/js/".(int)$mycat->id."result.js", $mybuffer);
					$alert.="Creating file ".JPATH_SITE. "/media/com_bfsurvey/js/".(int)$mycat->id."result.js<br>";
				}
				//========== end frontend ===============
			}
		}

		$params = JComponentHelper::getParams('com_bfsurvey');
		$debug = $params->get('debug');

		if($alert && $debug){
		?>
		<div class="span12">
			<div class="alert alert-info">
			<a class="close" data-dismiss="alert" href="#">×</a>
				<p><?php echo JText::_($alert); ?></p>
			</div>
		</div>
		<?php
		}
	}



	public static function dynamicForm($catid, &$mycat){
		$db = JFactory::getDBO();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->where('bfsurvey_category_id = '.(int)$catid);
		$query->order('ordering');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		//================= reorder =============================
		// establish the hierarchy of the questions
		$children = array();
		// first pass - collect children
		foreach ($myitems as $v )
		{
			//get the parent id
			$pt = $v->parent;
			// @ symbol tests to see if $children[parentid] is blank
			// ? ternary operator if first part is true, then $children[$pt] otherwise array()
			$list = @$children[$pt] ? $children[$pt] : array();
			//add current row element to the bottom of list array
			array_push( $list, $v );
			$children[$pt] = $list;
		}

		//second pass - reorder elements
		$mylist = array();
		foreach ($myitems as $v )
		{
			if($v->parent==0){
				array_push($mylist, $v);

				//now are there any children
				if(isset($children[$v->bfsurvey_question_id])){
					foreach ($children[$v->bfsurvey_question_id] as $c ){
						array_push($mylist, $c);
					}
				}
			}
		}
		$myitems=$mylist;
		//================= end reorder =============================



		$app = JFactory::getApplication();
		$page=1;

		// we'll generate XML output
		//header('Content-Type: text/xml');
		// generate XML header
		$return = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>
";
		$return .= '<form
	jsfiles="media://com_bfsurvey/js/mobile.js"
	enctype="multipart/form-data"
>
	';
		$return .= '<fieldset name="Details">
		';

		$return .= answerTable::createStandardFields($catid, $mycat);

		foreach($myitems as $item)
		{
			if($item->parent==0){
				$page++;
				if($page > 1){
					$return .= '
	</fieldset>
';
					if($item->question_type=="10")		// heading question type, use for label of tab
					{
						$return .= '	<fieldset name="'.$item->title.'">

		';
					}
					else
					{
						$return .= '	<fieldset name="page'.$page.'">

		';
					}
				}
			}
			$return .= answerTable::createField($item);
		}

		$return .= '
	</fieldset>
';

		$return .= '</form>';

		return $return;
	}

	public static function createStandardFields($catid, &$mycat)
	{
		$k       = 'bfsurvey_'.(int)$catid.'result_id';
		$use_captcha = $mycat->use_captcha;
		$showName = $mycat->showName;
		$nameText = $mycat->nameText;
		if($nameText==''){
			$nameText='COM_BFSURVEY_TITLE_NAME';
		}
		$showCompany = $mycat->showCompany;
		$companyText = $mycat->companyText;
		if($companyText==''){
			$companyText='COM_BFSURVEY_TITLE_COMPANY';
		}
		$showEmail = $mycat->showEmail;
		$emailText = $mycat->emailText;
		if($emailText==''){
			$emailText='JGLOBAL_EMAIL';
		}
		$anonymous = $mycat->anonymous;
		$anonymousText = $mycat->anonymousText;
		if($anonymousText==''){
			$anonymousText='COM_BFSURVEY_CATEGORIES_FIELD_ANONYMOUS_TEXT_DEFAULT';
		}
		$anonymousYes = $mycat->anonymousYes;
		if($anonymousYes==''){
			$anonymousYes = 'JYES';
		}
		$anonymousNo = $mycat->anonymousNo;
		if($anonymousNo==''){
			$anonymousNo = 'JNO';
		}

		$fieldCode = '
		<field name="'.$k.'" type="hidden" default="0" label="JGLOBAL_FIELD_ID_LABEL"
			readonly="true" class="readonly"
			description="JGLOBAL_FIELD_ID_DESC"
			/>
';
		if($anonymous){
			$fieldCode.='
		<field name="anonymous" type="radio"
     		label="'.$anonymousText.'"
     		class="btn-group"
     		default="0"
     		>
				<option value="1">'.$anonymousYes.'</option>
				<option value="0">'.$anonymousNo.'</option>
     	</field>
			';
		}

		if($showName){
			$fieldCode.='
		<field name="Name" type="text"
			class="inputbox"
			label="'.$nameText.'"
			labelclass="bfsurvey-label bfsurvey-label-main"
			required="true"
			size="30"
		 />';
		}

		if($showCompany){
			$fieldCode.='
		<field name="Company" type="text"
			class="inputbox"
			label="'.$companyText.'"
			labelclass="bfsurvey-label bfsurvey-label-main"
			required="true"
			size="30"
		/>';
		}

		if($showEmail){
			$fieldCode.='
		<field name="Email" type="email"
			class="inputbox"
			label="'.$emailText.'"
			required="true"
			size="30"
			validate="email"
		/>';
		}

		$fieldCode.='
		<field
			name="enabled"
			type="hidden"
			label="JSTATUS"
			description="JFIELD_PUBLISHED_DESC"
			class="inputbox"
			size="1"
			default="1">
			<option
				value="1">JPUBLISHED</option>
			<option
				value="0">JUNPUBLISHED</option>
			<option
				value="2">JARCHIVED</option>
			<option
				value="-2">JTRASH</option>
		</field>
	';

		if($use_captcha == 1)
		{
			$fieldCode.='
		<field
			name="captcha"
			type="captcha"
			label="COM_BFSURVEY_CAPTCHA_LABEL"
			validate="captcha"
			namespace="bfsurvey"
		/>
	';
		}

		return $fieldCode;
	}

	public static function createField($item)
	{
		$fieldCode = '';
		$required=$item->mandatory?"true":"false";
		$label=$item->suppressQuestion?"hidden":$item->title;

		switch($item->question_type)
		{
			case "0": //text
				$fieldCode = '<field
			name="'.$item->field_name.'"
			type="text" default="'.$item->default_value.'"
			label="'.$label.'"
			required="'.$required.'"
			description="'.htmlspecialchars($item->helpText).'"';
			if($item->fieldSize < 100)
			{
				$fieldCode .='
				size="'.$item->fieldSize.'"';
			}
			if($item->myclass)
			{
				$fieldCode .='
			class="'.$item->myclass.'"';
			}
			$fieldCode .='
		/>

		';
				break;
			case "1": //radio
				$type="radio";
				//do any of the options contain _OTHER_, if so change the type to radioother
				for($i=1; $i < 21; $i++)
				{
					$option = "option".$i;
					$myoption = htmlspecialchars($item->$option);
					if($myoption)
					{
						if($myoption == "_OTHER_")
						{
							$type="radioother";
						}
					}
				}

				$myclass = $item->horizontal?"btn-group":"btn-group-vertical";
				$fieldCode = '<field
			name="'.$item->field_name.'"
			type="'.$type.'"
			default="'.$item->default_value.'"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
			class="'.$myclass.'"
			required="'.$required.'">';
				for($i=1; $i < 21; $i++)
				{
					$option = "option".$i;
					$myoption = htmlspecialchars($item->$option);
					if($myoption)
					{
						if($myoption == "_OTHER_")
						{
							$fieldCode .='
					<option value="'.$myoption.'" otherprefix="'.$item->otherprefix.'" othersuffix="'.$item->othersuffix.'">'.$myoption.'</option>';
						}
						else
						{
							$fieldCode .='
					<option value="'.$myoption.'">'.$myoption.'</option>';
						}
					}
				}
				$fieldCode .= '
		</field>

		';
				break;
			case "2": //checkbox
				$type="checkboxes";
				//do any of the options contain _OTHER_, if so change the type to checkboxesother
				for($i=1; $i < 21; $i++)
				{
					$option = "option".$i;
					$myoption = htmlspecialchars($item->$option);
					if($myoption)
					{
						if($myoption == "_OTHER_")
						{
							$type="checkboxesother";
						}
					}
				}

				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="'.$type.'"
			class="inputbox btnchk-group"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
			value="true" filter="boolean">';
				for($i=1; $i < 21; $i++)
				{
					$option = "option".$i;
					$myoption = $item->$option;
					if($myoption)
					{
						if($myoption == "_OTHER_")
						{
							$fieldCode .='
					<option value="'.$myoption.'" otherprefix="'.$item->otherprefix.'" othersuffix="'.$item->othersuffix.'">'.$myoption.'</option>';
						}
						else
						{
							$fieldCode .='
					<option value="'.$myoption.'">'.$myoption.'</option>';
						}
					}
				}
				$fieldCode .= '
		</field>

		';
				break;
			case "3": //textarea
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="textarea"
			class="inputbox"
			rows="3"
			cols="30"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
		/>

		';
				break;
			case "4": //Attachment
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="file"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
			size="20"
		/>

		';
				break;
			case "5": //Date
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="calendar"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
			class="inputbox"
			size="22"
			format="%Y-%m-%d"
			filter="user_utc"
		/>

		';
				break;
			case "6": //Dropdown
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="list"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"';
			if($item->myclass)
			{
				$fieldCode .='
			class="'.$item->myclass.'"';
			}
			$fieldCode .='
		>
		';
				for($i=1; $i < 21; $i++)
				{
					$option = "option".$i;
					$myoption	= explode("|", $item->$option);
					if(count($myoption)==1){
						$myoption[1]=$myoption[0];
					}
					if($myoption[0])
					{
						$fieldCode .='
				<option value="'.$myoption[1].'">'.$myoption[0].'</option>';
					}
				}
				$fieldCode .= '
		</field>

		';
				break;
			case "7": //Userlist
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="list"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
		>
			';

				$fieldCode .='<option value="0"> - </option>';
				$db = JFactory::getDBO();

				$query	= $db->getQuery(true);
				$query->from($db->quoteName('#__users'));
				$query->select('id, name');
				$query->where('block = 0');
				$db->setQuery((string)$query);
				$myitems = $db->loadObjectList();

				foreach($myitems as $myitem)
				{
					$fieldCode .='
				<option value="'.$myitem->id.'">'.$myitem->name.'</option>';
				}
				$fieldCode .= '
		</field>

		';
				break;
			case "12": //URL
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="url"
			class="inputbox"
			filter="url"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
			required="'.$required.'"
			validate="url"
		/>

		';
				break;
			case "10": //heading - be aware that note field type is only available in Joomla 3.1 or greater
				$fieldCode ='<field
			name="'.$item->field_name.'"
			type="note"
			label="'.$label.'"
			description="'.htmlspecialchars($item->helpText).'"
		/>

		';
				break;
			case "11": //SQL
				$fieldCode = '<field
			name="'.$item->field_name.'"
			type="sql" default="'.$item->default_value.'"
			label="'.$label.'"
			required="'.$required.'"
			description="'.htmlspecialchars($item->helpText).'"
			query="'.$item->sql.'"
			key_field="'.$item->key_field.'"
			value_field="'.$item->value_field.'"';
			if($item->myclass)
			{
				$fieldCode .='
			class="'.$item->myclass.'"';
			}
			if($item->titles=="multiple"){
				$fieldCode .='
			multiple="multiple"';
			}
			$fieldCode .='
		>
			<option value="0">Please Select</option>
		</field>

		';
					break;
			default:
				return null;
				break;
		}

		return $fieldCode;
	}

	public static function dynamicList($catid){
		// we'll generate XML output

		$return = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>
";
		$return .= '<form
	lessfiles="media://com_bfsurvey/css/backend.less||media://com_bfsurvey/css/backend.css"
	type="browse"
	show_header="1"
	show_filters="0"
	show_pagination="1"
	norows_placeholder="COM_BFSURVEY_COMMON_NORECORDS"
>
	';

		$return.= '<headerset>
		<header name="ordering" type="ordering" sortable="true" tdwidth="1%" />
		<header name="bfsurvey_'.(int)$catid.'result_id" type="rowselect" tdwidth="20" />
		<header name="enabled" type="published" sortable="true" tdwidth="8%" />
		<header name="Req #" tdwidth="20" />
		<header name="Name" type="fieldsearchable" sortable="true"
			buttons="yes" buttonclass="btn"
		/>
		<header name="Date" type="field" sortable="true" tdwidth="12%" />

	</headerset>
';

		$return .= '	<fieldset name="items">
		<field name="ordering" type="ordering" labelclass="order"/>

		<field name="id" value="bfsurvey_'.(int)$catid.'result_id" type="selectrow"/>

		<field name="enabled" type="published"/>

		<field name="bfsurvey_'.(int)$catid.'result_id" type="sql"
			translate="false" query="SELECT *, CONCAT( \'#\', LPAD( `bfsurvey_'.(int)$catid.'result_id` , 4, \'0\' ) ) AS myid FROM #__bfsurvey_'.(int)$catid.'results"
			key_field="bfsurvey_'.(int)$catid.'result_id" value_field="myid"
		/>

		<field name="Name" type="text"
			show_link="true"
			url="index.php?option=com_bfsurvey&amp;view='.(int)$catid.'result&amp;layout=form&amp;id=[ITEM:ID]"
			class="bfsurveyquestion"
			empty_replacement="(no title)"
		 />

		<field name="created_on" type="date" />
	';

		$return .= '</fieldset>
';
		$return .= '</form>';

		return $return;
	}

	public static function dynamicMetadata($catid){

	$return = '<?xml version="1.0" encoding="utf-8"?>
<metadata>
    <view title="'.(int)$catid.'result" hidden="true">
        <options>
            <default name="COM_BFSURVEY_MENU_'.(int)$catid.'RESULT" msg="COM_BFSURVEY_MENU_'.(int)$catid.'RESULT_DESC" />
        </options>
    </view>
</metadata>';

		return $return;
	}

	public static function dynamicListMetadata($catid){

		$return = '<?xml version="1.0" encoding="utf-8"?>
<metadata>
    <view title="'.(int)$catid.'results" hidden="true">
        <options>
			<default name="COM_BFSURVEY_MENU_'.(int)$catid.'RESULTS" msg="COM_BFSURVEY_MENU_'.(int)$catid.'RESULTS_DESC" />
        </options>
    </view>
</metadata>';

		return $return;
	}

	public static function dynamicJavascript($catid, &$mycat){
		// we'll generate XML output
		$return="(function($)
{
	$(document).ready(function()
	{
";

		if($mycat->anonymous)
		{
			//standard javascript for anonymous
			$return.="
		$('label').click(function(event) {
			if(document.id('anonymous0').checked==true) {
				el1 = document.getElementById('Name');

				if(el1){
	      				el1.removeClass('invalid');
				      	el1.set('aria-invalid', 'false');
				      	el1.set('aria-required', 'false');
				      	el1.removeAttribute('required');

					if (el1.labelref) {
						document.id(el1.labelref).removeClass('invalid');
						document.id(el1.labelref).set('aria-invalid', 'false');
					}
				}
				document.id('Name-lbl').parentNode.parentNode.style.display = 'none';

				el2 = document.getElementById('Company');

				if(el2){
	      				el2.removeClass('invalid');
				      	el2.set('aria-invalid', 'false');
				      	el2.set('aria-required', 'false');
				      	el2.removeAttribute('required');

					if (el2.labelref) {
						document.id(el2.labelref).removeClass('invalid');
						document.id(el2.labelref).set('aria-invalid', 'false');
					}
				}
				document.id('Company-lbl').parentNode.parentNode.style.display = 'none';

				el3 = document.getElementById('Email');

				if(el3){
	      				el3.removeClass('invalid');
				      	el3.set('aria-invalid', 'false');
				      	el3.set('aria-required', 'false');
				      	el3.removeAttribute('required');

					if (el3.labelref) {
						document.id(el3.labelref).removeClass('invalid');
						document.id(el3.labelref).set('aria-invalid', 'false');
					}
				}
				document.id('Email-lbl').parentNode.parentNode.style.display = 'none';

			}else{
				el1 = document.getElementById('Name');
				el1.addClass('invalid');
				el1.set('aria-invalid', 'true');
				el1.set('aria-required', 'true');
				if (el1.labelref) {
					document.id(el1.labelref).addClass('invalid');
					document.id(el1.labelref).set('aria-invalid', 'true');
				}

				document.getElementById('Name').className = 'required';
				document.getElementById('Name').set('required', 'required');
				document.id('Name-lbl').parentNode.parentNode.style.display = '';

				el2 = document.getElementById('Company');
				el2.addClass('invalid');
				el2.set('aria-invalid', 'true');
				el2.set('aria-required', 'true');
				if (el2.labelref) {
					document.id(el2.labelref).addClass('invalid');
					document.id(el2.labelref).set('aria-invalid', 'true');
				}

				document.getElementById('Company').className = 'required';
				document.getElementById('Company').set('required', 'required');
				document.id('Company-lbl').parentNode.parentNode.style.display = '';

				el3 = document.getElementById('Email');
				el3.addClass('invalid');
				el3.set('aria-invalid', 'true');
				el3.set('aria-required', 'true');
				if (el3.labelref) {
					document.id(el3.labelref).addClass('invalid');
					document.id(el3.labelref).set('aria-invalid', 'true');
				}

				document.getElementById('Email').className = 'required';
				document.getElementById('Email').set('required', 'required');
				document.id('Email-lbl').parentNode.parentNode.style.display = '';
			}
		});

";
		}//end anonymous

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->from('#__bfsurvey_questions');
		$query->select('hide_options, hide_question, show_options, show_question, field_name,'
						.'option1, option2, option3, option4, option5, option6, option7, option8, option9, option10,'
						.'option11, option12, option13, option14, option15, option16, option17, option18, option19, option20');
		$query->where('bfsurvey_category_id='.(int) $catid);
		$db->setQuery((string)$query);
		$result = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		foreach( $result as $row ) {
			//======================================================================================================================================================
			if($row->hide_question){
				//get the details for the question that triggers the hide
				$query->clear();
				$query->from('#__bfsurvey_questions');
				$query->select('*');
				$query->where('bfsurvey_question_id='.(int) $row->hide_question);
				$db->setQuery((string)$query);
				$hide_question = $db->loadObjectList();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return false;
				}

				$field_name = $hide_question[0]->field_name;

				//is hide question a radio question?
				if($hide_question[0]->question_type==1){

					$return.="		$('label').click(function(event) {
				if(";

					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our hide_options?
						if($hide_question[0]->$myoption != ''){
							if (strpos($row->hide_options,$hide_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked==true";
								}else{
									$return.= " || document.id('".$myfield_name."').checked==true";
								}
								$counter++;
							}
						}
					}

					$return.=")";

					$return.="{
				document.id('".$row->field_name."-lbl').style.display = 'none';
				document.id('".$row->field_name."').style.display = 'none';
			}else{
				document.id('".$row->field_name."-lbl').style.display = '';
				document.id('".$row->field_name."').style.display = '';
			}";
				} //end radio

				//is hide question a checkbox question?
				if($hide_question[0]->question_type==2){
					$return.="		window.addEvent('domready',function(){
			document.id('".$field_name."').addEvent('change',function(){
				if(";

					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our hide_options?
						if($hide_question[0]->$myoption != ''){
							if (strpos($row->hide_options,$hide_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked";
								}else{
									$return.= " || document.id('".$myfield_name."').checked";
								}
								$counter++;
							}
						}
					}
					$return.=")";

					$return.="{
					document.id('".$row->field_name."-lbl').style.display = 'none';
					document.id('".$row->field_name."').style.display = 'none';
					document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = 'none';
				}else{
					document.id('".$row->field_name."-lbl').style.display = '';
					document.id('".$row->field_name."').style.display = '';
					document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = '';
				}";

					$return.="
			});";

				} // end checkbox

				$return.="
		});";
			} // end hide question
			//======================================================================================================================================================
			//------------------------------------------------------------------------------------------------------------------------------------------------------
			if($row->show_question){
				//get the details for the question that triggers the show
				$query->clear();
				$query->from('#__bfsurvey_questions');
				$query->select('*');
				//$query->where('bfsurvey_category_id='.(int) $catid);
				$query->where('bfsurvey_question_id='.(int) $row->show_question);
				$db->setQuery((string)$query);
				$show_question = $db->loadObjectList();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return false;
				}

				$field_name = $show_question[0]->field_name;

				//initially hide the question -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				$return.="

		window.onload = function () {";
				//radio
				if($show_question[0]->question_type==1){
					$return.="
			if(";
					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our show_options?
						if($show_question[0]->$myoption != ''){
							if (strpos($row->show_options,$show_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked==true";
								}else{
									$return.= " || document.id('".$myfield_name."').checked==true";
								}
								$counter++;
							}
						}
					}

					$return.="){";
				}
				//end radio

				//checkbox
				if($show_question[0]->question_type==2){
					$return.="
			if(";

					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our show_options?
						if($show_question[0]->$myoption != ''){
							if (strpos($row->show_options,$show_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked";
								}else{
									$return.= " || document.id('".$myfield_name."').checked";
								}
								$counter++;
							}
						}
					}
					$return.="){";
				}
				//end checkbox

				$return.="
				document.id('".$row->field_name."-lbl').style.display = '';
				document.id('".$row->field_name."').style.display = '';
				document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = '';
			}else{
				document.id('".$row->field_name."-lbl').style.display = 'none';
				document.id('".$row->field_name."').style.display = 'none';
				document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = 'none';
			}
		}

";
				//end initially hide the question -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

				//is show question a radio question?
				if($show_question[0]->question_type==1){

					$return.="		$('label').click(function(event) {
			if(";

					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our show_options?
						if($show_question[0]->$myoption != ''){
							if (strpos($row->show_options,$show_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked==true";
								}else{
									$return.= " || document.id('".$myfield_name."').checked==true";
								}
								$counter++;
							}
						}
					}

					$return.=")";

					$return.="{
				document.id('".$row->field_name."-lbl').style.display = '';
				document.id('".$row->field_name."').style.display = '';
				document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = '';
			}else{
				document.id('".$row->field_name."-lbl').style.display = 'none';
				document.id('".$row->field_name."').style.display = 'none';
				document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = 'none';
			}";
				} //end radio

				//is show question a checkbox question?
				if($show_question[0]->question_type==2){
					$return.="		window.addEvent('domready',function(){
			document.id('".$field_name."').addEvent('change',function(){
				if(";

					$counter=0;
					for($i=1; $i < 21; $i++){
						$myoption="option".$i;

						//is this option in our show_options?
						if($show_question[0]->$myoption != ''){
							if (strpos($row->show_options,$show_question[0]->$myoption) !== false) {
								$myfield_name=$field_name.($i-1);
								if($counter==0){
									$return.="document.id('".$myfield_name."').checked";
								}else{
									$return.= " || document.id('".$myfield_name."').checked";
								}
								$counter++;
							}
						}
					}
					$return.=")";

					$return.="{
					document.id('".$row->field_name."-lbl').style.display = '';
					document.id('".$row->field_name."').style.display = '';
					document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = '';
				}else{
					document.id('".$row->field_name."-lbl').style.display = 'none';
					document.id('".$row->field_name."').style.display = 'none';
					document.id('".$row->field_name."-lbl').parentNode.parentNode.style.display = 'none';
				}";

					$return.="
			});";

				} // end checkbox

				$return.="
		});";
			} // end show question
			//------------------------------------------------------------------------------------------------------------------------------------------------------
		}

		$return.="
	});

})(jQuery);";

		return $return;
	}


	public static function createTabbedForm($catid, $surveyTitle, $showTabs, $introText)
	{
		$return="&lt;&#63;php
defined('_JEXEC') or die;

jimport ('joomla.html.html.bootstrap');

JHtml::_('behavior.keepalive');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen');

FOFTemplateUtils::addJS('media://com_bfsurvey/js/mobile.js');
FOFTemplateUtils::addJS('media://com_bfsurvey/js/".$catid."result.js');
&#36;user = JFactory::getUser();

&#36;accessLevels = JFactory::getUser()-&gt;getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
&#36;categoryAccess = BfsurveyModelSurvey::getCategoryAccess(1);

if (!in_array(&#36;categoryAccess, &#36;accessLevels))
{
	// User trying to view a survey he doesn't have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_YOU_MUST_LOG_IN') );
	&#36;itemid = JRequest::getVar( 'Itemid' );
	&#36;redirectUrl = base64_encode(\"index.php&#63;option=com_bfsurvey&amp;view=survey&amp;catid=1&amp;Itemid=\".(int)&#36;itemid);
	&#36;redirectUrl = '&amp;return='.&#36;redirectUrl;
	&#36;joomlaLoginUrl = 'index.php&#63;option=com_users&amp;view=login';
	&#36;finalUrl = &#36;joomlaLoginUrl . &#36;redirectUrl;

	echo \"&lt;br&gt;&lt;a href='\".JRoute::_(&#36;finalUrl).\"'&gt;\".JText::_( 'COM_BFSURVEY_LOG_IN').\"&lt;/a&gt;&lt;br&gt;\";
	return;
}

&#63;&gt;
";
	if($surveyTitle != '')
	{
		$return.="&lt;h1&gt;".$surveyTitle."&lt;/h1&gt;";
	}

	if($introText != '')
	{
		$return.="
	          &lt;div class=\"bfsurvey_helptext\"&gt;
	          &lt;&#63;php echo JHTML::_('content.prepare', \"".$introText."\"); &#63;&gt;
	          &lt;/div&gt;&lt;br&gt;
";
	}

	$return.="
&lt;form action=\"&lt;&#63;php echo JRoute::_('index.php&#63;option=com_bfsurvey&amp;view=".$catid."result&amp;id='.(int) &#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id); &#63;&gt;\" method=\"post\" name=\"adminForm\" id=\"adminForm\" class=\"form-validate\" enctype=\"multipart/form-data\"&gt;
	&lt;input type=\"hidden\" name=\"bfsurvey_".$catid."result_id\" value=\"&lt;&#63;php echo &#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id &#63;&gt;\" /&gt;
	&lt;div class=\"row-fluid\"&gt;
		&lt;div class=\"span10 form-horizontal\"&gt;

		&lt;fieldset&gt;
";
	if($showTabs){
		$return.="
				&lt;ul class=\"nav nav-tabs\"&gt;
					&lt;&#63;php foreach(&#36;this-&gt;form-&gt;getFieldsets() as &#36;fieldset): // Iterate through the form fieldsets and display each one.&#63;&gt;
						&lt;li &lt;&#63;php echo (&#36;fieldset-&gt;name=='Details'&#63; 'class=\"active\"' : '') &#63;&gt; &gt;&lt;a href=\"#&lt;&#63;php echo preg_replace('/\s+/', '', &#36;fieldset-&gt;name); &#63;&gt;\" data-toggle=\"tab\"&gt;&lt;&#63;php echo (strpos(&#36;fieldset-&gt;name,'page')) &#63; JText::_('COM_BFSURVEY_TITLE_'.strtoupper(&#36;fieldset-&gt;name)) : &#36;fieldset-&gt;name ;&#63;&gt;&lt;/a&gt;&lt;/li&gt;
					&lt;&#63;php endforeach;&#63;&gt;
				&lt;/ul&gt;
				&lt;div class=\"tab-content\"&gt;";
	}

$return.="
			&lt;&#63;php foreach(&#36;this-&gt;form-&gt;getFieldsets() as &#36;fieldset): // Iterate through the form fieldsets and display each one.&#63;&gt;
				&lt;div class=\"tab-pane &lt;&#63;php echo (&#36;fieldset-&gt;name=='Details'&#63; 'active' : '') &#63;&gt;\" id=\"&lt;&#63;php echo preg_replace('/\s+/', '', &#36;fieldset-&gt;name); &#63;&gt;\"&gt;
					&lt;&#63;php if(&#36;fieldset-&gt;name=='Details'){ &#63;&gt;
						&lt;&#63;php if(isset(&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id)){ &#63;&gt;
							&lt;div class=\"control-label\"&gt;
							&lt;/div&gt;
							&lt;div class=\"controls&lt;&#63;php echo &#36;field-&gt;myclass; &#63;&gt;\"&gt;
								&lt;&#63;php echo '#'.str_pad(&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id, 4, \"0\", STR_PAD_LEFT); &#63;&gt;
							&lt;/div&gt;
						&lt;&#63;php } &#63;&gt;
					&lt;&#63;php } &#63;&gt;
					&lt;&#63;php foreach (&#36;this-&gt;form-&gt;getFieldset(&#36;fieldset-&gt;name) as &#36;field) : &#63;&gt;
						&lt;&#63;php
							if(&#36;field-&gt;class == \"btn-group\" || &#36;field-&gt;class == \"btn-group-vertical\" || &#36;field-&gt;class == \"readonly\" || &#36;field-&gt;class == \"inputbox\" || &#36;field-&gt;class == \"inputbox btnchk-group\"){
								&#36;field-&gt;myclass = \"\";
							}else{
								&#36;field-&gt;myclass = &#36;field-&gt;class;
							}
						&#63;&gt;
						&lt;div class=\"control-group&lt;&#63;php echo &#36;field-&gt;myclass; &#63;&gt;\"&gt;
						    &lt;&#63;php if (strpos(&#36;field-&gt;label, 'hidden') == FALSE){ &#63;&gt;
							&lt;div class=\"control-label&lt;&#63;php echo &#36;field-&gt;myclass; &#63;&gt;\"&gt;
								&lt;&#63;php echo &#36;field-&gt;label; &#63;&gt;
							&lt;/div&gt;
							&lt;&#63;php } &#63;&gt;
							&lt;div class=\"controls&lt;&#63;php echo &#36;field-&gt;myclass; &#63;&gt;\"&gt;
								&lt;&#63;php if(&#36;field-&gt;name==\"Name\" &amp;&amp; !(isset(&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id))){ &#63;&gt;
									&lt;&#63;php &#36;field-&gt;setValue(&#36;user-&gt;name); &#63;&gt;
								&lt;&#63;php } &#63;&gt;
								&lt;&#63;php if(&#36;field-&gt;name==\"Email\" &amp;&amp; !(isset(&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id))){ &#63;&gt;
									&lt;&#63;php &#36;field-&gt;setValue(&#36;user-&gt;email); &#63;&gt;
								&lt;&#63;php } &#63;&gt;
								&lt;&#63;php echo &#36;field-&gt;input; &#63;&gt;
							&lt;/div&gt;
						&lt;&#63;php if(&#36;field-&gt;type == \"File\"){ &#63;&gt;
							&lt;&#63;php
								&#36;file = JUri::base().\"images/com_bfsurvey/\".&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id.&#36;field-&gt;name.\".jpg\";
								&#36;thumb = JUri::base().\"images/com_bfsurvey/\".&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id.&#36;field-&gt;name.\"_t.jpg\";
								&#36;original = JUri::base().\"images/com_bfsurvey/\".&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id.&#36;field-&gt;name.\"_original\";
								&#36;original_path = JPATH_SITE.\"/images/com_bfsurvey/\".&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id.&#36;field-&gt;name.\"_original\";
								&#36;a_pic = JPATH_SITE.\"/images/com_bfsurvey/\".&#36;this-&gt;item-&gt;bfsurvey_".$catid."result_id.&#36;field-&gt;name.\".jpg\";

								&#36;myfile=\"\";
								&#36;myicon=\"\";
								if(file_exists(&#36;original_path.\".docx\")){
									&#36;myfile = &#36;original.\".docx\";
									&#36;myicon=JUri::base().\"media/com_bfsurvey/images/doc_icon.png\";
								}elseif(file_exists(&#36;original_path.\".doc\")){
									&#36;myfile = &#36;original.\".doc\";
									&#36;myicon=JUri::base().\"media/com_bfsurvey/images/doc_icon.png\";
								}elseif(file_exists(&#36;original_path.\".pdf\")){
									&#36;myfile = &#36;original.\".pdf\";
									&#36;myicon=JUri::base().\"media/com_bfsurvey/images/pdf_icon.png\";
								}elseif(file_exists(&#36;original_path.\".xlsx\")){
									&#36;myfile = &#36;original.\".xlsx\";
									&#36;myicon=JUri::base().\"media/com_bfsurvey/images/xls_icon.png\";
								}elseif(file_exists(&#36;original_path.\".xls\")){
									&#36;myfile = &#36;original.\".xls\";
									&#36;myicon=JUri::base().\"media/com_bfsurvey/images/xls_icon.png\";
								}elseif(file_exists(&#36;original_path.\".jpg\")){
									&#36;myfile = &#36;original.\".jpg\";
									if (file_exists(&#36;a_pic)){
										&#36;myicon=&#36;thumb;
									}else{
										&#36;myicon=JUri::base().\"media/com_bfsurvey/images/jpg_icon.png\";
									}
								}elseif(file_exists(&#36;original_path.\".png\")){
									&#36;myfile = &#36;original.\".png\";
									if (file_exists(&#36;a_pic)){
										&#36;myicon=&#36;thumb;
									}else{
										&#36;myicon=JUri::base().\"media/com_bfsurvey/images/jpg_icon.png\";
									}
								}elseif(file_exists(&#36;original_path.\".jpeg\")){
									&#36;myfile = &#36;original.\".jpeg\";
									if (file_exists(&#36;a_pic)){
										&#36;myicon=&#36;thumb;
									}else{
										&#36;myicon=JUri::base().\"media/com_bfsurvey/images/jpg_icon.png\";
									}
								}elseif(file_exists(&#36;original_path.\".gif\")){
									&#36;myfile = &#36;original.\".gif\";
									if (file_exists(&#36;a_pic)){
										&#36;myicon=&#36;thumb;
									}else{
										&#36;myicon=JUri::base().\"media/com_bfsurvey/images/jpg_icon.png\";
									}
								}
								&#63;&gt;
								&lt;&#63;php if(&#36;myfile){ &#63;&gt;
									&lt;div class=\"controls\"&gt;
										&lt;a href=\"&lt;&#63;php echo &#36;myfile; &#63;&gt;\" target=\"_blank\"&gt;&lt;img src=\"&lt;&#63;php echo &#36;myicon; &#63;&gt;\"&gt;&lt;/a&gt;
									&lt;/div&gt;
								&lt;&#63;php } &#63;&gt;
						&lt;&#63;php } &#63;&gt;
						&lt;/div&gt;
					&lt;&#63;php endforeach; &#63;&gt;

				&lt;/div&gt;
			&lt;&#63;php endforeach;&#63;&gt;

			&lt;input type=\"hidden\" name=\"task\" value=\"\" /&gt;
			&lt;&#63;php echo JHtml::_('form.token'); &#63;&gt;

		&lt;/fieldset&gt;
		&lt;/div&gt;
	&lt;/div&gt;

	&lt;input type=\"submit\" id=\"task_button\" name=\"task_button\" class=\"btn btn-large\" value=\"&lt;&#63;php echo JText::_( 'COM_BFSURVEY_SUBMIT_BUTTON' ); &#63;&gt;\" /&gt;
&lt;/form&gt;";

		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);
		$return = preg_replace('/&amp;/', '&' , $return);

		return $return;
	}

	public static function createController($catid)
	{
		$return="&lt;&#63;php

defined('_JEXEC') or die();

class bfsurveyController1results extends FOFController
{
	protected function onAfterSave()
	{
		&#36;model = &#36;this->getThisModel();
		&#36;id = &#36;model->getId();

		&#36;this-&gt;setRedirect(JRoute::_('index.php&#63;option=com_bfsurvey&amp;view=thankyou&amp;catid=".$catid."&amp;id='.&#36;id));
		return true;
	}

	protected function onBeforeApplySave(&amp;&#36;data)
	{
		//checkbox questions just passes an array
		//so we need to capture that data in a comma separated string
		//firstly, figure out which questions are checkbox question type
		&#36;db = JFactory::getDBO();

		&#36;query	= &#36;db-&gt;getQuery(true);
		&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
		&#36;query-&gt;select('field_name');
		&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
		&#36;query-&gt;where('question_type = 2');  //checkbox
		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;mycheckboxes = &#36;db-&gt;loadObjectList();

		foreach(&#36;mycheckboxes as &#36;mycheckbox)
		{
			//for checkbox question type
			if(isset(&#36;data[&#36;mycheckbox-&gt;field_name])){
				if(is_array(&#36;data[&#36;mycheckbox-&gt;field_name])){
					&#36;data[&#36;mycheckbox-&gt;field_name] = implode(\",\", &#36;data[&#36;mycheckbox-&gt;field_name]);
				}
			}
		}

		//now look at all the SQL fields with multiple selection
		&#36;query-&gt;clear();
		&#36;query	= &#36;db-&gt;getQuery(true);
		&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
		&#36;query-&gt;select('field_name');
		&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
		&#36;query-&gt;where('question_type = 11');  //SQL
		&#36;query-&gt;where('titles = \"multiple\"');  //allows multiple selection
		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;mymultiples = &#36;db-&gt;loadObjectList();

		foreach(&#36;mymultiples as &#36;mymultiple)
		{
			//for SQL question type with multiple selection
			if(isset(&#36;data[&#36;mymultiple-&gt;field_name])){
				if(is_array(&#36;data[&#36;mymultiple-&gt;field_name])){
					&#36;data[&#36;mymultiple-&gt;field_name] = implode(\",\", &#36;data[&#36;mymultiple-&gt;field_name]);
				}
			}
		}
		//end SQL field

		//see if there are any _OTHER_ option selected
		//get all radio &amp; checkbox question types
		&#36;query-&gt;clear();
		&#36;query	= &#36;db-&gt;getQuery(true);
		&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
		&#36;query-&gt;select('field_name');
		&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
		&#36;query-&gt;where('(question_type IN (1, 2))'); //radio or checkbox
		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;myothers = &#36;db-&gt;loadObjectList();

		foreach(&#36;myothers as &#36;myother)
		{
			if(isset(&#36;data[&#36;myother-&gt;field_name])){
				if(&#36;data[&#36;myother-&gt;field_name] == \"_OTHER_\"){
					&#36;data[&#36;myother-&gt;field_name] = \"_OTHER_\".&#36;data[&#36;myother-&gt;field_name.'_other_'];
				}
			}
		}
		//end _OTHER_ option

		//now get the field names of all the files fields
		&#36;query-&gt;clear();
		&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
		&#36;query-&gt;select('field_name');
		&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
		&#36;query-&gt;where('question_type = 4');  //attachment
		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;myFilesFields = &#36;db-&gt;loadObjectList();

		&#36;config = JComponentHelper::getParams( 'com_bfsurvey' );

		&#36;files  = JRequest::get( 'files' );
		include_once JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfsurvey.php';
		BFSurveyHelperBfsurvey::saveImages(&#36;data,&#36;files,&#36;config,&#36;myFilesFields);

		return true;
	}


}";

		$return = preg_replace('/&amp;/', '&' , $return);
		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);

		return $return;
	}

	public static function createResultsForm($catid)
	{
		$return="&lt;&#63;php
defined('_JEXEC') or die;

&#36;accessLevels = JFactory::getUser()-&gt;getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfsurvey/models/survey.php';
&#36;categoryAccess = BfsurveyModelSurvey::getCategoryAccessResults(".$catid.");

if (!in_array(&#36;categoryAccess, &#36;accessLevels))
{
	// User trying to view a survey he does not have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_YOU_MUST_LOG_IN') );
	&#36;itemid = JRequest::getVar( 'Itemid' );
	&#36;redirectUrl = base64_encode(\"index.php&#63;option=com_bfsurvey&amp;view=surveys&amp;catid=".$catid."&amp;Itemid=\".(int)&#36;itemid);
	&#36;redirectUrl = '&amp;return='.&#36;redirectUrl;
	&#36;joomlaLoginUrl = 'index.php&#63;option=com_users&amp;view=login';
	&#36;finalUrl = &#36;joomlaLoginUrl . &#36;redirectUrl;

	echo \"&lt;br&gt;&lt;a href='\".JRoute::_(&#36;finalUrl).\"'&gt;\".JText::_( 'COM_BFSURVEY_LOG_IN').\"&lt;/a&gt;&lt;br&gt;\";
	return;
}

&#36;viewTemplate = &#36;this-&gt;getRenderedForm();
echo &#36;viewTemplate;

&#63;&gt;";

		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);
		$return = preg_replace('/&amp;/', '&' , $return);

		return $return;
	}

	public static function createModel($catid, $mycat)
	{
		$return="&lt;&#63;php
/*
 * @package BF Survey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfsurveyModel1results extends FOFModel
{
	protected function onBeforeSave(&amp;&#36;data, &amp;&#36;table)
	{
		parent::onBeforeSave(&#36;data, &#36;table);
";
		$use_captcha = $mycat->use_captcha;

		if($use_captcha == 1)
		{
			$return.="
		&#36;post = JRequest::get('post');
		JPluginHelper::importPlugin('captcha');
		&#36;dispatcher = JDispatcher::getInstance();
		&#36;res = &#36;dispatcher->trigger('onCheckAnswer',&#36;post['recaptcha_response_field']);
		if(!&#36;res[0]){
			JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_INVALID_CAPTCHA') );

			&#36;app = JFactory::getApplication();
			&#36;app->setUserState('com_bfsurvey.edit.".$catid."result.data', &#36;data);

			&#36;app->redirect(JRoute::_('index.php?option=com_bfsurvey&view=".$catid."result', false));

			return false;
		}";
		}
		$return.="
		return true;
	}

	public function onBeforeLoadForm(&amp;&#36;name, &amp;&#36;source, &amp;&#36;options)
	{
		&#36;catid = ".$catid.";
		&#36;table = '#__bfsurvey_".$catid."results';

		&#36;user = JFactory::getUser();

		&#36;db = JFactory::getDbo();
		&#36;query	= &#36;db-&gt;getQuery(true);

		&#36;query-&gt;select('preventMultiple, preventMultipleEmail, preventMultipleUID');
		&#36;query-&gt;from('#__bfsurvey_categories AS a');
		&#36;query-&gt;where('a.bfsurvey_category_id = '.(int)&#36;catid);

		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;result = &#36;db-&gt;loadObjectList();

		&#36;preventMultiple = &#36;result[0]-&gt;preventMultiple;
		&#36;preventMultipleEmail = &#36;result[0]-&gt;preventMultipleEmail;
		&#36;preventMultipleUID = &#36;result[0]-&gt;preventMultipleUID;

		&#36;app = JFactory::getApplication();

		if(&#36;preventMultiple){
			//prevent multiple IP
			if (isset(&#36;_SERVER['HTTP_X_FORWARDED_FOR']))
			{
		 		&#36;ip = &#36;_SERVER['HTTP_X_FORWARDED_FOR'];
			} else {
				&#36;ip=&#36;_SERVER['REMOTE_ADDR'];
    		}

			&#36;query-&gt;clear();
			&#36;query-&gt;from(&#36;table.' AS a');
			&#36;query-&gt;select('count(a.ip)');
			&#36;query-&gt;where('a.ip = '. &#36;db-&gt;quote(&#36;ip).'AND a.enabled&gt;-1' );

			&#36;db-&gt;setQuery((string)&#36;query);
			&#36;result=&#36;db-&gt;loadResult();

			if(&#36;result &gt; 0){
				JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_IP_ALREADY_COMPLETED') );
				&#36;app-&gt;redirect(JRoute::_(JURI::root().'index.php'));
			}
		}

		if(&#36;preventMultipleEmail &amp;&amp; &#36;user-&gt;id != \"\" &amp;&amp; &#36;user-&gt;id != 0){
			&#36;query-&gt;clear();
			&#36;query-&gt;from(&#36;db-&gt;quoteName(&#36;table).' AS a');
			&#36;query-&gt;select('count(a.Email)');
			&#36;query-&gt;where('a.Email = '.&#36;db-&gt;quote( &#36;db-&gt;escape( &#36;user-&gt;email ), false ).'AND a.enabled&gt;-1' );

			&#36;db-&gt;setQuery((string)&#36;query);
			&#36;result=&#36;db-&gt;loadResult();

			if(&#36;result &gt; 0){
				JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_EMAIL_ALREADY_COMPLETED') );
				&#36;app-&gt;redirect(JRoute::_(JURI::root().'index.php'));
			}
		}

		if(&#36;preventMultipleUID &amp;&amp; &#36;user-&gt;id != \"\" &amp;&amp; &#36;user-&gt;id != 0){
			&#36;query-&gt;clear();
	      	&#36;query-&gt;from(&#36;db-&gt;quoteName(&#36;table));
			&#36;query-&gt;select('count(created_by)');
			&#36;query-&gt;where('created_by = '.(int) &#36;user-&gt;id.' AND enabled&gt;-1');

			&#36;db-&gt;setQuery((string)&#36;query);
			&#36;result=&#36;db-&gt;loadResult();

			if(&#36;result &gt; 0){
				JError::raiseWarning( 403, JText::_( 'COM_BFSURVEY_ERROR_UID_ALREADY_COMPLETED') );
				&#36;app-&gt;redirect(JRoute::_(JURI::root().'index.php'));
			}
		}
	}

	public function getForm(&#36;data = array(), &#36;loadData = true, &#36;source = null)
	{
		&#36;this-&gt;_formData = &#36;data;

		&#36;name = &#36;this-&gt;input-&gt;getCmd('option', 'com_foobar') . '.'
				. '".$catid."result';

		if (empty(&#36;source))
		{
			&#36;source = &#36;this-&gt;getState('form_name', null);
		}

		if (empty(&#36;source))
		{
			&#36;source = 'form.' . &#36;this-&gt;input-&gt;getCmd('view', 'cpanels');
		}

		&#36;options = array(
				'control'	 =&gt; false,
				'load_data'	 =&gt; &#36;loadData,
		);

		&#36;this-&gt;onBeforeLoadForm(&#36;name, &#36;source, &#36;options);

		&#36;form = &#36;this-&gt;loadForm(&#36;name, &#36;source, &#36;options);

		if (&#36;form instanceof FOFForm)
		{
			&#36;this-&gt;onAfterLoadForm(&#36;form, &#36;name, &#36;source, &#36;options);
		}

		return &#36;form;
	}


	protected function loadForm(&#36;name, &#36;source = null, &#36;options = array(), &#36;clear = false, &#36;xpath = false)
	{
		// Handle the optional arguments.
		&#36;options['control'] = JArrayHelper::getValue(&#36;options, 'control', false);

		// Create a signature hash.
		&#36;hash = md5(&#36;source . serialize(&#36;options));

		// Check if we can use a previously loaded form.

		if (isset(&#36;this-&gt;_forms[&#36;hash]) &amp;&amp; !&#36;clear)
		{
			return &#36;this-&gt;_forms[&#36;hash];
		}

		// Try to find the name and path of the form to load
		&#36;formFilename = &#36;this-&gt;findFormFilename(&#36;source);

		// No form found&#63; Quit!

		if (&#36;formFilename === false)
		{
			return false;
		}

		// Set up the form name and path
		&#36;source = basename(&#36;formFilename, '.xml');
		FOFForm::addFormPath(dirname(&#36;formFilename));

		// Set up field paths

		&#36;option = &#36;this-&gt;input-&gt;getCmd('option', 'com_foobar');
		&#36;componentPaths = FOFPlatform::getInstance()-&gt;getComponentBaseDirs(&#36;option);
		&#36;view = &#36;this-&gt;input-&gt;getCmd('view', 'cpanels');
		&#36;file_root = &#36;componentPaths['main'];
		&#36;alt_file_root = &#36;componentPaths['alt'];

		FOFForm::addFieldPath(&#36;file_root . '/fields');
		FOFForm::addFieldPath(&#36;file_root . '/models/fields');
		FOFForm::addFieldPath(&#36;alt_file_root . '/fields');
		FOFForm::addFieldPath(&#36;alt_file_root . '/models/fields');

		FOFForm::addHeaderPath(&#36;file_root . '/fields/header');
		FOFForm::addHeaderPath(&#36;file_root . '/models/fields/header');
		FOFForm::addHeaderPath(&#36;alt_file_root . '/fields/header');
		FOFForm::addHeaderPath(&#36;alt_file_root . '/models/fields/header');

		// Get the form.
		try
		{
			&#36;form = FOFForm::getInstance(&#36;name, &#36;source, &#36;options, false, &#36;xpath);

			if (isset(&#36;options['load_data']) &amp;&amp; &#36;options['load_data'])
			{
				// Get the data for the form.
				&#36;data = &#36;this-&gt;loadFormData();
			}
			else
			{
				&#36;data = array();
			}

			// Allows data and form manipulation before preprocessing the form
			&#36;this-&gt;onBeforePreprocessForm(&#36;form, &#36;data);

			// Allow for additional modification of the form, and events to be triggered.
			// We pass the data because plugins may require it.
			&#36;this-&gt;preprocessForm(&#36;form, &#36;data);

			// Allows data and form manipulation After preprocessing the form
			&#36;this-&gt;onAfterPreprocessForm(&#36;form, &#36;data);

			// Load the data into the form after the plugins have operated.
			&#36;form-&gt;bind(&#36;data);
		}
		catch (Exception &#36;e)
		{
			&#36;this-&gt;setError(&#36;e-&gt;getMessage());

			return false;
		}

		// Store the form for later.
		&#36;this-&gt;_forms[&#36;hash] = &#36;form;

		return &#36;form;
	}


	public function findFormFilename(&#36;source, &#36;paths = array())
	{
		&#36;option = &#36;this-&gt;input-&gt;getCmd('option', 'com_foobar');
		&#36;view = '".$catid."result';

		&#36;componentPaths = FOFPlatform::getInstance()-&gt;getComponentBaseDirs(&#36;option);
		&#36;file_root = &#36;componentPaths['main'];
		&#36;alt_file_root = &#36;componentPaths['alt'];
		&#36;template_root = FOFPlatform::getInstance()-&gt;getTemplateOverridePath(&#36;option);

		if (empty(&#36;paths))
		{
			// Set up the paths to look into
			&#36;paths = array(
					// In the template override
					&#36;template_root . '/' . &#36;view,
					&#36;template_root . '/' . FOFInflector::singularize(&#36;view),
					&#36;template_root . '/' . FOFInflector::pluralize(&#36;view),
					// In this side of the component
					&#36;file_root . '/views/' . &#36;view . '/tmpl',
					&#36;file_root . '/views/' . FOFInflector::singularize(&#36;view) . '/tmpl',
					&#36;file_root . '/views/' . FOFInflector::pluralize(&#36;view) . '/tmpl',
					// In the other side of the component
					&#36;alt_file_root . '/views/' . &#36;view . '/tmpl',
					&#36;alt_file_root . '/views/' . FOFInflector::singularize(&#36;view) . '/tmpl',
					&#36;alt_file_root . '/views/' . FOFInflector::pluralize(&#36;view) . '/tmpl',
					// In the models/forms of this side
					&#36;file_root . '/models/forms',
					// In the models/forms of the other side
					&#36;alt_file_root . '/models/forms',
			);
		}

		// Set up the suffixes to look into
		&#36;suffixes = array();
		&#36;temp_suffixes = FOFPlatform::getInstance()-&gt;getTemplateSuffixes();

		if (!empty(&#36;temp_suffixes))
		{
			foreach (&#36;temp_suffixes as &#36;suffix)
			{
				&#36;suffixes[] = &#36;suffix . '.xml';
			}
		}

		&#36;suffixes[] = '.xml';

		// Look for all suffixes in all paths
		JLoader::import('joomla.filesystem.file');
		&#36;result = false;

		foreach (&#36;paths as &#36;path)
		{
			foreach (&#36;suffixes as &#36;suffix)
			{
				&#36;filename = &#36;path . '/' . &#36;source . &#36;suffix;

				if (JFile::exists(&#36;filename))
				{
					&#36;result = &#36;filename;
					break;
				}
			}

			if (&#36;result)
			{
				break;
			}
		}

		return &#36;result;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return  array    The default data is an empty array.
	 *
	 * @since   2.0
	 */
	protected function loadFormData()
	{
		&#36;this->_formData = JFactory::getApplication()->getUserState('com_bfsurvey.edit.".$catid."result.data', array());
		JFactory::getApplication()->setUserState('com_bfsurvey.edit.".$catid."result.data', '');

		if (empty(&#36;this-&gt;_formData))
		{
			return array();
		}
		else
		{
			//now look at all the SQL fields with multiple selection
			//need to turn the comma separated list back into an array
			&#36;db = JFactory::getDBO();
			&#36;query	= &#36;db-&gt;getQuery(true);
			&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
			&#36;query-&gt;select('field_name');
			&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
			&#36;query-&gt;where('question_type = 11');  //SQL
			&#36;query-&gt;where('titles = \"multiple\"');  //allows multiple selection
			&#36;db-&gt;setQuery((string)&#36;query);
			&#36;mymultiples = &#36;db-&gt;loadObjectList();

			foreach(&#36;mymultiples as &#36;mymultiple)
			{
				//for SQL question type with multiple selection
				&#36;this-&gt;_formData[&#36;mymultiple-&gt;field_name] = explode(',',&#36;this-&gt;_formData[&#36;mymultiple-&gt;field_name]);
			}
			//end SQL fields

			//now adjust for _OTHER_ options in radio or checkbox
			&#36;query-&gt;clear();
			&#36;query	= &#36;db-&gt;getQuery(true);
			&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
			&#36;query-&gt;select('field_name');
			&#36;query-&gt;where('bfsurvey_category_id = ".$catid."');
			&#36;query-&gt;where('(question_type IN (1, 2))'); //radio or checkbox
			&#36;db-&gt;setQuery((string)&#36;query);
			&#36;myothers = &#36;db-&gt;loadObjectList();

			foreach(&#36;myothers as &#36;myother)
			{
				if(isset(&#36;this-&gt;_formData[&#36;myother-&gt;field_name])){
					if(strpos(&#36;this-&gt;_formData[&#36;myother-&gt;field_name], \"_OTHER_\") !== false){
					}
				}
			}
			//end _OTHER_ option

			return &#36;this-&gt;_formData;
		}
	}

	/**
	 * This method is only called after a record is saved. We will hook on it
	 * to send an email to the address specified in the email template.
	 *
	 * @param   FOFTable  &#36;table  The FOFTable which was just saved
	 */
	protected function onAfterSave(&amp;&#36;table)
	{
		&#36;result = parent::onAfterSave(&#36;table);
		&#36;catid = ".$catid.";
		&#36;id=&#36;table-&gt;bfsurvey_".$catid."result_id;

		//**************************************************************
		//in case files were uploaded before id assigned
		jimport( 'joomla.filesystem.file' );
		&#36;path= JPATH_SITE.\"/images/com_bfsurvey\";

		//get the field names of all the files fields
		&#36;db = JFactory::getDBO();
		&#36;query	= &#36;db-&gt;getQuery(true);

		&#36;query-&gt;from(&#36;db-&gt;quoteName('#__bfsurvey_questions'));
		&#36;query-&gt;select('field_name');
		&#36;query-&gt;where('bfsurvey_category_id = '.&#36;catid);
		&#36;query-&gt;where('question_type = 4');  //attachment
		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;myFilesFields = &#36;db-&gt;loadObjectList();

		foreach(&#36;myFilesFields as &#36;myField)
		{
			&#36;field_name=&#36;myField-&gt;field_name;
			&#36;extensions = array('jpg', 'jpeg', 'gif', 'png', 'xls', 'xlsx', 'pdf', 'doc', 'docx');

			foreach(&#36;extensions as &#36;extn)
			{
				&#36;src=\"&#36;path/0\".&#36;field_name.\"_original.\".&#36;extn;
				&#36;dest=&#36;path.\"/\".&#36;id.&#36;field_name.\"_original.\".&#36;extn;
				if ( file_exists(&#36;src) &amp;&amp; !file_exists(&#36;&#36;dest) ) {
					JFile::move(&#36;src, &#36;dest);
				}

				&#36;src=\"&#36;path/0\".&#36;field_name.\"_t.\".&#36;extn;
				&#36;dest=&#36;path.\"/\".&#36;id.&#36;field_name.\"_t.\".&#36;extn;
				if ( file_exists(&#36;src) &amp;&amp; !file_exists(&#36;&#36;dest) ) {
					JFile::move(&#36;src, &#36;dest);
				}

				&#36;src=\"&#36;path/0\".&#36;field_name.\".\".&#36;extn;
				&#36;dest=&#36;path.\"/\".&#36;id.&#36;field_name.\".\".&#36;extn;
				if ( file_exists(&#36;src) &amp;&amp; !file_exists(&#36;&#36;dest) ) {
					JFile::move(&#36;src, &#36;dest);
				}
			}
		}
		//**************************************************************

		&#36;myview='com_bfsurvey.'.(int)&#36;catid.'result';

		//which event is triggering the email&#63;
		//need to find out id in #__content_types table
		&#36;query-&gt;clear();

		&#36;query-&gt;select('type_id');
		&#36;query-&gt;from('#__content_types');
		&#36;query-&gt;where('type_alias = '.&#36;db-&gt;quote(&#36;myview));

		&#36;db-&gt;setQuery((string)&#36;query);
		&#36;type_id=&#36;db-&gt;loadResult();

		&#36;emailType = BFSurveyDispatcher::getEmailType(&#36;id, &#36;type_id, &#36;table-&gt;status, (int)&#36;catid);
		&#36;myemail = \"\";
		foreach(&#36;emailType as &#36;i =&gt; &#36;myEmailType):
			if(&#36;myEmailType != \"\")
			{
				&#36;myemail[&#36;i] = BFSurveyDispatcher::getEmailTemplate(&#36;myEmailType,(int)&#36;catid);
			}
		endforeach;

		if (&#36;result !== false)
		{
			if(&#36;myemail)
			{
				foreach(&#36;myemail as &#36;emailTemplate):
					BFSurveyDispatcher::sendEmail(&#36;emailTemplate, &#36;table, (int)&#36;catid);
				endforeach;
			}
		}

		return &#36;result;
	}

}";

		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);
		$return = preg_replace('/&amp;/', '&' , $return);

		return $return;
	}

	public static function createTable($catid)
	{
		$return="&lt;&#63;php
/**
 *  @package BFSurvey
 *  @copyright Copyright (c)2014 Tim Plummer
 *  @license GNU General Public License version 2, or later
 *
 *  This file is required because the content history (version control) assumes we are using JTable
 *  The class name is mentioned in the content_types record
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BFSurveyTableMy".$catid."result extends JTable
{
	public function __construct(&amp;&#36;db)
	{
		parent::__construct('#__bfsurvey_".$catid."results', 'bfsurvey_".$catid."result_id', &#36;db);
	}

}";

		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);
		$return = preg_replace('/&amp;/', '&' , $return);

		return $return;
	}
}