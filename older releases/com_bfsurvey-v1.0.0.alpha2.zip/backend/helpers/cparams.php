<?php
defined('_JEXEC') or die;

class BFSurveyHelperCparams
{
	private static $params = null;

	public static function getParam($key, $default = null)
	{
		if(!is_object(self::$params)) {
			JLoader::import('joomla.application.component.helper');
			self::$params = JComponentHelper::getParams('com_bfsurvey');
		}
		return self::$params->get($key, $default);
	}

	public static function setParam($key, $value)
	{
		if(!is_object(self::$params)) {
			JLoader::import('joomla.application.component.helper');
			self::$params = JComponentHelper::getParams('com_bfsurvey');
		}

		self::$params->set($key, $value);

		$db = JFactory::getDBO();
		$data = self::$params->toString();
		$sql = $db->getQuery(true)
			->update($db->qn('#__extensions'))
			->set($db->qn('params').' = '.$db->q($data))
			->where($db->qn('element').' = '.$db->q('com_bfsurvey'))
			->where($db->qn('type').' = '.$db->q('component'));
		$db->setQuery($sql);
		$db->execute();
	}
}