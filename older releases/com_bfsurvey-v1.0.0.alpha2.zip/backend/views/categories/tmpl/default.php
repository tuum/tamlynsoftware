<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

$viewTemplate = $this->getRenderedForm();
echo $viewTemplate;

require_once JPATH_COMPONENT.'/helpers/answertable.php';

$errors = answerTable::buildAnswerTables();
if($errors){
	JError::raiseWarning(100, $errors);
}
?>