ALTER TABLE [#__bfsurvey_emailitems] ADD [pdfEmail] [smallint] NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] ADD [template] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] ADD [templateCoverpage] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] ADD [templateHeader] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] ADD [templateFooter] [nvarchar](max) NOT NULL;
