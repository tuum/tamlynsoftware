<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.jqplot.min.css');

AkeebaStrapper::addJSfile('media://com_bfsurvey/js/excanvas.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jquery.jqplot.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.highlighter.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.dateAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.barRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pieRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.hermite.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.categoryAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pointLabels.min.js');

?>

<?php foreach ($this->items as $i => $row) : ?>
	<?php
	$options = array($row->option1, $row->option2, $row->option3, $row->option4, $row->option5, $row->option6, $row->option7, $row->option8, $row->option9, $row->option10, $row->option11, $row->option12, $row->option13, $row->option14, $row->option15, $row->option16, $row->option17, $row->option18, $row->option19, $row->option20);
	$options = array_filter($options);
	$data = array();

	$catid = $row->bfsurvey_category_id;
	$question_type = $row->question_type;
	//now get the stats count for each option
	for ($x=1; $x < 21; $x++)
	{
		$question=$row->field_name;
		$name = 'option'.$x;
		$response=$row->$name;
		if($response != '' && $response != null)
		{
			if($question_type == 2){ //checkbox
				if($response == "_OTHER_"){
					$value = BfsurveyModelStats::getStatsOther($question, $response, $catid);
					$options[$x-1] = $row->otherprefix;
				}else{
					$value = BfsurveyModelStats::getStatsCheckbox($question, $response, $catid);
				}
			}else if($question_type == 0 | $question_type == 3 | $question_type == 5 | $question_type == 8 | $question_type == 9 | $question_type == 13){
				$value="";
			}else{
				if($response == "_OTHER_"){
					$value = BfsurveyModelStats::getStatsOther($question, $response, $catid);
					$options[$x-1] = trim($row->otherprefix." ".$row->othersuffix);
				}else{
					$value = BfsurveyModelStats::getStats($question, $response, $catid);
				}
			}

			$data[$x-1]=$value;
		}
	}

	if($question_type == 0 || $question_type == 3 || $question_type == 12){ //text or Textarea
		$answers = BfsurveyModelStats::getStatsText($row->field_name, $catid);
		$field_name = $row->field_name;
		echo "<hr>";
		echo "<h3>".$row->title."</h3>";
		foreach($answers AS $answer){
			if($answer->$field_name){
				echo trim($answer->$field_name)."<br>";
			}
		}
		echo "<hr>";
	}else if($question_type == 10 || $question_type == 4 || $question_type == 11 || $question_type == 7 || $question_type == 5 || $question_type == 13){ //heading or attachment or SQL or userlist or date or helptext
		// do nothing
	}else if($question_type == 9){ //rating
		$mylabels = array();
		if($row->titles == ""){
			// do nothing
		}else{
			$mylabels = preg_split("/;/",$row->titles);
		}

		for($z=0; $z < 20; $z++)
		{
			$data = array();
			$total = 0;
			$options = array();
			$myAnswer = array();
			$tempvalue="option".($z+1);

			if($row->$tempvalue != "" && $row->$tempvalue != null){

				$field=$row->field_name;
				$question=$field.'_'.($z+1);

				for($y=1; $y < $row->key_field+1; $y++){
					if($row->titles == ""){
						$response = $y;
					}else{
						$response = $mylabels[$y-1];
					}
					$answer = BfsurveyModelStats::getStats($question, $response, $catid);
					$options[$y]=$response;
					if($answer > 0){
						$total=$total + $answer;
					}

					$data[$y-1]=$answer;
				}

			echo '<div id="chart'.$row->bfsurvey_question_id.'_'.$z.'" style="margin-top:20px; margin-left:20px; width:800px;"></div>';
			?>

			<script class="code" type="text/javascript">
				(function($)
				{
					$(document).ready(function()
					{
						var data = [ '<?php echo implode("', '", $data); ?>'];

						var ticks = [ '<?php echo implode("', '", $options); ?>'];

						var plot1 = $.jqplot ('chart<?php echo $row->bfsurvey_question_id; ?>_<?php echo $z; ?>', [data],
						{
							title: '<?php echo $row->title; ?>',
							seriesDefaults: {
								// Make this a bar chart.
								renderer:$.jqplot.BarRenderer,
								rendererOptions: {
									fillToZero: true,
							  varyBarColor: true
								}
							},
							legend: { show:false },

							axes: {
								// Use a category axis on the x axis and use our custom ticks.
								xaxis: {
									renderer: $.jqplot.CategoryAxisRenderer,
									ticks: ticks
								},
								// Pad the y axis just a little so bars can get close to, but
								// not touch, the grid boundaries.  1.2 is the default padding.
								yaxis: {
									pad: 1.05,
									tickOptions: {formatString: '%d'}
								}
							}

						}
						);
					})
				})(jQuery);
				</script>

			<?php
			}
		}

	}else{
		//show graph for other question types
		echo '<div id="chart'.$row->bfsurvey_question_id.'" style="margin-top:20px; margin-left:20px; width:800px;"></div>';
	?>

	<script class="code" type="text/javascript">
	(function($)
	{
		$(document).ready(function()
		{
			var data = [ <?php echo ($question_type == 2)? implode(",", $data) : "'".implode("', '", $data)."'"; ?>];

			var ticks = [ '<?php echo implode("', '", $options); ?>'];

			var plot1 = $.jqplot ('chart<?php echo $row->bfsurvey_question_id; ?>', [data],
			{
				title: '<?php echo $row->title; ?>',
				seriesDefaults: {
					// Make this a bar chart.
					renderer:$.jqplot.BarRenderer,
					rendererOptions: {
						fillToZero: true,
				  varyBarColor: true
					}
				},
				legend: { show:false },

				axes: {
					// Use a category axis on the x axis and use our custom ticks.
					xaxis: {
						renderer: $.jqplot.CategoryAxisRenderer,
						ticks: ticks
					},
					// Pad the y axis just a little so bars can get close to, but
					// not touch, the grid boundaries.  1.2 is the default padding.
					yaxis: {
						pad: 1.05,
						tickOptions: {formatString: '%d'}
					}
				}

			}
			);

			//Generate the img version of the graph for PDF export
 			$('#chart<?php echo $row->bfsurvey_question_id; ?>').jqplotSaveImage();

		})

		$.fn.jqplotSaveImage = function() {
	    	var imgData = $('#chart<?php echo $row->bfsurvey_question_id; ?>').jqplotToImageStr({});
	    	if (imgData) {
	        	//window.location.href = imgData.replace("image/png", "image/octet-stream");
	    	}
		};
	})(jQuery);
	</script>

	<?php } ?>

 <?php endforeach; ?>

<!--
<div id="chart1" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
		  var data = [
		    ['Heavy Industry', 12],['Retail', 9], ['Light Industry', 14],
		    ['Out of home', 16],['Commuting', 7], ['Orientation', 9]
		  ];
		  var plot1 = $.jqplot ('chart1', [data],
		    {
		      title: 'Bubble Chart with Gradient Fills',
		      seriesDefaults: {
		        // Make this a pie chart.
		        renderer: $.jqplot.PieRenderer,
		        rendererOptions: {
		          // Put data labels on the pie slices.
		          showDataLabels: true,
		          dataLabels: 'all'
		        }
		      },
		      legend: { show:true, location: 'e' }
		    }
		  );
	})
})(jQuery);
</script>
 -->

<!--
<div id="chart2" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
	  var data = [
	    12, 9, 14, 16, 7, 9
	  ];

	  var ticks = ['Heavy Industry', 'Retail', 'Light Industry', 'Out of home', 'Commuting', 'Orientation'];

	  var plot1 = $.jqplot ('chart2', [data],
	    {
	      title: 'Second Chart example',
	      seriesDefaults: {
	        // Make this a bar chart.
			renderer:$.jqplot.BarRenderer,
	        rendererOptions: {
	          fillToZero: true,
			  varyBarColor: true
	        }
	      },
	      legend: { show:false },

	      axes: {
	          // Use a category axis on the x axis and use our custom ticks.
	          xaxis: {
	              renderer: $.jqplot.CategoryAxisRenderer,
	              ticks: ticks
	          },
	          // Pad the y axis just a little so bars can get close to, but
	          // not touch, the grid boundaries.  1.2 is the default padding.
	          yaxis: {
	              pad: 1.05,
	              tickOptions: {formatString: '%d'}
	          }
	      }

	    }
	  );
	})
})(jQuery);
</script>
 -->

<!--
<div id="chart3" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
		  var data = [
		    [12,1], [9,2], [14,3], [16,4], [7,5], [9,6]
		  ];

		  var ticks = ['Heavy Industry', 'Retail', 'Light Industry', 'Out of home', 'Commuting', 'Orientation'];

		  var plot1 = $.jqplot ('chart3', [data],
		    {
		      title: 'Second Chart example',
		      seriesDefaults: {
		        // Make this a bar chart.
				renderer:$.jqplot.BarRenderer,
		        rendererOptions: {
		          fillToZero: true,
		          barDirection: 'horizontal',
		          varyBarColor: true
		        },
		        shadowAngle: 135,
		      },
		      legend: { show:false },

		      axes: {
		          // Use a category axis on the x axis and use our custom ticks.
		          yaxis: {
		              renderer: $.jqplot.CategoryAxisRenderer,
		              ticks: ticks
		          },
		          // Pad the y axis just a little so bars can get close to, but
		          // not touch, the grid boundaries.  1.2 is the default padding.
		          xaxis: {
		              pad: 1.05,
		              tickOptions: {formatString: '%d'}
		          }
		      }
		    }
		  );
	})
})(jQuery);
</script>
 -->