<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$params = JComponentHelper::getParams('com_bfsurvey');
$downloadid = $params->get('downloadid');
$nostorage = $params->get('nostorage');

$lang = JFactory::getLanguage();
$icons_root = JURI::base().'media/com_bfsurvey/images/';

$groups = array('basic','tools','update');

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/backend.css');
?>

<?php
//content history feature was added in Joomla 3.2
if (version_compare(JVERSION, '3.2.0', 'lt'))
{
?>
<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSURVEY_JOOMLA_VERSION_REQUIRED'); ?></p>
</div>
<?php } ?>

<div id="updateNotice"></div>

<div id="cpanel" class="row-fluid">
	<div class="span11">

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=categories">
				<div class="bfsurvey-icon-category"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_CATEGORIES'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=questions">
				<div class="bfsurvey-icon-question"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_QUESTIONS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=emailitems">
				<div class="bfsurvey-icon-email"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_EMAIL_TEMPLATE'); ?></span>
			</a>
		</div>

		<?php if($nostorage == 0){ ?>
		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=resultscategories">
				<div class="bfsurvey-icon-results"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_RESULTS'); ?></span>
			</a>
		</div>
		<?php } ?>

		<?php if($nostorage == 0){ ?>
		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=statistics">
				<div class="bfsurvey-icon-stats"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_STATISTICS'); ?></span>
			</a>
		</div>
		<?php } ?>

		<?php if($nostorage == 0){ ?>
		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=reports">
				<div class="bfsurvey-icon-reports"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_REPORTS'); ?></span>
			</a>
		</div>
		<?php } ?>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=maintenance">
				<div class="bfsurvey-icon-maintenance"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_MAINTENANCE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/documentation/bfsurvey.html" target="_blank">
				<div class="bfsurvey-icon-documentation"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_USER_GUIDE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/contact-us/support-tickets.html" target="_blank">
				<div class="bfsurvey-icon-help"> </div>
				<span><?php echo JText::_('COM_BFSURVEY_TITLE_SUPPORT_TICKETS'); ?></span>
			</a>
		</div>

		<?php if(version_compare(PHP_VERSION, '5.3.0', 'ge') && $downloadid){ ?>
		<div align="center">
		<?php echo LiveUpdate::getIcon(); ?>
		</div>
		<?php } ?>

	</div>
</div>

<div class="ak_clr"></div>

<div class="row-fluid footer">
<div class="span12">
	<?php global $bfsurvey_version; ?>
	<p style="font-size: small" class="well">Copyright &copy;<?php echo date('Y');?> Tamlyn Software. All Rights Reserved.
		<?php echo JText::_( 'COM_BFSURVEY_VERSION'); ?>
		<?php echo $bfsurvey_version; ?>

		<a href="index.php?option=com_bfsurvey&view=update&task=force" class="btn btn-inverse btn-small">
			<?php echo JText::_('COM_BFSURVEY_CPANEL_MSG_RELOADUPDATE'); ?>
		</a>
	</p>
</div>
</div>

<div style="clear: both;"></div>

<script type="text/javascript">
	(function ($)
	{
		$(document).ready(function ()
		{
			$.ajax('index.php?option=com_bfsurvey&view=cpanel&task=updateinfo&tmpl=component', {
				success: function (msg, textStatus, jqXHR)
				{
					// Get rid of junk before and after data
					var match = msg.match(/###([\s\S]*?)###/);
					data = match[1];

					if (data.length)
					{
						$('#updateNotice').html(data);
					}
				}
			})
		});
	})(akeeba.jQuery);

</script>