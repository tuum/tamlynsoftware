<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelReports extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'reports';
	}

	public function save($data)
	{
		if(is_array($data['fields'])){
			$data['fields'] = implode(",", $data['fields']);
		}

		parent::save($data);

		return true;
	}

	public function getReport($id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('bfsurvey_category_id, title, fields, since, until, '
				.'condition_field1, condition_criteria1, condition_value1, condition_operator1, '
				.'condition_field2, condition_criteria2, condition_value2, template, templateCoverpage, templateHeader, templateFooter, rowsAsSeparatePages, filename');
		$query->from('#__bfsurvey_reports');
		$query->where('bfsurvey_report_id='.(int)$id);
		$db->setQuery((string)$query);
		$result = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		return $result;
	}

	public function createReport($result)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select($result[0]->fields);
		$query->from('#__bfsurvey_'.$result[0]->bfsurvey_category_id.'results');

		if(isset($result[0]->condition_field1) && isset($result[0]->condition_value1) && $result[0]->condition_criteria1 > -1){
			switch($result[0]->condition_criteria1){
				case '0': 	$condition_criteria1 = '<';
				break;
				case '1':	$condition_criteria1 = '=';
				break;
				case '2':	$condition_criteria1 = '>';
				break;
				case '3':	$condition_criteria1 = '<>';
				break;
				default: 	$condition_criteria1 = '=';
			}
			$condition1 = $result[0]->condition_field1.' '.$condition_criteria1.' '.$result[0]->condition_value1;

			switch($result[0]->condition_operator1){
				case '0': $condition_operator1 = "AND";
				break;
				case '1': $condition_operator1 = "OR";
				break;
				default: $condition_operator1 = "AND";
			}
		}

		if(isset($result[0]->condition_field2) && isset($result[0]->condition_value2) && $result[0]->condition_criteria2 > -1){
			switch($result[0]->condition_criteria2){
				case '0': 	$condition_criteria2 = '<';
				break;
				case '1':	$condition_criteria2 = '=';
				break;
				case '2':	$condition_criteria2 = '>';
				break;
				case '3':	$condition_criteria2 = '<>';
				break;
				default: 	$condition_criteria2 = '=';
			}
			$condition2 = $result[0]->condition_field2.' '.$condition_criteria2.' '.$result[0]->condition_value2;
		}

		if(isset($condition1) && isset($condition2)){
			$query->where($condition1.' '.$condition_operator1.' '.$condition2);
		}else if(isset($condition1)){
			$query->where($condition1);
		}

		if(isset($result[0]->since) && $result[0]->since!="0000-00-00 00:00:00" && $result[0]->since!="1970-01-01 00:00:00"){
			$query->where('created_on >= '.$db->quote($result[0]->since));
		}

		if(isset($result[0]->until) && $result[0]->until!="0000-00-00 00:00:00" && $result[0]->since!="1970-01-01 00:00:00"){
			$query->where('created_on <= '.$db->quote($result[0]->until));
		}

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return false;
		}

		return $result;
	}

	public function createPDF($reportDetails, $report)
	{
		$html = "";

		if($reportDetails->templateCoverpage != '')
		{
			$templateCoverpage = $reportDetails->templateCoverpage;
			foreach ($report as $i => $item) :
			foreach (explode(',',$reportDetails->fields) as $field) :
			$templateCoverpage = preg_replace('/\['.$field.'\]/', $item->$field, $templateCoverpage);
			endforeach;
			endforeach;
			$now = JFactory::getDate();
			$date=$now->format('d M Y');
			$templateCoverpage = preg_replace('/\{date\}/', $date, $templateCoverpage);
			$html.= $templateCoverpage;
			$html .= $reportDetails->templateFooter;
			//add page break
			$html.= '<div style="page-break-after: always"></div>';
			if($reportDetails->templateHeader != '' && $reportDetails->rowsAsSeparatePages==0)
			{
				$html.= $reportDetails->templateHeader;
			}
		}

		if($reportDetails->template != '')
		{
			foreach ($report as $i => $item) :
				$template = "";
				if($reportDetails->rowsAsSeparatePages)
				{
					if($reportDetails->templateHeader != '')
					{
						$template .= $reportDetails->templateHeader;
						$template .= '<div class="clearfix"> </div>';
					}
				}
				$template .= $reportDetails->template;

				foreach (explode(',',$reportDetails->fields) as $field) :
					$template = preg_replace('/\['.$field.'\]/', htmlspecialchars($item->$field), $template);
					if($i % 2)
					{
						$template = preg_replace('/\<tr\>/', '<tr style="background-color:#DDDDDD;">', $template);
					}
				endforeach;
				$html.= $template;

				if($reportDetails->rowsAsSeparatePages)
				{
					// Repair the input HTML
					if (function_exists('tidy_repair_string'))
					{
						$tidyConfig = array(
							'bare'							=> 'yes',
							'clean'							=> 'yes',
							'drop-proprietary-attributes'	=> 'yes',
							'clean'							=> 'yes',
							'output-html'					=> 'yes',
							'show-warnings'					=> 'no',
							'ascii-chars'					=> 'no',
							'char-encoding'					=> 'utf8',
							'input-encoding'				=> 'utf8',
							'output-bom'					=> 'no',
							'output-encoding'				=> 'utf8',
							'force-output'					=> 'yes',
							'tidy-mark'						=> 'no',
							'wrap'							=> 0,
						);
						$repaired = tidy_repair_string($html, $tidyConfig, 'utf8');
						if ($repaired !== false)
						{
							$html = $repaired;
						}
					}

					// Create the PDF
					$pdf = $this->getTCPDF();
					$pdf->SetPrintFooter(false);
					$pdf->AddPage();
					$pdf->writeHTML($html, true, false, true, false, '');
					$pdf->lastPage();
					$pdfData = $pdf->Output('', 'S');

					unset($pdf);

					// Write the PDF data to disk using JFile::write();
					JLoader::import('joomla.filesystem.file');

					if($reportDetails->filename)
					{
						$name = preg_replace('/\s+/', '', $reportDetails->filename) . '.pdf';
					}
					else
					{
						$name = preg_replace('/\s+/', '', $reportDetails->title) . '_' . $i. '.pdf';
					}

					$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';

					$ret = JFile::write($path . $name, $pdfData);
					if($reportDetails->rowsAsSeparatePages)
					{
						//reset html variable
						$html="";
					}
				}
			endforeach;

			if($reportDetails->rowsAsSeparatePages)
			{
				if ($ret)
				{
					// return the name of the file
					return $name;
				}
				else
				{
					return false;
				}
			}
		}else{
			//default layout for report
			$html.='<h1>'.$reportDetails->title.'</h1>';

			if($reportDetails->since != "0000-00-00 00:00:00" && $result[0]->since!="1970-01-01 00:00:00"){
				$html.=JText::_('COM_BFSURVEY_REPORT_SINCE').$reportDetails->since.' ';
			}

			if($reportDetails->until != "0000-00-00 00:00:00" && $result[0]->since!="1970-01-01 00:00:00"){
				$html.=JText::_('COM_BFSURVEY_REPORT_UNTIL').$reportDetails->until;
			}

			$html.='
				<div id="j-main-container" class="span10">

					<div class="clearfix"> </div>
					<table class="table table-striped" id="reportList">
						<thead>
							<tr>';
								foreach (explode(',',$reportDetails->fields) as $i => $item) :
								$html.='
									<th>
										'.$item.'
									</th>';
								endforeach;
							$html.='
							</tr>
						</thead>
						<tbody>';
						foreach ($report as $i => $item) :
							$html.='
							<tr class="row'.($i % 2).'">';
								foreach (explode(',',$reportDetails->fields) as $field) :
									$html.='
									<td>
										'.$item->$field.'
									</td>';
								endforeach;
							$html.='
							</tr>';
							endforeach;
						$html.='
						</tbody>
					</table>
				</div>';
		}

		// Repair the input HTML
		if (function_exists('tidy_repair_string'))
		{
			$tidyConfig = array(
				'bare'							=> 'yes',
				'clean'							=> 'yes',
				'drop-proprietary-attributes'	=> 'yes',
				'clean'							=> 'yes',
				'output-html'					=> 'yes',
				'show-warnings'					=> 'no',
				'ascii-chars'					=> 'no',
				'char-encoding'					=> 'utf8',
				'input-encoding'				=> 'utf8',
				'output-bom'					=> 'no',
				'output-encoding'				=> 'utf8',
				'force-output'					=> 'yes',
				'tidy-mark'						=> 'no',
				'wrap'							=> 0,
			);
			$repaired = tidy_repair_string($html, $tidyConfig, 'utf8');
			if ($repaired !== false)
			{
				$html = $repaired;
			}
		}

		if($reportDetails->templateHeader != '' && $reportDetails->templateCoverpage == '')
		{
			$template = $reportDetails->templateHeader;
			$template .= $html;
			$html = $template;
		}

		$html .= $reportDetails->templateFooter;

		//echo "<pre>" . htmlentities($html) . "</pre>"; die();

		// Create the PDF
		$pdf = $this->getTCPDF();
		$pdf->AddPage();
		$pdf->writeHTML($html, true, false, true, false, '');
		$pdf->lastPage();
		$pdfData = $pdf->Output('', 'S');

		unset($pdf);

		// Write the PDF data to disk using JFile::write();
		JLoader::import('joomla.filesystem.file');
		if (function_exists('openssl_random_pseudo_bytes'))
		{
			$rand = openssl_random_pseudo_bytes(16);
			if ($rand === false)
			{
				// Broken or old system
				$rand = mt_rand();
			}
		}
		else
		{
			$rand = mt_rand();
		}
		$hashThis = serialize($reportDetails) . microtime() . $rand;
		if (function_exists('hash'))
		{
			$hash = hash('sha256', $hashThis);
		}
		if (function_exists('sha1'))
		{
			$hash = sha1($hashThis);
		}
		else
		{
			$hash = md5($hashThis);
		}
		if($reportDetails->filename)
		{
			$name = preg_replace('/\s+/', '', $reportDetails->filename);
		}
		else
		{
			$name = preg_replace('/\s+/', '', $reportDetails->title) . '.pdf';
		}

		$path = JPATH_ADMINISTRATOR . '/components/com_bfsurvey/reports/';

		$ret = JFile::write($path . $name, $pdfData);
		if ($ret)
		{
			// return the name of the file
			return $name;
		}
		else
		{
			return false;
		}
	}

	public function &getTCPDF()
	{
		// Set up TCPDF
		$jreg = JFactory::getConfig();
		$tmpdir = $jreg->get('tmp_path');
		$tmpdir = rtrim($tmpdir, '/' . DIRECTORY_SEPARATOR) . '/';
		$siteName = $jreg->get('sitename');

		$baseurl = JURI::base();
		$baseurl = rtrim($baseurl, '/');

		define('K_TCPDF_EXTERNAL_CONFIG', 1);

		define ('K_PATH_MAIN', JPATH_BASE . '/');
		define ('K_PATH_URL', $baseurl);
		define ('K_PATH_FONTS', JPATH_ROOT.'/media/com_bfsurvey/tcpdf/fonts/');
		define ('K_PATH_CACHE', $tmpdir);
		define ('K_PATH_URL_CACHE', $tmpdir);
		define ('K_PATH_IMAGES', JPATH_ROOT.'/media/com_bfsurvey/tcpdf/images/');
		define ('K_BLANK_IMAGE', K_PATH_IMAGES.'_blank.png');
		define ('PDF_PAGE_FORMAT', 'A4');
		define ('PDF_PAGE_ORIENTATION', 'P');
		define ('PDF_CREATOR', 'BFSurvey Applicaiton');
		define ('PDF_AUTHOR', $siteName);
		define ('PDF_UNIT', 'mm');
		define ('PDF_MARGIN_HEADER', 5);
		define ('PDF_MARGIN_FOOTER', 10);
		define ('PDF_MARGIN_TOP', 27);
		define ('PDF_MARGIN_BOTTOM', 25);
		define ('PDF_MARGIN_LEFT', 15);
		define ('PDF_MARGIN_RIGHT', 15);
		define ('PDF_FONT_NAME_MAIN', 'dejavusans');
		define ('PDF_FONT_SIZE_MAIN', 8);
		define ('PDF_FONT_NAME_DATA', 'dejavusans');
		define ('PDF_FONT_SIZE_DATA', 8);
		define ('PDF_FONT_MONOSPACED', 'dejavusansmono');
		define ('PDF_IMAGE_SCALE_RATIO', 1.25);
		define('HEAD_MAGNIFICATION', 1.1);
		define('K_CELL_HEIGHT_RATIO', 1.25);
		define('K_TITLE_MAGNIFICATION', 1.3);
		define('K_SMALL_RATIO', 2/3);
		define('K_THAI_TOPCHARS', true);
		define('K_TCPDF_CALLS_IN_HTML', false);

		require_once JPATH_ADMINISTRATOR . '/components/com_bfsurvey/assets/tcpdf/tcpdf.php';

		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor(PDF_AUTHOR);
		$pdf->SetTitle('Report');
		$pdf->SetSubject('Report');

		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

		$pdf->setHeaderFont(array('dejavusans', '', 8, '', false));
		$pdf->setFooterFont(array('dejavusans', '', 8, '', false));
		$pdf->SetFont('dejavusans', '', 8, '', false);

		return $pdf;
	}
}