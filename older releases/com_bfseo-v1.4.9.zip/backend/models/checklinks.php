<?php
/**
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelChecklinks extends F0FModel
{
	public $pageTitle;
	public $url;

	public function check($url)
	{
		$this->url = $url;
		$results['url'] = $url;

		$html = file_get_contents($url);

		if (empty($html)) {
			//file_get_contents didn't work, so lets try using CURL instead
			$html = bfseoHelper::url_get_contents($url);
		}

		if (empty($html)) {
			return false;
		}
		libxml_use_internal_errors(true);

		$dom = new DOMDocument();
		$dom->loadHTML($html);
		$xpath = new DOMXpath($dom);

		$anchors = $this->findUrls($xpath->query("//a[@href]"), 'href');
		$images  = $this->findUrls($xpath->query("//img[@src]"), 'src');
		$links   = $this->findUrls($xpath->query("//link[@href and @rel='stylesheet']"), 'href');
		$scripts = $this->findUrls($xpath->query("//script[@src]"), 'src');

		$results['pages'] = $this->parseStatus($this->fetchUrls($anchors));
		$results['images'] = $this->parseStatus($this->fetchUrls($images));
		$results['links'] = $this->parseStatus($this->fetchUrls($links));
		$results['scripts'] = $this->parseStatus($this->fetchUrls($scripts));

		sort($results['pages']);
		sort($results['images']);
		sort($results['links']);
		sort($results['scripts']);

		return $results;

	}

	function parseStatus($urls)
	{
		$results = array();
		foreach ($urls as $url => $content) {
			if (empty($content)) {
				$results[] = '500|'.$url;
			}
			// Note: Seems some server will return 404 based on (or no) user agent
			// Note2: Parked domains will return 200 OK
			if (strpos($content, " 404 Not Found") !== false) {
				$results[] = '404|'.$url;

			} else if (strpos($content, " 301 Moved") !== false) {
				$results[] = '301|'.$url;

			} else if (strpos($content, " 302 Found") !== false) {
				$results[] = '302|'.$url;

			} else if (strpos($content, " 200 OK") !== false) {
				$results[] = '200|'.$url;
			}
		}
		return $results;
	}

	function findUrls($links, $attrib)
	{
		$urls = array();
		$host = parse_url($this->url);
		$host = $host['scheme']."://".$host['host'].'/';

		foreach ($links as $link) {

			$url = $link->getAttribute($attrib);
			$parsedUrl = parse_url($url);

			if ($url == '/' || strpos($url, '#') !== false || empty($parsedUrl) || strpos($url, 'dns-prefetch') !== false) {
				continue;
			}
			if (isset($parsedUrl['scheme']) && ($parsedUrl['scheme'] == 'javascript' || $parsedUrl['scheme'] == 'mailto') ) {
				continue;
			}
			if (!isset($parsedUrl['host'])) {
				$path = $link->getAttribute($attrib);

				if (strpos($path, '/') === 0) {
					$url = $host . $path;	// relative path
				} else {
					$url = $this->url . $path;
				}
				// remove duplicate slash in path
				$url = preg_replace('%([^:]\/)\/+%i', '$1', $url);

			} else {
				// protocol relative url
				if (strpos($url, '//') === 0) {
					$_host = parse_url($this->url);
					if (isset($_host['scheme'])) {
						$url = str_replace('//', $_host['scheme'].'://', $url);
					} else {
						continue;
					}
				}
			}
			$urls[] = $url;
		}
		return $urls;
	}

	function fetchUrls($urls)
	{
		$result = array();
		$chs = array();
		$mh = curl_multi_init();

		foreach ($urls as $url) {
			$ch = curl_init();
			$chs[$url] = $ch;

			//curl_setopt($c, CURLOPT_USERAGENT, 'BF SEO Link Checker');
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false); 	// Set option to follow?
			curl_setopt($ch, CURLOPT_MAXREDIRS , 1);
			curl_setopt($ch, CURLOPT_HEADER, true);
			curl_setopt($ch, CURLOPT_NOBODY, true);
			curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'HEAD');
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

			curl_multi_add_handle($mh, $ch);
		}

		$active = 0;
		do {
			$status = curl_multi_exec($mh, $active);

		} while ($status === CURLM_CALL_MULTI_PERFORM || $active);

		foreach ($chs as $url => $ch) {
			$result[$url] = curl_multi_getcontent($ch);
			curl_multi_remove_handle($mh, $ch);
		}
		curl_multi_close($mh);

		return $result;
	}
}
