<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class BFSEOController extends JControllerLegacy
{

	public function display($cachable = false, $urlparams = false)
	{
		parent::display();
	}

}

