CREATE TABLE IF NOT EXISTS `#__bfseo_urls` (
	`bfseo_urls_id` bigint(20) unsigned not null auto_increment,
	`url` text not null,
	`new_url` text not null,	
	`status` smallint(6) not null,
	`title` varchar(50) not null,
	`depth` tinyint(4) not null,
	`score` text not null,
	`seen` tinyint(4) not null,
	`created` datetime not null default '0000-00-00 00:00:00',
	`modified` datetime not null default '0000-00-00 00:00:00',	
	`menu_id` int(11) null default null,
	`cat_id` int(11) null default null,
	`article_id` int(11) null default null,
	`redir_status` smallint(6) not null default '301',
	`hits` int(11) not null default '0',
	`published` tinyint(4) not null default '1',
	PRIMARY KEY (`bfseo_urls_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__bfseo_404s` (
	`bfseo_404_id` bigint(20) unsigned not null auto_increment,
	`title` text not null,
	`lang` tinytext not null,
	`html` text not null,
	`published` tinyint(4) not null default '1',
	PRIMARY KEY (`bfseo_404_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;