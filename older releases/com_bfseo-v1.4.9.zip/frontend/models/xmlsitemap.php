<?php
/**
 *  @package BF SEO
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfseoModelXmlsitemap extends F0FModel
{
	static function getMenuItems()
	{
		$router = JSite::getRouter();

		//which menu items should we use in our sitemap
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('sitemap_menus');
		$query->from('#__bfseo_xmlsitemap');
		$query->where('bfseo_xmlsitemap_id = 1');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$sitemapsetting = $db->loadResult();

		$query->clear();
		$query = $db->getQuery(true);
		$query->select('#__menu.id, #__menu.title, #__menu.params, #__menu.link, #__menu.type, #__menu.home');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('#__menu.menutype = #__menu_types.menutype');
		if(isset($sitemapsetting)){
			$query->where('#__menu_types.id IN ('.$db->quote($sitemapsetting).')');
		}
		$db->setQuery($query);

		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		//now for articles get last modified date
		$counter=0;
		foreach ($rows as $menu):
			if (strpos($menu->link, 'article') !== false && strpos($menu->link, 'id') !== false) {
				$pieces = explode("=", $menu->link);
				$id = $pieces[3];
				$modified='';

				if($id){
					$query->clear();
					$query->select('modified');
					$query->from('#__content');
					$query->where('id = '.(int)$id);

					$db->setQuery($query);
					$db->query();
					if ($db->getErrorNum()) {

					}
					$modified = $db->loadResult();
				}

				//put date in correct format
				if($modified != '0000-00-00 00:00:00')
				{
					$date =  new JDate($modified);
					$modified = $date->toUnix();

					if ($modified) {
						$modified = gmdate('Y-m-d\TH:i:s\Z', $modified);
					}

					$rows[$counter]->modified = $modified;
				}
			}

			// escape the characters
			$rows[$counter]->link = preg_replace('/&/', '&amp;', $rows[$counter]->link);
			$rows[$counter]->link = preg_replace('/\'/', '&apos;', $rows[$counter]->link);
			$rows[$counter]->link = preg_replace('/"/', '&quot;', $rows[$counter]->link);
			$rows[$counter]->link = preg_replace('/>/', '&gt;', $rows[$counter]->link);
			$rows[$counter]->link = preg_replace('/</', '&lt;', $rows[$counter]->link);

			switch ($rows[$counter]->type)
			{
				case 'separator':
				case 'heading':
					break;
				case 'url':
					if ((strpos($rows[$counter]->link, 'index.php?') === 0) && (strpos($rows[$counter]->link, 'Itemid=') === false)) {
						// internal Joomla link so make sure the Itemid is set.
						$rows[$counter]->link = $rows[$counter]->link.'&Itemid='.$rows[$counter]->id;
						break;
					}
					$rows[$counter]->link='';
					break;
				case 'alias':
					// alias so use the item id stored in the parameters to make the link.
					$params = json_decode($rows[$counter]->params, true);
					$rows[$counter]->link = 'index.php?Itemid='.$params['aliasoptions'];
					break;
				default:
					if ($router->getMode() == JROUTER_MODE_SEF) {
						$rows[$counter]->link = 'index.php?Itemid='.$rows[$counter]->id;
					}
					elseif (!$rows[$counter]->home) {
						$rows[$counter]->link .= '&Itemid='.$rows[$counter]->id;
					}
					break;
			}

			$counter++;
		endforeach;

		return $rows;
	}

	static function getCategoryItems()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('sitemap_categories');
		$query->from('#__bfseo_xmlsitemap');
		$query->where('bfseo_xmlsitemap_id = 1');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$results = $db->loadResult();

		if (empty($results)) {
			return array();
		}

		$query = $db->getQuery(true);
		$query->select('#__content.id, modified, catid');
		$query->from('#__categories');
		$query->innerJoin('#__content');
		$query->where('extension="com_content"');
		$query->where('#__content.catid = #__categories.id');
		$query->where('#__categories.id IN ('.$db->escape($results).')');

		$db->setQuery($query);

		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		$counter = 0;
		foreach ($rows as $row) {
			if ($row->modified != '0000-00-00 00:00:00') {
				$date = new JDate($row->modified);
				$modified = $date->toUnix();
				if ($modified) {
					$modified = gmdate('Y-m-d\TH:i:s\Z', $modified);
				}
				$rows[$counter]->modified = $modified;
			} else {
				unset($rows[$counter]->modified);
			}

			//get menu Itemid
			$rows[$counter]->Itemid = BfseoModelXmlsitemap::getMenuItemid($row->id, $row->catid);

			$counter++;
		}
		return $rows;
	}

	static function getMenuItemid($id, $catid)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//are there any single articles menus pointing to this
		$query->select('#__menu.id, #__menu.title, #__menu.params, #__menu.link, #__menu.type, #__menu.home');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('link=\'index.php?option=com_content&view=article&id='.(int)$id.'\'');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$Itemid = $db->loadResult();

		if($Itemid == null)
		{
			$Itemid = 0;
		}
		else
		{
			// we don't want duplicate content, so let's not include this one in the sitemap
			return -1;
		}

		//is this part of a category blog
		$query->clear();
		$query = $db->getQuery(true);
		$query->select('#__menu.id, #__menu.title, #__menu.params, #__menu.link, #__menu.type, #__menu.home');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('link=\'index.php?option=com_content&view=category&layout=blog&id='.(int)$catid.'\'');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$Itemid = $db->loadResult();

		if($Itemid == null)
		{
			$Itemid = 0;
		}
		else
		{
			return $Itemid;
		}

		//is this part of a category list
		$query->clear();
		$query = $db->getQuery(true);
		$query->select('#__menu.id, #__menu.title, #__menu.params, #__menu.link, #__menu.type, #__menu.home');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('link=\'index.php?option=com_content&view=category&id='.(int)$catid.'\'');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$Itemid = $db->loadResult();

		if($Itemid == null)
		{
			$Itemid = 0;
		}
		else
		{
			return $Itemid;
		}

		//is this part of list all categories
		$query->clear();
		$query = $db->getQuery(true);
		$query->select('#__menu.id, #__menu.title, #__menu.params, #__menu.link, #__menu.type, #__menu.home');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('link=\'index.php?option=com_content&view=categories&id=0\'');

		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$Itemid = $db->loadResult();

		if($Itemid == null)
		{
			$Itemid = 0;
		}
		else
		{
			return $Itemid;
		}

		return $Itemid;
	}
}