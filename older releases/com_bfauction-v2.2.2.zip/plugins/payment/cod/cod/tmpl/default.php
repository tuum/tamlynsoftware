<? defined('_JEXEC') or die('Restricted access'); ?>

<form class='form-horizontal' method='post'>
	<div>
		<input type='hidden' name='orderId' value='<?php echo $vars->order_id ?>' />
		<input type='hidden' name='option' value='com_bfauction' />
		<input type='hidden' name='task' value='update' />
		<input type='hidden' name='view' value='payments' />
		<input type='submit' class='btn btn-success' value='<?php echo JText::_('SUBMIT') ?>'/>
	</div>
</form>

