<?php
/*
 * @package BF Auction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

class bfauctionControllerAuctions extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'auctions';
	}

	/*
	 * AJAX lookup of current bid for bid view
	*/
	function luCurrentBid(){
		$app = JFactory::getApplication();
		$params = $app->getParams();
		$dateFormat = $params->get( 'dateFormat' );

		$itemid=JRequest::getVar( 'itemid');

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('currentBid');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id='.(int)$itemid);
		$db->setQuery((string)$query);

		$currentBid=$db->loadResult();
		if($currentBid){
			//do nothing as returned value is ok
		}else{
			$currentBid=JText::_('COM_BFAUCTION_ERROR_LIST_NOT_EXIST');
		}

		$query->clear();
		$query->select('endDate');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id='.(int)$itemid);
		$db->setQuery((string)$query);
		$endDate=$db->loadResult();

		$query->clear();
		$query->select('highBidder');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id='.(int)$itemid);
		$db->setQuery((string)$query);
		$highBidder=$db->loadResult();

		$user = JFactory::getUser();
		if($highBidder == $user->username){
			$highBidder = JText::_('COM_BFAUCTION_YOU_ARE_CURRENT_BIDDER');
		}else{
			$highBidder = substr($highBidder, 0, 1).'******'.substr($highBidder, -1);
		}

		// is dst on on that particular date ?
		$now = JFactory::getDate();
		$date=$now->format('Y-m-d H:i:s');
		if (is_numeric( $date)) {
			$ts = $date;
		} else {
			$ts = strtotime( $date . ' UTC');
		}
		$dst = date( 'I', $ts);

		$app = JFactory::getApplication();

		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$currentDate = $now->toSql();
		}else{
			$currentDate = $now->toMySQL();
		}

		$secondsDiff = 0;
		if($currentDate > $endDate){

			$query->clear();
			$query->select('winEmailDate');
			$query->from('#__bfauction_items');
			$query->where('bfauction_item_id='.(int)$itemid);
			$db->setQuery((string)$query);
			$winEmaildate=$db->loadResult();

			if ($winEmaildate == "0000-00-00 00:00:00") {
				$query = $db->getQuery(true);
				$query->update('#__bfauction_items');
				$query->set('winEmailSent = 1');
				$query->set('winEmailDate = ' . "'$currentDate'");
				$query->where('bfauction_item_id = ' . (int)$itemid);
				$db->setQuery((string)$query);
				$db->query();
			}

			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_AUCTION_HAS_ENDED') );

		}else{
			$endDateAsSeconds = strtotime($endDate);
			$currentDateAsSeconds = strtotime($currentDate);

			$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
		}

		$remainingDay     = floor($secondsDiff/60/60/24);
		$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
		$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
		$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

		// we'll generate XML output
		header('Content-Type: text/xml');
		// generate XML header
		$return = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

		// create the <response> element
		$return .= "<response>";

		$return .= "<myBid>";
		// generate output
		$return .= htmlentities($currentBid);
		$return .= "</myBid>";

		$return .= "<myBidder>";
		$return .= htmlentities($highBidder);
		$return .= "</myBidder>";

		$return .= "<myDate>";
		$return .= htmlentities( JHTML::_('date',  $endDate, $dateFormat ) );
		$return .= "</myDate>";

		$return .= "<myDay>";
		$return .= htmlentities($remainingDay);
		$return .= "</myDay>";

		$return .= "<myHour>";
		$return .= htmlentities($remainingHour);
		$return .= "</myHour>";

		$return .= "<myMin>";
		$return .= htmlentities($remainingMinutes);
		$return .= "</myMin>";

		$return .= "<mySec>";
		$return .= htmlentities($remainingSeconds);
		$return .= "</mySec>";

		// close the <response> element
		$return .= "</response>";

		echo $return;
		$app->close();
	}

	function mybid()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'bid', 0, '', 'float' );
		$bidIncrement 	= JRequest::getVar( 'bidIncrement', 1, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );
		$quantityPurchased = JRequest::getVar( 'quantityPurchased', 1, '', 'int' );
		$deliveryOption = JRequest::getVar( 'deliveryOption', '', '', 'string' );
		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$currentDate = $now->toSql();
		}else{
			$currentDate = $now->toMySQL();
		}
		$params = JFactory::getApplication()->getParams();

		$allowEmail = $params->get('allowEmail');
		$bfcurrency = $params->get('bfcurrency', '$');
		$reverseAuction = $params->get('reverseAuction');
		$increaseEndTime = $params->get('increaseEndTime');
		$increaseEndTimeLastMinutes = $params->get('increaseEndTimeLastMinutes');
		$increaseEndTimeAmount = $params->get('increaseEndTimeAmount');
		$allowAutoBidding = $params->get( 'allowAutoBidding' );
		$allowOverBidding = $params->get( 'allowOverBidding' );
		$autobid = 0;

		if ($itemId==0 | $bid < $bidIncrement)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_PROCESSING_BID') );
			$msg="";
			$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
		}else {
			$user = JFactory::getUser();
			$userusername = $user->username;
			$userid = $user->id;
			$useremail = $user->email;

			$now = JFactory::getDate()->format('Y-m-d H:i:s');

			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_items');
			$query->where('enabled = 1 and bfauction_item_id = '.(int)$itemId);
			$query->order('title');
			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
			$myresult=$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
			} elseif($allowOverBidding==0 && $userusername == $myresult->highBidder) {
				//when allow over bidding is turned off, don't allow user to out bid themselves
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_OVERBIDDING') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
			} else {
				//-------------------------------------
				$maxbid=0;
				if($allowAutoBidding){
					//are there any automatic bids for this item?
					$db			= JFactory::getDBO();

					$query->clear();
					$query->select('a.username, a.created_by, a.email, a.bid, a.maxbid, a.itemid, a.id');
					$query->from('#__bfauction_items_bid AS a');
					$query->where('a.itemid='.(int)$itemId);
					$query->where('a.maxbid>0');
					$query->order('a.bfauction_item_id DESC');
					$db->setQuery((string)$query);
					$autobidrows = $db->loadObjectList();
					if ($db->getErrorNum())
					{
						echo $db->stderr();
						return false;
					}
					if($autobidrows){
						$maxbid = $autobidrows[0]->maxbid;
					}
				}

				//-------------------------------------
				if (($bid >= ($myresult->currentBid + ((float)$bidIncrement)) & $reverseAuction==0) | ($reverseAuction & $bid <= ($myresult->currentBid - ((float)$bidIncrement))) | ($bid >= $myresult->currentBid & $reverseAuction==0 & $myresult->highBidder == '0' & $bid>(float)$bidIncrement) )
				{
					if($allowAutoBidding){
						//need to check that current bid is greater than maxbid of previous bidder
						//this code doesn't support reverse auction
						if($bid >= ($maxbid + (float)$bidIncrement) ){
						//new bidder is now winning. Need to set bid to current bid, and set the max bid
						$maxbid = $bid;
						if($maxbid >= ($myresult->currentBid + (float)$bidIncrement) ){
						//$bid = $myresult->currentBid + (float)$bidIncrement;
							$bid = $myresult->currentBid;
							if($bid == 0){
							$bid = (float)$bidIncrement;
							}

							//now check that bid is higher than previous maxbid
							if($bid > $autobidrows[0]->maxbid){
							//all good
						}else{
							$bid = $autobidrows[0]->maxbid + (float)$bidIncrement;
							if($bid > $maxbid){
							JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_LOWER') );
										$this->setRedirect( 'index.php?option=com_bfauction&view=auction&cid='.$itemId.'&Itemid='.$Itemid, $msg );
							}
							}
							}else{
							JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_LOWER') );
								$this->setRedirect( 'index.php?option=com_bfauction_plus&view=auction&cid='.$itemId.'&Itemid='.$Itemid, $msg );
							}

							//now proceed as per normal
							$msg = JText::_( 'COM_BFAUCTION_BID_CONFIRMED' );
						}else{
							//current bid is lower. Need to write this bid to history, then automatically add new bid for person with automatic bid.
							$db			= JFactory::getDBO();
							$autobid = 1;

							//this bit is changed as of 22/09/2013, no longer write this bid to history, only put the next automatic bid
							//write new bid to db
							//$tempmaxbid = 0;
							//$query->clear();
							//if(is_callable(array('JDatabaseQuery', 'columns'))){
							//	$query->insert('#__bfauction_plus_bid');
							//	$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('uid'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
							//	$query->values( (int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$user->id.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(float)$tempmaxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
							//}else{
							//	//joomla 1.6
							//	$query = 'INSERT INTO #__bfauction_plus_bid (`itemid`, `username`, `uid`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
							//		. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$tempmaxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
							//		;
							//}
							//
							//$db->setQuery( $query );
							//if (!$db->query())
							//{
							//	echo $db->getErrorMsg();
							//	return false;
							//}

							//now set up automatic bid
							$userusername = $autobidrows[0]->username;
							$userid = $autobidrows[0]->created_by;
							$useremail = $autobidrows[0]->email;
							$maxbid = $autobidrows[0]->maxbid;
							//now figure out what the current bid is
							//is maxbid greater than currentBid + increment
							if(($maxbid + (float)$bidIncrement) > $bid ){
								if($bid > $maxbid){
									$bid = $maxbid;
								}else{
									$bid = $bid;
								}
							}else{
								$bid = $maxbid;
								$maxbid = 0;
							}

							JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_LOWER') );
						}
					}

					$db = JFactory::getDbo();
					$query	= $db->getQuery(true);

					$query->update('#__bfauction_items');
					$query->set('currentBid = '.(float)$bid);
					$query->set('highBidder = '.$db->quote( $db->escape($userusername), false ) );
					$query->set('tax = '.(float)$tax);
					$query->set('commission = '.(float)$commission);
					$query->set('saleType = 1');
					$query->set('quantityPurchased = '.(int)$quantityPurchased);
					$query->set('deliveryOption = '.$db->quote( $db->escape($deliveryOption), false ) );
					$query->where('bfauction_item_id = '.(int)$itemId);

					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}

					$query->clear();
					if(is_callable(array('JDatabaseQuery', 'columns'))){
						$query->insert('#__bfauction_bids');
						$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('created_by'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('maxbid'), $db->quoteName('quantity'), $db->quoteName('deliveryOption') ));
						$query->values( (int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(float)$maxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
					}else{
						//joomla 1.6
						$query = 'INSERT INTO #__bfauction_bids (`itemid`, `username`, `created_by`, `email`, `bid`, `bid_time`, `bidCurrency`, `tax`, `commission`,`maxbid`, `quantity`, `deliveryOption`)'
						. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($userusername), false ).', '.(int)$userid.', '.$db->quote( $db->escape($useremail), false ).', '.(float)$bid.',  "'.$currentDate.'", "'.$bfcurrency.'", '.(float)$tax.', '.(float)$commission.', '.(float)$maxbid.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
							;
					}
					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}

					$bidId=$db->insertid();

					if($autobid == 1){
						// don't show bid confirmed message when automatic bid is being placed, but show the rest of the time.
						$msg = '';
					}else{
						$msg = JText::_( 'COM_BFAUCTION_BID_CONFIRMED' );
					}

					//add item to watchlist
					$this->watchlist( (int)$itemId );

					//now see if time needs to be added to end time
					if($increaseEndTime){
						//how much time left?
						$secondsDiff = strtotime($myresult->endDate) - strtotime($currentDate);  //convert to unix time (number of seconds) and work out difference
						$remainingMinutes = floor(($secondsDiff)/60);

						if( ($remainingMinutes -1) < $increaseEndTimeLastMinutes ){
							$timestamp = strtotime($currentDate) + $increaseEndTimeAmount*60;
							$newEndTime = date('Y-m-d H:i:s', $timestamp);

							$db = JFactory::getDbo();
							$query	= $db->getQuery(true);

							$query->update('#__bfauction_items');
							$query->set('endDate = '.$db->quote( $db->escape($newEndTime), false ));
							$query->where('bfauction_item_id = '.(int)$itemId);
							$db->setQuery((string)$query);
							$db->query();
							if ($db->getErrorNum())
							{
								echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
								return;
							}

							$msg .= "<br>".JText::_( 'COM_BFAUCTION_BID_TIMEINCREASED' );
						}

					}

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						BfauctionDispatcher::triggerEmails("BidConfirm", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						BfauctionDispatcher::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}
				} else {
					if($reverseAuction){
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_HIGHER') );
					}else{
						JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_LOWER') );
					}
					$msg="";
					$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auction&id='.$itemId, false), $msg );
				}
			}
		}

		$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auction&id='.$itemId, false), $msg );
	}

	function watchlist($id = null)
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user = JFactory::getUser();
		$userid = $user->id;

		if($id){
			$itemId = $id;
		}else{
			$itemId = JRequest::getVar( 'cid', 0, '', 'int' );
		}

		$db	= JFactory::getDBO();

		$query = 'INSERT INTO #__bfauction_watchlists (`itemid`, `created_by`)'
			   . ' VALUES ('.(int)$itemId.', '.(int)$userid.')';

		$db->setQuery( $query );
		if (!$db->query()) {
			echo $db->getErrorMsg();
			return false;
		}

		$menu = JFactory::getApplication()->getMenu();
		$menuItem = $menu->getItems('link', 'index.php?option=com_bfauction&view=watchlists', true);

		$msg = JText::_('COM_BFAUCTION_WATCHLIST_CONFIRMED');
		$task = JRequest::getVar('task');

		if ($task == 'auctions.watchlist') {
			$this->setRedirect( 'index.php?option=com_bfauction&view=watchlists&Itemid='.$menuItem->id, $msg );
		} else {
			$this->setRedirect( 'index.php?option=com_bfauction&view=auction&cid='.$itemId.'&Itemid='.$menuItem->id, $msg );
		}

	}

	function watchlistDelete()
	{
		//check form is submitted from our site
		JRequest::checkToken() or die( 'Invalid Token' );

		$user = JFactory::getUser();
		$userid = $user->id;

		//$id = JRequest::getVar( 'id', 0, 'POST', 'int' );
		$id = JFactory::getApplication()->input->get('id', 0,'INT');
		$Itemid = JRequest::getVar('Itemid');

		$db			= JFactory::getDBO();

		$query = 'DELETE FROM #__bfauction_watchlists WHERE `itemid`='.(int)$id.' AND `created_by`='.(int)$userid
		;

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		$msg = JText::_( 'COM_BFAUCTION_WATCHLIST_DELETED' );
		$this->setRedirect( 'index.php?option=com_bfauction&view=watchlists&id='.$id.'&Itemid='.$Itemid, $msg );
	}

	function commitBuyNow(){
		$app = JFactory::getApplication();
		$itemId 		= JRequest::getVar( 'cid', 0, '', 'int' );
		$bid 			= JRequest::getVar( 'buyNowPrice', 0, '', 'float' );
		$tax 			= JRequest::getVar( 'tax', 0, '', 'float' );
		$commission		= JRequest::getVar( 'commission', 0, '', 'float' );
		$quantityPurchased = JRequest::getVar( 'quantityPurchased', 1, '', 'int' );
		$deliveryOption = JRequest::getVar( 'deliveryOption', '', '', 'string' );

		$app		= JFactory::getApplication();
		$params		= $app->getParams();
		$allowEmail = $params->get('allowEmail');
		$bfcurrency = $params->get('bfcurrency');

		if($bfcurrency == ""){
			$bfcurrency = "$";
		}
		$dst_fix = $params->get('dst');

		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$currentDate = $now->toSql();
		}else{
			$currentDate = $now->toMySQL();
		}

		if ($itemId==0 | $bid < 0.01)
		{
			JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_PROCESSING_BID') );
			$msg="";
			$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
		} else {
			$user = JFactory::getUser();

			//$now = JFactory::getDate()->format('Y-m-d H:i:s');

			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_items');
			$query->where('enabled = 1');
			$query->where('bfauction_item_id = '.(int)$itemId);
			$query->order('title');
			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
			$myresult=&$rows[0];

			if ($currentDate > $myresult->endDate)
			{
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_AUCTION_ENDED') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
			}elseif($quantityPurchased > $myresult->quantity){
				JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_INCORRECT_QTY') );
				$msg="";
				$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions', false), $msg );
			}else{
				if ($bid > $myresult->currentBid )
				{
					$db = JFactory::getDbo();
					$query	= $db->getQuery(true);

					$query->update('#__bfauction_items');
					$query->set('currentBid = '.(float)$bid);
					$query->set('highBidder = '.$db->quote( $db->escape($user->username), false ));
					$query->set('tax = '.(float)$tax);
					$query->set('commission = '.(float)$commission);
					$query->set('endDate = '.$db->quote($currentDate, false ));
					$query->set('saleType = 2');
					$query->set('quantityPurchased = '.(int)$quantityPurchased );
					$query->set('quantity = '.(int)$quantityPurchased );
					$query->set('deliveryOption = '.$db->quote($deliveryOption, false ) );
					$query->set('winEmailSent = 2');
					$query->set('winEmailDate = '."'$currentDate'");
					$query->where('bfauction_item_id = '.(int)$itemId);

					$db->setQuery((string)$query);
					$db->query();
					if (!$db->query())
					{
						echo $db->getErrorMsg();
						return false;
					}

					$query->clear();
					if(is_callable(array('JDatabaseQuery', 'columns'))){
						$query->insert('#__bfauction_bids');
						$query->columns(array($db->quoteName('itemid'), $db->quoteName('username'), $db->quoteName('created_by'), $db->quoteName('email'), $db->quoteName('bid'), $db->quoteName('bid_time'), $db->quoteName('bidCurrency'), $db->quoteName('tax'), $db->quoteName('commission'), $db->quoteName('quantity'), $db->quoteName('deliveryOption')));
						$query->values((int)$itemId.', '.$db->quote( $db->escape($user->username), false ).', '.(int)$user->id.', '.$db->quote( $db->escape($user->email), false ).', '.(float)$bid.', '.$db->quote($currentDate, false ).', '.$db->quote($bfcurrency, false ).', '.(float)$tax.', '.(float)$commission.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ) );
					}else{
						//joomla 1.6
						$query = 'INSERT INTO #__bfauction_bids (`itemid`, `username`, `email`, `bid`, `bidCurrency`, `bid_time`, `tax`, `commission`, `quantity`, `deliveryOption`)'
								. ' VALUES ('.(int)$itemId.', '.$db->quote( $db->escape($user->username), false ).', '.$db->quote( $db->escape($user->email), false ).', '.(float)$bid.', '.$db->quote($bfcurrency, false ).', "'.$currentDate.'", '.(float)$tax.', '.(float)$commission.', '.(int)$quantityPurchased.', '.$db->quote( $db->escape($deliveryOption), false ).')'
										;
					}
					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}
					$bidId=$db->insertid();

					$msg = JText::_( 'COM_BFAUCTION_BUY_NOW_PURCHASE' );

					//send email confirmation
					if($allowEmail){
						//Prepare notification emails
						//----------------------BID CONFIRM---------------------------------------------
						BfauctionDispatcher::triggerEmails("BuyNow", $itemId, $bidId);
						//----------------------ENDBID CONFIRM---------------------------------------------
						//----------------------OUTBID---------------------------------------------
						BfauctionDispatcher::triggerEmails("Outbid", $itemId, $bidId);
						//----------------------END OUTBID---------------------------------------------
					}

					//for multiple quantity items, is there still some available?
					$newQuantity = $myresult->quantity - $quantityPurchased;
					if($newQuantity > 1){
						JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_bfauction/tables');
						$row = JTable::getInstance('item', 'Table');
						$id = $myresult->bfauction_item_id;

						$row->load((int) $id);
						//exitsting item is archived and new copy is created with unique id.
						$row->bfauction_item_id	= "";
						$row->enabled     	= 1;
						$row->highBidder	= "";
						$row->currentBid	= 0;
						$row->ordering 		= 0;
						$row->winEmailSent	= 0;
						$row->winEmailDate = '0000-00-00 00:00:00';
						$row->saleType 	= 0;
						$row->endDate = $myresult->endDate;
						$row->quantityPurchased = 0;
						$row->deliveryOption = "";

						if($row->relistid == 0){
							$row->relistid = (int) $id;

							//Use images from original item.
							$row->imageShared = (int) $id;
						}
						$row->quantity		= (int)$newQuantity;

						if (!$row->check()) {
							return JError::raiseWarning(500, $row->getError());
						}
						if (!$row->store()) {
							return JError::raiseWarning(500, $row->getError());
						}
					}
				} else {
					JError::raiseWarning( 500, JText::_( 'COM_BFAUCTION_ERROR_BID_NOT_ACCEPTED_LOWER') );
					$msg="";
					$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auctions&id='.$itemId, false), $msg );
				}
			}
		}
		$this->setRedirect( JRoute::_('index.php?option=com_bfauction&view=auction&id='.$itemId, false), $msg );
	}
}