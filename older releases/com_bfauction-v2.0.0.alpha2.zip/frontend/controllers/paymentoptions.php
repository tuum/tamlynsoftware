<?php
/**
 *  @package bfauction
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionControllerPaymentoptions extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'orders';
	}

	public function showPaymentOptions() {
		$view = $this->getView('paymentoption', 'html');
		$this->data = $_POST;
		$view->assignRef('data', $data);
		$view->display();
		//$this->setRedirect(JRoute::_('index.php?option=com_bfauction&view=paymentoptions', false));
	}
}