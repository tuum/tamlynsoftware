<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<script language="javascript" type="text/javascript">
<!--

function round(n,dec) {
	n = parseFloat(n);
	if(!isNaN(n)){
		if(!dec) var dec= 0;
		var factor= Math.pow(10,dec);
		var result = Math.floor(n*factor+((n*factor*10)%10>=5?1:0))/factor;
		return result.toFixed(2);
	}else{
		return n;
	}
}

function process()
{
	includeCommission = <?php echo $this->cparams->includeCommission ? $this->cparams->includeCommission : 0; ?>;
	commissionAmount = <?php echo $this->cparams->commissionAmount; ?>;
	includeTax = <?php echo $this->cparams->includeTax ? $this->cparams->includeTax : 0; ?>;
	taxableItem = <?php echo $this->cparams->taxableItem; ?>;
	taxAmount = <?php echo $this->cparams->taxAmount; ?>;
	userId = <?php echo $user->id; ?>;
	showTotalPrice = <?php echo $this->cparams->showTotalPrice ? $this->cparams->showTotalPrice : 0; ?>;
	currentBid = <?php echo $this->form->getValue('currentBid') ? $this->form->getValue('currentBid') : 0; ?>;
	nextBid = <?php echo $nextBid ? $nextBid : 0; ?>;
	quantity = <?php echo $this->form->getValue('quantity') ? $this->form->getValue('quantity') : 1; ?>;

	if(includeCommission == "1"){
		commission = round( ( parseFloat(nextBid) * parseFloat(commissionAmount) ) / 100, 2 );
		document.getElementById("divCommission").innerHTML =commission;
		document.getElementById("commission").value = commission;

		commissionCurrent = round( ( parseFloat(currentBid) * parseFloat(commissionAmount) ) / 100, 2 );
		document.getElementById("divCommissionCurrent").innerHTML =commissionCurrent;
	}else{
		commission = 0;
		commissionCurrent = 0;
	}

	if(includeTax){
		if(taxableItem){
			tax = round( ( ( parseFloat(nextBid) + parseFloat(commission) ) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( ( parseFloat(currentBid) + parseFloat(commissionCurrent) ) * parseFloat(taxAmount) ) / 100, 2 );
		}else{
			/* tax commission only */
			tax = round( ( parseFloat(commission) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( parseFloat(commissionCurrent) * parseFloat(taxAmount) ) / 100, 2 );
		}
		document.getElementById("divTax").innerHTML = tax;
		document.getElementById("tax").value = tax;
		document.getElementById("divTaxCurrent").innerHTML = taxCurrent;
	}else{
		tax = 0;
		taxCurrent = 0;
	}

	if(showTotalPrice){
		shipping = <?php echo $this->form->getValue('shipping');?>;
		totalPrice = round( (parseFloat(nextBid) + parseFloat(shipping) + parseFloat(commission) + parseFloat(tax) ) ,2 );

		quantityPurchased = document.getElementById("quantityPurchased").value;

		if(parseFloat(quantityPurchased) > parseFloat(quantity)){
			document.getElementById("quantityPurchased").value = quantity;
			quantityPurchased = quantity;
		}

		if(parseFloat(quantityPurchased) > 1){
			totalPrice = totalPrice * parseFloat(quantityPurchased);
		}

		document.getElementById("divTotalPrice").innerHTML = totalPrice;
	}

	/* restart sequence (runs every 10 seconds) */
	setTimeout('process()', 10000);
}


//-->
</script>