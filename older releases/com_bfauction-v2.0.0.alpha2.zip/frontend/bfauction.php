<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

// Load F0F
include_once JPATH_LIBRARIES.'/f0f/include.php';
if(!defined('F0F_INCLUDED')) {
	JError::raiseError ('500', 'F0F is not installed');
}

// Load TJCPG
$path = JPATH_COMPONENT.DIRECTORY_SEPARATOR.'helpers'.DIRECTORY_SEPARATOR."tjcpg.php";
if(!class_exists('tjcpgHelper')) {  
   JLoader::register('tjcpgHelper', $path);
   JLoader::load('tjcpgHelper');
}

F0FDispatcher::getTmpInstance('com_bfauction')->dispatch();