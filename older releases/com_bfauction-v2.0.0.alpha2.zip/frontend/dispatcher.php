<?php
defined('_JEXEC') or die();

class BfauctionDispatcher extends F0FDispatcher
{
	public function onBeforeDispatch() {
		$result = parent::onBeforeDispatch();

		if($result) {
			// Load Akeeba Strapper
			include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
			AkeebaStrapper::bootstrap();
			AkeebaStrapper::jQueryUI();
			AkeebaStrapper::addCSSfile('media://com_bfauction/css/frontend.css');
			F0FTemplateUtils::addCSS('media://com_bfauction/css/lytebox.css');
			F0FTemplateUtils::addJS('media://com_bfauction/js/lytebox.js');
		}

		return $result;
	}

	static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
	{
		$conf	= JFactory::getConfig();

		$mailfrom 	= $conf->get('config.mailfrom');
		$fromname 	= $conf->get('config.fromname');

		$emailBody = $body;
		$mode = 1;

		JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
	}

	static function getEmailTemplate($title)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_emailitems');
		$query->where('enabled = 1 AND title='.$db->quote( $db->escape($title), false ));
		//$query->where('bfauction_category_id = '.(int)$category);
		$query->order('title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}

	static function getEmailType($id, $contentType, $status, $catid)
	{
		$emailType="";

		//which event is triggering the email?

		//let's get all the email templates for this category
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('title, condition_trigger, condition_field1, condition_criteria1, condition_value1');
		$query->from($db->quoteName('#__bfauction_emailitems'));
		$query->where('bfauction_category_id = '.(int)$catid);
		$query->where('enabled');
		$db->setQuery((string)$query);
		$myemailitems = $db->loadObjectList();

		// has status (or any other field) changed since last save?
		// look at history table
		$table1 = JTable::getInstance('Contenthistory');
		$table2 = JTable::getInstance('Contenthistory');

		$query->clear();
		$query->from($db->quoteName('#__ucm_history'));
		$query->select('version_id');
		$query->where('ucm_type_id = '.(int)$contentType);
		$query->where('ucm_item_id = '.(int)$id);
		$query->order('save_date DESC');
		$db->setQuery((string)$query);
		$myids = $db->loadObjectList();

		$id1 = $myids[0]->version_id;
		$id2 = isset($myids[1]->version_id) ? $myids[1]->version_id : $myids[0]->version_id;

		$myresult = array();

		foreach($myemailitems as $i => $emailitem):
		//what is the email trigger?

		if($emailitem->condition_trigger=="0")
		{
			if(count($myids)==1 || count($myids)==0)
			{
				//initial save or content history turned off
				$emailType[$i]=$emailitem->title;
			}
			else
			{
				//not first save as this item has content history
				$emailType[$i]="";
			}
		}
		else if($emailitem->condition_trigger==1)
		{
			//field changes
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			if($condition_criteria1 == -1 || $condition_value1 == '')
			{
				// only care if this field has changed or not
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so use this email template
						$emailType[$i]=$emailitem->title;
					}
				}
			}
			else
			{
				// we want this field to change, but also have a specific value
				// basically we only want one email triggered for this status, regardless of whether there are multiple changes
				if ($table1->load($id1) && $table2->load($id2))
				{
					foreach (array($table1, $table2) as $mytable)
					{
						$object = new stdClass;
						$object->data = ContenthistoryHelper::prepareData($mytable);
						$object->version_note = $mytable->version_note;
						$object->save_date = $mytable->save_date;
						$myresult[] = $object;
					}

					if($myresult[0]->data->$condition_field1->value == $myresult[1]->data->$condition_field1->value){
						//field is the same, so this email is not triggered
						$emailType[$i]="";
					}else{
						//field has changed, so now check if it has specific value
						if ($condition_criteria1<>"-1")
						{
							foreach (array($table1, $table2) as $mytable)
							{
								$object = new stdClass;
								$object->data = ContenthistoryHelper::prepareData($mytable);
								$object->version_note = $mytable->version_note;
								$object->save_date = $mytable->save_date;
								$myresult[] = $object;
							}

							if($condition_criteria1 == 1)
							{
								if($status == $condition_value1){
									//field is the same, so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 0)
							{
								if($status < $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 2)
							{
								if($status > $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
							else if($condition_criteria1 == 3)
							{
								if($status <> $condition_value1){
									//this matches so this email is triggered
									$emailType[$i]=$emailitem->title;
								}
								else
								{
									//don't use this template
									$emailType[$i]="";
								}
							}
						}
					}
				}
			}
		}
		else if($emailitem->condition_trigger==2)
		{
			//field has specific value
			$condition_field1 = $emailitem->condition_field1;
			$condition_criteria1 = $emailitem->condition_criteria1;
			$condition_value1 = $emailitem->condition_value1;

			//we only care about the updated value on the form
			if ($table1->load($id1) && $condition_criteria1<>"-1")
			{
				foreach ($table1 as $mytable)
				{
					$object = new stdClass;
					$object->data = ContenthistoryHelper::prepareData($mytable);
					$object->version_note = $mytable->version_note;
					$object->save_date = $mytable->save_date;
					$myresult[] = $object;
				}

				if($condition_criteria1 == 1)
				{
					if($status == $condition_value1){
						//field is the same, so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 0)
				{
					if($status < $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 2)
				{
					if($status > $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
				else if($condition_criteria1 == 3)
				{
					if($status <> $condition_value1){
						//this matches so this email is triggered
						$emailType[$i]=$emailitem->title;
					}
					else
					{
						//don't use this template
						$emailType[$i]="";
					}
				}
			}
		}
		else
		{
			$emailType[$i]="";
		}
		endforeach;

		return $emailType;
	}

	static function sendEmail($myemail, $table, $catid)
	{
		$id = 'bfauction_item_id';
		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction&view=auction&id='. $table->$id.'">'.$table->$id.'</a>';

		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url

		$myemail[0]->subject=preg_replace('/{bfauction_item_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->subject); // insert id
		$myemail[0]->description=preg_replace('/{bfauction_item_id}/', str_pad($table->$id, 4, "0", STR_PAD_LEFT) , $myemail[0]->description); // insert description

		//now get the field names of all the files fields
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__bfauction_items'));
		$query->select('field_name');
		$query->where('bfauction_category_id = '.(int)$catid);
		$db->setQuery((string)$query);
		$myFields = $db->loadObjectList();

		//get list of all fields in the database
		foreach($myFields AS $field)
		{
			$fieldname=$field->field_name;
			if(is_array($table->$fieldname)){
				$table->$fieldname = implode(",", $table->$fieldname);
			}
			$myemail[0]->description=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->description);
			$myemail[0]->subject=preg_replace('/{'.$fieldname.'}/', $table->$fieldname , $myemail[0]->subject);
		}

		$emailSubject = $myemail[0]->subject;
		$body = $myemail[0]->description;
		$sendEmailTo = $myemail[0]->sendTo;

		BauctionDispatcher::sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject);
	}

	static function triggerEmails($emailType, $id, $bidId){
		$app = JFactory::getApplication();
		$params = $app->getParams();
		$dateFormat = $params->get( 'dateFormat' );

		if($emailType == "Outbid" | $emailType == "LoosingBid"){
			//get previous high bidder from bid history
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			// if there is no previous bidder, don't send any outbid or loosing email.
			if($rows == null){
				return false;
			}

			// do not send outbid email if this is the first bid on an item
			if(count($rows)<2){
				return false;
			}

			//don't send outbid or loosing email if the same person bids twice in a row
			if($rows[0]->created_by == $rows[1]->created_by){
				return false;
			}

			//set bid id for loosing email so we send to the correct person
			if($emailType == "LoosingBid"){
				$bidId = $rows[1]->id;
			}
		}else if($emailType == "Watchlist"){
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->select('a.*');
			$query->from('#__bfauction_watchlists AS a');
			$query->where('a.bfauction_watchlist_id = '.(int)$id);
			$query->select('c.email, c.username');
			$query->join('LEFT', '#__users AS c ON c.id = a.created_by');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			$id = (int)$rows[0]->itemid;
		}

		$myemail = BfauctionDispatcher::getEmailTemplate($emailType);
		$myitem =  BfauctionDispatcher::getItem($id);

		if($myemail == null){
			//no email template found so don't send anything
			return false;
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get bid details
		if($bidId == null){
			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->order('bid_time desc');
			//get the bid with the largest id
		}else{
			//get a sepecific bid
			$query->select('*');
			$query->from('#__bfauction_bids');
			$query->where('itemid = '.(int)$id);
			$query->where('bfauction_bid_id = '.(int)$bidId);
			$query->order('bid_time desc');
		}

		$db->setQuery((string)$query);
		$bids = $db->loadObjectList();

		//get seller details
		$query->clear();
		$query->select('*');
		$query->from('#__users');
		$query->where('id = '.(int)$myitem[0]->created_by);

		$db->setQuery((string)$query);
		$userdetail = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		$sellername = $userdetail[0]->name; //get seller name
		$selleremail = $userdetail[0]->email; //get seller email

		$url = '<a href="'.JURI::root().'index.php?option=com_bfauction&view=auction&id='. $myitem[0]->id.'">'.$myitem[0]->title.'</a>';

		//repace fields with actual data
		if($emailType != "Watchlist"){
			$myemail[0]->description=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->description); // insert bfcurrency
			$myemail[0]->description=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->description); // insert bid amount
			$myemail[0]->description=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->description); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->description); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->description=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->description); // insert user name
		}else{
			$myemail[0]->description=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->description); // insert user name
		}
		$myemail[0]->description=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->description); // insert item title
		$myemail[0]->description=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->description); // insert item id
		$myemail[0]->description=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->description); // insert product id
		$myemail[0]->description=preg_replace('/{sellername}/', $sellername , $myemail[0]->description); // insert seller name
		$myemail[0]->description=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->description); // insert seller email
		$myemail[0]->description=preg_replace('/{url}/', $url , $myemail[0]->description); // insert url
		$myemail[0]->description=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->description); // insert deliverymethod

		if($emailType != "Watchlist"){
			$myemail[0]->subject=preg_replace('/{currency}/', $bids[0]->bidCurrency , $myemail[0]->subject); // insert bfcurrency
			$myemail[0]->subject=preg_replace('/{bid}/', $bids[0]->bid , $myemail[0]->subject); // insert bid amount
			$myemail[0]->subject=preg_replace('/{maxbid}/', $bids[0]->maxbid , $myemail[0]->subject); // insert maxbid
		}
		if($emailType == "Outbid"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[1]->username , $myemail[0]->subject); // insert user name
		}else if($emailType == "Watchlist"){
			$myemail[0]->subject=preg_replace('/{username}/', $rows[0]->username , $myemail[0]->subject); // insert user name
		}else{
			$myemail[0]->subject=preg_replace('/{username}/', $bids[0]->username , $myemail[0]->subject); // insert user name
		}
		$myemail[0]->subject=preg_replace('/{description}/', $myitem[0]->description , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{enddate}/', JHTML::_('date',  $myitem[0]->endDate, $dateFormat ) , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{itemtitle}/', $myitem[0]->title , $myemail[0]->subject); // insert item title
		$myemail[0]->subject=preg_replace('/{itemid}/', $myitem[0]->id , $myemail[0]->subject); // insert item id
		$myemail[0]->subject=preg_replace('/{productid}/', $myitem[0]->productId , $myemail[0]->subject); // insert product id
		$myemail[0]->subject=preg_replace('/{sellername}/', $sellername , $myemail[0]->subject); // insert seller name
		$myemail[0]->subject=preg_replace('/{selleremail}/', $selleremail , $myemail[0]->subject); // insert seller email
		$myemail[0]->subject=preg_replace('/{url}/', $url , $myemail[0]->subject); // insert url
		$myemail[0]->subject=preg_replace('/{deliverymethod}/', $myitem[0]->deliveryMethod , $myemail[0]->subject); // insert url

		$subject = $myemail[0]->subject;
		$body = $myemail[0]->description;

		if($emailType == "Outbid"){
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $rows[1]->email, $subject);
		}else if($emailType == "Watchlist"){
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $rows[0]->email, $subject);
		}else{
			BfauctionDispatcher::sendHTMLNotificationEmail($body, $bids[0]->email, $subject);
		}

		return true;
	}

	static function getItem($itemId)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id = '.(int)$itemId);
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		return $rows;
	}
}