<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */
defined('_JEXEC') or die();

JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
include_once JPATH_SITE.'/components/com_bfauction/models/bfauction.php';
$canDo	= BfauctionModelBfauction::getActions();

if (!$canDo->get('core.create')) {
	// User trying to view questions that he does not have access to
	JError::raiseWarning( 403, JText::_( 'COM_BFAUCTION_ERROR_NO_ACCESS_ITEMS') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction&view=items&Itemid=".(int)$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
	$finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFAUCTION_LOG_IN')."</a><br>";
	return;
}
?>
<?php echo $this->getRenderedForm(); ?>