<?php
defined('_JEXEC') or die();

class bfauctionViewCategorygrids extends F0FViewHtml
{

}