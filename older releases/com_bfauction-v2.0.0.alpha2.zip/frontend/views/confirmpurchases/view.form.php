<?php
defined('_JEXEC') or die();

class BfauctionViewConfirmpurchases extends F0FViewForm
{
	public function display($tpl = null)
	{
		$params = JComponentHelper::getParams('com_bfauction');

		$cparams = (object)array(
			'bfcurrency' 			=> $params->get('bfcurrency', '$'),
			'bfcurrency_code' 		=> $params->get('bfcurrency_code'),
			'bidIncrement' 			=> $params->get('bidIncrement'),
			'hideBid' 				=> $params->get('hideBid'),
			'reverseAuction' 		=> $params->get('reverseAuction', 0),
			'includeCommission' 	=> $params->get('includeCommission'),
			'commissionAmount' 		=> $params->get('commissionAmount', 0),
			'includeTax' 			=> $params->get('includeTax'),
			'taxAmount' 			=> $params->get('taxAmount'),
			'showTotalPrice' 		=> $params->get('showTotalPrice'),
			'mainImageSize' 		=> $params->get('mainImageSize', 200),
			'dateFormat' 			=> $params->get('dateFormat'),
			'allowWatchlist' 		=> $params->get('allowWatchlist'),
			'showDeliveryOptions' 	=> $params->get('showDeliveryOptions'),
			'currencySymbolAfter'	=> $params->get('currencySymbolAfter', 0),
		);
		$this->cparams = $cparams;

		parent::display($tpl);
	}
}