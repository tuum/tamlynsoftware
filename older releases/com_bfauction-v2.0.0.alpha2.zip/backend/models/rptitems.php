<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelRptitems extends F0FModel
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->table = 'items';
	}
}