DROP TABLE IF EXISTS `#__bfauction_items`;
DROP TABLE IF EXISTS `#__bfauction_bids`;
DROP TABLE IF EXISTS `#__bfauction_emailitems`;
DROP TABLE IF EXISTS `#__bfauction_watchlists`;
DROP TABLE IF EXISTS `#__bfauction_logs`;
DROP TABLE IF EXISTS `#__bfauction_categories`;
DROP TABLE IF EXISTS `#__bfauction_orders`;