<?php
/**
 * $Id: maintenance.php 56 2013-11-15 11:08:33Z tuum $
 * bfsurvey_plus Controller for BF Survey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');

/**
 * BF Survey Plus
 *
 * @package		Joomla.Administrator
 * @subpackage	com_bfsurvey_plus
 * @since		1.6
 */
class bfsurvey_plusControllerMaintenance extends JControllerAdmin
{
	public function getModel($name = 'Maintenance', $prefix = 'bfsurvey_plusModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

    public function fixDatabase()
    {
    	$this->setRedirect( 'index.php?option=com_bfsurvey_plus&view=maintenance' );
    	require_once JPATH_ROOT.'/administrator/components/com_bfsurvey_plus/controller.php';

    	$errors = bfsurvey_plusController::buildAnswerTables();
		if($errors){
			return JError::raiseWarning(500, $errors);
		}else{
    		$this->setMessage( JText::_( 'COM_BFSURVEYPLUS_DATABASE_FIXED' ) );
		}
    }
}