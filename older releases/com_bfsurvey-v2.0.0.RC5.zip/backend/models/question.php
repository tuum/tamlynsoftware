<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyModelQuestion extends F0FModel
{
	public function save($data)
	{
		if(is_array($data['hide_options'])){
			$data['hide_options'] = implode(",", $data['hide_options']);
		}

		if(is_array($data['show_options'])){
			$data['show_options'] = implode(",", $data['show_options']);
		}

		parent::save($data);

		return true;
	}


	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	function saveImages($post,$files,$config,$model,$cid)
	{
		$app = JFactory::getApplication();

		$conf = new stdClass();
		$conf->max_width = $config->get('max_width');
		$conf->max_height = $config->get('max_height');
		$conf->max_width_t = $config->get('max_width_t');
		$conf->max_height_t = $config->get('max_height_t');
		$conf->max_image_size = $config->get('max_image_size');
		$id = $post['bfsurvey_question_id'];

		for($i = 1; $i < 21; $i++){
			// image delete
			if ( $post['d_img'.$i] == "delete") {
				$pict = JPATH_SITE."/images/com_bfsurvey/".$id."img".$i.".jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
				$pict = JPATH_SITE."/images/com_bfsurvey/".$id."img".$i."_t.jpg";
				if ( file_exists( $pict)) {
					unlink( $pict);
				}
			}

			if (isset( $files['img'.$i])) {
				if ( $files['img'.$i]['size'] > $conf->max_image_size) {
					$app->redirect("index.php?option=com_bfsurvey&view=questionss", JText::_('COM_BFSURVEY_IMAGETOOBIG'));
					return;
				}
			}

			// image5 upload
			if (isset( $files['img'.$i]) and !$files['img'.$i]['error'] ) {
				$path= JPATH_SITE."/images/com_bfsurvey/";
				$model->createImageAndThumb($files['img'.$i]['tmp_name'],
						$id."img".$i.".jpg",
						$id."img".$i."_t.jpg",
						$conf->max_width,
						$conf->max_height,
						$conf->max_width_t,
						$conf->max_height_t,
						"",
						$path,
						$files['img'.$i]['name']);
			}
		}
	}

	/**
	 * @author		Tim Plummer
	 * @author 		This function is based on AdsManager extension. Copyright (C) 2010-2011 JoomPROD.com
	 */
	function createImageAndThumb($src_file,$image_name,$thumb_name,
			$max_width,
			$max_height,
			$max_width_t,
			$max_height_t,
			$tag,
			$path,
			$orig_name)
	{
		if (intval(ini_get('memory_limit')) < 64)
			ini_set('memory_limit', '64M');

		$src_file = urldecode($src_file);

		$orig_name = strtolower($orig_name);
		$findme  = '.jpg';
		$pos = strpos($orig_name, $findme);
		if ($pos === false)
		{
			$findme  = '.jpeg';
			$pos = strpos($orig_name, $findme);
			if ($pos === false)
			{
				$findme  = '.gif';
				$pos = strpos($orig_name, $findme);
				if ($pos === false)
				{
					$findme  = '.png';
					$pos = strpos($orig_name, $findme);
					if ($pos === false)
					{
						return;
					}
					else
					{
						$type = "png";
					}
				}
				else
				{
					$type = "gif";
				}
			}
			else
			{
				$type = "jpeg";
			}
		}
		else
		{
			$type = "jpeg";
		}

		$max_h = $max_height;
		$max_w = $max_width;
		$max_thumb_h = $max_height_t;
		$max_thumb_w = $max_width_t;

		if ( file_exists( "$path/$image_name")) {
			unlink( "$path/$image_name");
		}

		if ( file_exists( "$path/$thumb_name")) {
			unlink( "$path/$thumb_name");
		}

		$read = 'imagecreatefrom' . $type;
		$write = 'image' . $type;

		$src_img = $read($src_file);

		// height/width
		$imginfo = getimagesize($src_file);
		$src_w = $imginfo[0];
		$src_h = $imginfo[1];

		$zoom_h = $max_h / $src_h;
		$zoom_w = $max_w / $src_w;
		$zoom   = min($zoom_h, $zoom_w);
		$dst_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
		$dst_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$zoom_h = $max_thumb_h / $src_h;
		$zoom_w = $max_thumb_w / $src_w;
		$zoom   = min($zoom_h, $zoom_w);
		$dst_thumb_h  = $zoom<1 ? round($src_h*$zoom) : $src_h;
		$dst_thumb_w  = $zoom<1 ? round($src_w*$zoom) : $src_w;

		$dst_img = imagecreatetruecolor($dst_w,$dst_h);
		$white = imagecolorallocate($dst_img,255,255,255);
		imagefill($dst_img,0,0,$white);
		imagecopyresampled($dst_img,$src_img, 0,0,0,0, $dst_w,$dst_h,$src_w,$src_h);
		if($type == 'jpeg'){
			$desc_img = $write($dst_img,"$path/$image_name", 75);
		}else{
			$desc_img = $write($dst_img,"$path/$image_name", 2);
		}

		imagedestroy($dst_img);

		$dst_t_img = imagecreatetruecolor($dst_thumb_w,$dst_thumb_h);
		$white = imagecolorallocate($dst_t_img,255,255,255);
		imagefill($dst_t_img,0,0,$white);
		imagecopyresampled($dst_t_img,$src_img, 0,0,0,0, $dst_thumb_w,$dst_thumb_h,$src_w,$src_h);
		if($type == 'jpeg'){
			$desc_img = $write($dst_t_img,"$path/$thumb_name", 75);
		}else{
			$desc_img = $write($dst_t_img,"$path/$thumb_name", 2);
		}

		imagedestroy($dst_t_img);
	}
}