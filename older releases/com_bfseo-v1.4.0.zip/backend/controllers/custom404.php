<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoControllerCustom404 extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'custom404';
	}

	public function delete()
	{
		$input = JFactory::getApplication()->input;

		$cbs = $input->getVars('cb');

		$ids = array();
		foreach ($cbs as $id => $value) {
			$ids[] = $id;
		}
		$db = JFactory::getDbo();

		$ids = implode(',', $ids);
		$query = "delete from #__bfseo_404s where bfseo_404_id in ($ids)";

		$db->setQuery($query);
		if (!$db->query()) {
			JError::raiseError(500, $db->getErrorMsg());
		}

		$this->setMessage(JText::_('COM_BFSEO_SELECTED_ITEMS_DELETED'));
		$this->setRedirect('index.php?option=com_bfseo&view=custom404');
	}

}

