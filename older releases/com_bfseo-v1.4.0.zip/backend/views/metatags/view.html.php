<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoViewMetatags extends F0FViewHtml
{
	protected function onAdd($tpl = null)
	{
		$this->menuItems = BfseoModelMetatags::getMenuItems();

		include_once(JPATH_ADMINISTRATOR.'/components/com_redirect/helpers/redirect.php');
		$this->enabled              = RedirectHelper::isEnabled();
		$this->collect_urls_enabled = RedirectHelper::collectUrlsEnabled();
		return true;
	}
}