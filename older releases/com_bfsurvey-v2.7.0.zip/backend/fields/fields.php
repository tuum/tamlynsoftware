<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Fields Form Field class
 */
class JFormFieldFields extends JFormFieldList
{
	/**
     * The field type.
     *
     * @var         string
     */
    protected $type = 'fields';

    /**
     * Method to get a list of options for a list input.
     *
     * @return      array           An array of JHtml options.
     */
    protected function getOptions()
    {
    	$values = (array) $this->value;

	    // Initialize variables.
		$options = array();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//$catid=JRequest::getInt('cid', 0);
		//$session = JFactory::getSession();
		//if($catid){
		//	$session->set('catid', $catid);
		//}else{
		//	$catid=$session->get('catid');
		//}
		//$catid=1;

		$query->select('bfsurvey_category_id');
		$query->from('#__bfsurvey_categories AS a');
		$query->where('a.enabled');
		$query->order('a.ordering');

		$db->setQuery((string)$query);
		$catid=$db->loadResult();

		//if we are loading existing report, get that category
		$id = JRequest::getVar( 'id', 0, '', 'int' );
		if($id>0)
		{
			$query->clear();
			$query->from('#__bfsurvey_reports');
			$query->select('bfsurvey_category_id');
			$query->where('bfsurvey_report_id='.(int) $id);
			$db->setQuery((string)$query);
			$catid=$db->loadResult();
		}

		if($catid==0)
		{
			$catid = 1;
		}

		try
		{
			$table = '#__bfsurvey_'.(int)$catid.'results';

			// Grab the fields for the selected table
			$fields = $db->getTableColumns( $table, true );
		}
		catch (Exception $e)
		{
			JError::raiseWarning( 500, JText::_('COM_BFSURVEY_ERROR_NO_ANSWER_TABLE') );
			return;
		}

		if(!$fields){
			JError::raiseWarning( 500, JText::_('COM_BFSURVEY_ERROR_NO_ANSWER_TABLE') );
			return;
		}else{
			$options = array();
			$options[] = JHtml::_('select.option',  '0', JText::_('COM_BFSURVEY_SELECT_PLEASE_SELECT'));
			if( sizeof( $fields ) ) {
				// We found some fields so let's create the list
				foreach( $fields as $field => $type ) {
					$options[] = JHtml::_('select.option', $field, $field);
				}
			}
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		reset($options);

		return $options;
	}

	protected function getInput()
	{
		$html = array();
		$attr = '';

		if (!is_array($this->value) && !empty($this->value))
		{
			// String in format 2,5,4
			if (is_string($this->value))
			{
				$this->value = explode(',', $this->value);
			}
		}

		// Get the field options.
		$options = (array) $this->getOptions();

		$input = parent::getInput();

		return $input;
	}

}