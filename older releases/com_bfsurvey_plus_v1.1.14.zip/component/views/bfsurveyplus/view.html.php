<?php
/**
 * $Id: view.html.php 56 2013-11-15 11:08:33Z tuum $
 * BF Survey Plus View for BF Survey Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * BFSurveyPlusViewBFSurvey View
 *
 * @package    Joomla
 * @subpackage Components
 */
class BFSurveyPlusViewBFSurveyPlus extends JViewLegacy
{
	protected $state;
	protected $item;

    function display($tpl = null)
    {
		$app		= JFactory::getApplication();
		$params		= $app->getParams();

		// Now get all data from the model
	    $items		= $this->get('Item');

	    $this->assignRef( 'items', $items );
	    $this->assignRef( 'params', $params );

	    $catid=JRequest::getInt('catid', 0);
	    if($catid){
        	parent::display($tpl);
	    }else{
	    	echo JText::_( "COM_BFSURVEYPLUS_ERROR_MUST_SELECT_CATEGORY");
	    }
    }

}