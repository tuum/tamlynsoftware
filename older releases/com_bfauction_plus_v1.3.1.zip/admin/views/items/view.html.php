<?php
/**
 * $Id: view.html.php 63 2012-09-29 09:21:00Z tuum $
 * Default View for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;

/**
 * Default View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusViewitems extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;
	protected $form;

	/**
	 * Items view display method
	 * @return void
	 **/
	function display($tpl = null)
	{
		$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->form			= $this->get('Form');

		bfauction_plusHelper::addSubmenu('bfauction_plus');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->ordering = array();

		$this->addToolbar();
		require_once JPATH_COMPONENT .'/models/fields/auctionstatus.php';
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfauction_plus.php';

		$state	= $this->get('State');
		$canDo	= bfauction_plusHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title(JText::_('COM_BFAUCTIONPLUS_TOOLBAR_ITEM_LIST'), 'bfauction_plus_toolbar_title');
		$toolbar = JToolBar::getInstance('toolbar');
		if ($canDo->get('core.create')) {
			JToolBarHelper::addNew('item.add','JTOOLBAR_NEW');
		}
		if ($canDo->get('core.edit')) {
			JToolBarHelper::editList('item.edit','JTOOLBAR_EDIT');
		}
		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom('items.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom('items.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);

			JToolBarHelper::archiveList('items.archive','JTOOLBAR_ARCHIVE');
		}
		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'items.delete','JTOOLBAR_EMPTY_TRASH');
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('items.trash','JTOOLBAR_TRASH');
		}

		if ($canDo->get('core.admin')) {
			JToolBarHelper::custom('export_csv', 'export', 'export', 'COM_BFAUCTIONPLUS_EXPORT_CSV', false);
			JToolBarHelper::custom('importcsv', 'import', 'import', 'COM_BFAUCTIONPLUS_IMPORT_CSV', false);
		}

		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom( 'items.copy', 'copy.png', 'copy_f2.png', 'COM_BFAUCTIONPLUS_TOOLBAR_COPY' );
			JToolBarHelper::custom( 'items.relist', 'refresh', 'refresh', 'COM_BFAUCTIONPLUS_TOOLBAR_RELIST' );
		}

		if ($canDo->get('core.admin')) {
			JToolBarHelper::preferences('com_bfauction_plus');
			JToolBarHelper::divider();
		}

		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_auction_plus&view=items');

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_PUBLISHED'),
				'filter_published',
				JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_CATEGORY'),
				'filter_category_id',
				JHtml::_('select.options', JHtml::_('category.options', 'com_bfauction_plus'), 'value', 'text', $this->state->get('filter.category_id'))
			);
		}
	}

	/**
	 * Returns an array of fields the table can be sorted by
	 *
	 * @return  array  Array containing the field name to sort by as the key and display text as value
	 *
	 * @since   3.0
	 */
	protected function getSortFields()
	{
		return array(
			'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
			'a.state' => JText::_('JSTATUS'),
			'a.title' => JText::_('JGLOBAL_TITLE'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}

}