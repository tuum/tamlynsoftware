<?php
/**
 * $Id: default.php 90 2014-05-11 12:54:57Z tuum $
 * Grid view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	require_once( JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfauction_plus.php' );

    $app = JFactory::getApplication();
    $user = JFactory::getUser();

	$bfcurrency = $this->params->get('bfcurrency', '$');
	$rowColour = $this->params->get('rowColour');
	$alternateColour = $this->params->get('alternateColour');
	$max_width_t = $this->params->get('max_width_t');
	$max_height_t = $this->params->get('max_height_t');
	$showTimer = $this->params->get('showTimer');
	$currencySymbolAfter= $this->params->get('currencySymbolAfter', 0);

	$items = 0;
	$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
	$limit = JRequest::getVar('limit', 0, '', 'int');

	$context="";
	$filter_catid		= $app->getUserStateFromRequest( $context.'filter_catid',		'filter_catid',		'',			'int' );
	$filter_sort		= $app->getUserStateFromRequest( $context.'filter_sort',		'filter_sort',		'',			'int' );
	$filter_filter		= $app->getUserStateFromRequest( $context.'filter_filter',		'filter_filter',	'',			'int' );
	$search				= $app->getUserStateFromRequest( $context.'search',				'search',			'',			'string' );

	$lists = array();

	// build list of categories
	$javascript		= 'onchange="document.adminForm2.submit();"';

	// state filter
	$lists['order'] = bfauction_plusHelper::orderList($filter_sort);
	$lists['filter'] = bfauction_plusHelper::filterList($filter_filter);

	$session = JFactory::getSession();
	$catid = $session->get('catid');
	$showAllCategories = $session->get('showAllCategories');

	// search filter
	$lists['search']= $search;

	/******************** countdown timer ***************************/
	if($showTimer){
		$now = JFactory::getDate();
		$currentDate=$now->format('Y-m-d H:i:s');
?>
		<script type="text/javascript">
		<!--
		  var days = 0;
		  var hours = 0;
		  var minutes = 0;
		  var seconds = 0;

		function setCountDown (days, hours, mintues, seconds, i)
		{
			seconds--;
			if (seconds < 0){
				mintues--;
				seconds = 59
			}
			if (mintues < 0){
				hours--;
				mintues = 59
			}
			if (hours < 0){
				days--;
				hours = 23
			}
			if(seconds < 10){
				seconds = "0"+seconds;
			}
			document.getElementById("txt"+i).value = days+"d "+hours+"h "+mintues+":"+seconds;

			if(days < 0){
				document.getElementById("txt"+i).value = "0:00";
			}else{
				setTimeout(function() {
					setCountDown(days, hours, mintues, seconds, i);
			    }, 1000);
			}
		}

		//-->

		</script>
<?php
	}
	/****************************************************************/
?>

<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=grid'); ?>" name="adminForm2" id="adminForm2" method="post">
<div class="bffilter_bar">
		<div class="span12">
			<?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_FILTER' ); ?>:
			<input type="text" name="search" id="search2" value="<?php echo htmlspecialchars($lists['search']);?>" class="text_area" onchange="document.adminForm2.submit();" />
			<button onclick="this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_BUTTON_GO' ); ?></button>
			<button onclick="document.getElementById('search2').value='';this.form.submit();"><?php echo JText::_( 'COM_BFAUCTIONPLUS_SEARCH_BUTTON_RESET' ); ?></button>
		</div>
		<div class="span12">
			<?php
			echo $lists['order'];
			if($showAllCategories){
				?>
			<select name="filter_catid" class="inputbox" onchange="document.adminForm2.submit();">
				<option value=""><?php echo JText::_('JOPTION_SELECT_CATEGORY');?></option>
				<?php echo JHtml::_('select.options', JHtml::_('category.options', 'com_bfauction_plus'), 'value', 'text', (int)$filter_catid);?>
			</select>
				<?php
			}

			echo $lists['filter'];
			?>
		</div>
</div>
<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>
<input type="hidden" name="option" value="com_bfauction_plus" />
<input type="hidden" name="task" value="listItems" />
<input type="hidden" name="boxchecked" value="0" />
</form>
<div class="clr"></div>
<div class="span12">
	<?php

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$link 		= JRoute::_( 'index.php?option=com_bfauction_plus&view=bid&cid='. $row->id.'&grid=1' );

		$newrow = ($i > 1) && ($i % 6 == 0);
		if($newrow){
			echo '<div class="clrgap"></div>';
		}
	?>

		<div class="span2" style="background-color:<?php echo $i & 1 ? $alternateColour : $rowColour; ?>;<?php echo $newrow ? "margin-left: 0px;": ""?>">

			<div style="margin-top:5px; height: <?php echo $max_height_t; ?>px; text-align: center">
				<?php
				$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$row->id."img1.jpg";
				if (file_exists($a_pic)){
					echo '<a href="'.$link.'"><img src="'.JUri::base().'images/com_bfauction_plus/'.$row->id.'img1_t.jpg?time='.time().'"/></a>';
				}elseif($row->imageShared > 0){
					$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$row->imageShared."img1.jpg";
					if (file_exists($a_pic)){
						echo '<a href="'.$link.'"><img src="'.JUri::base().'images/com_bfauction_plus/'.$row->imageShared.'img1_t.jpg?time='.time().'"/></a>';
					}
				?>
				<?php }elseif($row->image != ""){ ?>
    				<a href="<?php echo $link;?>"><img src="<?php echo $row->image;?>" border=0></a>
    			<?php }else{ ?>
    				<a href="<?php echo $link;?>"><div class="noimage">No Image</div></a>
    			<?php } ?>
			</div>
			<div align="center">
				<a href="<?php echo $link; ?>" alt="<?php echo $row->title; ?>"><?php echo substr($row->title, 0, 15); ?></a>
			</div>

			<div align="center">
				<?php echo $currencySymbolAfter? '':$bfcurrency; ?><?php echo $row->currentBid; ?>
				<?php echo $currencySymbolAfter? $bfcurrency : ''; ?>
			</div>
			<?php if($showTimer){ ?>
			<div align="center" class="gridcountdown">
				<input id="txt<?php echo $i; ?>" name="txt" readonly value="" class="gridtimer">
			</div>
			<?php } ?>
		</div>

		<?php
		/******************** countdown timer ***************************/
		if($showTimer){
			$endDate = $row->endDate;

			$secondsDiff = 0;
			if($currentDate < $endDate){
				$endDateAsSeconds = strtotime($endDate);
				$currentDateAsSeconds = strtotime($currentDate);
				$secondsDiff = $endDateAsSeconds - $currentDateAsSeconds;
			}

			$remainingDay     = floor($secondsDiff/60/60/24);
			$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
			$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
			$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));
			?>

			<script type="text/javascript">
			<!--
			 setCountDown(<?php echo $remainingDay; ?>, <?php echo $remainingHour; ?>, <?php echo $remainingMinutes; ?>, <?php echo $remainingSeconds; ?>, <?php echo $i; ?>); // Start clock.
			//-->
			</script>
		<?php
		}
		/******************** end countdown timer ***************************/
	}
	?>
</div>
<div class="clr"></div>
<div class="span12">
	      <form method="post" name="adminForm" action="index.php?option=com_bfauction_plus">
	      	<?php echo $this->pagination->getListFooter(); ?>
	      	<input type="hidden" name="option" value="com_bfauction_plus" />
		  	<input type="hidden" name="task" value="grid" />
		  	<input type="hidden" name="boxchecked" value="0" />
		  	<input type="hidden" name="cid" value="<?php if(isset($row)){ echo $row->id; } ?>" />
		  	<input type="hidden" name="view" value="grid" />
		  </form>
</div>
<div class="clr"></div>

<?php bfauction_plusController::triggerBFAuctionEmail(); ?>

