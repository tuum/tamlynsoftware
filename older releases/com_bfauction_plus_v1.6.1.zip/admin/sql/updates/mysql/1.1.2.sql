 ALTER TABLE `#__bfauction_plus` ADD `supplier` varchar(255) NOT NULL; 
 ALTER TABLE `#__bfauction_plus` ADD `costPrice` FLOAT( 10, 2 ) NOT NULL DEFAULT '0';