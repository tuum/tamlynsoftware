<?php
/**
 * $Id: bid.php 94 2014-11-25 04:32:56Z tuum $
 * Bid Model for bfauction_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Bid Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfauction_plusModelbid extends JModelLegacy
{
	/**
	 * Constructor that retrieves the ID from the request
	 *
	 * @access	public
	 * @return	void
	 */
	function __construct()
	{
		parent::__construct();

		$cid = JRequest::getVar('cid', 0, '', 'int');
		$id = JRequest::getVar('id', 0, '', 'int');
		if($id > $cid){
			$this->setId((int)$id);
		}else{
			$this->setId((int)$cid);
		}
	}

	/**
	 * Method to set the Item identifier
	 *
	 * @access	public
	 * @param	int Item identifier
	 * @return	void
	 */
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
		$this->_lastbiddata	= null;
	}


	/**
	 * Method to get a Item
	 * @return object with data
	 */
	function &getData()
	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT a.*, b.username AS seller FROM #__bfauction_plus AS a'.
					' LEFT JOIN #__users AS b ON a.uid=b.id'.
					' WHERE a.id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->title = null;
		}
		return $this->_data;
	}

	function &getLastBidData()
	{
		// Load the data
		if (empty( $this->_lastbiddata )) {
			$query = ' SELECT * FROM #__bfauction_plus_bid '
				. '  WHERE `itemid` = '.(int)$this->_id.''
				. ' ORDER BY bid_time desc'
	  			;
			$this->_db->setQuery( $query );
			$this->_lastbiddata = $this->_db->loadObject();
		}
		if (!$this->_lastbiddata) {
			$this->_lastbiddata = new stdClass();
			$this->_lastbiddata->id = 0;
			$this->_lastbiddata->title = null;
			$this->_lastbiddata->maxbid = 0;
		}
		return $this->_lastbiddata;
	}

	/**
	 * Method to store a record
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function store()	{
		$row = $this->getTable();

		$data = JRequest::get( 'post' );

		// Bind the form fields to the Question table
		if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Set order if 0 or blank
		if ($row->ordering == "0" | $row->ordering == "") {
		   // get next ordering
		   $query = ' SELECT MAX(ordering) as ordering FROM #__bfauction_plus_bid';
		   $this->_db->setQuery( $query );
		   $this->_mydata = $this->_db->loadObject();
		   $row->ordering = intval($this->_mydata->ordering)+1;
		}

		// Make sure the bfauction_plus record is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the web link table to the database
		if (!$row->store()) {
			$this->setError( $this->_db->getErrorMsg() );
			return false;
		}

		return true;
	}

	/**
	 * Method to delete record(s)
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

		$row = $this->getTable();

		if (count( $cids ))		{
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}


}
?>
