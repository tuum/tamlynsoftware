<?php
/**
 * $Id: default.php 87 2013-12-15 09:51:52Z tuum $
 * Items view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
$version = new JVersion();

$params = JComponentHelper::getParams('com_bfauction_plus');

$dateFormat = $this->params->get('dateFormat');
?>

<?php
$user = JFactory::getUser();
if($user->id == 0){
	JError::raiseWarning( 403, JText::_( 'COM_BFAUCTIONPLUS_ERROR_MUST_LOGIN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction_plus&view=items&Itemid=".$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".JRoute::_($finalUrl)."'>".JText::_( 'COM_BFAUCTIONPLUS_AUCTION_LOG_IN')."</a><br>";
}else{
?>

<?php
	$items = 0;
	$limitstart = 0;
	$limit = 0;

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<?php if(floatval($version->RELEASE) <= '2.5') { ?>
<form action="<?php echo JRoute::_( 'index.php'); ?>" method="post" id="adminForm" name="adminForm">
	<?php echo $this->getToolbar(); ?>
	<input type = "hidden" name = "task" value = "" />
	<input type = "hidden" name = "option" value = "com_bfauction_plus" />
	<input type = "hidden" name = "view" value = "items" />
</form>
<div class="clr"></div>
<br><br>
<?php } ?>

<form action="<?php echo JRoute::_( 'index.php?option=com_bfauction_plus' ); ?>" method="post" name="adminForm" id="adminForm">
<?php if( floatval($version->RELEASE) >= 3 ) { ?>
	<div class="btn-toolbar">
		<div class="btn-group">
			<button type="button" class="btn btn-primary" onclick="Joomla.submitbutton('item.add')">
				<i class="icon-new"></i> <?php echo JText::_('JNEW') ?>
			</button>
		</div>
	</div>
<?php } ?>
<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_ID' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_CATEGORY' ); ?>
			</th>
			<th width="20%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_END_DATE' ); ?>
			</th>

		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = $this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction_plus&task=item.edit&id='. $row->id );
		$id = JHTML::_('grid.id',  $i, $row->id );
		$order = JHTML::_('grid.order',  $i, $row->id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo $row->category_name;?>
			</td>
			<td align="center">
				<?php echo JHTML::_('date',  $row->endDate, $dateFormat ); ?>
			</td>

		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <td colspan="4"><?php echo $this->pagination->getListFooter(); ?></td>
	    </tr>
	  </tfoot>

	</table>
</div>

<input type="hidden" name="option" value="com_bfauction_plus" />
<input type="hidden" name="task" value="items" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="items" />
<input type="hidden" name="controller" value="items" />
<input type="hidden" name="c" value="items" />

<?php
// insert a hidden token to the form field
echo JHTML::_('form.token');
?>

</form>

<?php
}  // end force login
?>