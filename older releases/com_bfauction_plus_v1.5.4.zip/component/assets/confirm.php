<?php
/**
 * $Id: confirm.php 87 2013-12-15 09:51:52Z tuum $
 * Javascript code for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<script language="javascript" type="text/javascript">
<!--

function round(n,dec) {
	n = parseFloat(n);
	if(!isNaN(n)){
		if(!dec) var dec= 0;
		var factor= Math.pow(10,dec);
		var result = Math.floor(n*factor+((n*factor*10)%10>=5?1:0))/factor;
		return result.toFixed(2);
	}else{
		return n;
	}
}

function process()
{
	includeCommission = <?php echo $includeCommission ? $includeCommission : 0; ?>;
	commissionAmount = <?php echo $commissionAmount; ?>;
	includeTax = <?php echo $includeTax ? $includeTax : 0; ?>;
	taxableItem = <?php echo $taxableItem; ?>;
	taxAmount = <?php echo $taxAmount; ?>;
	userId = <?php echo $user->id; ?>;
	showTotalPrice = <?php echo $showTotalPrice ? $showTotalPrice : 0; ?>;
	currentBid = <?php echo $this->bfauction_plus->currentBid ? $this->bfauction_plus->currentBid : 0; ?>;
	nextBid = <?php echo $nextBid ? $nextBid : 0; ?>;
	quantity = <?php echo $quantity ? $quantity : 1; ?>;

	if(includeCommission == "1"){
		commission = round( ( parseFloat(nextBid) * parseFloat(commissionAmount) ) / 100, 2 );
		document.getElementById("divCommission").innerHTML =commission;
		document.getElementById("commission").value = commission;

		commissionCurrent = round( ( parseFloat(currentBid) * parseFloat(commissionAmount) ) / 100, 2 );
		document.getElementById("divCommissionCurrent").innerHTML =commissionCurrent;
	}else{
		commission = 0;
		commissionCurrent = 0;
	}

	if(includeTax){
		if(taxableItem){
			tax = round( ( ( parseFloat(nextBid) + parseFloat(commission) ) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( ( parseFloat(currentBid) + parseFloat(commissionCurrent) ) * parseFloat(taxAmount) ) / 100, 2 );
		}else{
			/* tax commission only */
			tax = round( ( parseFloat(commission) * parseFloat(taxAmount) ) / 100, 2 );
			taxCurrent = round( ( parseFloat(commissionCurrent) * parseFloat(taxAmount) ) / 100, 2 );
		}
		document.getElementById("divTax").innerHTML = tax;
		document.getElementById("tax").value = tax;
		document.getElementById("divTaxCurrent").innerHTML = taxCurrent;
	}else{
		tax = 0;
		taxCurrent = 0;
	}

	if(showTotalPrice){
		shipping = <?php echo $this->bfauction_plus->shipping;?>;
		totalPrice = round( (parseFloat(nextBid) + parseFloat(shipping) + parseFloat(commission) + parseFloat(tax) ) ,2 );

		quantityPurchased = document.getElementById("quantityPurchased").value;

		if(parseFloat(quantityPurchased) > parseFloat(quantity)){
			document.getElementById("quantityPurchased").value = quantity;
			quantityPurchased = quantity;
		}

		if(parseFloat(quantityPurchased) > 1){
			totalPrice = totalPrice * parseFloat(quantityPurchased);
		}

		document.getElementById("divTotalPrice").innerHTML = totalPrice;
	}

	/* restart sequence (runs every 10 seconds) */
	setTimeout('process()', 10000);
}


//-->
</script>