<?php
/**
 * $Id: edit.php 87 2013-12-15 09:51:52Z tuum $
 * Item view for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
$app = JFactory::getApplication();

$params = JComponentHelper::getParams('com_bfauction_plus');
$includeCommission = $params->get('includeCommission');
$includeTax = $params->get('includeTax');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form'))) {
			Joomla.submitform(task, document.getElementById('item-form'));
		}
		else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_bfauction_plus&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="item-form" class="form-validate" enctype="multipart/form-data">

<?php
	$version = new JVersion();
	if( floatval($version->RELEASE) >= 3 ) {
?>
	<?php if(!$app->isAdmin()){ ?>
		<div class="btn-toolbar">
			<div class="btn-group">
				<button type="button" class="btn btn-primary" onclick="Joomla.submitbutton('item.save')">
					<i class="icon-ok"></i> <?php echo JText::_('JSAVE') ?>
				</button>
			</div>
			<div class="btn-group">
				<button type="button" class="btn" onclick="Joomla.submitbutton('item.cancel')">
					<i class="icon-cancel"></i> <?php echo JText::_('JCANCEL') ?>
				</button>
			</div>
		</div>
	<?php } ?>
	<!-- Begin Emailitem -->
	<div class="span10 form-horizontal">

	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFAUCTIONPLUS_TITLE_DETAILS') : JText::sprintf('COM_BFAUCTIONPLUS_EDIT_ITEM', $this->item->id); ?></a></li>
			<li><a href="#payment" data-toggle="tab"><?php echo JText::_('COM_BFAUCTIONPLUS_TITLE_PAYMENT_OPTIONS');?></a></li>
			<li><a href="#options" data-toggle="tab"><?php echo JText::_('COM_BFAUCTIONPLUS_SLIDER_OPTIONS');?></a></li>
		</ul>
		<div class="tab-content">
<?php
	} //end Joomla 3.x

	if(floatval($version->RELEASE) <= '2.5') {
?>
	<?php if($app->isAdmin()){ ?>
	<div class="width-60 fltlft">
	<?php }else{ ?>
	<div class="width-100 fltlft">
	<?php } ?>
		<fieldset class="adminform">
<?php } // end 2.5 ?>
			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('catid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('catid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>
				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('endDate'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('endDate'); ?></div>
				</div>
				<?php } ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('quantity'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('quantity'); ?></div>
				</div>
				<?php if($app->isAdmin()){ ?>
					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('featured'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('featured'); ?></div>
					</div>
					<?php } ?>
				<?php } ?>
				<?php if( floatval($version->RELEASE) >= 3 ) { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
				</div>
				<?php } ?>
				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="clr"></div>
				<?php echo $this->form->getLabel('description'); ?>
				<div class="clr"></div>
				<?php echo $this->form->getInput('description'); ?>
				<?php } ?>
				<?php if(!empty($this->item->id)){ ?>
					<div class="clr"></div>
					<div class="control-group">
						<a href="<?php echo JRoute::_('index.php?option=com_bfauction_plus&view=bidHistory&cid='.$this->item->id); ?>"><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BID_HISTORY' ); ?></a>
					</div>
				<?php } ?>
			</div>
		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
		<fieldset class="adminform">
			<legend><?php echo JText::_('COM_BFAUCTIONPLUS_TITLE_PAYMENT_OPTIONS'); ?></legend>
		<?php } ?>
			<div class="tab-pane" id="payment">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('productId'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('productId'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('onlineStore'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('onlineStore'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('paypalEmail'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('paypalEmail'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('buyNowPrice'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('buyNowPrice'); ?></div>
				</div>

			</div>
		<?php if(floatval($version->RELEASE) <= '2.5') { ?>
		</fieldset>
	</div>
		<?php } ?>

	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
	<?php if($app->isAdmin()){ ?>
	<div class="width-40 fltrt">
	<?php }else{ ?>
	<div class="width-100 fltlft">
	<?php } ?>
		<?php echo JHtml::_('sliders.start', 'option-slider'); ?>
		<?php echo JHtml::_('sliders.panel',JText::_('COM_BFAUCTIONPLUS_SLIDER_OPTIONS'), 'options-details'); ?>
		<fieldset class="panelform">
	<?php } ?>
			<div class="tab-pane" id="options">

				<?php if(floatval($version->RELEASE) <= '2.5') { ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('endDate'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('endDate'); ?></div>
				</div>
				<?php } ?>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('imageShared'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('imageShared'); ?></div>
				</div>

				<?php for($i=1; $i < 21; $i++){ ?>
					<?php if( floatval($version->RELEASE) >= 3 ) { ?>
					<div class="control-group">
						<div class="control-label"><?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_IMAGE' ); ?><?php echo $i; ?></div>
						<div class="controls">
					<?php } // end 3 ?>

					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					<li>
						<label class="hasTip" name="image<?php echo $i; ?>">
						   <?php echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_IMAGE' ); ?><?php echo $i; ?> :
						</label>
					<div class="fltlft">
					<?php } // end 2.5 ?>

						<input type="file" name="img<?php echo $i; ?>"/>
							<?php
								$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->item->id."img".$i.".jpg";
								if (file_exists($a_pic))
								{
									if($app->isAdmin()){
										echo '<img src="../images/com_bfauction_plus/'.$this->item->id.'img'.$i.'_t.jpg?time='.time().'"/>';
									}else{
										echo '<img src="./images/com_bfauction_plus/'.$this->item->id.'img'.$i.'_t.jpg?time='.time().'"/>';
									}
									echo "<input type='checkbox' name='d_img".$i."' value='delete'>".JText::_('COM_BFAUCTIONPLUS_IMAGE_DELETE');
								}else if($this->item->imageShared > 0){
									$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$this->item->imageShared."img".$i.".jpg";
									if (file_exists($a_pic))
									{
										if($app->isAdmin()){
											echo '<img src="../images/com_bfauction_plus/'.$this->item->imageShared.'img'.$i.'_t.jpg?time='.time().'"/>';
										}else{
											echo '<img src="./images/com_bfauction_plus/'.$this->item->imageShared.'img'.$i.'_t.jpg?time='.time().'"/>';
										}
									}
									echo "<input type='hidden' name='d_img".$i."' value=''>";
								}else{
									echo "<input type='hidden' name='d_img".$i."' value=''>";
								}
							?>
					<?php if(floatval($version->RELEASE) <= '2.5') { ?>
					</div>
					</li>
					<?php } ?>

					<?php if( floatval($version->RELEASE) >= 3 ) { ?>
						</div>
					</div>
					<?php } ?>
				<?php }	?>

				<?php if ($this->form->getValue('currentBid') < 1): ?>
					<?php $this->form->setFieldAttribute('currentBid','readonly','false');?>
				<?php endif; ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('currentBid'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('currentBid'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('reservePrice'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('reservePrice'); ?></div>
				</div>
				<?php if($app->isAdmin()){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bidIncrement'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bidIncrement'); ?></div>
				</div>
				<?php } ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('highBidder'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('highBidder'); ?><?php echo $this->form->getInput('quantityPurchased'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('itemLocation'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('itemLocation'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('deliveryMethod'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('deliveryMethod'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('shipping'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('shipping'); ?></div>
				</div>

				<?php if($includeCommission){ ?>
					<?php if($app->isAdmin()){ ?>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('commissionAmount'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('commissionAmount'); ?></div>
					</div>
					<?php } ?>
				<?php } ?>

			<?php if($includeTax){ ?>
				<?php if($app->isAdmin()){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('taxAmount'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('taxAmount'); ?></div>
				</div>
				<?php } ?>
			<?php } ?>

			<?php if($includeCommission){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('commission'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('commission'); ?></div>
				</div>
			<?php }else{ ?>
				<input id="jform_commission" type="hidden" readonly="readonly" value="0.00" name="jform[commission]">
			<?php } ?>

			<?php if($includeTax){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('tax'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('tax'); ?></div>
				</div>
			<?php }else{ ?>
				<input id="jform_tax" type="hidden" readonly="readonly" value="0.00" name="jform[tax]">
			<?php } ?>


			<?php if($includeTax){ ?>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('taxableItem'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('taxableItem'); ?></div>
				</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('totalPrice'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('totalPrice'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('priceEstimate'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('priceEstimate'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('condition'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('condition'); ?></div>
			</div>

			<?php if($app->isAdmin()){ ?>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('buyersPremium'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('buyersPremium'); ?></div>
			</div>
			<?php } ?>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('supplier'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('supplier'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('costPrice'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('costPrice'); ?></div>
			</div>

		</div>
	<?php if(floatval($version->RELEASE) <= '2.5') { ?>
	</fieldset>
	<?php echo JHtml::_('sliders.end'); ?>
	<?php } ?>

	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
		</div>
	</fieldset>

	</div>
	<?php } ?>
	<!-- End Auction Item -->

	<?php if($app->isAdmin()){ ?>
	<?php if( floatval($version->RELEASE) >= 3 ) { ?>
	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('state'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('state'); ?>
				</div>
			</div>
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('featured'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('featured'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
	<?php } ?>
	<?php } ?>

		<input type="hidden" name="task" value="item.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
	<div class="clr"></div>
</form>

<script language="Javascript">
<!--
calcualteTotalPrice();
//-->
</script>