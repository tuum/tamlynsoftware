<?php
/**
 * $Id: default_body.php 84 2013-11-28 02:01:32Z tuum $
 * BF User log Component for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF User Log is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

$user	= JFactory::getUser();
$listOrder	= $this->escape($this->state->get('list.ordering'));
$saveOrder	= $listOrder == 'a.ordering';

$canCheckin	= $user->authorise('core.manage',		'com_checkin') || $item->checked_out==$user->get('id') || $item->checked_out==0;
$canChange	= $user->authorise('core.edit.state',	'com_bfauction_plus.category') && $canCheckin;
$version = new JVersion();
?>
<?php foreach($this->items as $i => $item): ?>
	<tr class="row<?php echo $i % 2; ?>" sortable-group-id="<?php echo $item->catid?>">
		<?php if( floatval($version->RELEASE) >= 3 ) { ?>
		<td class="order nowrap center hidden-phone">
		<?php if ($canChange) :
			$disableClassName = '';
			$disabledLabel	  = '';
			if (!$saveOrder) :
				$disabledLabel    = JText::_('JORDERINGDISABLED');
				$disableClassName = 'inactive tip-top';
			endif; ?>
			<span class="sortable-handler <?php echo $disableClassName?>" title="<?php echo $disabledLabel?>" rel="tooltip">
				<i class="icon-menu"></i>
			</span>
			<input type="text" style="display:none"  name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
		<?php else : ?>
			<span class="sortable-handler inactive" >
				<i class="icon-menu"></i>
			</span>
		<?php endif; ?>
		</td>
		<?php } ?>
		<td class="center hidden-phone">
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
		<td class="center nowrap">
			<?php echo JHtml::_('jgrid.published', $item->published, $i, 'bfuserlogs.', $canChange, 'cb', $item->publish_up, $item->publish_down); ?>
		</td>
		<td class="center hidden-phone">
			<?php echo $item->uid; ?>
			<?php $this->data .= $item->uid . "\t"; ?>
		</td>
		<td>
			<?php echo $item->name; ?>
			<?php $this->data .= $item->name . "\t"; ?>
		</td>
		<td class="center hidden-phone">
			<?php echo $item->username; ?>
			<?php $this->data .= $item->username . "\t"; ?>
		</td>
		<td class="center hidden-phone">
			<?php echo $item->email; ?>
			<?php $this->data .= $item->email . "\t"; ?>
		</td>
		<td class="center hidden-phone">
			<?php
			if($item->site == ""){
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_INACTIVE' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_INACTIVE' ) . "\t";
			}elseif($item->site == 2){
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_BACKEND' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_BACKEND' ) . "\t";
			}else{
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_FRONTEND' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_FRONTEND' ) . "\t";
			}
			?>
		</td>
		<td align="center">
			<?php echo JHTML::_( 'date', $item->visitDate, 'd-m-Y H:i' ); ?>
			<?php $this->data .= JHTML::_( 'date', $item->visitDate, 'd-m-Y H:i' ) . "\t"; ?>
		</td>
		<td class="center hidden-phone">
			<?php
			if($item->login == ""){
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_INACTIVE' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_INACTIVE' ) . "\t";
			}elseif($item->login == 1){
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_LOGIN' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_LOGIN' ) . "\t";
			}else{
				echo JText::_( 'COM_BFAUCTIONPLUS_TITLE_LOGOUT' );
				$this->data .= JText::_( 'COM_BFAUCTIONPLUS_TITLE_LOGOUT' ) . "\t";
			}
			?>
		</td>
		<td class="center hidden-phone">
			<?php echo (int) $item->id; ?>
			<?php $this->data .= (int) $item->id . "\t"; ?>
		</td>
	</tr>
	<?php $this->data .= "\n"; ?>
<?php endforeach; ?>
