<?php
/**
 * $Id: bfauction_plus.php 87 2013-12-15 09:51:52Z tuum $
 * Helper for bfauction_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.html.toolbar');

class bfauction_plusHelper
{
	/**
	* build the select list for online store
	*/
	function onlineStore( &$onlineStore )
	{

		$click[] = JHTML::_('select.option',  'None', JText::_( 'COM_BFAUCTIONPLUS_NONE' ) );
		//$click[] = JHTML::_('select.option',  'VirtueMart', JText::_( 'COM_BFAUCTIONPLUS_VIRTUEMART' ) );
		//$click[] = JHTML::_('select.option',  'Oscommerce', JText::_( 'COM_BFAUCTIONPLUS_OSCOMMERCE' ) );
		$click[] = JHTML::_('select.option',  'PayPal', JText::_( 'COM_BFAUCTIONPLUS_PAYPAL' ) );

		if($onlineStore == null){
		   $onlineStore="None";
		}

		$target = JHTML::_('select.genericlist',   $click, 'onlineStore', 'class="inputbox" size="3"', 'value', 'text',  $onlineStore );

		return $target;
	}

	/**
	* build the select list for group id
	*/
	function groupID( &$gid )
	{

		$db = JFactory::getDbo();
		$db->setQuery(
		 'SELECT DISTINCT map.group_id as gid, groups.name as mygroup'.
		 ' FROM #__core_acl_groups_aro_map AS map'.
		 ' LEFT JOIN #__core_acl_aro_groups AS groups on map.group_id=groups.id'
		);

		$result = $db->loadObjectList();

		if ($error = $db->getErrorMsg()) {
			$this->setError($error);
			return false;
		}


		for($i=0; $i < count($result); $i++){
			$click[] = JHTML::_('select.option',  $result[$i]->gid, $result[$i]->mygroup );
		}

		$target = JHTML::_('select.genericlist',   $click, 'gid', 'class="inputbox" size="5"', 'value', 'text',  $gid );

		return $target;
	}

    public static function orderList($title)
    {
    	$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFAUCTIONPLUS_ORDER_SORT_BY' ) );
    	$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFAUCTIONPLUS_ORDER_TIME_ASC' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFAUCTIONPLUS_ORDER_TIME_NEW' ) );
		$click[] = JHTML::_('select.option',  '3', JText::_( 'COM_BFAUCTIONPLUS_ORDER_PRICE_ASC' ) );
		$click[] = JHTML::_('select.option',  '4', JText::_( 'COM_BFAUCTIONPLUS_ORDER_PRICE_DESC' ) );

		if($title == null){
		   $title="0";
		}

		$javascript		= 'onchange="document.adminForm2.submit();"';
		$target = JHTML::_('select.genericlist',   $click, 'filter_sort', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $title );
		return $target;
    }

    public static function filterList($title)
    {
    	$click[] = JHTML::_('select.option',  '0', JText::_( 'COM_BFAUCTIONPLUS_FILTER_FILTER' ) );
    	$click[] = JHTML::_('select.option',  '1', JText::_( 'COM_BFAUCTIONPLUS_FILTER_BUY_NOW' ) );
		$click[] = JHTML::_('select.option',  '2', JText::_( 'COM_BFAUCTIONPLUS_FILTER_BID_ONLY' ) );

		if($title == null){
		   $title="0";
		}

		$javascript		= 'onchange="document.adminForm2.submit();"';
		$target = JHTML::_('select.genericlist',   $click, 'filter_filter', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $title );
		return $target;
    }

	/**
	 * Display Copyright information
	 *
	 */
	public static function displayVersion() {
		global $bfauctionplus_version ;
		echo '<div class="copyright" style="text-align:center;margin-top: 5px; display:block; width:100%; float:left;">'.JText::_( 'COM_BFAUCTIONPLUS_VERSION').' <strong>'.$bfauctionplus_version.'</strong></div>' ;
	}

	/**
	 * Configure the Linkbar.
	 *
	 * @param	string	The name of the active view.
	 * @since	1.6
	 */
	public static function addSubmenu($vName = 'bfauction_plus')
	{
		JSubMenuHelper::addEntry(
			JText::_('COM_BFAUCTIONPLUS_TITLE_ITEMS'),
			'index.php?option=com_bfauction_plus',
			$vName == 'bfauction_plus'
		);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_CATEGORIES'),
    		'index.php?option=com_categories&extension=com_bfauction_plus',
    		$vName == 'categories'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_EMAIL_TEMPLATE'),
    		'index.php?option=com_bfauction_plus&view=emailitems',
    		$vName == 'emailitems'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_RPTITEMS'),
    		'index.php?option=com_bfauction_plus&view=rptitems',
    		$vName == 'rptitems'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_RPTSALES'),
    		'index.php?option=com_bfauction_plus&view=rptsales',
    		$vName == 'rptsales'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_BFUSERLOG'),
    		'index.php?option=com_bfauction_plus&view=bfuserlogs',
    		$vName == 'bfuserlogs'
    	);

    	JSubMenuHelper::addEntry(
    		JText::_('COM_BFAUCTIONPLUS_TITLE_HELP'),
    		'index.php?option=com_bfauction_plus&view=help',
    		$vName == 'help'
    	);

    	// Tim's note: Payment Plugins have only been partially implemented so hide view.
    	// on my TODO to finish for next version.
    	//JSubMenuHelper::addEntry(
    	//	JText::_('COM_BFAUCTIONPLUS_TITLE_PLUGINS'),
    	//	'index.php?option=com_bfauction_plus&view=plugins',
    	//	$vName == 'plugins'
    	//);

	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @param	int		The category ID.
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_bfauction_plus';
		} else {
			$assetName = 'com_bfauction_plus.category.'.(int) $categoryId;
		}

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}

    public static function filterSite($site_filter)
    {
		$click[] = JHTML::_('select.option',  '0', JText::_('COM_JDEPRODUCTS_FILTER_BY_SITE') );
		$click[] = JHTML::_('select.option',  '1', JText::_('COM_BFAUCTIONPLUS_TITLE_FRONTEND') );
		$click[] = JHTML::_('select.option',  '2', JText::_('COM_BFAUCTIONPLUS_TITLE_BACKEND') );

		if($site_filter == null){
		   $site_filter="-1";
		}

		$javascript		= 'onchange="document.adminForm.submit();"';
		$target = JHTML::_('select.genericlist',   $click, 'filter_site', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $site_filter );
		return $target;
    }

    public static function filterLogin($login_filter)
    {
		$click[] = JHTML::_('select.option',  '0', JText::_('COM_JDEPRODUCTS_FILTER_BY_LOGIN') );
		$click[] = JHTML::_('select.option',  '1', JText::_('COM_BFAUCTIONPLUS_TITLE_LOGIN') );
		$click[] = JHTML::_('select.option',  '2', JText::_('COM_BFAUCTIONPLUS_TITLE_LOGOUT') );
		$click[] = JHTML::_('select.option',  '3', JText::_('COM_BFAUCTIONPLUS_TITLE_INACTIVE') );

		if($login_filter == null){
		   $login_filter="-1";
		}

		$javascript		= 'onchange="document.adminForm.submit();"';
		$target = JHTML::_('select.genericlist',   $click, 'filter_login', 'class="inputbox" size="1" '.$javascript, 'value', 'text',  $login_filter );
		return $target;
    }

	public static function exportMysqlToCsv($sql_query,$filename = 'export.csv')
	{
	    $csv_terminated = "\n";
	    $csv_separator = ",";
	    $csv_enclosed = '"';
	    $csv_escaped = "\\";

		$app = JFactory::getApplication();
		$host = $app->getCfg('host');
		$db = $app->getCfg('db');
		$user = $app->getCfg('user');
		$password = $app->getCfg('password');
		$dbtype = $app->getCfg('dbtype');

	    // Gets the data from the database
		if($dbtype == 'mysqli'){
			$link = mysqli_connect($host, $user, $password, $db);
			@mysqli_query($link, 'set character set "utf8"');
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$result = mysqli_query($link, $sql_query);
		}else if($dbtype == 'sqlsrv'){
			$config = array(
				'Database' => $db,
				'uid' => $user,
				'pwd' => $password,
				'CharacterSet' => 'UTF-8',
				'ReturnDatesAsStrings' => true);

			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
			$link = sqlsrv_connect($host, $config);
			$result = sqlsrv_query($link, $sql_query);
			if( $result === false ) {
     			die( print_r( sqlsrv_errors(), true));
			}
			$fields_cnt = sqlsrv_num_fields($result);
		}else{
			$sql_query = preg_replace('/#__/', $app->getCfg('dbprefix'), $sql_query);
	    	$result = mysql_query($sql_query);
	    	$fields_cnt = mysql_num_fields($result);
		}

	    $schema_insert = '';

		if($dbtype == 'mysqli'){
			$fields = mysqli_fetch_fields($result);
			$i=0;
			foreach ($fields as $field) {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes($field->name)) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		        $i++;
			}
			$fields_cnt = $i;
		}else if($dbtype == 'sqlsrv'){
			//this bit just really doesnt work with SQL server.
			//todo - fix CSV export for SQLSRV

			if( sqlsrv_fetch( $result ) === false )
			{
			     echo "Error in retrieving row.\n";
			     die( print_r( sqlsrv_errors(), true));
			}
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(sqlsrv_get_field( $result, $i) )) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}else{
		    for ($i = 0; $i < $fields_cnt; $i++)
		    {
		        $l = $csv_enclosed . str_replace($csv_enclosed, $csv_escaped . $csv_enclosed,
		            stripslashes(mysql_field_name($result, $i))) . $csv_enclosed;
		        $schema_insert .= $l;
		        $schema_insert .= $csv_separator;
		    } // end for
		}

	    $out = trim(substr($schema_insert, 0, -1));
	    $out .= $csv_terminated;

	    // Format the data
	    if($dbtype == 'sqlsrv'){
	    	$row = sqlsrv_fetch_array($result);
	    }else{
	    	$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
		}

	    while ($row)
	    {
	        $schema_insert = '';
	        for ($j = 0; $j < $fields_cnt; $j++)
	        {
	            if ($row[$j] == '0' || $row[$j] != '')
	            {

	                if ($csv_enclosed == '')
	                {
	                    $schema_insert .= $row[$j];
	                } else
	                {
	                    $schema_insert .= $csv_enclosed .
						str_replace($csv_enclosed, $csv_escaped . $csv_enclosed, $row[$j]) . $csv_enclosed;
	                }
	            } else
	            {
	                $schema_insert .= '';
	            }

	            if ($j < $fields_cnt - 1)
	            {
	                $schema_insert .= $csv_separator;
	            }
	        } // end for

	        $out .= $schema_insert;
	        $out .= $csv_terminated;

			if($dbtype == 'sqlsrv'){
				$row = sqlsrv_fetch_array($result);
			}else{
				$row = ($dbtype == 'mysqli') ? $result->fetch_array(MYSQLI_NUM) : mysql_fetch_array($result);
			}
	    } // end while

	    header("Content-Length: " . strlen($out));
	    // Output to browser with appropriate mime type, you choose ;)
	    header('Content-Encoding: UTF-8');
		header('Content-type: text/csv; charset=UTF-8');
	   	header("Pragma: no-cache");
		header("Expires: 0");
	    header("Content-Disposition: attachment; filename=$filename");
	    echo "\xEF\xBB\xBF"; // UTF-8 BOM
	    echo $out;
	    exit;
   }
}