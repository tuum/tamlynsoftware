<?php
/**
 * $Id: view.html.php 63 2014-03-04 10:44:40Z tuum $
 * bfquiz_plusViewResults View for BFQuiz_Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * bfquiz_plusViewResults View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusViewResults extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;

    /**
     * Email Template view display method
     * @return void
     **/
    function display($tpl = null)
    {
    	$catid	= JRequest::getVar( 'cid', 0, '', 'int' );

    	$session = JFactory::getSession();
    	if($catid==0){
			$catid=$session->get('catid', $catid);
		}
		$session->set('catid', $catid);

    	$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');

		bfquiz_plusHelper::addSubmenu('results');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->ordering = array();

		if(empty($catid) | $catid==0){
		    JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_ERROR_CATEGORY_DOES_NOT_EXIST') );
		}else{
			$this->assignRef( 'catid', $catid );

			$this->addToolbar();
			parent::display($tpl);
		}
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';

		$state	= $this->get('State');
		$canDo	= bfquiz_plusHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title(JText::_('COM_BFQUIZPLUS_TOOLBAR_RESULTS'), 'bfquiz_toolbar_title');

		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'results.delete','JTOOLBAR_EMPTY_TRASH');
			JToolBarHelper::divider();
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('results.trash','JTOOLBAR_TRASH');
			JToolBarHelper::divider();
		}
		
		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_bfquiz_plus&view=results');
		
			JSubMenuHelper::addFilter(
			JText::_('JOPTION_SELECT_PUBLISHED'),
			'filter_published',
			JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);
		}		
	}

	/**
	 * Returns an array of fields the table can be sorted by
	 *
	 * @return  array  Array containing the field name to sort by as the key and display text as value
	 *
	 * @since   3.0
	 */
	protected function getSortFields()
	{
		return array(
			'a.Name' => JText::_('COM_BFQUIZPLUS_TITLE_NAME'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}
}