-- <?php /* $Id: install.sqlsrv.utf8.sql 40 2012-09-23 04:17:28Z tuum $ */ defined('_JEXEC') or die() ?>;

SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[question] [nvarchar](255) NOT NULL,	
  	[question_type] [nvarchar](255) NOT NULL,
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,	
	[state] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[option1] [nvarchar](255) NOT NULL,
	[option2] [nvarchar](255) NOT NULL,
	[option3] [nvarchar](255) NOT NULL,
	[option4] [nvarchar](255) NOT NULL,
	[option5] [nvarchar](255) NOT NULL,
	[option6] [nvarchar](255) NOT NULL,
	[option7] [nvarchar](255) NOT NULL,
	[option8] [nvarchar](255) NOT NULL,
	[option9] [nvarchar](255) NOT NULL,
	[option10] [nvarchar](255) NOT NULL,
	[option11] [nvarchar](255),
	[option12] [nvarchar](255),
	[option13] [nvarchar](255),
	[option14] [nvarchar](255),
	[option15] [nvarchar](255),
	[option16] [nvarchar](255),
	[option17] [nvarchar](255),
	[option18] [nvarchar](255),
	[option19] [nvarchar](255),
	[option20] [nvarchar](255),
	[answer1] [smallint],
	[answer2] [smallint],
	[answer3] [smallint],
	[answer4] [smallint],
	[answer5] [smallint],
	[answer6] [smallint],
	[answer7] [smallint],
	[answer8] [smallint],
	[answer9] [smallint],
	[answer10] [smallint],
	[answer11] [smallint],
	[answer12] [smallint],
	[answer13] [smallint],
	[answer14] [smallint],
	[answer15] [smallint],
	[answer16] [smallint],
	[answer17] [smallint],
	[answer18] [smallint],
	[answer19] [smallint],
	[answer20] [smallint],
	[score1] [nvarchar](10),
	[score2] [nvarchar](10),
	[score3] [nvarchar](10),
	[score4] [nvarchar](10),
	[score5] [nvarchar](10),
	[score6] [nvarchar](10),
	[score7] [nvarchar](10),
	[score8] [nvarchar](10),
	[score9] [nvarchar](10),
	[score10] [nvarchar](10),
	[score11] [nvarchar](10),
	[score12] [nvarchar](10),
	[score13] [nvarchar](10),
	[score14] [nvarchar](10),
	[score15] [nvarchar](10),
	[score16] [nvarchar](10),
	[score17] [nvarchar](10),
	[score18] [nvarchar](10),
	[score19] [nvarchar](10),
	[score20] [nvarchar](10),
	[next_question1] [int] NOT NULL,
	[next_question2] [int] NOT NULL,
	[next_question3] [int] NOT NULL,
	[next_question4] [int] NOT NULL,
	[next_question5] [int] NOT NULL,
	[next_question6] [int] NOT NULL,
	[next_question7] [int] NOT NULL,
	[next_question8] [int] NOT NULL,
	[next_question9] [int] NOT NULL,
	[next_question10] [int] NOT NULL,
	[next_question11] [int],
	[next_question12] [int],
	[next_question13] [int],
	[next_question14] [int],
	[next_question15] [int],
	[next_question16] [int],
	[next_question17] [int],
	[next_question18] [int],
	[next_question19] [int],
	[next_question20] [int],
	[prefix] [nvarchar](255) NOT NULL,
	[suffix] [nvarchar](255) NOT NULL,
	[field_name] [nvarchar](50) NOT NULL,	
	[fieldSize] [int] NOT NULL,
	[mandatory] [smallint] NOT NULL,
	[helpText] [nvarchar](max) NOT NULL,
	[horizontal] [smallint] NOT NULL,
	[solution] [nvarchar](max) NOT NULL,
	[suppressQuestion] [smallint] NOT NULL,
	[field_type] [nvarchar](50) NOT NULL,
	[validation_type] [nvarchar](50) NOT NULL,
	[scorecatid] [int],
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_matrix]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus_matrix](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[description] [nvarchar](255) NOT NULL,	
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[default] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,  
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[redirectURL] [nvarchar](255) NOT NULL,
	[score1] [nvarchar](10) NOT NULL,
	[score2] [nvarchar](10) NOT NULL,
	[score3] [nvarchar](10) NOT NULL,
	[score4] [nvarchar](10) NOT NULL,
	[condition1] [nvarchar](10) NOT NULL,
	[condition2] [nvarchar](10) NOT NULL,
	[condition3] [nvarchar](10) NOT NULL,
	[condition4] [nvarchar](10) NOT NULL,
	[condition5] [nvarchar](10) NOT NULL,
	[qty1] [int] NOT NULL,
	[qty2] [int] NOT NULL,
	[qty3] [int] NOT NULL,
	[qty4] [int] NOT NULL,
	[qty5] [int] NOT NULL,
	[operator1] [nvarchar](10) NOT NULL,
	[operator2] [nvarchar](10) NOT NULL,
	[operator3] [nvarchar](10) NOT NULL,
	[operator4] [nvarchar](10) NOT NULL,
	[operator5] [nvarchar](10) NOT NULL,
	[exactMatch] [nvarchar](255) NOT NULL,
	[resultText] [nvarchar](max) NOT NULL,
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_matrix_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_scorerange]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus_scorerange](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[description] [nvarchar](255) NOT NULL,	
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[default] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,  
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[redirectURL] [nvarchar](255) NOT NULL,
	[scoreStart] [nvarchar](10) NOT NULL,
	[scoreEnd] [nvarchar](10) NOT NULL,
	[resultText] [nvarchar](max) NOT NULL,
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_scorerange_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_pool]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus_pool](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[description] [nvarchar](255) NOT NULL,	
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[default] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,  
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[qnsPerQuiz] [int] NOT NULL,
	[qnsPerPage] [int] NOT NULL,
	[mandatoryQns] [nvarchar](max) NOT NULL,
	[mandatoryPos] [nvarchar](10) NOT NULL,
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_pool_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_email]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus_email](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[catid] [int] NOT NULL,
	[title] [nvarchar](250) NOT NULL,	
	[subject] [nvarchar](255) NOT NULL,
	[description] [nvarchar](max) NOT NULL,  
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,  
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[showQuestions] [smallint] NOT NULL,
	[showIncorrect] [smallint] NOT NULL,
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_email_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_scorecat]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__bfquiz_plus_scorecat](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[description] [nvarchar](max) NOT NULL,  
	[date] [datetime] NOT NULL,
	[checked_out] [int] NOT NULL,
	[checked_out_time] [datetime] NOT NULL,
	[state] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[archived] [smallint] NOT NULL,
	[approved] [smallint] NOT NULL,
	[access] [int] NOT NULL,
	[language] [nchar](7) NOT NULL,
	[created] [datetime] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[modified] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[parent] [bigint] NOT NULL,  
	[publish_up] [datetime] NOT NULL,
	[publish_down] [datetime] NOT NULL,
	[congratulationsText] [nvarchar](max) NOT NULL,
	[additionalInformationText] [nvarchar](max) NOT NULL,
	[alias] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__bfquiz_plus_scorecat_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;