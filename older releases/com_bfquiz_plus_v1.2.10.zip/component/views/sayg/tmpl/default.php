<?php defined('_JEXEC') or die(); ?>
<?php
/**
 * $Id: default.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php

$session = JFactory::getSession();
$app		= JFactory::getApplication();
$menus		= $app->getMenu();
$menu = $menus->getActive();
$Itemid = (int) $menu->id;

/*********************** TIMED QUIZ ******************************/
$timedQuiz = $this->params->get( 'timedQuiz' );
$timeLimit = $this->params->get( 'timeLimit' );
$timerText = $this->params->get( 'timerText' );
$timerCompleteText = $this->params->get( 'timerCompleteText' );

// $minutes and $seconds are added together to get total time.
$minutes = $timeLimit; // Enter minutes
$seconds = 0; // Enter seconds
$time_limit = ($minutes * 60) + $seconds; // Convert total time into seconds
// Add $time_limit (total time) to start time. And store into session variable.
if(!$session->has('start_time'.$Itemid)){
	$session->set('start_time'.$Itemid, mktime(date('G'),date('i'),date('s'),date('m'),date('d'),date('Y')) + $time_limit);
}

$targetDate = $session->get('start_time'.$Itemid);
$actualDate = time();

// Define date format
$dateFormat = "Y-m-d H:i:s";

$secondsDiff = $targetDate - $actualDate;

$remainingDay     = floor($secondsDiff/60/60/24);
$remainingHour    = floor(($secondsDiff-($remainingDay*60*60*24))/60/60);
$remainingMinutes = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))/60);
$remainingSeconds = floor(($secondsDiff-($remainingDay*60*60*24)-($remainingHour*60*60))-($remainingMinutes*60));

$targetDateDisplay = date($dateFormat,$targetDate);
$actualDateDisplay = date($dateFormat,$actualDate);
?>
<script language="Javascript">
<!--
  // get variable from php
  var days = <?php echo $remainingDay; ?>;
  var hours = <?php echo $remainingHour; ?>;
  var minutes = <?php echo $remainingMinutes; ?>;
  var seconds = <?php echo $remainingSeconds; ?>;
  var timerCompleteText = "<?php echo $timerCompleteText ?>";
  var timedQuiz = "<?php echo $timedQuiz ?>";

function setCountDown ()
{
  seconds--;
  if (seconds < 0){
      minutes--;
      seconds = 59
  }
  if (minutes < 0){
      hours--;
      minutes = 59
  }
  if (hours < 0){
      days--;
      hours = 23
  }

  if(seconds < 10){
	  seconds = "0"+seconds;
  }
  document.getElementById("txt").value = minutes+":"+seconds;

  if(days < 0){
     clearInterval(ct);
     document.getElementById("txt").value = "0:00";
     document.getElementById("next_question").value = -1;
  	 document.myquiz.submit();
     alert(timerCompleteText);
  }

}

if(timedQuiz=="1"){
    var ct = setInterval("setCountDown()",1000); // Start clock.
 }

//-->
</script>
<?php

if($remainingSeconds < 10){
	$remainingSecs = "0".$remainingSeconds;
}else{
    $remainingSecs = $remainingSeconds;
}

$timerinit="".$remainingMinutes.":".$remainingSecs;
/*****************************************************************/

if(!$session->has('dateReceived')){
	$now = JFactory::getDate();
	if(is_callable(array('JDate', 'toSql'))){
		$session->set('dateReceived', $now->toSql());
	}else{
		$session->set('dateReceived', $now->toMySQL());
	}
}

$introText = $this->params->get( 'introText' );
$quizTitle = $this->params->get( 'quizTitle' );
$thankyouText = $this->params->get( 'thankyouText' );
$emailText = $this->params->get( 'emailText' );
$nameText = $this->params->get( 'nameText' );
$allowEmail = $this->params->get( 'allowEmail' );
$allowAuthorEmail = $this->params->get( 'authorEmail' );
$sendEmailTo = $this->params->get( 'sendEmailTo' );
$submitText = $this->params->get( 'submitText' );
$anonymous = $this->params->get( 'anonymous' );
$anonymousText = $this->params->get( 'anonymousText' );
$anonymousYes = $this->params->get( 'anonymousYes' );
$anonymousNo = $this->params->get( 'anonymousNo' );
$nameText = $this->params->get( 'nameText' );
$emailText = $this->params->get( 'emailText' );
$showName = $this->params->get( 'showName' );
$showEmail = $this->params->get( 'showEmail' );
$errorText = $this->params->get( 'errorText' );
$use_captcha = $this->params->get( 'use_captcha' );
$registeredUsers = $this->params->get( 'registeredUsers' );
$preventMultiple = $this->params->get( 'preventMultiple' );
$preventMultipleEmail = $this->params->get( 'preventMultipleEmail' );
$preventMultipleUID = $this->params->get( 'preventMultipleUID' );
$scoringMethod = $this->params->get( 'scoringMethod' );
$randomOptions = $this->params->get( 'randomOptions' );
$answerAfterQuestion = $this->params->get( 'answerAfterQuestion' );
$questionColour = $this->params->get( 'questionColour', '#abc' );
$optionColour = $this->params->get( 'optionColour', '#eee' );
$saveAndQuit = $this->params->get( 'saveAndQuit', 0 );

$user="";
$emailcount=0;
$uidcount=0;

/* Load Recaptcha if Bigo Captcha not on site */
if (!class_exists('plgSystemBigocaptcha')) {
	JPluginHelper::importPlugin('captcha');

	$plugin = JPluginHelper::getPlugin('captcha');
	if($plugin){
	    $pluginParams = new JRegistry();
	    $pluginParams->loadString($plugin[0]->params);
	    $pubkey = $pluginParams->get('public_key', '');

		if ($pubkey == null || $pubkey == '')
		{
			//do nothing as ReCaptcha public key not set
		}else{
			$dispatcher = JDispatcher::getInstance();
			$dispatcher->trigger('onInit','dynamic_recaptcha_1');
		}
	}
}
/* End Recaptcha */

if($anonymous == ""){
   $anonymous = "1";
}

if($showName == ""){
   $showName = "1";
}

if($showEmail == ""){
   $showEmail = "1";
}

$catid = JRequest::getVar( 'catid', 0, '', 'int' );

if($catid == 0){
	$app = JFactory::getApplication();
	JError::raiseWarning( 500, JText::_('COM_BFQUIZPLUS_ERROR_SELECT_CATEGORY') );
	$app->redirect( 'index.php' );
}

$table="#__bfquizplus_".(int)$catid;

$ip = Bfquiz_plusController::getIP();
$ipcount = Bfquiz_plusController::checkIP($table,$ip);

//increment page no
$page_no = JRequest::getVar( 'page_no' );
if(!empty($page_no)){
   $start_qn = JRequest::getVar( 'start_qn', 0, 'post', 'int' );
   $end_qn = JRequest::getVar( 'end_qn', 0, 'post', 'int' );

   // get answers to last question(s)
   $numberQns = $end_qn - $start_qn;
   if($numberQns < 1){
      $numberQns = 1;
   }

   $answerSeq = $session->get('answerSeq');
   $body = $session->get('body');
   $score = $session->get('score');

   $qntable="#__bfquiz_plus";

   if($page_no - $numberQns == 0){  // second page
		$session->set('fullname', JRequest::getVar( 'fullname', '', 'post', 'string' ));
		$session->set('email', JRequest::getVar( 'email', '', 'post', 'string' ));
		$session->set('sendEmailTo', JRequest::getVar( 'sendEmailTo', '', 'post', 'string' ));
		$session->set('uid', JRequest::getVar( 'uid', 0, 'post', 'int' ));

	    $score=0;

		if($session->get('fullname') == ""){
			$session->set('fullname', "Anonymous");
		}

      	$preventMultipleEmail = JRequest::getVar( 'preventMultipleEmail', 0, '' );
      	$emailcount = Bfquiz_plusController::checkEmail($table, $session->get('email'));

		/**
		Captcha
   		*/
   		if ($use_captcha) {
   			if (class_exists('plgSystemBigocaptcha')) {
	    		$correct=Bfquiz_plusController::_checkCaptcha();
	      		if (!$correct) {
	      			JError::raiseWarning("666",JText::_("COM_BFQUIZPLUS_CAPTCHA_WRONG") );
	      			$page_no=1;
	      			$start_qn = -1;
	      			$end_qn = 0;
	      		}else{
	      		   // captcha is correct
	   			}
   			}else{
   				/* Recaptcha */
   				if ($pubkey == null || $pubkey == ''){
   					//do nothing
   				}else{
	   				$post = JRequest::get('post');
	   				JPluginHelper::importPlugin('captcha');
	   				$dispatcher = JDispatcher::getInstance();
	   				$res = $dispatcher->trigger('onCheckAnswer',$post['recaptcha_response_field']);
	   				if(!$res[0]){
	   					JError::raiseWarning( "666", JText::_( 'COM_BFQUIZPLUS_CAPTCHA_WRONG') );
	   					$page_no=1;
	   					$start_qn = -1;
	   					$end_qn = 0;
	   				}
   				}
   				/* End Recaptcha */
   			}
   		}

   		// save basic details to db, and generate id
   		$result = Bfquiz_plusController::save($session->get('fullname'), $session->get('email'), $table);
   		//save userid
   		Bfquiz_plusController::saveField($result,"uid",$session->get('uid'), $table);
   		$session->set('result', $result);

   		$body = "\n\nName: ".$session->get('fullname')."\nEmail: ".$session->get('email')."\n";
		$answerSeq="";
   }

   for($y = ($page_no-$numberQns)+1;$y < $page_no+1; $y++){
	   // get answers to last question
	   $qid = JRequest::getVar( 'question'.$y, 0, 'post', 'int' );
	   $session->set('question'.$y, $qid);
	   $session->set('questiontype'.$y, JRequest::getVar( 'question_type'.$y, 0, 'post', 'int' ) );

       if(JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) != NULL ){
          if($session->get('questiontype'.$y) == "2"){   //checkbox
             $answer = JRequest::getVar( 'q'.$qid, array(), 'post', 'array' );
          }else{
             $answer = JRequest::getVar( 'q'.$qid, "", 'POST', 'string' ) ;
          }
       }else{
      	  $answer = "";
       }

       if($session->has('q'.$qid.'_OTHER_')){
      	 $session->set('q'.$qid.'_OTHER_', JRequest::getVar( 'q'.$qid.'_OTHER_', "", 'POST', 'string'  ) );
       }else{
      	 $session->set('q'.$qid.'_OTHER_', "");
       }
       $fieldname = JRequest::getVar( 'field_name'.$y, "", 'POST', 'string'  );
       $session->set('page_no', $y);

	   //now save the last page answers to database
	   $question = Bfquiz_plusController::getQuestion($qid);

	   if($session->get('questiontype'.$y) == 1){ // radio
	      if($answer == "_OTHER_"){
	         $answer = $session->get('q'.$qid.'_OTHER_');
	      }
	   }

   	   if($session->get('questiontype'.$y) == 2){ // checkbox
   	   if($answer==""){
          // do nothing
       }else{
       	   $check_msg = "";
           foreach($answer as $value) {
              if($value == "_OTHER_"){
                 $value = $session->get('q'.$qid.'_OTHER_');
              }
                 $check_msg .= "$value\n";
              }
           $answer = $check_msg;
           }
       }

       $session->set('q'.$qid, $answer);

	   if($answer == ""){
	      // do nothing
	   }else{
	      //uncomment this line if you want email to show all results, even if correct.
	      $body .= "\n".$question.": \n".JText::_("COM_BFQUIZPLUS_ANSWER").": ".$answer."\n";
	   }

	   if($fieldname == "" | $fieldname == "NULL"){
	      // do nothing
	   }else if($session->get('questiontype'.$y) == 10){  //heading
			//do nothing
	   }else{ // save data to db
	      Bfquiz_plusController::saveField($session->get('result'), $fieldname, $answer, $table);
	      $score=$score+Bfquiz_plusController::getScore($fieldname,$qntable,$answer);
	      if($scoringMethod == 1){
	         $answerSeq.=Bfquiz_plusController::getAnswerSeq($fieldname,$answer);
	      }
	   }

	}

	$session->set('answerSeq', $answerSeq );
	$session->set('body', $body );
	$session->set('score', $score );

	//do you want to show incorrect answers after each question
	for($y = ($page_no-$numberQns)+1;$y < $page_no+1; $y++){
		if($answerAfterQuestion){
			$qid = JRequest::getVar( 'question'.$y, 0, 'post', 'int' );
			$answer = $session->get('q'.$qid);
			$fieldname = $session->get('field_name'.$page_no);
			if($session->get('questiontype'.$y) == "10"){  //heading
			    // do nothing
			 }else{
				Bfquiz_plusController::showIncorrect2($answer,$fieldname,$qid);
			}
		}
	}

	$page_no = $page_no + 1;

}else{
   // defaults for first page
   $page_no = 1;
   $start_qn = -1;
   $end_qn = 0;
   $score=0;
}

$total_qns=count( $this->items );

$next_question = JRequest::getVar( 'next_question', 0, 'post', 'int' );

//Use conditional branching to determine next question
if($page_no > 1){
   if($qid == ""){
      $next_question = 0;
   }else{
   	  if($next_question == -1){ //quiz auto submitted due to timer
   	  	//do nothing
   	  }else{
         $next_question = Bfquiz_plusController::getNextQuestion($qid, $session->get('q'.$qid) );
   	  }
   }
}else{
   $next_question=0;
}

if($next_question == 0){
   // default to next question
   if($start_qn == -1){
      //first page
      $start_qn = $start_qn +1;
   }else{
      $start_qn = $end_qn;
   }
   $end_qn = $end_qn + 1;
}else if($next_question == -1){ // end of quiz
   $start_qn = $total_qns;

   // null answers to all other questions
   for($i=$page_no; $i < $total_qns+1; $i++){
		$session->set('question'.$i, "" );
		$session->set('questiontype'.$i, "" );
   }
}else{
   $page=0;
   for($i=0; $i < $total_qns; $i++){
      //blank out questions that were skipped
      if($i > $page_no-1){
   	     $session->set('question'.$i, "" );
   	     $session->set('questiontype'.$i, "" );
      }

      $row = &$this->items[$i];
      if($row->id == $next_question){
         $i = $total_qns+1;
      }

      $page++;
   }
   $start_qn = $page-1;
   $end_qn = $page;
   $page_no = $page;
}

?>

<?php
 $user = JFactory::getUser();

 if($registeredUsers == "1"){
    $emailcount = Bfquiz_plusController::checkEmail($table,$user->email);
    $uidcount = Bfquiz_plusController::checkUID($table,$user->id);
 }

 if (($user->id) | $registeredUsers != "1") { // test if registerd users only

    if($ipcount < 1 | $preventMultiple != "1"){  // check if IP address has already completed quiz

        if($emailcount < 1 | $preventMultipleEmail != "1"){  // check if email address has already completed quiz

        	if($uidcount < 1 | $preventMultipleUID != "1"){  // check if UID has already completed quiz
?>

<?php if($start_qn > $total_qns-1)
{
// no more questions left

$qntable="#__bfquiz_plus";

$answerSeq = $session->get('answerSeq');
$body = $session->get('body');
$score = $session->get('score');
$result = $session->get('result');

//save score
Bfquiz_plusController::saveField($result,"score",$score,$table);

//save answer sequence
Bfquiz_plusController::saveField($result,"answerseq",$answerSeq,$table);

$emailBody = "";

echo "<div class=\"Bfquiz_plusOptions\">";
echo $thankyouText;
echo "</div>";
echo "<br>";
Bfquiz_plusController::showResultsScoreCategory($result,$table,$catid);
Bfquiz_plusController::showResults($score);
echo "<br>";
if(!$answerAfterQuestion){
	$myIncorrect=Bfquiz_plusController::showIncorrect($result,$table);
}else{
	$myIncorrect="";
}

//------------------------------------ email ------------------------------------------------------------
	$emailBodyIncorrect = "<br>".JText::_("COM_BFQUIZPLUS_INCORRECT_ANSWERS")."<br>".$myIncorrect."<br>";

	$adminEmail = Bfquiz_plusController::getEmailTemplate("Admin", $catid);

	$maxScore = Bfquiz_plusController::getMaxScore($catid);

	//repace fields with actual data
	$adminEmail[0]->description=preg_replace('/{score}/', $score , $adminEmail[0]->description); // insert score
	$adminEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $adminEmail[0]->description); // insert maximum score
	$adminEmail[0]->description=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->description); // insert category
	$adminEmail[0]->description=preg_replace('/{name}/', $session->get('fullname') , $adminEmail[0]->description); // insert name
	$adminEmail[0]->description=preg_replace('/{email}/', $session->get('email') , $adminEmail[0]->description); // insert email

	$adminEmail[0]->subject=preg_replace('/{score}/', $score , $adminEmail[0]->subject); // insert score
	$adminEmail[0]->subject=preg_replace('/{category}/', $adminEmail[0]->category_name , $adminEmail[0]->subject); // insert category
	$adminEmail[0]->subject=preg_replace('/{name}/', $session->get('fullname') , $adminEmail[0]->subject); // insert name
	$adminEmail[0]->subject=preg_replace('/{email}/', $session->get('email') , $adminEmail[0]->subject); // insert email

	$subject = $adminEmail[0]->subject;
	$body = $adminEmail[0]->description;
	if($adminEmail[0]->showQuestions == 1){
		$body .= $emailBody;
	}

	if($adminEmail[0]->showIncorrect == 1){
		$body .= $emailBodyIncorrect;
	}

	$Itemid = JRequest::getVar('Itemid');
	$menu = JMenu::getInstance('site');
	$config = $menu->getParams( $Itemid );

   	$allowEmail = $config->get( 'allowEmail' );
   	$sendEmailTo = $config->get( 'sendEmailTo' );

   	if($allowEmail){
		Bfquiz_plusController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);
   	}

	$authorEmail = Bfquiz_plusController::getEmailTemplate("Author", $catid);

	//repace fields with actual data
	$authorEmail[0]->description=preg_replace('/{score}/', $score , $authorEmail[0]->description); // insert score
	$authorEmail[0]->description=preg_replace('/{maxscore}/', $maxScore , $authorEmail[0]->description); // insert score
	$authorEmail[0]->description=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->description); // insert category
	$authorEmail[0]->description=preg_replace('/{name}/', $session->get('fullname') , $authorEmail[0]->description); // insert name
	$authorEmail[0]->description=preg_replace('/{email}/', $session->get('email') , $authorEmail[0]->description); // insert email

	$authorEmail[0]->subject=preg_replace('/{score}/', $score , $authorEmail[0]->subject); // insert score
	$authorEmail[0]->subject=preg_replace('/{category}/', $authorEmail[0]->category_name , $authorEmail[0]->subject); // insert category
	$authorEmail[0]->subject=preg_replace('/{name}/', $session->get('fullname') , $authorEmail[0]->subject); // insert name
	$authorEmail[0]->subject=preg_replace('/{email}/', $session->get('email') , $authorEmail[0]->subject); // insert email

	$subject = $authorEmail[0]->subject;
	$body = $authorEmail[0]->description;
	if($authorEmail[0]->showQuestions == 1){
		$body .= $emailBody;
	}

	if($authorEmail[0]->showIncorrect == 1){
		$body .= $emailBodyIncorrect;
	}

	if($allowAuthorEmail == "1" & $session->get('email')!=""){
		Bfquiz_plusController::sendHTMLNotificationEmail($body, $session->get('email'), $subject);
	}
	//------------------------------------ end email ------------------------------------------------------------


if($scoringMethod == 1){
   Bfquiz_plusController::checkABCD($fieldname, $answerSeq, $result, $table);
}else if($scoringMethod == 2){
   Bfquiz_plusController::checkscorerange($fieldname, $score, $result, $table);
}

//clear session data
$session->set('start_time'.$Itemid, null);
$session->set('dateReceived', null);

for($y=0; $y < $page_no+1; $y++){
	$session->set('question'.$y, null);
	$session->set('q'.$qid, null);
	$session->set('q'.$qid.'_OTHER_', null);
	$session->set('field_name'.$y, null);
}

$session->set('page_no', null);
$session->set('fullname', null);
$session->set('email', null);
$session->set('sendEmailTo', null);
$session->set('uid', null);

for($i=$page_no; $i < $total_qns+1; $i++){
	$session->set('question'.$i, null);
	$session->set('questiontype'.$i, null);
}
//end clear session data

?>

<?php
}else{
?>

<script language="Javascript">
<!--
	// get variable from php
	var showName = "<?php echo $showName ?>";
	var showEmail = "<?php echo $showEmail ?>";
	var toggle = 1;
	var total_qns = "<?php echo $total_qns ?>";

	function ToggleDetails(){
   		if(toggle == 1){
   		   // hide details
   		   if(showName=="1"){
		      document.getElementById("MyName").style.display = 'none';
		      document.getElementById("fullname").className = 'none';
		      document.getElementById("fullname").removeClass('invalid');
		      document.getElementById("fullname").set('aria-invalid', 'false');
		      document.getElementById("fullname").set('aria-required', 'false');
		      document.getElementById("fullname").set('required', '');
		      document.getElementById("fullname").set('disabled', 'disabled');
		   }

           if(showEmail=="1"){
              document.getElementById("email").className = 'none';
              document.getElementById("MyEmail").style.display = 'none';
              document.getElementById("email").removeClass('invalid');
		      document.getElementById("email").set('aria-invalid', 'false');
		      document.getElementById("email").set('aria-required', 'false');
		      document.getElementById("email").set('required', '');
		      document.getElementById("email").set('disabled', 'disabled');
           }
           toggle=0;

   		}else{
           // show details
           if(showName=="1"){
		      document.getElementById("MyName").style.display = '';
		      document.getElementById("fullname").className = 'required';
		      document.getElementById("fullname").set('disabled', '');
		   }

		   if(showEmail=="1"){
              document.getElementById("email").className = 'required validate-email';
              document.getElementById("MyEmail").style.display = '';
              document.getElementById("email").set('disabled', '');
           }
		   toggle=1;
        }
	}

//-->
</script>



<?php
// Check that the class exists before trying to use it
if (class_exists('plgBFValidatePlus'))
{
   plgBFValidatePlus::formbfvalidation();
}else{
   JHTML::_('behavior.formvalidation');
}
?>

<script language="javascript">
function myValidate(f) {
	if (document.formvalidator.isValid(f)) {
	    f.check='';
		f.check.value='<?php echo JSession::getFormToken(); ?>';//send token
		return true;
	}
	else {
		alert( '<?php echo addslashes($errorText) ?>' );
	}
	return false;
}
function imposeMaxLength(Object, MaxLen)
{
  return (Object.value.length < MaxLen);
}
</script>

<form action="<?php echo JRoute::_( 'index.php?option=com_bfquiz_plus&view=sayg&Itemid='.$Itemid); ?>" method="POST" name="myquiz" id="myquiz" class="form-validate" onSubmit="return myValidate(this);">

<input type="hidden" name="catid" value="<?php echo $catid ?>" />
<input type="hidden" name="score" value="<?php echo $score ?>" />

<table width="100%">
	<thead>
		<tr>
			<th>
				<div class="Bfquiz_plusTitle"><?php echo JText::_( $quizTitle ); ?></div>
			</th>
		</tr>
	</thead>

<?php if($timedQuiz == "1"){ ?>
<tr>
   <td>
		<div class="timeremaining"><?php echo JText::_($timerText); ?> <input id="txt" name="txt" readonly value="<?php echo $timerinit; ?>"></div>
   </td>
</tr>
<?php } ?>

<?php if($page_no == 1){
   // only show this bit on first page
?>

<tr>
    <td>
    <div class="Bfquiz_plusIntro">
    <?php echo JText::_( $introText ); ?>
    </div>
    <div class="Bfquiz_plusQuestionFooter">
	</div>
    </td>
</tr>

<?php if($showName == "1"){ ?>
<tr>
    <th>
       <?php if($anonymous == "1"){ ?>
       <table>
       <tr>
           <td>
               <div class="Bfquiz_plusCustomerQuestion">
               <?php echo JText::_( $anonymousText ); ?>
               </div>
           </td>
           <td>
               <div class="Bfquiz_plusCustomerOptions">
               <label for="anon1"><input type="radio" name="anonymous" id="anon1" value="No" checked onchange='ToggleDetails()' ><?php echo JText::_( $anonymousNo ); ?></label>
               <label for="anon2"><input type="radio" name="anonymous" id="anon2" value="Yes" onchange='ToggleDetails()'><?php echo JText::_( $anonymousYes ); ?></label>
               </div>
           </td>
       </tr>
       </table>
       <?php
       }else{
          // do nothing, anonymous responses not allowed!
       }?>
    </th>
</tr>
<?php } ?>

<?php if($showName == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyName">
        <table>
        <tr>
            <td width="70">
                <div class="Bfquiz_plusCustomerQuestion">
                <?php echo JText::_( $nameText ); ?>
                </div>
            </td>
            <td>
                <div class="Bfquiz_plusCustomerOptions">
                <input name="fullname" id="fullname" size='55' <?php echo 'class="required"'; ?> value='<?php echo $user->name; ?>' >
   				<input type="hidden" name="uid" id="uid" value='<?php echo $user->id; ?>' >
   				</div>
            </td>
        </tr>
        </table>
        </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="fullname" id="fullname" value='<?php echo $user->name; ?>' >
   <input type="hidden" name="uid" id="uid" value='<?php echo $user->id; ?>' >
<?php
      }
?>

<?php if($showEmail == "1"){ ?>
<tr>
    <th>
        <DIV ID="MyEmail">
        <table>
		       <tr>
		           <td width="70">
		               <div class="Bfquiz_plusCustomerQuestion">
		               <?php echo JText::_( $emailText ); ?>
		               </div>
		           </td>
		           <td>
		               <div class="Bfquiz_plusCustomerOptions">
		               <input name="email" id="email" size='55' <?php echo 'class="required validate-email"'; ?> value='<?php echo $user->email; ?>' >
		               </div>
		           </td>
		       </tr>
       </table>
       </DIV>
    </th>
</tr>
<?php }else{
?>
   <input type="hidden" name="email" id="email" value='<?php  echo $user->email; ?>' >
<?php
      }
?>

<tr>
<td>
<?php if ($use_captcha) {
	// Check that the class exists before trying to use it
	if (class_exists('plgSystemBigocaptcha')) {
	?>
	<!-- Bigo Captcha -->
	<img src="index.php?option=com_bfquiz_plus&task=displaycaptcha&catid=<?php echo $catid; ?>&use_captcha=<?php echo $use_captcha; ?>">
	<br />
	<input type="text" name="word"/><br>
	<?php echo JText::_( "COM_BFQUIZPLUS_CAPTCHA_INPUT_WORD"); ?>
	<?php
	}else{
		// Recaptcha
		echo '<div id="dynamic_recaptcha_1"></div>';
	}
	?>
<?php } ?>
</td>
</tr>

<?php
   }  // end only show on first page
?>

<?php
$k = 0;

for ($i=$start_qn; $i < $end_qn; $i++)
{
	$row = &$this->items[$i];

	$numChildren=0;

	//is this a parent item?
	if($row->parent == 0){
	   $numChildren=Bfquiz_plusController::getNumChildren($row->id);
	   $end_qn = $end_qn + $numChildren;
	   $page_no = $page_no + $numChildren;
	}
?>

    <?php if($row->suppressQuestion != "1"){ ?>
	<tr>
	    <th>
	       <div class="Bfquiz_plusQuestion" style="background-color:<?php echo $questionColour; ?>"><?php echo JText::_( $row->question ); ?></div>
	    </th>
	</tr>
	<?php } ?>

	<tr>
	    <th>
	      <?php if($row->suppressQuestion != "1"){ ?>
	         <div class="Bfquiz_plusOptions" style="background-color:<?php echo $optionColour; ?>">
	       <?php }else{ ?>
	         <div>
	       <?php } ?>

	       <?php
	       if($row->helpText == ""){
	          // do nothing
	       }else{
	          echo JHTML::_('content.prepare', $row->helpText);
	          echo "<br>";
	       }

	       if(!isset($row->prefix)){
	          $row->prefix = "";
	       }else{
	          $row->prefix.=" "; //add extra space
	       }

		   if(!isset($row->suffix)){
	          $row->suffix = "";
	       }

	       $sequence = $row->id;
	       if($row->fieldSize == 0){
	       	$row->fieldSize=20;
	       }

	       if($row->question_type == "0"){  //text
	           $mylength="65";
	           if($row->fieldSize < 65){
	              $mylength=$row->fieldSize;
	           }
	           if($row->mandatory){
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
				  }else{
	              ?>
		             <div class="Bfquiz_plusSuppressQuestion">
	                 <?php echo JText::_($row->prefix); ?>
	                 </div>
	                 <div class="Bfquiz_plusSuppressOptions">
	                 <?php
	                    echo "<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize." class=\"".$row->validation_type."\"> ".JText::_($row->suffix);
	                 ?>
	                 </div>
       			  <?php
       			  }
	           }else{
	              if($row->suppressQuestion != "1"){
	                 echo "".JText::_($row->prefix)."<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	              }else{
	              ?>
	                <div class="Bfquiz_plusSuppressQuestion">
	                <?php echo JText::_($row->prefix); ?>
	                </div>
	                <div class="Bfquiz_plusSuppressOptions">
	                <?php
	                   echo "<INPUT id='q".$sequence."' name='q".$sequence."' size=".$mylength." MAXLENGTH=".$row->fieldSize."> ".JText::_($row->suffix);
	                ?>
	                </div>
       			  <?php
       			  }
	           }
	       }else if($row->question_type == "1"){  // Radio

		      if($randomOptions != "1"){

	       		    for($z=0; $z < 20; $z++)
	       		    {
	       		        $tempvalue="option".($z+1);
	       		        $tempnext="next_question".($z+1);

	       		        if($row->$tempvalue != ""){
	       		        	if($row->horizontal == "1"){
		 	  			       $myclass="bfradiohorizontal";
		 	  			    }else{
		 	  			       $myclass="bfradio";
		 	  		        }
				  			if($row->mandatory & class_exists('plgBFValidatePlus')){
				  			   ?>
				  			   <?php echo JText::_($row->prefix); ?>
				  			   <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				  			   <?php
				  			}else{
				  			   ?>
				  			   <?php echo JText::_($row->prefix); ?>
				  			   <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
				  			   <?php
			  				}

			  				if($row->horizontal == "1"){
					    	    echo "&nbsp;&nbsp;&nbsp;";
		   		   	    	}else{
		   		   	    	    echo "<br>";
		   		   	    	}
	       	        	}
	       	     	}

	       	  }else{
				//-------------------------------random options--------------------------------------------------
				$numofoptions=0;
                $myoptions = array();
                //how many options are there?
                for($x=0; $x < 20; $x++)
                {
                   $numofoptions = $x;
                   $tempvalue="option".($x+1);

                   if($row->$tempvalue == ""){
                      $x=20;
                   }else{
                      $myoptions[$x]= $x;
                   }
                }

                //randomly reorder questions
                shuffle($myoptions);

                for($y=0; $y < 20; $y++)
                {
                    if($y+1 > $numofoptions){
                       $z = $y;
                    }else{
                       $z = $myoptions[$y];
                    }

                    $tempvalue="option".($z+1);
                    $tempnext="next_question".($z+1);

                    if($row->$tempvalue != ""){
                       if($row->mandatory & class_exists('plgBFValidatePlus')){
                          ?>

                          <?php if($row->horizontal == "1"){
                             $myclass="bfradiohorizontal";
                          }else{
                             $myclass="bfradio";
                          } ?>

                          <?php echo JText::_($row->prefix); ?>
                          <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>" class="required validate-radio"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }else{
                          ?>
                          <?php echo JText::_($row->prefix); ?>
                          <label for="q<?php echo $sequence; ?><?php echo $z; ?>" class="<?php echo $myclass; ?>"><input type="radio" id="q<?php echo $sequence; ?><?php echo $z; ?>" name="q<?php echo $sequence; ?>" value="<?php echo JText::_($row->$tempvalue); ?>"><?php echo JText::_($row->$tempvalue); ?></label> <?php echo JText::_($row->suffix); ?>
                          <?php
                       }

                       if($row->horizontal == "1"){
                          echo "&nbsp;&nbsp;&nbsp;";
                       }else{
                          echo "<br>";
                       }
                     }
                  }
	              //-------------------------------end random options--------------------------------------------------

	       	  }

			}else if($row->question_type == "2"){  // Checkbox

				if($row->horizontal == "1"){
				   $myclass="bfradiohorizontal";
				}else{
				   $myclass="bfradio";
				}

			    for($z=0; $z < 20; $z++)
			   {
			       $tempvalue="option".($z+1);
	   	           if($row->$tempvalue != ""){
	   	              if($row->$tempvalue == "_OTHER_"){
	   	                 if($row->mandatory & class_exists('plgBFValidatePlus')){
	       	                echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'" class="'.$row->validation_type.'" onchange="MakeOtherMandatory('.$sequence.','.$z.')">'.JText::_($row->otherprefix).'</label><INPUT id="q'.$sequence.''.$z.'_other" name="q'.$sequence.'_OTHER_" class="">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       	             }else{
	       	                echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" value="'.JText::_($row->$tempvalue).'">'.JText::_($row->otherprefix).'</label><INPUT id="q'.$sequence.''.$z.'" name="q'.$sequence.'_OTHER_">'.JText::_($row->othersuffix).' '.JText::_($row->suffix);
	       	             }
	       	          }else{
			             if($row->mandatory & class_exists('plgBFValidatePlus')){
	   	                    echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" class="'.$row->validation_type.'">'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
				         }else{
	   	                    echo ''.JText::_($row->prefix).'<label for="q'.$sequence.''.$z.'" class='.$myclass.'><input type="checkbox" name="q'.$sequence.'[]" value="'.JText::_($row->$tempvalue).'" id="q'.$sequence.''.$z.'" >'.JText::_($row->$tempvalue).'</label> '.JText::_($row->suffix);
	   	                 }
				   	  }
			  		  if($row->horizontal == "1"){
					      echo "&nbsp;&nbsp;&nbsp;";
		   		   	  }else{
		   		   	      echo "<br>";
		   		   	  }
	   	           }
	   	        }
		   }else if($row->question_type == "3"){  // Textarea
	           if($row->mandatory){
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" class="required" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');" ></textarea> '.JText::_($row->suffix);
		       }else{
		          echo ''.JText::_($row->prefix).'<textarea id="q'.$sequence.'" name="q'.$sequence.'" cols="50" rows="6" wrap="virtual" onkeypress="return imposeMaxLength(this, '.$row->fieldSize.');"></textarea> '.JText::_($row->suffix);
		       }
	       }

		   echo '<input type="hidden" name="question'.($i+1).'" value="'.$sequence.'" />';
		   echo '<input type="hidden" name="question_type'.($i+1).'" value="'.$row->question_type.'" />';
		   echo '<input type="hidden" name="field_name'.($i+1).'" value="'.$row->field_name.'">';
	       ?>
	       </div>
	       <div class="Bfquiz_plusQuestionFooter">

	       </div>
	    </th>
	</tr>
	<?php
	$k = 1 - $k;
}
?>
</table>


<?php
$num=count( $this->items );
?>

<input type="hidden" name="page_no" value="<?php echo $page_no ?>" />
<input type="hidden" name="start_qn" id="start_qn" value="<?php echo $start_qn ?>" />
<input type="hidden" name="next_question" id="next_question" value="<?php echo $next_question ?>" />
<input type="hidden" name="end_qn" value="<?php echo $end_qn ?>" />
<input type="hidden" name="num" value="<?php echo $num ?>" />
<input type="hidden" name="option" value="com_bfquiz_plus" />
<input type="hidden" name="task" value="add" />
<input type="hidden" name="allowEmail" value="<?php echo $allowEmail ?>" />
<?php if($saveAndQuit){ ?>
	<input type="submit" name="task_button" class="button" value="<?php echo JText::_( 'COM_BFQUIZ_PLUS_SAVE_AND_QUIT' ); ?>" onclick="document.getElementById('next_question').value=-1;" />
<?php } ?>
<input type="submit" name="task_button" class="button" value="<?php echo JText::_( $submitText ); ?>" />
</form>

<table width="200" border=1>
<tr>
<td>
<div class="progressbar_color_1" style="height:5px;width:<?php echo (($page_no/$total_qns)*100) ?>%"></div>
</td>
</tr>
</table>

<?php
}  // end check start_qn
?>

<?php
	      }else{
	  	     echo JText::_( "COM_BFQUIZPLUS_UID_ALREADY_COMPLETED");
	      }

      }else{
  	     echo JText::_( "COM_BFQUIZPLUS_EMAIL_ALREADY_COMPLETED");
      }

   }else{
      echo JText::_( "COM_BFQUIZPLUS_IP_ALREADY_COMPLETED");
   }

}else{
   echo JText::_( "COM_BFQUIZPLUS_MUST_LOGIN");
}
?>
