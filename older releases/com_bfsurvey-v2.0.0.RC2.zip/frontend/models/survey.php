<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

class BfsurveyModelSurvey extends F0FModel
{
	public static function getCategoryAccess($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('access');
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	public static function getCategoryAccessResults($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('accessResults');
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	public static function getStatsAccess($catid)
	{
		if($catid==0)
		{
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('accessStats');
		$query->from('#__bfsurvey_categories');
		$query->where('bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

		return $result;
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @param	int		The category ID.
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions($categoryId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($categoryId)) {
			$assetName = 'com_bfsurvey';
		} else {
			$assetName = 'com_bfsurvey.category.'.(int) $categoryId;
		}

		$actions = array(
				'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}
}