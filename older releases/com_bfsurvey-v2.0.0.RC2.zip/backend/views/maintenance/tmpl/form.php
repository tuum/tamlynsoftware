<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

//echo $this->renderLinkbar();
?>

<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSURVEY_DATABASE_CLEANUP_WARNING1'); ?></p>
	<p><?php echo JText::_('COM_BFSURVEY_DATABASE_CLEANUP_WARNING2'); ?></p>
</div>

<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="backup" />
	<input type="hidden" name="format" value="raw" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_BACKUP'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_BACKUP_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-primary btn-large" value="<?php echo JText::_('COM_BFSURVEY_DATABASE_BACKUP_BUTTON') ?>" />
	</div>
</form>

<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="change" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_CLEANUP'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_DATABASE_CLEANUP_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-warning btn-large" value="<?php echo JText::_('COM_BFSURVEY_AUTO_DATABASE_CLEANUP') ?>" />
	</div>
</form>

<?php
	//does jos_bfsurvey_plus table exist?
	$db = JFactory::getDbo();
	$query	= $db->getQuery(true);

	$app = JFactory::getApplication();

	$mytables = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfsurvey_plus", $mytables)) {
?>
<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="maintenance" />
	<input type="hidden" name="task" value="import" />

	<div class="control-group">
		<?php echo JText::_( 'COM_BFSURVEY_IMPORT'); ?>
		<?php echo JText::_( 'COM_BFSURVEY_IMPORT_DETAIL'); ?>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-inverse" value="<?php echo JText::_('COM_BFSURVEY_IMPORT_BUTTON') ?>" />
	</div>
</form>
<?php } //end if ?>