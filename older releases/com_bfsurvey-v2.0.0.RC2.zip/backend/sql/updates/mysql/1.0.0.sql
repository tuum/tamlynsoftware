ALTER TABLE `#__bfsurvey_categories` ADD `customJS` text;
ALTER TABLE `#__bfsurvey_categories` ADD `nextText` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `#__bfsurvey_categories` ADD `previousText` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `#__bfsurvey_categories` ADD `accessStats` int(5) NOT NULL DEFAULT '3';
ALTER TABLE `#__bfsurvey_emailitems` CHANGE `sendTo` `sendTo` text;
ALTER TABLE `#__bfsurvey_emailitems` ADD `sendToGroup` bigint(20) unsigned NOT NULL DEFAULT '0';