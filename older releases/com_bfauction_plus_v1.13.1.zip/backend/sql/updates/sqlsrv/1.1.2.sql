ALTER TABLE [#__bfauction_plus_bid] ADD [supplier] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfauction_plus_bid] ADD [costPrice] [numeric](10, 2) NOT NULL;	