<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

class BfsurveyModelThankyou extends F0FModel
{
	public static function getThankyou()
	{
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('a.thankyouText, a.redirectURL, a.showReferenceNo');
		$query->from('#__bfsurvey_categories AS a');
		$query->where('a.bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		return $result[0];
	}

	public static function getTerminate($id)
	{
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get this record just saved
		$query->select('*');
		$query->from('#__bfsurvey_'.$catid.'results');
		$query->where('bfsurvey_'.$catid.'result_id = '.(int)$id);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		//now get all the questions
		$query->clear();
		$query->from($db->quoteName('#__bfsurvey_questions'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->where('bfsurvey_category_id = '.$catid);
		$db->setQuery((string)$query);
		$questions = $db->loadObjectList();

		foreach($questions as $question)
		{
			if($question->terminate_url == '' || $question->terminate_options == '')
			{
				//do nothing
			}
			else
			{
				//now see if any of the options match
				$field_name = $question->field_name;
				if (strpos($question->terminate_options,$result[0]->$field_name) !== false) {
					return $question->terminate_url;
				}
			}
		}

		return;
	}
}