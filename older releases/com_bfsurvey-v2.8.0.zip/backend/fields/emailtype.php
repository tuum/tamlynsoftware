<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Email Type Form Field class
 */
class JFormFieldemailtype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'emailtype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

				$options[] = JHTML::_('select.option',  'Admin', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_ADMIN' ) );
				$options[] = JHTML::_('select.option',  'Author', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_AUTHOR' ) );
				$options[] = JHTML::_('select.option',  'Invite', JText::_( 'COM_BFSURVEY_EMAIL_TYPE_INVITE' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }
}
