<?php
/**
 * $Id: view.html.php 84 2013-11-28 02:01:32Z tuum $
 * BF User log Component for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF User Log is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access to this file
defined('_JEXEC') or die;

/**
 * BFUserLogs View
 */
class bfauction_plusViewBFUserLogs extends JViewLegacy
{
	protected $state;
	protected $pagination;

	/**
	 * BFUserLogs view display method
	 * @return void
	 */
	function display($tpl = null)
	{
		// Get data from the model
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->state		= $this->get('State');

		bfauction_plusHelper::addSubmenu('bfuserlogs');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		}

		// Set the toolbar
		$this->addToolBar();

		// Display the template
		parent::display($tpl);

		// Set the document
		$this->setDocument();
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar()
	{
		$canDo = bfauction_plusHelper::getActions();
		JToolBarHelper::title(JText::_('COM_BFAUCTIONPLUS_MANAGER_BFUSERLOGS'), 'bfauction_plus_toolbar_title');
		if ($canDo->get('core.edit'))
		{
			JToolBarHelper::publish('bfuserlogs.publish', 'JTOOLBAR_PUBLISH', true);
			JToolBarHelper::unpublish('bfuserlogs.unpublish', 'JTOOLBAR_UNPUBLISH', true);
			JToolBarHelper::archiveList('bfuserlogs.archive');
		}
		if ($canDo->get('core.delete'))
		{
			$state	= $this->get('State');
			if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
				JToolBarHelper::deleteList('', 'bfuserlogs.delete', 'JTOOLBAR_EMPTY_TRASH');
			} else{
				JToolBarHelper::trash('bfuserlogs.trash');
			}
		}

		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_bfauction_plus&view=bfuserlogs');

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_PUBLISHED'),
				'filter_published',
				JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);

			$app = JFactory::getApplication();
			$site_filter		= $app->getUserStateFromRequest( 'filter.site',					'filter_site',	'',			'string' );
			$login_filter		= $app->getUserStateFromRequest( 'filter.login',				'filter_login',	'',			'string' );

			$lists['site'] = bfauction_plusHelper::filterSite($site_filter);
			$lists['login'] = bfauction_plusHelper::filterLogin($login_filter);
			echo $lists['site'];
			echo $lists['login'];
		}
	}
	/**
	 * Method to set up the document properties
	 *
	 * @return void
	 */
	protected function setDocument()
	{
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('COM_BFAUCTIONPLUS_ADMINISTRATION'));
	}

	/**
	 * Returns an array of fields the table can be sorted by
	 *
	 * @return  array  Array containing the field name to sort by as the key and display text as value
	 *
	 * @since   3.0
	 */
	protected function getSortFields()
	{
		return array(
			'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
			'a.state' => JText::_('JSTATUS'),
			'a.title' => JText::_('JGLOBAL_TITLE'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}
}
