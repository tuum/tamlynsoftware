<?php
/**
 * $Id: ajax.php 84 2013-11-28 02:01:32Z tuum $
 * AJAX code for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

<script language="javascript" type="text/javascript">
<!--

function round(n,dec) {
	n = parseFloat(n);
	if(!isNaN(n)){
		if(!dec) var dec= 0;
		var factor= Math.pow(10,dec);
		var result = Math.floor(n*factor+((n*factor*10)%10>=5?1:0))/factor;
		return result.toFixed(2);
	}else{
		return n;
	}
}

/* AJAX code for current bid. Function called is in /controllers/bid.php */
/* stores the reference to the XMLHttpRequest object */
var xmlHttp = createXmlHttpRequestObject();

/* retrieves the XMLHttpRequest object */
function createXmlHttpRequestObject()
{
	/* stores the reference to the XMLHttpRequest object */
	var xmlHttp;

	/* if running Internet Explorer 6 or older */
	if(window.ActiveXObject)
	{
		/* For browsers: IE, version 6 and before, use another model */
		/* assume IE6 or older */
		var XmlHttpVersions = new Array('MSXML2.XMLHTTP.6.0',
										'MSXML2.XMLHTTP.5.0',
										'MSXML2.XMLHTTP.4.0',
										'MSXML2.XMLHTTP.3.0',
										'MSXML2.XMLHTTP',
										'Microsoft.XMLHTTP');
		/* try every prog id until one works */
		for (var i=0; i<XmlHttpVersions.length && !xmlHttp; i++)
		{
			try
			{
				/* try to create XMLHttpRequest object */
				xmlHttp = new ActiveXObject(XmlHttpVersions[i]);
			}catch (e) {
				xmlHttp = false;
			}
		}
	}

	/* if running Mozilla or other browsers */
	/* For browsers: Safari, Firefox, etc. use one XML model */
	else
	{
		try {
			xmlHttp = new XMLHttpRequest();
			if (xmlHttp.overrideMimeType) {
				xmlHttp.overrideMimeType('text/xml');
			}
		}
		catch (e) {
			xmlHttp = false;
		}
	}

	/* return the created object or display an error message */
	if (!xmlHttp)
		alert("Error creating the XMLHttpRequest object.");
	else
		return xmlHttp;
}

/* make asynchronous HTTP request using the XMLHttpRequest object */
function process()
{
	/* proceed only if the xmlHttp object isn't busy */
	if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0)
	{
		/* retrieve the name typed by the user on the form */
		myItemId = <?php echo $this->bfauction_plus->id; ?>;
		dst_fix = <?php echo $dst_fix; ?>;

		/* execute the luCurrentBid page from the server (located in /components/com_bfauction_plus/controller.php) */
		xmlHttp.open("GET", "index.php?option=com_bfauction_plus&task=luCurrentBid&itemid=" + myItemId + "&dst_fix=" + dst_fix + "&format=raw&random=" +Math.random() , true);
		xmlHttp.setRequestHeader('Content-Type',  'text/xml');
		/* define the method to handle server responses */
		xmlHttp.onreadystatechange = handleServerResponse;
		/* make the server request */
		xmlHttp.send(null);
	}
	else
		/* if the connection is busy, try again after five second */
		setTimeout('process()', 5000);
}

/* callback function executed when a message is received from the server */
function handleServerResponse()
{
	/* move forward only if the transaction has completed */
	if (xmlHttp.readyState == 4)
	{
		/* status of 200 indicates the transaction completed */
		/* successfully */
		if (xmlHttp.status == 200)
		{
			includeCommission = <?php echo $includeCommission ? $includeCommission : 0; ?>;
			commissionAmount = <?php echo $commissionAmount; ?>;
			includeTax = <?php echo $includeTax ? $includeTax : 0; ?>;
			taxableItem = <?php echo $taxableItem; ?>;
			taxAmount = <?php echo $taxAmount; ?>;
			userId = <?php echo $user->id; ?>;
			showTotalPrice = <?php echo $showTotalPrice ? $showTotalPrice : 0; ?>;

			/* extract the XML retrieved from the server */
			xmlResponse = xmlHttp.responseXML;

			/* catching potential errors with IE and Opera */
			if (!xmlResponse || !xmlResponse.documentElement)
				throw("Invalid XML structure:\n" + xmlHttp.responseText);

			/* catching potential errors with Firefox */
			var rootNodeName = xmlResponse.documentElement.nodeName;
			if (rootNodeName == "parsererror")
				throw("Invalid XML structure:\n" + xmlHttp.responseText);

			/* obtain the document element (the root element) of the XML */
			/* structure */
			xmlDocumentElement = xmlResponse.documentElement;

			/* get the text message, which is in the first child of */
			/* the the document element */
			/* currentBid = xmlDocumentElement.firstChild.data; */
			bidArray = xmlDocumentElement.getElementsByTagName("myBid");
			var currentBid = bidArray.item(0).firstChild.data.toString();
			/* display the data received from the server */
			document.getElementById("divCurrentBid").innerHTML =currentBid;

			highBidderArray = xmlDocumentElement.getElementsByTagName("myBidder");
			var highBidder = highBidderArray.item(0).firstChild.data.toString();

			/* is this a reverse auction? */
			reverseAuction = <?php echo $reverseAuction; ?>;
			/* update next bid */
			if(reverseAuction){
				nextBid = parseFloat(currentBid) - <?php echo (float)$bidIncrement; ?>;
				if(nextBid < 0){
					nextBid = <?php echo (float)$bidIncrement; ?>;
				}
			}else{
				if(highBidder == "0******0"){
					/* no bidder yet so use opening bid */
					nextBid = parseFloat(currentBid);
				}else{
					nextBid = parseFloat(currentBid) + <?php echo (float)$bidIncrement; ?>;
				}
			}

			/* need to update the highBidder now */
			document.getElementById("highBidder").innerHTML =highBidder;

			if(userId){
				if(reverseAuction){
					if( parseFloat(nextBid) > parseFloat(document.getElementById("bid").value) ){
						/* do nothing */
						nextBid = document.getElementById("bid").value;
					}else{
						document.getElementById("bid").value = nextBid;
					}
				}else if( parseFloat(document.getElementById("bid").value) > parseFloat(nextBid) ){
					/* do nothing */
					nextBid = document.getElementById("bid").value;
				}else{
					document.getElementById("bid").value = nextBid;
				}
			}

			if(highBidder == "0******0"){
				/* no bids yet on this item */
				nextBid = parseFloat(currentBid);
				/*document.getElementById("bid").value = nextBid;*/
			}

			dateArray = xmlDocumentElement.getElementsByTagName("myDate");
			var endDate = dateArray.item(0).firstChild.data.toString();
			/* need to update the endDate now */
			document.getElementById("endDate").innerHTML =endDate;

			dayArray = xmlDocumentElement.getElementsByTagName("myDay");
			days = dayArray.item(0).firstChild.data.toString();

			hourArray = xmlDocumentElement.getElementsByTagName("myHour");
			hours = hourArray.item(0).firstChild.data.toString();

			minArray = xmlDocumentElement.getElementsByTagName("myMin");
			minutes = minArray.item(0).firstChild.data.toString();

			secArray = xmlDocumentElement.getElementsByTagName("mySec");
			seconds = secArray.item(0).firstChild.data.toString();

			if(includeCommission == "1"){
				commission = round( ( parseFloat(nextBid) * parseFloat(commissionAmount) ) / 100, 2 );
				document.getElementById("divCommission").innerHTML =commission;
				document.getElementById("commission").value = commission;

				commissionCurrent = round( ( parseFloat(currentBid) * parseFloat(commissionAmount) ) / 100, 2 );
				document.getElementById("divCommissionCurrent").innerHTML =commissionCurrent;
			}else{
				commission = 0;
				commissionCurrent = 0;
			}

			if(includeTax){
				if(taxableItem){
					tax = round( ( ( parseFloat(nextBid) + parseFloat(commission) ) * parseFloat(taxAmount) ) / 100, 2 );
					taxCurrent = round( ( ( parseFloat(currentBid) + parseFloat(commissionCurrent) ) * parseFloat(taxAmount) ) / 100, 2 );
				}else{
					/* tax commission only */
					tax = round( ( parseFloat(commission) * parseFloat(taxAmount) ) / 100, 2 );
					taxCurrent = round( ( parseFloat(commissionCurrent) * parseFloat(taxAmount) ) / 100, 2 );
				}
				document.getElementById("divTax").innerHTML = tax;
				document.getElementById("tax").value = tax;
				document.getElementById("divTaxCurrent").innerHTML = taxCurrent;
			}else{
				tax = 0;
				taxCurrent = 0;
			}

			if(showTotalPrice){
				shipping = <?php echo $this->bfauction_plus->shipping;?>;
				totalPrice = round( (parseFloat(nextBid) + parseFloat(shipping) + parseFloat(commission) + parseFloat(tax) ) ,2 );
				quantityPurchased = document.getElementById("quantityPurchased").value;
				if(parseFloat(quantityPurchased) > 1){
					totalPrice = totalPrice * parseFloat(quantityPurchased);
				}
				document.getElementById("divTotalPrice").innerHTML = totalPrice;

				totalPriceCurrent = round( (parseFloat(currentBid) + parseFloat(shipping) + parseFloat(commissionCurrent) + parseFloat(taxCurrent) ) ,2 );

				quantityPurchased = document.getElementById("quantityPurchased").value;
				if(parseFloat(quantityPurchased) > 1){
					totalPriceCurrent = totalPriceCurrent * parseFloat(quantityPurchased);
				}

				document.getElementById("divTotalPriceCurrent").innerHTML = totalPriceCurrent;
			}

			/* restart sequence (runs every 10 seconds) */
			setTimeout('process()', 10000);
		}
		else if (xmlHttp.status == 0)
		{
		   /* do nothing */
		}
		/* a HTTP status different than 200 signals an error */
		else
		{
			alert(xmlHttp.status);
			alert("There was a problem accessing the server: " +
					xmlHttp.statusText);
		}
	}
}

/* END AJAX code */
//-->
</script>