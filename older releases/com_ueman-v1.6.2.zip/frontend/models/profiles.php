<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

class UemanModelProfiles extends F0FModel
{
	public function loadUsersByGroup($groupId)
	{
		jimport( 'joomla.access.access' );
		$userList = JAccess::getUsersByGroup($groupId);

		$data = array();
		$i=0;
		foreach($userList as $userid)
		{
			$data[$i] = $this->loadUserById($userid);
			$i++;
		}

		return $data;
	}

	public function loadUserById($userid = 0)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, name, username, email');
		$query->from('#__users');
		$query->where('id='.(int)$userid);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		if(!$result)
		{
			return null;
		}

		return $result[0];
	}

	public function loadUser()
	{
		$id = JRequest::getVar( 'id', 0, 'get', 'INT' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('name, username, email');
		$query->from('#__users');
		$query->where('id='.(int)$id);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		if(!$result)
		{
			return null;
		}

		return $result[0];
	}

	public function getCustomFields()
	{
		$db = JFactory::getDBO();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__ueman_customfields'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		return $myitems;
	}

	public function getProfileData()
	{
		$id = JRequest::getVar( 'id', 0, 'get', 'INT' );

		// Load the profile data from the database.
		$db = JFactory::getDbo();
		$db->setQuery(
				'SELECT profile_key, profile_value FROM #__user_profiles' .
				' WHERE user_id = ' . (int)$id . " AND profile_key LIKE 'ueman.%'" .
				' ORDER BY ordering'
		);

		try
		{
			$results = $db->loadRowList();
		}
		catch (RuntimeException $e)
		{
			$this->_subject->setError($e->getMessage());

			return false;
		}

		//echo var_dump($results);

		// Merge the profile data.
		$data = array();

		foreach ($results as $v)
		{
			$k = str_replace('ueman.', '', $v[0]);
			$data[$k] = json_decode($v[1], true);

			if ($data[$k] === null)
			{
				$data[$k] = $v[1];
			}
		}

		return $data;
	}
}