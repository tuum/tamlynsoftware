<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

$params = JComponentHelper::getParams('com_ueman');
$enable_profile = $params->get('enable_profile');

if(!$enable_profile)
{
	// Public user profiles are disabled
	JError::raiseWarning( 403, JText::_( 'COM_UEMAN_ERROR_PROFILES_DISABLED') );
	return;
}

$minimum_access = $params->get('minimum_access');
//check if user has permission
$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
if (!in_array($minimum_access, $accessLevels))
{
	//user does not have access
	JError::raiseWarning( 403, JText::_( 'COM_UEMAN_ERROR_PROFILES_NO_ACCESS') );
	return;
}

$userList = $this->userList;

if(!isset($userList))
{
	return;
}

?>

<div class="well">
	<div CLASS="row-fluid">
		<?php foreach($userList as $myuser){ ?>
			<div class="span1">
				<?php $link = 'index.php?option=com_ueman&view=profile&id='.(int)$myuser->id; ?>
				<?php if($this->cparams->show_gravatar){ ?>
					<?php
					$email = md5( strtolower( trim( htmlspecialchars(JStringPunycode::emailToUTF8($myuser->email), ENT_COMPAT, 'UTF-8') ) ) );
					echo "<a href='".$link."'><img class='thumbnail pull-left media-object xl' id='gravataImage' src='http://www.gravatar.com/avatar/".$email."' /></a>";
					?>
				<?php } ?>
				<?php if($this->cparams->show_name){ ?>
					<a href='<?php echo $link; ?>'><?php echo $myuser->name; ?></a>
				<?php } ?>
				<?php if($this->cparams->show_username){ ?>
					<a href='<?php echo $link; ?>'><?php echo $myuser->username; ?></a>
				<?php } ?>
			</div>
		<?php } ?>
	</div>
</div>