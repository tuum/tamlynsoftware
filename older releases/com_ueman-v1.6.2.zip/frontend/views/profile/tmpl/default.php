<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

$params = JComponentHelper::getParams('com_ueman');
$enable_profile = $params->get('enable_profile');

if(!$enable_profile)
{
	// Public user profiles are disabled
	JError::raiseWarning( 403, JText::_( 'COM_UEMAN_ERROR_PROFILES_DISABLED') );
	return;
}

$show_name = $params->get('show_name');
$show_username = $params->get('show_username');
$show_email = $params->get('show_email');
$minimum_access = $params->get('minimum_access');
//check if user has permission
$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
if (!in_array($minimum_access, $accessLevels))
{
	//user does not have access
	JError::raiseWarning( 403, JText::_( 'COM_UEMAN_ERROR_PROFILES_NO_ACCESS') );
	return;
}

$myuser = $this->myuser;

if(!isset($myuser))
{
	return;
}

$myprofile = $this->myprofile;
?>

<dl class="dl-horizontal">

<?php if($show_name){ ?>
	<dt><?php echo JText::_('COM_UEMAN_PROFILE_NAME_LABEL'); ?></dt>
	<dd><?php echo $myuser->name; ?></dd>
<?php } ?>

<?php if($show_username){ ?>
	<dt><?php echo JText::_('COM_UEMAN_PROFILE_USERNAME_LABEL'); ?></dt>
	<dd><?php echo $myuser->username; ?></dd>
<?php } ?>

<?php if($show_email){ ?>
	<dt><?php echo JText::_('COM_UEMAN_PROFILE_EMAIL1_LABEL'); ?></dt>
	<dd><?php echo $myuser->email; ?></dd>
<?php } ?>

<?php
	if(isset($this->myitems))
	{
		foreach ($this->myitems as $item )
		{
			$field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));

			if($item->public_profile)
			{
				//check if user has permission
				$accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
				if (!in_array($item->access, $accessLevels) && $item->access > 1)
				{
					//user does not have access, so hide this field
				}
				else
				{
					?>
					<dt><?php echo $item->title; ?></dt>
					<dd>
					<?php
						if($item->field_type==2 && isset($myprofile[$field_name]))
						{
							//checkbox question type, need to convert array to string
							$myprofile[$field_name] = implode(",",$myprofile[$field_name]);
						}
						if(isset($myprofile[$field_name]))
						{
							echo $myprofile[$field_name];
						}
						else
						{
							echo "&nbsp";
						}
					?>
					</dd>
					<?php
				}
			}
		}
	}
?>

</dl>