<?php
/*
 * @package UE Man Log authentication plugin
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('JPATH_BASE') or die;

class plgAuthenticationUem_loginas extends JPlugin
{
	protected $autoloadLanguage = true;

	/**
	 * This method handles any  authentication and reports back to the subject
	 * The method checks to see if the password entered matches the master user password
	 *
	 * @access    public
	 * @access	public
	 * @param   array 	$credentials Array holding the user credentials
	 * @param 	array   $options     Array of extra options
	 * @param   object  $response    Authentication response object
	 * @return    boolean
	 * @since 1.6
	 */
	function onUserAuthenticate( $credentials, $options, &$response )
	{
		jimport('joomla.user.helper');

		$response->type = 'Uem_loginas';
		/*
		 */
		$response->status = JAuthentication::STATUS_FAILURE;
		$response->error_message = JText::_('JGLOBAL_AUTH_INVALID_PASS');

		//fail the authentication if there is no username or password
		if (empty($credentials['username']) || empty($credentials['password']))
		{
			$response->status = JAuthentication::STATUS_FAILURE;
			$response->error_message = JText::_('JGLOBAL_AUTH_EMPTY_PASS_NOT_ALLOWED');

			return (false);
		}

		//check to make sure that the username exists, and fail authentication if it doesn't
		$db = JFactory::getDBO();
		$query	= $db->getQuery(true);
		$query->select('id');
		$query->from('#__users');
		$query->where('username=' . $db->Quote($credentials['username']));

		$db->setQuery($query);
		$result = $db->loadObject();
		if (!$result)
		{
			$response->status = JAuthentication::STATUS_FAILURE;
			$response->error_message =  JText::_('JGLOBAL_AUTH_NO_USER');

			return (false);
		}

		//check if the password matches our super awesome all powerful user
		//firstly, who is our super awesome all powerful user
		$app = JFactory::getApplication();
		$params = JComponentHelper::getParams('com_ueman');
		$awesomeuser = $params->get('loginasuser', 0);
		$enable_loginas = $params->get('enable_loginas', 0);

		if (!$awesomeuser || !$enable_loginas)
		{
			// no log in as user set in component options
			$response->status = JAuthentication::STATUS_FAILURE;
			$response->error_message =  JText::_('JGLOBAL_AUTH_NO_USER');

			return (false);
		}

		//now get their details
		$query = $db->getQuery(true);
		$query->select('id, username, password');
		$query->from('#__users AS u');
		$query->where('id ='.$awesomeuser);

		$db->setQuery($query);
		$loginasRows = $db->loadObjectList();

		if( $loginasRows)
		{
			foreach($loginasRows AS $loginasRow)
			{

				$match = false;

				if(method_exists('JUserHelper','verifyPassword'))
				{
					$match = JUserHelper::verifyPassword($credentials['password'], $loginasRow->password, $loginasRow->id);
				}
				else
				{
					$match = $this->legacyTest($loginasRow, $credentials);
				}

				if($match){
					$user = JUser::getInstance($result->id);
					$response->email = $user->email;
					$response->fullname = $user->name;
					$response->status = JAuthentication::STATUS_SUCCESS;
					$response->error_message = '';
					break;
				}
			}
		}
		else
		{
			$response->error_message = JText::_('JGLOBAL_AUTH_INVALID_PASS');
		}
	}

	/*
	 * Used for older versions of Joomla that store password differently
	 */
	private function legacyTest($row, $credentials)
	{
		$parts	= explode( ':', $row->password );
		$crypt	= $parts[0];
		$salt	= @$parts[1];
		$testcrypt = JUserHelper::getCryptedPassword($credentials['password'], $salt);

		if($crypt == $testcrypt)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}