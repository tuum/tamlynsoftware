<?php
/*
* @copyright Copyright (c) 2015 UE Man
* @license GNU General Public License version 3 or later
*
 *	  UE Man is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
*    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die('Restricted access');

class plgContentUeman_content_profiles extends JPlugin
{
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->loadLanguage();
    }

    /**
     * Use trigger onContentPrepare instead onContentAfterDisplay to avoid sorting problems with other plugins which use this (wrong!)
     * trigger. Actually this trigger should only be used to manipulate the output and not to add data to the output!
     *
     * @param string $context
     * @param object $row
     * @param string $params
     * @param integer $page
     */
    function onContentPrepare($context, &$row, &$params, $page = 0)
    {
        // Only execute plugin with this trigger in the article view and the call is from the component com_content
        if(JFactory::getApplication()->input->getWord('view') == 'article' AND $context == 'com_content.article')
        {
            $this->renderUEMContentProfiles($row, true);
        }
    }

    /**
     * This trigger (onContentAfterDisplay) is used to show the small counter in all views except the article view.
     *
     * @param string $context
     * @param object $row
     * @param string $params
     * @param integer $page
     * @return string
     */

    public function onContentAfterDisplay($context, &$row, &$params, $page = 0)
    {
        // Only show the counter if it is activated in the settings
        if($this->params->get('counter', 1))
        {
            // Only execute plugin with this trigger not in the article view and the call is from the component com_content
            if(JFactory::getApplication()->input->getWord('view') != 'article' AND ($context == 'com_content.featured' OR $context == 'com_content.category'))
            {
                return $this->renderUEMContentProfiles($row, false);
            }
        }
    }

    /**
     * Render the Author content Profile area
     *
     * @param array $row
     * @param string $view
     * @return
     */

    public function renderUEMContentProfiles(&$row, $view)
    {
        // Check whether the loaded article is excluded
        $exclude_article = $this->excludeArticles($row->id, $row->catid);

        if(empty($exclude_article))
        {

            // If view is article, then the comments box is loaded else a counter of the corresponding article
            if($view == 'article')
            {
                // Create the output of the box
                //$output = 'test is an article';
                $theme = $this->params->get('theme', 'default.php');

                // Get the path for the layout file based on the theme
                $path = JPATH_SITE.'/plugins/content/ueman_content_profiles/tmpl/'.$theme;

                // Render the theme
                ob_start();
                include $path;
                $row->text .= ob_get_clean();
            }
            else
            {
                // Create the output and return it to the trigger
                //$output = 'else test';


            }
            //return $output;
            return;
        }
    }

    /**
     * Check whether the loaded article should be excluded
     *
     * @param integer $catid
     * @return boolean
     */
    private function excludeArticles($id, $catid)
    {
        // Exclude articles via their IDs
        $exclude_articles_ids = $this->params->get('exclude_articles_ids');

        if(!empty($exclude_articles_ids))
        {
            $exclude_articles_ids = array_map('trim', explode(',', $exclude_articles_ids));

            if(in_array($id, $exclude_articles_ids))
            {
                return true;
            }
        }

        // Exclude articles via their category IDs
        $exclude_articles_categories = $this->params->get('exclude_articles_categories');

        if(!empty($exclude_articles_categories))
        {
            $exclude_articles_categories = array_map('trim', explode(',', $exclude_articles_categories));

            if(in_array($catid, $exclude_articles_categories))
            {
                return true;
            }
        }

        return false;
    }
}