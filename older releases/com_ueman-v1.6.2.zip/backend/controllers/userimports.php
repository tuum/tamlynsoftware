<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

class UemanControllerUserimports extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);
	}

	public function execute($task) {
		if(!in_array($task, array('importusers','importcsv'))) $task = 'browse';
		parent::execute($task);
	}

	function importusers()
	{
		$model = $this->getThisModel();

		$files  = JRequest::get( 'files' );

		$result = $model->importusers($files);

		//now redirect to the user import view
		$url = 'index.php?option=com_ueman&view=userimport';
		$this->setRedirect($url, '');
	}

	function importcsv()
	{
		$app = JFactory::getApplication();
		$input = $app->input;

		$session = JFactory::getSession();
		$availableFields = $session->get('availableFields');

		$myFields = explode(',', $availableFields);
		foreach($myFields AS $field)
		{
			$field = trim($field);
			//check to see what this field is mapped to
			$mymapping = $input->get($field, '', 'STR');
			$session->set($field, $mymapping);
		}

		$userGroup = $input->get('userGroup', '', 'INT');
		$session->set('userGroup', $userGroup);

		$notifyNewUser = $input->get('notifyNewUser', '', 'INT');
		$session->set('notifyNewUser', $notifyNewUser);

		$model = $this->getThisModel();

		$result = $model->importcsv();

		$countUsersUpdated = $session->get('countUsersUpdated', 0);

		//now redirect to the user import view
		$url = 'index.php?option=com_ueman&view=userimports&task=importcomplete';
		$this->setRedirect($url, JText::sprintf('COM_UEMAN_USERS_IMPORTED', $countUsersUpdated));
	}
}