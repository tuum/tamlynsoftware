<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class UemanModelUserimports extends F0FModel
{
	function importusers($files)
	{
		$filename = $files["myfilevalue"]["name"];
		$type = $files["myfilevalue"]["type"];
		$tmp_name = $files["myfilevalue"]["tmp_name"];

		if($type == 'text/csv')
		{
			$csv_terminated = "\n";
			$csv_separator = ",";
			$csv_enclosed = '"';
			$csv_escaped = "\\";

			jimport( 'joomla.filesystem.file' );
			$contents = JFile::read($tmp_name);

			// separate each line into an array
			$line = explode(PHP_EOL, $contents);

			// get the first line (header) and put it in it's own array
			$csvheader = str_getcsv ( $line[0], $csv_separator, $csv_enclosed, $csv_escaped );

			//now we need to map fields.
			//first, let's see what fields are availble
			$availableFields = 'id, name, username, email, password, block, sendEmail, registerDate, lastvisitDate, activation, params, lastResetTime, resetCount, otpKey, otep, requireReset';

			//standard UE Man fields
			$availableFields .= ', expiryDate, biography, googlePlus, facebook, linkedin, twitter, website, phone';

			$db = JFactory::getDbo();

			// get all the custom UE Man fields
			$query	= $db->getQuery(true);
			$query->from($db->quoteName('#__ueman_customfields'));
			$query->select('*');
			$query->where('enabled = 1');
			$query->order('ordering');
			$db->setQuery((string)$query);
			$myitems = $db->loadObjectList();

			foreach($myitems AS $item)
			{
				$availableFields .= ', '.$item->title;
			}

			//standard Joomla User profile plugin fields
			$availableFields .= ', address1, address2, city, region, postcode, country, phone';

			$usergroups = $this->getUserGroups();

			//now stick all this in session variables so we can get to it from the user import view
			$session = JFactory::getSession();
			$session->set('availableFields', $availableFields);
			$session->set('csvheader', $csvheader);
			$session->set('contents', $contents);
			$session->set('usergroups', $usergroups);
		}
		else
		{
			// Not a CSV file, so don't do any import
			return false;
		}

		return true;
	}

	/*
	 * This function imports users from a CSV file
	 */
	function importcsv()
	{
		$csv_terminated = "\n";
		$csv_separator = ",";
		$csv_enclosed = '"';
		$csv_escaped = "\\";

		$mapping = array();

		$countUsersUpdated = 0;

		$session = JFactory::getSession();
		$availableFields = $session->get('availableFields');
		$csvheader = $session->get('csvheader');
		$contents = $session->get('contents');
		$userGroup = $session->get('userGroup');

		//now load the users into the database
		$myFields = explode(',', $availableFields);
		foreach($myFields AS $field)
		{
			$field = trim($field);
			$mapping[$field] = $session->get($field);
		}

		// separate each line into an array
		$line = explode(PHP_EOL, $contents);

		$data = array();

		for($counter=1; $counter < count($line); $counter++)
		{
			// get the first line (header) and put it in it's own array
			$myline = str_getcsv ( $line[$counter], $csv_separator, $csv_enclosed, $csv_escaped );

			$counter2=0;
			foreach($csvheader AS $headfield)
			{
				if(isset($myline[$counter2]))
				{
					//what is the mapping field for this
					$mappingfield = $this->getMappingField(trim($headfield), $myFields, $mapping);

					if($mappingfield != null)
					{
						$data[$counter-1][$mappingfield] = $myline[$counter2];
					}
				}
				$counter2++;
			}
		}

		//now need to write these to the database
		for($i=0; $i < count($data); $i++)
		{
			$countUsersUpdated++;
			foreach($myFields AS $field)
			{
				$id=0;
				$matchid=0;
				//before we start, do we have an id field?
				if(isset($data[$i]['id']))
				{
					//yes we have an id field supplied

					//now does this user record already exist?
			 		$myid = $this->matchAgainstId($data[$i]['id']);

			 		if($myid == 0)
			 		{
			 			//no existing users with this id, can we match email or username to an existing record?
			 			$matchid = $this->matchAgainstEmail($data[$i]['email']);

			 			if($matchid)
			 			{
			 				$id = $matchid;
			 			}
			 			else
			 			{
			 				//user doesn't match. Don't update existing record.
			 				$id = 0;
			 			}
			 		}
			 		else
			 		{
			 			$id = $myid;
			 		}
				}
				else
				{
					//we don't have an id feild. Let's see if the user exists by matching on the email
					$matchid = $this->matchAgainstEmail($data[$i]['email']);

					if($matchid)
					{
						$id = $matchid;
					}
					else
					{
						//user doesn't match. Don't update existing record.
						$id = 0;
					}
				}

				if($id == 0 && $matchid == 0)
				{
					//can't match this user, let's create one
					if(isset($data[$i]['name']) && isset($data[$i]['username']) && isset($data[$i]['email']) )
					{
						$newpassword = '';
						if(!isset($data[$i]['password']) || trim($data[$i]['password']) == '' )
						{
							//no password is set, so lets generate one randomly
							jimport('joomla.user.helper');
							$newpassword = JUserHelper::genRandomPassword(8);
							$password = JUserHelper::hashPassword($newpassword);

							$data[$i]['password'] = $password;
						}
						else if(strlen($data[$i]['password']) < 60 )
						{
							//pain text password, needs to be encrypted
							jimport('joomla.user.helper');
							$data[$i]['password'] = JUserHelper::hashPassword($data[$i]['password']);
						}

						//user does not exist. Lets create one
						$id = $this->createUser($data[$i]['name'], $data[$i]['username'], $data[$i]['email'], $data[$i]['password'], $newpassword);
					}
					else
					{
						//don't have the minimum fields
						return false;
					}
				}

				//now lets write all the standard com_user fields
				$standardFields = 'id, name, username, email, password, block, sendEmail, registerDate, lastvisitDate, activation, params, lastResetTime, resetCount, otpKey, otep, requireReset';
				$stdFields = explode(',', $standardFields);

				foreach($stdFields AS $field)
				{
					$field = trim($field);
					if(isset($data[$i][$field]))
					{
						$this->updateUser($field, $data[$i][$field], $id);
					}
				}

				//is the user in the group selected?
				$this->checkUsergroup($id, $userGroup);

				//now time to update the user profile fields
				$standardFields = 'address1, address2, city, region, postcode, country, phone';
				$stdFields = explode(',', $standardFields);

				foreach($stdFields AS $field)
				{
					$field = trim($field);
					if(isset($data[$i][$field]))
					{
						$this->updateUserProfile($field, $data[$i][$field], $id);
					}
				}

				//now time to update the UE Man fields
				//standard UE Man fields
				$standardUemanFields = 'expiryDate, biography, googlePlus, facebook, linkedin, twitter, website, phone';

				$db = JFactory::getDbo();

				// get all the custom UE Man fields
				$query	= $db->getQuery(true);
				$query->from($db->quoteName('#__ueman_customfields'));
				$query->select('*');
				$query->where('enabled = 1');
				$query->order('ordering');
				$db->setQuery((string)$query);
				$myitems = $db->loadObjectList();

				foreach($myitems AS $item)
				{
					$standardUemanFields .= ', '.$item->title;
				}

				$stdFields = explode(',', $standardUemanFields);

				foreach($stdFields AS $field)
				{
					$field = trim($field);
					if(isset($data[$i][$field]))
					{
						$this->updateUserUeman($field, $data[$i][$field], $id);
					}
				}
			}
		}

		$countUsersUpdated = $session->set('countUsersUpdated', $countUsersUpdated);

		return true;
	}

	/*
	 * This function figures out when field is mapped to each column in the CSV file
	 */
	static function getMappingField($headfield, $myFields, $mapping)
	{
		foreach($myFields AS $field)
		{
			$field = trim($field);
			if(isset($mapping[$field]))
			{
				if($mapping[$field] == $headfield)
				{
					return $field;
				}
			}
		}

		return null;
	}

	/*
	 * Check to see if user exists via the id column
	 */
	static function matchAgainstId($id)
	{
		$matchid=0;

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id');
		$query->from('#__users');
		$query->where('id = '.(int)$id);

		$db->setQuery((string)$query);
		try
		{
			$matchid = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return 0;
		}

		return $matchid;
	}

	/*
	 * Check to see if this user exists against the email column
	 */
	static function matchAgainstEmail($email)
	{
		$matchid=0;

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id');
		$query->from('#__users');
		$query->where('email = '.$db->quote($email));
		$db->setQuery((string)$query);
		try
		{
			$matchid = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return null;
		}

		return $matchid;
	}

	/*
	 * Update an individual field for the user
	 */
	static function updateUser($fieldname, $value, $id)
	{
		if($fieldname == 'id')
		{
			//don't update id field
			return;
		}

		if($fieldname == 'password')
		{
			if($value == '')
			{
				//don't update blank password
				return;
			}
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->update('#__users');
		$query->set($fieldname.' = '.$db->quote($value));
		$query->where('id = '.(int)$id);

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

	/*
	 * Update an individual field for the user in the user profile
	 */
	static function updateUserProfile($fieldname, $value, $id)
	{
		if($fieldname == 'id')
		{
			//don't update id field
			return;
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//is there a user profile record for this field for this user?
		$query->select($db->quote('profile.'.$fieldname));
		$query->from('#__user_profiles');
		$query->where('user_id = '.(int)$id);
		$query->where('profile_key = '.$db->quote('profile.'.$fieldname));

		$db->setQuery((string)$query);
		try
		{
			$matchid = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return null;
		}

		if($matchid)
		{
			//yes, so let's update existing field
			$query->clear();
			$query->update('#__user_profiles');
			$query->set('profile_value = '.$db->quote($value));
			$query->where('user_id = '.(int)$id);
			$query->where('profile_key = '.$db->quote('profile.'.$fieldname));

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
		}
		else
		{
			//no, so let's insert a new record
			$query->clear();
			$query->insert('#__user_profiles');
			$query->columns(array($db->quoteName('user_id'), $db->quoteName('profile_key'),$db->quoteName('profile_value')));
			$query->set('user_id = '.(int)$id);
			$query->set('profile_key = '.$db->quote('profile.'.$fieldname));
			$query->set('profile_value = '.$db->quote($value));
			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
		}
	}

	/*
	 * Update an individual field for UE Man
	 */
	static function updateUserUeman($fieldname, $value, $id)
	{
		if($fieldname == 'id')
		{
			//don't update id field
			return;
		}

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//is there a user profile record for this field for this user?
		$query->select($db->quote('ueman.'.$fieldname));
		$query->from('#__user_profiles');
		$query->where('user_id = '.(int)$id);
		$query->where('profile_key = '.$db->quote('ueman.'.$fieldname));

		$db->setQuery((string)$query);
		try
		{
			$matchid = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return null;
		}

		if($matchid)
		{
			//yes, so let's update existing field
			$query->clear();
			$query->update('#__user_profiles');
			$query->set('profile_value = '.$db->quote($value));
			$query->where('user_id = '.(int)$id);
			$query->where('profile_key = '.$db->quote('ueman.'.$fieldname));

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
		}
		else
		{
			//no, so let's insert a new record
			$query->clear();
			$query->insert('#__user_profiles');
			$query->columns(array($db->quoteName('user_id'), $db->quoteName('profile_key'),$db->quoteName('profile_value')));
			$query->set('user_id = '.(int)$id);
			$query->set('profile_key = '.$db->quote('ueman.'.$fieldname));
			$query->set('profile_value = '.$db->quote($value));
			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
		}
	}

	/*
	 * Create a new user entry in com_users
	 */
	static function createUser($name, $username, $email, $password, $newpassword)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get next id in sequence
		$query->select('MAX(id)');
		$query->from('#__users');
		$db->setQuery((string)$query);
		try
		{
			$matchid = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return null;
		}

		$id= (int)$matchid+1;

		$query->clear();
		$query->insert('#__users');
		$query->columns(array($db->quoteName('id'), $db->quoteName('name'),$db->quoteName('username'),$db->quoteName('email'),$db->quoteName('password')));
		$query->set('id = '.(int)$id);
		$query->set('name = '.$db->quote($name));
		$query->set('username = '.$db->quote($username));
		$query->set('email = '.$db->quote($email));
		$query->set('password = '.$db->quote($password));

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$id = $db->insertid();

		if($newpassword != '')
		{
			//force password reset
			UemanModelUserimports::updateUser('requireReset', 1, $id);

			$now = JFactory::getDate();
			$currentDate=$now->format('Y-m-d H:i:s');
			UemanModelUserimports::updateUser('lastResetTime', $currentDate, $id);

			$session = JFactory::getSession();
			$notifyNewUser = $session->get('notifyNewUser', 0);

			if($notifyNewUser)
			{
				//notify user of new account and password
				$conf	= JFactory::getConfig();

				$emailRecipient = $email;
				$mailfrom     = $conf->get('mailfrom', $conf->get('config.mailfrom'));
				$fromname     = $conf->get('fromname', $conf->get('config.fromname'));
				$sitename	= $conf->get('sitename', $conf->get('config.sitename'));

				$emailBody = JText::_('COM_UEMAN_NEW_ACCOUNT_EMAIL_BODY').'<br>'.JText::_('COM_UEMAN_NEW_ACCOUNT_USERNAME').$username.'<br>'.JText::_('COM_UEMAN_NEW_ACCOUNT_PASSWORD').$newpassword.'<br><a href="'.JURI::base().'index.php?option=com_users&task=login" target="_blank">'.JURI::base().'index.php?option=com_users&task=login</a>';
				$emailSubject = JText::_('COM_UEMAN_NEW_ACCOUNT_EMAIL_SUBJECT').' '.$sitename;
				$mode = 1;

				JFactory::getMailer()->sendMail($mailfrom, $fromname, $emailRecipient, $emailSubject, $emailBody, $mode);
			}
		}

		return $id;
	}

	/*
	 * Get the Joomla user groups available
	 */
	static function getUserGroups()
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__usergroups'));
		$query->select('id, title');
		$query->where('title <> \'Super Users\'');
		$db->setQuery((string)$query);
		$mygroups = $db->loadObjectList();

		return $mygroups;
	}

	/*
	 * Check to see if the user is in the group specified, if not then add them
	 */
	static function checkUsergroup($id, $userGroup)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__user_usergroup_map'));
		$query->select('user_id');
		$query->where('user_id = '.(int)$id);
		$db->setQuery((string)$query);
		try
		{
			$groupcheck = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			echo $e->getMessage();
			return null;
		}

		if($groupcheck)
		{
			//user is already in this group
			return true;
		}
		else
		{
			//let's add them to the group
			$query->clear();
			$query->insert('#__user_usergroup_map');
			$query->columns(array($db->quoteName('user_id'), $db->quoteName('group_id') ));
			$query->set('user_id = '.(int)$id);
			$query->set('group_id = '.(int)$userGroup);

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}
		}

		return true;
	}
}