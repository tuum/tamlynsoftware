ALTER TABLE [#__ueman_customfields] ADD [default_value] [nvarchar](255) NOT NULL;
ALTER TABLE [#__ueman_customfields] ADD [placeholder] [nvarchar](255) NOT NULL;