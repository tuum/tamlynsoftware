<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die;

class ueman
{
	static function buildUserProfile()
	{
		jimport( 'joomla.filesystem.file' );
		$alert='';

		if(file_exists(JPATH_SITE. "/plugins/user/ueman/profiles/profile.xml")){
			JFile::delete(JPATH_SITE. "/plugins/user/ueman/profiles/profile.xml");
		}

		if(!file_exists(JPATH_SITE . "/plugins/user/ueman/profiles/profile.xml")){
			$mybuffer = ueman::createProfileXML();
			JFile::write(JPATH_SITE. "/plugins/user/ueman/profiles/profile.xml", $mybuffer);
			$alert.="Creating file ".JPATH_SITE. "/plugins/user/ueman/profiles/profile.xml<br>";
		}

		if(file_exists(JPATH_SITE. "/plugins/user/ueman/ueman.php")){
			JFile::delete(JPATH_SITE. "/plugins/user/ueman/ueman.php");
		}

		if(!file_exists(JPATH_SITE . "/plugins/user/ueman/ueman.php")){
			$mybuffer = ueman::createProfilePHP();
			JFile::write(JPATH_SITE. "/plugins/user/ueman/ueman.php", $mybuffer);
			$alert.="Creating file ".JPATH_SITE. "/plugins/user/ueman/ueman.php<br>";
		}

		$params = JComponentHelper::getParams('com_ueman');
		$debug = $params->get('debug');

		if($alert && $debug){
		?>
			<div class="span12">
				<div class="alert alert-info">
				<a class="close" data-dismiss="alert" href="#">×</a>
					<p><?php echo JText::_($alert); ?></p>
				</div>
			</div>
		<?php
		}
	}

	public static function createProfileXML()
	{
		$return = '<?xml version="1.0" encoding="utf-8"?>

<form>
        <fields name="uemanprofile">
                <fieldset name="uemanprofile"
                        label="PLG_USER_UEMANPROFILE_SLIDER_LABEL"
                >

';

		$params = JComponentHelper::getParams('com_ueman');
		$showGravatar = $params->get('showGravatar');
		if($showGravatar)
		{
			$return.='
			<field name="showgravatar" type="showgravatar" label="" />
			/>

';
		}

		$showExpiryDate = $params->get('showExpiryDate');
		if($showExpiryDate == 1)
		{
 			$return.='
 			<field
				name="expiryDate"
				type="calendar"
				label="COM_UEMAN_USER_FIELD_EXPIRYDATE_LABEL"
				description="COM_UEMAN_USER_FIELD_EXPIRYDATE_DESC"
				format="%Y-%m-%d %H:%M:%S"
				size="22"
				filter="user_utc"
			/>
';
		}

		$allowGroupSelection = $params->get('allowGroupSelection');
		if($allowGroupSelection == 1)
		{
			$userGroups = $params->get('userGroups');

			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
			$query->select('*');
			$query->from($db->quoteName('#__usergroups'));
			$query->order('title');
			$db->setQuery($query);
			$groups = $db->loadObjectList('id');

			$return.='
 			<field
				name="userGroup"
				type="list"
				multiple="true"
				label="COM_UEMAN_USER_FIELD_USER_GROUP_LABEL"
				description="COM_UEMAN_USER_FIELD_USER_GROUP_DESC"';

				$defaultGroup = $params->get('defaultGroup');
				if($defaultGroup > 0)
				{
					$return.='
				default="'.$defaultGroup.'"';
				}

			$return.='
			>
';

			foreach($groups as $group)
			{
				if(in_array($group->id, $userGroups))
				{
					$return.='
					<option value="'.$group->id.'">'.$group->title.'</option>';
				}
			}

			$return.='
			</field>
';
		}

		$showBiography = $params->get('showBiography');
		if($showBiography == 1)
		{
			$return.='
 			<field
				name="biography"
				type="textarea"
				class="inputbox"
				rows="3"
				cols="30"
				label="COM_UEMAN_USER_FIELD_BIOGRAPHY_LABEL"
				description="COM_UEMAN_USER_FIELD_BIOGRAPHY_DESC"
			/>

';
		}

		$showGooglePlus = $params->get('showGooglePlus');
		if($showGooglePlus == 1)
		{
			$return.='
 			<field
				name="googlePlus"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_GOOGLEPLUS_LABEL"
				description="COM_UEMAN_USER_FIELD_GOOGLEPLUS_DESC"
			/>

';
		}

		$showFacebook = $params->get('showFacebook');
		if($showFacebook == 1)
		{
			$return.='
 			<field
				name="facebook"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_FACEBOOK_LABEL"
				description="COM_UEMAN_USER_FIELD_FACEBOOK_DESC"
			/>

';
		}

		$showLinkedin = $params->get('showLinkedin');
		if($showLinkedin == 1)
		{
			$return.='
 			<field
				name="linkedin"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_LINKEDIN_LABEL"
				description="COM_UEMAN_USER_FIELD_LINKEDIN_DESC"
			/>

';
		}

		$showTwitter = $params->get('showTwitter');
		if($showTwitter == 1)
		{
			$return.='
 			<field
				name="twitter"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_TWITTER_LABEL"
				description="COM_UEMAN_USER_FIELD_TWITTER_DESC"
			/>

';
		}

		$showWebsite = $params->get('showWebsite');
		if($showWebsite == 1)
		{
			$return.='
 			<field
				name="website"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_WEBSITE_LABEL"
				description="COM_UEMAN_USER_FIELD_WEBSITE_DESC"
			/>

';
		}

		$showPhone = $params->get('showPhone');
		if($showPhone == 1)
		{
			$return.='
 			<field
				name="phone"
				type="text"
				class="inputbox"
				label="COM_UEMAN_USER_FIELD_PHONE_LABEL"
				description="COM_UEMAN_USER_FIELD_PHONE_DESC"
			/>

';
		}

		$db = JFactory::getDBO();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__ueman_customfields'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		if(isset($myitems))
		{
			foreach ($myitems as $item )
			{
				$return .= ueman::createField($item);
			}
		}

		$return.='
                </fieldset>
        </fields>
</form>';

		return $return;
	}

	public static function createField($item)
	{
		$fieldCode = '';
		$required=$item->mandatory?"true":"false";
		$item->field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));
		$label = $item->title;

		switch($item->field_type)
		{
			case "0": //text
				$fieldCode = '
 			<field
				name="'.$item->field_name.'"
				type="text"
				label="'.$label.'"
				required="'.$required.'"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
			/>

';
			break;

			case "1": //radio
				$fieldCode = '
			<field
				name="'.$item->field_name.'"
				type="radio"
				label="'.$label.'"
				class="btn-group"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
				required="'.$required.'">';

				$options = explode(',', $item->options);

				foreach($options AS $option)
				{
					$myoption = htmlspecialchars($option);
					if($myoption)
					{
						$fieldCode .='
					<option value="'.$myoption.'">'.$myoption.'</option>';
					}
				}
				$fieldCode .= '
			</field>

';
				break;

				case "2": //checkbox
					$type="checkboxes";

					$myclass = $item->mandatory?"required validate-checkbox":"";

					$fieldCode ='
				<field
					name="'.$item->field_name.'"
					type="'.$type.'"
					class="inputbox btnchk-group"
					label="'.$label.'"
					default="'.$item->default_value.'"
					hint="'.$item->placeholder.'"
			required="'.$required.'">
';

					$options = explode(',', $item->options);

					foreach($options AS $option)
					{
						$myoption = htmlspecialchars($option);
						if($myoption)
						{
							$fieldCode .='
					<option value="'.$myoption.'" class="'.$myclass.'">'.$myoption.'</option>';
						}
					}

					$fieldCode .= '
				</field>

';
				break;

			case "3": //textarea
				$rows=3;
				$cols=30;
				$fieldCode ='
 			<field
				name="'.$item->field_name.'"
				type="textarea"
				class="inputbox"
				rows="'.$rows.'"
				cols="'.$cols.'"
				label="'.$label.'"
				required="'.$required.'"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
			/>

';
			break;

		case "5": //Date
			$fieldCode ='
 			<field
				name="'.$item->field_name.'"
				type="calendar"
				label="'.$label.'"
				class="inputbox"
				size="22"
				format="%Y-%m-%d"
				filter="user_utc"
				required="'.$required.'"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
			/>

';
			break;

			case "6": //Dropdown
				$fieldCode ='
			<field
				name="'.$item->field_name.'"
				type="list"
				label="'.$label.'"
				required="'.$required.'"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
		>
		';

				$options = explode(',', $item->options);

				foreach($options AS $option)
				{
					$myoption = htmlspecialchars($option);
					if($myoption)
					{
						$fieldCode .='
				<option value="'.$myoption.'">'.$myoption.'</option>';
					}
				}
				$fieldCode .= '
		</field>

';
				break;

			case "12": //URL
				$fieldCode ='
 			<field
				name="'.$item->field_name.'"
				type="url"
				class="inputbox"
				filter="url"
				label="'.$label.'"
				required="'.$required.'"
				validate="url"
				default="'.$item->default_value.'"
				hint="'.$item->placeholder.'"
			/>
';
			break;
		}

		return $fieldCode;
	}

	public static function createProfilePHP()
	{
		$params = JComponentHelper::getParams('com_ueman');

		$db = JFactory::getDBO();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__ueman_customfields'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		$return = "&lt;&#63;php
/*
 * @package ueman user plugin
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 *
 */

defined('JPATH_BASE') or die;
require_once JPATH_ADMINISTRATOR.'/components/com_ueman/fields/showgravatar.php';

JHtml::_('jquery.framework');
include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
AkeebaStrapper::addJSfile('media://com_ueman/js/validationfix.js');

class plgUserUeman extends JPlugin
{
	/**
	 * Expiry Date.
	 *
	 * @var    string
	 */
	private &#36;expiryDate = '';

	protected &#36;autoloadLanguage = true;

	public function onContentPrepareData(&#36;context, &#36;data)
	{
		// Check we are manipulating a valid form.
		if (!in_array(&#36;context, array('com_users.profile', 'com_users.user', 'com_users.registration', 'com_admin.profile')))
		{
			return true;
		}

		if (is_object(&#36;data))
		{
			&#36;userId = isset(&#36;data-&gt;id) &#63; &#36;data-&gt;id : 0;

			if (!isset(&#36;data-&gt;uemanprofile) and &#36;userId &gt; 0)
			{
				// Load the profile data from the database.
				&#36;db = JFactory::getDbo();
				&#36;db-&gt;setQuery(
					'SELECT profile_key, profile_value FROM #__user_profiles' .
						' WHERE user_id = ' . (int) &#36;userId . \" AND profile_key LIKE 'ueman.%'\" .
						' ORDER BY ordering'
				);

				try
				{
					&#36;results = &#36;db-&gt;loadRowList();
				}
				catch (RuntimeException &#36;e)
				{
					&#36;this-&gt;_subject-&gt;setError(&#36;e-&gt;getMessage());

					return false;
				}

				// Merge the profile data.
				&#36;data-&gt;uemanprofile = array();

				foreach (&#36;results as &#36;v)
				{
					&#36;k = str_replace('ueman.', '', &#36;v[0]);
					&#36;data-&gt;uemanprofile[&#36;k] = json_decode(&#36;v[1], true);

					if (&#36;data-&gt;uemanprofile[&#36;k] === null)
					{
						&#36;data-&gt;uemanprofile[&#36;k] = &#36;v[1];
					}
				}
				&#36;data-&gt;uemanprofile['showgravatar'] = isset(&#36;data-&gt;email) ? &#36;data->email : '';
			}

			if (!JHtml::isRegistered('users.expiryDate'))
			{
				JHtml::register('users.expiryDate', array(__CLASS__, 'expiryDate'));
			}
		}

		return true;
	}

	/**
	 * returns html markup showing a date picker
	 *
	 * @param   string  &#36;value  valid date string
	 *
	 * @return  mixed
	 */
	public static function expiryDate(&#36;value)
	{
		if (empty(&#36;value))
		{
			return JHtml::_('users.value', &#36;value);
		}
		else
		{
			return JHtml::_('date', &#36;value, null, null);
		}
	}

	public function onContentPrepareForm(&#36;form, &#36;data)
	{
		if (!(&#36;form instanceof JForm))
		{
			&#36;this-&gt;_subject-&gt;setError('JERROR_NOT_A_FORM');

			return false;
		}

		include_once JPATH_ROOT.'/media/akeeba_strapper/strapper.php';
		AkeebaStrapper::addCSSfile('media://com_ueman/css/frontend.css');

		// Check we are manipulating a valid form.
		&#36;name = &#36;form-&gt;getName();

		if (!in_array(&#36;name, array('com_admin.profile', 'com_users.user', 'com_users.profile', 'com_users.registration')))
		{
			return true;
		}

		// Add the registration fields to the form.
		JForm::addFormPath(__DIR__ . '/profiles');
		&#36;form-&gt;loadFile('profile', false);

		&#36;fields = array(
				'expiryDate',
";
		if(isset($myitems))
		{
			foreach ($myitems as $item )
			{
				$return.="				'".strtolower(preg_replace('/\W+/', "_" , $item->title))."',
";
			}
		}

		$return.="
		);

		//remove expiryDate from user registration form and user profile form
		if (&#36;name == 'com_users.registration' || &#36;name == 'com_users.profile')
		{
			&#36;form->removeField('expiryDate', 'uemanprofile');
		}

		//remove user group selection from everything but user registration form
		if (&#36;name != 'com_users.registration')
		{
			&#36;form->removeField('userGroup', 'uemanprofile');
		}

		//remove gravatar from user registration form
		if (&#36;name == 'com_users.registration')
		{
			&#36;form->removeField('showgravatar', 'uemanprofile');
		}
";

		if(isset($myitems))
		{
			foreach ($myitems as $item )
			{
				$item->field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));

				if($item->registration_form == 0)
				{
					$return.="
		if (&#36;name == 'com_users.registration')
		{
			//hide this field from user registration form
			&#36;form->removeField('$item->field_name', 'uemanprofile');
		}
";
				}

				if($item->profile_form == 0)
				{
					$item->field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));
					$return.="
		if (&#36;name == 'com_users.profile')
		{
			//hide this field from user profile form
			&#36;form->removeField('$item->field_name', 'uemanprofile');
		}
";
				}

				if($item->admin_form == 0)
				{
					$item->field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));
					$return.="
		if (&#36;name == 'com_admin.profile')
		{
			//hide this field from admin profile form
			&#36;form->removeField('$item->field_name', 'uemanprofile');
		}
";
				}

				if($item->user_form == 0)
				{
					$item->field_name = strtolower(preg_replace('/\W+/', "_" , $item->title));
					$return.="
		if (&#36;name == 'com_users.user')
		{
			//hide this field from user form
			&#36;form->removeField('$item->field_name', 'uemanprofile');
		}
";
				}

				if($item->access > 1)
				{
				$return.="
		//check if user has permission
		&#36;accessLevels = JFactory::getUser()->getAuthorisedViewLevels();
		if (!in_array('$item->access', &#36;accessLevels))
		{
			//user does not have access
			//hide this field from user form
			&#36;form->removeField('$item->field_name', 'uemanprofile');
		}
";
				}

			}
		}

		$return.="
		return true;
	}

	public function onUserBeforeSave(&#36;user, &#36;isnew, &#36;data)
	{
		// Check that the date is valid.
		if (!empty(&#36;data['uemanprofile']['expiryDate']))
		{
			try
			{
				&#36;date = new JDate(&#36;data['uemanprofile']['expiryDate']);
				&#36;this-&gt;date = &#36;date-&gt;format('Y-m-d H:i:s');
			}
			catch (Exception &#36;e)
			{
				// Throw an exception if date is not valid.
				throw new InvalidArgumentException(JText::_('PLG_USER_PROFILE_ERROR_INVALID_DOB'));
			}
		}

		return true;
	}

	public function onUserAfterSave(&#36;data, &#36;isNew, &#36;result, &#36;error)
	{";

		$allowGroupSelection = $params->get('allowGroupSelection');
		if($allowGroupSelection == 1)
		{
			$userGroups = $params->get('userGroups');
			$availableUserGroups = "'".implode("','",$userGroups)."'";

			$return.="
		if(&#36;isNew && &#36;result)
		{
			&#36;availableGroups = array(".$availableUserGroups.");
			&#36;input = JFactory::getApplication()->input;
			&#36;formData  = &#36;input-&gt;post-&gt;get('jform', array(), 'array');

			&#36;ok = 1;
			foreach(&#36;formData['uemanprofile']['userGroup'] as &#36;selectedGroup)
			{
				if(!in_array(&#36;selectedGroup, &#36;availableGroups))
				{
					&#36;ok = 0;
				}
			}

			if(isset(&#36;formData['uemanprofile']['userGroup']) && &#36;ok){
				&#36;myuser = JFactory::getUser(&#36;data['id']);
				&#36;myuser-&gt;groups = &#36;formData['uemanprofile']['userGroup'];
				unset(&#36;formData['uemanprofile']['userGroup']);
				&#36;input-&gt;set('jform', &#36;formData, 'array');
				&#36;myuser-&gt;save();
			}
		}
";
		}

		$return.="
		&#36;userId = JArrayHelper::getValue(&#36;data, 'id', 0, 'int');

		if (&#36;userId && &#36;result && isset(&#36;data['uemanprofile']) && (count(&#36;data['uemanprofile'])))
		{
			try
			{
				// Sanitize the date
				&#36;data['uemanprofile']['expiryDate'] = &#36;this-&gt;date;

				&#36;db = JFactory::getDbo();
				&#36;query = &#36;db-&gt;getQuery(true)
				-&gt;delete(&#36;db-&gt;quoteName('#__user_profiles'))
				-&gt;where(&#36;db-&gt;quoteName('user_id') . ' = ' . (int) &#36;userId)
				-&gt;where(&#36;db-&gt;quoteName('profile_key') . ' LIKE ' . &#36;db-&gt;quote('ueman.%'));
				&#36;db-&gt;setQuery(&#36;query);
				&#36;db-&gt;execute();

				&#36;tuples = array();
				&#36;order = 1;

				foreach (&#36;data['uemanprofile'] as &#36;k =&gt; &#36;v)
				{
					&#36;tuples[] = '(' . &#36;userId . ', ' . &#36;db-&gt;quote('ueman.' . &#36;k) . ', ' . &#36;db-&gt;quote(json_encode(&#36;v)) . ', ' . (&#36;order++) . ')';
				}

				&#36;db-&gt;setQuery('INSERT INTO #__user_profiles VALUES ' . implode(', ', &#36;tuples));
				&#36;db-&gt;execute();
			}
			catch (RuntimeException &#36;e)
			{
				&#36;this-&gt;_subject-&gt;setError(&#36;e-&gt;getMessage());

				return false;
			}
		}

		return true;
	}

	public function onUserAfterDelete(&#36;user, &#36;success, &#36;msg)
	{
		if (!&#36;success)
		{
			return false;
		}

		&#36;userId = JArrayHelper::getValue(&#36;user, 'id', 0, 'int');

		if (&#36;userId)
		{
			try
			{
				&#36;db = JFactory::getDbo();
				&#36;db-&gt;setQuery(
						'DELETE FROM #__user_profiles WHERE user_id = ' . &#36;userId .
						\" AND profile_key LIKE 'ueman.%'\"
				);

				&#36;db-&gt;execute();
			}
			catch (Exception &#36;e)
			{
				&#36;this-&gt;_subject-&gt;setError(&#36;e-&gt;getMessage());

				return false;
			}
		}

		return true;
	}

}";

		$return = preg_replace('/&#36;/', '$' , $return);
		$return = preg_replace('/&lt;/', '<' , $return);
		$return = preg_replace('/&gt;/', '>' , $return);
		$return = preg_replace('/&#63;/', '?' , $return);
		$return = preg_replace('/\"/', '"' , $return);
		$return = preg_replace('/&amp;/', '&' , $return);

		return $return;
	}
}