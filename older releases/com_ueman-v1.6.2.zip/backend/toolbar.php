<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

class UemanToolbar extends F0FToolbar
{
	public function onProfilesBrowse()
	{
		//show toolbar on front end
		$this->renderFrontendButtons = false;
		$app = JFactory::getApplication();

		$this->onBrowse();

		JToolBarHelper::divider();
		if($app->isAdmin()){
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman&view=cpanels');
		}

		JToolBarHelper::preferences('com_ueman');
	}

	public function onCustomfieldsBrowse()
	{
		//show toolbar on front end
		$this->renderFrontendButtons = true;
		$app = JFactory::getApplication();

		$this->onBrowse();

		JToolBarHelper::divider();
		if($app->isAdmin()){
			JToolBarHelper::custom( 'rebuildProfile', 'rebuild', 'rebuild', 'COM_UEMAN_TOOLBAR_REBUILD', false );
			JToolBarHelper::divider();
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman&view=cpanels');
		}

		JToolBarHelper::preferences('com_ueman');
	}

	public function onLogsBrowse()
	{
		$this->onBrowse();

		$app = JFactory::getApplication();

		JToolBarHelper::divider();
		if($app->isAdmin()){
			JToolBarHelper::custom( 'rebuildProfile', 'rebuild', 'rebuild', 'COM_UEMAN_TOOLBAR_REBUILD', false );
			JToolBarHelper::custom( 'export', 'export', 'export', 'COM_UEMAN_TOOLBAR_EXPORT', false );
			JToolBarHelper::divider();
			JToolbarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman&view=cpanels');
		}

		JToolBarHelper::preferences('com_ueman');
	}

	public function onToolsBrowse()
	{
		JToolBarHelper::title(JText::_('COM_UEMAN_VIEW_TOOLS_TITLE'), 'ueman');
		JToolBarHelper::save();
		JToolBarHelper::divider();
		JToolBarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman');
	}

	public function onEmailtestsBrowse()
	{
		JToolBarHelper::title(JText::_('COM_UEMAN_VIEW_EMAILTESTS_TITLE'), 'ueman');
		JToolBarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman');
	}

	public function onUserimportsBrowse()
	{
		JToolBarHelper::title(JText::_('COM_UEMAN_VIEW_USERIMPORTS_TITLE'), 'ueman');
		JToolBarHelper::back('JTOOLBAR_BACK', 'index.php?option=com_ueman');
	}

	//public function onCpanelsBrowse()
	//{
	//	parent::onCpanelsBrowse();
	//
	//	JToolBarHelper::custom( 'rebuildProfile', 'rebuild', 'rebuild', 'COM_UEMAN_TOOLBAR_REBUILD', false );
	//}
}