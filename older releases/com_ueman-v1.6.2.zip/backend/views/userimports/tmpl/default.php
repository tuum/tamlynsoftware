<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

$app = JFactory::getApplication();
if ($app->isAdmin())
{
	$jinput = JFactory::getApplication()->input;
	$task = $jinput->get('task', '', 'WORD');
	if($task == 'importcomplete')
	{
		// don't show stuff below
	}
	else
	{
?>

<div class="control-group">
	<?php echo JText::_( 'COM_UEMAN_FILE_TO_IMPORT'); ?>
</div>

<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal" enctype="multipart/form-data">
	<input type="hidden" name="option" value="com_ueman" />
	<input type="hidden" name="view" value="userimport" />
	<input type="hidden" name="task" value="importusers" />

	<div class="control-group">
		<div class="control-label">
			<?php echo JText::_( 'COM_UEMAN_CHOOSE_FILE_TO_IMPORT'); ?>
		</div>
		<div class="controls">
			<input name="myfilevalue" type="file"
			label="Select CSV file to import"
			description="Choose a CSV file from your computer with a list of users to import"
			size="10"
			accept=".csv"
			/>
		</div>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-primary btn-large" value="<?php echo JText::_('COM_UEMAN_IMPORT_NEXT_BUTTON') ?>" />
	</div>
</form>

<?php
	}
}
?>