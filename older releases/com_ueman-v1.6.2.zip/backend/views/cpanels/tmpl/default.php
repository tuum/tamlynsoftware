<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

JHTML::_('behavior.framework');

$params = JComponentHelper::getParams('com_ueman');
$downloadid = $params->get('downloadid');

$lang = JFactory::getLanguage();
$icons_root = JURI::base().'media/com_ueman/images/';
?>

<div id="cpanel" class="row-fluid">
	<div class="span11">

		<div class=icon>
			<a href="index.php?option=com_ueman&view=customfields">
				<div class="ueman-icon-customfields"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_CUSTOM_FIELDS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_ueman&view=logs">
				<div class="ueman-icon-logs"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_LOGS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_ueman&view=customfields&task=rebuildProfileCpanel">
				<div class="ueman-icon-rebuild"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_REBUILD'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_ueman&view=emailtests">
				<div class="ueman-icon-emailtests"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_EMAILTESTS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_ueman&view=userexports&format=csv">
				<div class="ueman-icon-userexport"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_USEREXPORT'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_ueman&view=userimports">
				<div class="ueman-icon-userimport"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_USERIMPORT'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://ueapps.co/documentation/ueman" target="_blank">
				<div class="ueman-icon-documentation"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_USER_GUIDE'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://ueapps.co/support" target="_blank">
				<div class="ueman-icon-help"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_SUPPORT_TICKETS'); ?></span>
			</a>
		</div>

		<div class=icon>
			<a href="http://extensions.joomla.org/extensions/extension/user-enhancement-manager-ue-man" target="_blank">
				<div class="ueman-icon-rate"> </div>
				<span><?php echo JText::_('COM_UEMAN_TITLE_RATE_AND_REVIEW'); ?></span>
			</a>
		</div>
	</div>
</div>

<div class="ak_clr"></div>

<div class="row-fluid footer">
<div class="span12">
	<?php global $ueman_version; ?>
	<p style="font-size: small" class="well">Copyright &copy; <?php echo date('Y');?> <a href="http://ueapps.co" target="_blank">User Enhancement Manager</a>. All Rights Reserved.
		<?php echo JText::_( 'COM_UEMAN_VERSION'); ?>
		<?php echo $ueman_version; ?>
	</p>
</div>
</div>

<div style="clear: both;"></div>