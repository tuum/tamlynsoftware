<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

// Load FOF if not already loaded
if (!defined('F0F_INCLUDED'))
{
	$paths = array(
			(defined('JPATH_LIBRARIES') ? JPATH_LIBRARIES : JPATH_ROOT . '/libraries') . '/f0f/include.php',
			__DIR__ . '/fof/include.php',
	);

	foreach ($paths as $filePath)
	{
		if (!defined('F0F_INCLUDED') && file_exists($filePath))
		{
			@include_once $filePath;
		}
	}
}

// Pre-load the installer script class from our own copy of FOF
if (!class_exists('F0FUtilsInstallscript', false))
{
	@include_once __DIR__ . '/fof/utils/installscript/installscript.php';
}

// Pre-load the database schema installer class from our own copy of FOF
if (!class_exists('F0FDatabaseInstaller', false))
{
	@include_once __DIR__ . '/fof/database/installer.php';
}

// Pre-load the update utility class from our own copy of FOF
if (!class_exists('F0FUtilsUpdate', false))
{
	@include_once __DIR__ . '/fof/utils/update/update.php';
}

// Pre-load the cache cleaner class from our own copy of FOF
if (!class_exists('F0FUtilsCacheCleaner', false))
{
	@include_once __DIR__ . '/fof/utils/cache/cleaner.php';
}

class Com_UemanInstallerScript extends F0FUtilsInstallscript
{
	/**
	 * The title of the component (printed on installation and uninstallation messages)
	 *
	 * @var string
	 */
	protected $componentTitle = 'User Enhancement Manager';

	/**
	 * The component's name
	 *
	 * @var   string
	 */
	protected $componentName = 'com_ueman';

	/**
	 * The list of extra modules and plugins to install on component installation / update and remove on component
	 * uninstallation.
	 *
	 * @var   array
	 */
	protected $installation_queue = array
	(
			// modules => { (folder) => { (module) => { (position), (published) } }* }*
			'modules' => array(
					'site' => array(
							'ueprofile' => array('position-7', 0)
					)
			),
			// plugins => { (folder) => { (element) => (published) }* }*
			'plugins' => array(
					'system' => array(
						'ueman' => 1,
					),
					'user' => array(
						'ueman' => 1,
						'uem_log' => 1,
					),
                    'content' => array(
                        'uem_content_profiles' => 1,
                    ),
					'authentication' => array(
							'uem_loginas' => 1,
							'uem_loginviaemail' => 1,
					),
			)
	);

	/**
	 * Runs after install, update or discover_update
	 * @param string $type install, update or discover_update
	 * @param JInstaller $parent
	 */
	function postflight($type, $parent)
	{
		parent::postflight($type, $parent);
	}

	/**
	 * Renders the post-installation message
	 */
	function renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent)
	{
		?>
		<h2>Welcome to User Enhanced Manager!</h2>

		<p>Thank you for installing User Enhancement (UE) Manager for Joomla.
		This extension has auto published the required plugins to enable its features.
		Please navigate to Components -> User Enhancement Manager to start using the component.</p>

		<p><strong>Documentation</strong><br>
		Please visit our website for full documentation in regards to how to use UE Manager for Joomla.<br>
		<a href="http://ueapps.co/documentation/ueman" target="_blank">http://ueapps.co/documentation/ueman</a>
		</p>

		<p><strong>Support</strong><br>
		Need help with the extension? Visit our website for resources, FAQs and information in regards to how to get started and become a power user of UE Manager. We also provide paid support to help you get started and work out the bugs in your website.<br>
		<a href="http://ueapps.co/support" target="_blank">http://ueapps.co/support</a>
		</p>

		<p><strong>Rating and Review</strong><br>
		If you like using UE Manager, please give us a rating and review. It helps others discover and trust what we build for the Joomla community.<br>
		<a href="http://extensions.joomla.org/extensions/extension/user-enhancement-manager-ue-man" target="_blank">http://extensions.joomla.org/extensions/extension/user-enhancement-manager-ue-man</a>
		</p>

		<?php
		parent::renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent);
		?>

		<?php
	}
}