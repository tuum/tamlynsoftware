<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// no direct access
defined('_JEXEC') or die;


/**
 * Item Table class
 *
 */
class Tableitem extends JTable
{
	/**
	 * Constructor
	 *
	 * @param JDatabase A database connector object
	 */
	public function __construct(&$db)
	{
		parent::__construct('#__bfauction_items', 'bfauction_item_id', $db);

		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$this->set( 'date', $now->toSql() );
		}else{
			$this->set( 'date', $now->toMySQL() );
		}

		$user = JFactory::getUser();
		$this->set( 'created_by', (int)$user->id );
	}

	/**
	 * Overload the store method for the item table.
	 *
	 * @param	boolean	Toggle whether null values should be updated.
	 * @return	boolean	True on success, false on failure.
	 * @since	1.6
	 */
	public function store($updateNulls = false)
	{
		$date	= JFactory::getDate();
		$user	= JFactory::getUser();
		if ($this->bfauction_item_id) {
			// Existing item
			if(is_callable(array('JDate', 'toSql'))){
				$this->modified		= $date->toSql();
			}else{
				$this->modified		= $date->toMySQL();
			}
			$this->modified_by	= $user->get('id');
		} else {
			// New item. An item created and created_by field can be set by the user,
			// so we don't touch either of these if they are set.
			if (!intval($this->created)) {
				if(is_callable(array('JDate', 'toSql'))){
					$this->created = $date->toSql();
				}else{
					$this->created = $date->toMySQL();
				}
			}
			if (empty($this->created_by)) {
					$this->created_by = $user->get('id');
			}
			if (empty($this->state)) {
					$this->enabled = 1;
			}
		}

		$this->currentBid = (float)$this->currentBid;
		$this->bidIncrement = (float)$this->bidIncrement;
		$this->shipping = (float)$this->shipping;
		$this->buyNowPrice = (float)$this->buyNowPrice;
		$this->reservePrice = (float)$this->reservePrice;
		$this->commission = (float)$this->commission;
		$this->tax = (float)$this->tax;
		$this->commissionAmount = (float)$this->commissionAmount;
		$this->taxAmount = (float)$this->taxAmount;
		$this->imageShared = (int)$this->imageShared;

		$table = JTable::getInstance('Item', 'Table');

		// Attempt to store the user data.
		return parent::store($updateNulls);
	}
}

