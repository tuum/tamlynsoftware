<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionModelBids extends F0FModel
{
	public function buildQuery($overrideLimits = false)
	{
		$id	= JRequest::getVar( 'cid', 0, 'get', 'INT' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_bids');
		$query->where('itemid='.(int)$id);
		$query->order('bid_time DESC');

		return $query;
	}

	function retractBid(){
		$cid = JRequest::getVar('cid', array(), 'post') ;
		$itemid = JRequest::getVar('itemid', array(), 'post') ;

		//get all the bids for this item
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_bids');
		$query->where('itemid = '.$itemid);
		$query->order('bid_time DESC');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if(count($rows) > 1){
			//there is more than one bid one this item, need to roll back to previous one.

			//now is this the first bid?
			if($rows[0]->bfauction_bid_id == $cid){
				//This is the most recent bid for this item.

				//update item with second entry in bid history
				$query->clear();
				$query->update('#__bfauction_items');
				$query->set('currentBid = '.(float)$rows[1]->bid);
				$query->set('highBidder = '.$db->quote( $db->escape($rows[1]->username), false ) );
				$query->set('tax = '.(float)$rows[1]->tax);
				$query->set('commission = '.(float)$rows[1]->commission);
				$query->set('saleType = 1');
				$query->set('quantityPurchased = '.(int)$rows[1]->quantity);
				$query->set('deliveryOption = '.$db->quote( $db->escape($rows[1]->deliveryOption), false ) );
				$query->where('bfauction_item_id = '.(int)$itemid);

				$db->setQuery((string)$query);
				$db->query();
				if ($db->getErrorNum())
				{
					echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
					return;
				}

				//now delete the item from bidHistory
				$query->clear();
				$query->delete($db->quoteName('#__bfauction_bids'));
				$query->where('bfauction_bid_id = '.$cid);

				$db->setQuery($query);
				$result = $db->query();

			}else{
				//Not the first item, just delete this entry in the bid table

				//now delete the item from bidHistory
				$query->clear();
				$query->delete($db->quoteName('#__bfauction_bids'));
				$query->where('bfauction_bid_id = '.$cid);

				$db->setQuery($query);
				$result = $db->query();
			}
		}else{
			//this is the only bid on this item. Need to reset item.

			//reset the current item
			$query->clear();
			$query->update('#__bfauction_items');
			$query->set('currentBid = 0');
			$query->set('highBidder = 0');
			$query->set('tax = 0');
			$query->set('commission = 0');
			$query->set('saleType = 0');
			$query->set('quantityPurchased = 0');
			$query->set('deliveryOption = ""');
			$query->set('winEmailSent = 0');
			$query->set('winEmailDate = "0000-00-00 00:00:00"');
			$query->where('bfauction_item_id = '.(int)$itemid);

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//now delete the item from bidHistory
			$query->clear();
			$query->delete($db->quoteName('#__bfauction_bids'));
			$query->where('bfauction_bid_id = '.$cid);

			$db->setQuery($query);
			$result = $db->query();
		}

		return true;
	}
}