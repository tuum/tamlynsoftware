<?php

defined('_JEXEC') or die();

class BfauctionControllerPayment extends F0FController
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->modelName = 'payment';

		$this->model = $this->getThisModel();
	}

	public function display($cachable = false, $urlparams = false, $tpl = NULL)
	{
		$user = JFactory::getUser();
		if (!$user->id) {
			JError::raiseWarning(500, 'COM_BFAUCTION_LOGIN_REQUIRED');
			return;
		}

		$jinput = JFactory::getApplication()->input;
		$orderId = $jinput->get('orderId');
		if (empty($orderId)) {
			JError::raiseWarning(500, 'COM_BFAUCTION_INVALID_PARAMETERS_1');
			return;
		}

		$item = $this->model->getItemByOrderId($orderId);

		$view = $this->getView('payments', 'html');
		$view->item = $item;
		$view->display();

	}

	public function save()
	{
		$jinput = JFactory::getApplication()->input;
		$processor = $jinput->get('processor');
		$item_id = $jinput->get('item_id');

		if (empty($item_id) || empty($processor)) {
			JError::raiseWarning(500, JText::_('COM_BFAUCTION_PLUGIN_ERROR'));
			return;
		}

		$user = JFactory::getUser();
		$user_name = $user->username;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('bfauction_item_id=' . (int)$item_id);
		$query->where("highBidder='$user_name'");
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if (empty($rows) || $db->getErrorNum()) {
			JError::raiseWarning(500, 'COM_BFAUCTION_INVALID_PARAMETERS_2');
			return;
		}

		$result = $rows[0];

		$commission  = $result->currentBid * ($result->commissionAmount/100);
		$tax 		 = ($result->currentBid + $commission) * ($result->taxAmount/100);
		$quantity 	 = $result->quantity > 1 ? $result->quantity : 1;
		$totalAmount = ($result->currentBid  + $tax + $commission) * $quantity;
		$isShipping  = $result->shipping > 0;
		if ($jinput->get('deliveryOption', $isShipping) == COM_BFAUCTION_DELIVERY_DIRECT) {
			$totalAmount += $result->shipping;
		}

		$orderId = (int)$result->bfauction_item_id + 1000;
		$params = JComponentHelper::getParams('com_bfauction');
		$currency = $params->get('addcurrency', 'USD');

		$query = $db->getQuery(true);
		$query->update('#__bfauction_items');
		$query->set('orderId='.$orderId);
		$query->set("processor='$processor'");
		$query->set("currency='$currency'");
		$query->set("totalAmount=$totalAmount");
		$query->set("deliveryOption='{$jinput->get('deliveryOption')}'");
		$query->where('bfauction_item_id=' . (int)$item_id);
		$query->where("highBidder='$user_name'");

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum()) {
			JError::raiseWarning(500, 'COM_BFAUCTION_DATABASE_ERROR');
			return;
		}

		$view = $this->getView('payment', 'html');
		$view->item = $this->model->getItemByOrderId($orderId);
		$view->display();

	}

	public function update()
	{
		$orderId = JFactory::getApplication()->input->get('orderId');
		$item = $this->model->getItemByOrderId($orderId);

		if (!empty($item)) {
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('payment', $item->processor);
			$data = $dispatcher->trigger('onTP_Processpayment', array(JRequest::get('post')));
			if (empty($data)) {
				JError::raiseWarning(500, 'COM_BFAUCTION_TRANSACTION_ERROR');
				return;
			}
			$data = $data[0];

			$this->orderStatus = $orderStatus = $data['status'];
			if ($orderStatus == "C") { // Completed
				$order = array(
					'orderId' => $orderId,
					'orderStatus' => $orderStatus,
					'txnId' => $data['transaction_id'],
					'totalAmount' => $data['total_paid_amt'],
					'buyerEmail' => $data['buyer_email'],
					'rawData' => json_encode($data['raw_data']),
				);
				$this->model->updateOrder($order);
				$item = $this->model->getItemByOrderId($orderId);
			}
		}

		$view = $this->getView('payment', 'html');
		$view->item = $this->model->getItemByOrderId($orderId);
		$view->display();

	}

}