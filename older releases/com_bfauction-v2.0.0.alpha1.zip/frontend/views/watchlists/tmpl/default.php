<?php
/**
 * $Id: default.php 88 2014-02-02 11:55:57Z tuum $
 * My Bids view for BF Auction Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

	// Check to ensure this file is included in Joomla!
	defined('_JEXEC') or die();

	//equire_once( JPATH_COMPONENT_ADMINISTRATOR.'/helpers/bfauction.php' );

    $app = JFactory::getApplication();

    $params = JFactory::getApplication()->getParams();
	$bfcurrency = $params->get('bfcurrency', '$');
	$rowColour = $params->get('rowColour');
	$alternateColour = $params->get('alternateColour');
	$dateFormat = $params->get( 'dateFormat' );
	$hideBid = $params->get('hideBid');
?>

<?php
$user = JFactory::getUser();
if($user->id == 0){
	JError::raiseWarning( 403, JText::_( 'COM_BFAUCTION_ERROR_MUST_LOGIN') );
	$itemid = JRequest::getVar( 'Itemid' );
	$redirectUrl = base64_encode("index.php?option=com_bfauction&view=watchlists&Itemid=".$itemid);
	$redirectUrl = '&return='.$redirectUrl;
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl . $redirectUrl;

	echo "<br><a href='".$finalUrl."'>".JText::_( 'COM_BFAUCTION_AUCTION_LOG_IN')."</a><br>";
}else{
?>

<?php
	$items = 0;
	$limitstart = 0;
	$limit = 0;

	jimport('joomla.html.pagination');
	$pageNav = new JPagination( $items, $limitstart, $limit );
?>

<div id="editcell">

	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_ID' ); ?>
			</th>
			<th width="90" align="center">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_IMAGE' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_TITLE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap">
			    <?php echo JText::_( 'COM_BFAUCTION_TITLE_END_DATE' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_CURRENT_BID' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_HIGH_BIDDER' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				<?php echo JText::_( 'COM_BFAUCTION_TITLE_BID_NOW' ); ?>
			</th>
			<th width="10%" nowrap="nowrap" align="center">
				&nbsp;
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)
	{
		$row = &$this->items[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->bfauction_item_id );
		$link 		= JRoute::_( 'index.php?option=com_bfauction&view=auction&id='. $row->bfauction_item_id );
		$id = JHTML::_('grid.id',  $i, $row->bfauction_item_id );
		$order = JHTML::_('grid.order',  $i, $row->bfauction_item_id );

		?>

		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->bfauction_item_id; ?>
			</td>
			<td>
				<?php
				$a_pic = JPATH_SITE."/images/com_bfauction/".$row->bfauction_item_id."img1.jpg";
				if (file_exists($a_pic)){
					echo '<a href="'.JUri::base().'images/com_bfauction/'.$row->bfauction_item_id.'img1.jpg?time='.time().'"  rel="lytebox[myimages'.$i.']"><img src="'.JUri::base().'images/com_bfauction/'.$row->bfauction_item_id.'img1_t.jpg?time='.time().'"/></a>';
				}elseif($row->imageShared > 0){
					$a_pic = JPATH_SITE."/images/com_bfauction/".$row->imageShared."img1.jpg";
					if (file_exists($a_pic)){
						echo '<a href="'.JUri::base().'images/com_bfauction/'.$row->imageShared.'img1.jpg?time='.time().'"  rel="lytebox[myimages'.$i.']"><img src="'.JUri::base().'images/com_bfauction/'.$row->imageShared.'img1_t.jpg?time='.time().'"/></a>';
					}
				?>
				<?php }elseif($row->image != ""){ ?>
    				<a href="<?php echo $row->image;?>"  rel="lytebox[myimages<?php echo $i; ?>]"><img src="<?php echo $row->image;?>" width="90" border=0></a>
    			<?php } ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td align="center">
				<?php echo JHTML::_('date',  $row->endDate, $dateFormat ); ?>
			</td>
			<td align="center">
				<?php echo $bfcurrency; ?><?php echo $row->currentBid; ?>
			</td>
			<td align="center">
				<?php
				if($row->highBidder <> '0'){
					if($row->highBidder == $user->username){
						echo $row->highBidder;
					}else{
						echo substr($row->highBidder, 0, 1);
						echo "******";
						echo substr($row->highBidder, -1);
					}
				}
				?>
			</td>
			<td>
				<?php if(!$row->winEmailSent){ ?>
				<form method="get" name="adminForm"  id="adminForm" action="<?php echo JRoute::_('index.php?option=com_bfauction&view=auction&layout=item&id='.$row->bfauction_item_id); ?>">
					<input type="hidden" name="option" value="com_bfauction" />
					<input type="hidden" name="view" value="auction" />
					<input type="hidden" name="layout" value="item" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="id" value="<?php echo $row->bfauction_item_id; ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
					<input class="btn-success" name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo ($row->buyNowPrice > $row->currentBid & $hideBid) ? JText::_( 'COM_BFAUCTION_BUTTON_BUY_NOW' ):JText::_( 'COM_BFAUCTION_BUTTON_BID_NOW' ); ?>" />
				</form>
				<?php } ?>
			</td>
			<td>
				<form method="post" name="watchlist">
					<input type="hidden" name="option" value="com_bfauction" />
					<input type="hidden" name="view" value="auctions" />
					<input type="hidden" name="task" value="watchlistDelete" />
					<input type="hidden" name="boxchecked" value="0" />
					<input type="hidden" name="controller" value="" />
					<input type="hidden" name="id" value="<?php echo $row->bfauction_item_id; ?>" />
					<?php echo JHTML::_( 'form.token' ); ?>
					<input class="btn-success" name="SubmitBid" type="submit" id="SubmitBid" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_WATCHLIST_REMOVE' ) ?>" />
				</form>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	<tfoot>
	    <tr>
	      <form method="post" name="adminForm" action="index.php?option=com_bfauction">
	      	<td colspan="7"><?php echo $this->pagination->getListFooter(); ?></td>
	      	<input type="hidden" name="option" value="com_bfauction" />
		  	<input type="hidden" name="boxchecked" value="0" />
		  	<input type="hidden" name="id" value="<?php if(isset($row)){ echo $row->bfauction_item_id; } ?>" />
		  	<input type="hidden" name="view" value="watchlists" />
		  </form>
	    </tr>
	  </tfoot>

	</table>
</div>

<?php
}  // end force login
?>