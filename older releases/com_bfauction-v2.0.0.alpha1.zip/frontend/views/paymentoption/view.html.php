<?php

defined('_JEXEC') or die;

class BfauctionViewPaymentoptions extends F0FView
{
	protected $gateways = null;

	public function display($tpl = null)
	{
		$input = JFactory::getApplication()->input;
		$item_id = $input->get('itemid', 0);
		if ($item_id > 0) {
			$params = JComponentHelper::getParams('com_bfauction');
			$gateways = array();
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('payment');
			if (!is_array($params->get('gateways'))) {
				$gateway_param[] = $params->get('gateways');
			} else {
				$gateway_param = $params->get('gateways');
			}
			if (!empty($gateway_param)) {
				$gateways = $dispatcher->trigger('onTP_GetInfo', array($gateway_param));
			}
			$this->gateways = $gateways;
		}

		parent::display($tpl);
	}
}