<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */
 
defined('_JEXEC') or die();

$params = JComponentHelper::getParams('com_bfauction');

$showDisclaimer = $params->get('showDisclaimer', 0);
$disclaimerText = $params->get('disclaimerText', 0);

$app = JFactory::getApplication();

$limitstart = JRequest::getVar('limitstart', 0, '', 'int');

$app	= JFactory::getApplication();
$menus	= $app->getMenu();
$menu	= $menus->getActive();

$itemId	= JRequest::getInt('Itemid');
if($menu && !$itemId){
	$itemId = $menu->id;
}

if($showDisclaimer & $limitstart==0){
	echo $disclaimerText;
}else{
	$redirectURL = "index.php?option=com_bfauction&view=auctions&limitstart=".$limitstart."&Itemid=".$itemId;
	$msg = "";	
	$app->redirect( JRoute::_($redirectURL, false), $msg );
}
?>

<div>&nbsp;</div>
<form method="post" action="<?php echo JRoute::_('index.php?option=com_bfauction&view=auctions&limitstart='.$limitstart.'&Itemid='.$itemId); ?>" name="adminForm">
<input type="hidden" name="option" value="com_bfauction" />
<input class="btn-success" name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFAUCTION_BUTTON_GO_TO_AUCTION' ); ?>" />
</form>
