<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */
defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfauction/css/j25.css');

$viewTemplate = $this->getRenderedForm();
echo $viewTemplate;
?>