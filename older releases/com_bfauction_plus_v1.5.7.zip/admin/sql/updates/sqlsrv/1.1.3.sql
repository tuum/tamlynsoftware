ALTER TABLE [#__bfauctionplus_watchlist] ADD [emailSent] [smallint] NOT NULL;
ALTER TABLE [#__bfauctionplus_watchlist] ADD [emailDate] [datetime] NOT NULL;