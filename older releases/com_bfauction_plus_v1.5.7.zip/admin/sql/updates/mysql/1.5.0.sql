ALTER TABLE `#__bfauction_plus` ADD `url` varchar(250) NOT NULL DEFAULT '';
ALTER TABLE `#__bfauction_plus` ADD `created_by_alias` varchar(255) NOT NULL DEFAULT '';