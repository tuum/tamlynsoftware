<?php
/**
 * $Id: items.php 88 2014-02-02 11:55:57Z tuum $
 * Items Controller for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controlleradmin');

/**
 * BF Auction Plus list controller class.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_bfauction_plus
 * @since		1.6
 */
class bfauction_plusControllerItems extends JControllerAdmin
{
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->registerTask('unfeatured',	'featured');
	}

	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function getModel($name = 'Item', $prefix = 'bfauction_plusModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

    /**
     * Method to copy items
     *
     */
    public function copy()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Item', 'Table');

        $this->setRedirect( 'index.php?option=com_bfauction_plus' );

        $n		= count( $cid );

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	$row->title		= JText::_('COM_BFAUCTIONPLUS_COPY_OF').' '. $row->title;
            	$row->id            = 0;
            	$row->state     	= 0;
				$row->highBidder	= "";
				$row->currentBid	= 0;
				$row->ordering 		= 0;
				$row->winEmailSent	= 0;
				$row->winEmailDate = '0000-00-00 00:00:00';

				$now = JFactory::getDate();
				if(is_callable(array('JDate', 'toSql'))){
					$row->date	= $now->toSql();
				}else{
					$row->date 	= $now->toMySQL();
				}

				// set end date to be 7 days from now
				$date = JFactory::getDate();
				$date->modify("+7 days");

				if(is_callable(array('JDate', 'toSql'))){
					$row->endDate = $date->toSql();
				}else{
					$row->endDate = $date->toMySQL();
				}

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::sprintf( 'COM_BFAUCTIONPLUS_ITEMS_COPIED', $n ) );

        return true;
    }

	public function relist()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Item', 'Table');

        $this->setRedirect( 'index.php?option=com_bfauction_plus' );

        $n		= count( $cid );

   		//archive existing items
   		$model = $this->getModel();
		if (!$model->publish($cid, 2))
		{
			JLog::add($model->getError(), JLog::WARNING, 'jerror');
		}

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	//exitsting item is archived and new copy is created with unique id.
            	$row->id			= "";
            	$row->state     	= 1;
				$row->highBidder	= "";
				$row->currentBid	= 0;
				$row->ordering 		= 0;
				$row->winEmailSent	= 0;
				$row->winEmailDate = '0000-00-00 00:00:00';
				$item->saleType 	= 0;
				$item->quantity 	= $item->quantity ? $item->quantity : 1;

				if($row->relistid == 0){
					$row->relistid = (int) $id;

					//Use images from original item.
					$row->imageShared = (int) $id;
				}

				$now = JFactory::getDate();
				if(is_callable(array('JDate', 'toSql'))){
					$row->date	= $now->toSql();
				}else{
					$row->date 	= $now->toMySQL();
				}

				// set end date to be 7 days from now
				$date = JFactory::getDate();
				$date->modify("+7 days");

				if(is_callable(array('JDate', 'toSql'))){
					$row->endDate = $date->toSql();
				}else{
					$row->endDate = $date->toMySQL();
				}

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFAUCTIONPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::plural( 'COM_BFAUCTION_PLUS_N_ITEMS_RELISTED', $n ) );

        return true;
    }

	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   3.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}

	/**
	 * Method to toggle the featured setting of a list of articles.
	 *
	 * @return  void
	 * @since   1.6
	 */
	public function featured()
	{
		// Check for request forgeries
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		$user   = JFactory::getUser();
		$ids    = $this->input->get('cid', array(), 'array');
		$values = array('featured' => 1, 'unfeatured' => 0);
		$task   = $this->getTask();
		$value  = JArrayHelper::getValue($values, $task, 0, 'int');

		if (empty($ids))
		{
			JError::raiseWarning(500, JText::_('JERROR_NO_ITEMS_SELECTED'));
		}
		else
		{
			// Get the model.
			$model = $this->getModel();

			// Publish the items.
			if (!$model->featured($ids, $value))
			{
				JError::raiseWarning(500, $model->getError());
			}
		}

		$this->setRedirect('index.php?option=com_bfauction_plus');
	}
}