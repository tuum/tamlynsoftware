<?php
/**
 *  @package	Slick Slider
 *  @copyright	Copyright (c)2016 Tim Plummer / TamlynSoftware.com
 *  @license	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Slick Slider is a third party JQuery library developed by Ken Wheeler
 *  http://kenwheeler.github.io/slick/7
 *  Copyright (c) 2014 Ken Wheeler
 *  Licensed under the MIT license.
 */

// no direct access
defined('_JEXEC') or die('');

JHtml::_('jquery.framework');

$document = JFactory::getDocument();

$cssFile = JURI::base().'media/mod_slick/css/slick.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/slick-theme.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/style.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$document->addScript(JURI::base().'media/mod_slick/js/slick.min.js' );

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

$images = array();
$imageFolder = $params->get('imageFolder', '');
$urlPath = "images/$imageFolder";
$dir = JPATH_BASE."/$urlPath/";
if (is_dir($dir)) {
	$i = 0;
	foreach (glob("$dir/*") as $image) {
		$i++;
		$images[$i]['img'] 	 = "$urlPath/".basename($image);
		$images[$i]['title'] = '';
		$images[$i]['url']   = '';
	};
} else {
	for ($i = 1; $i <= 10; $i++) {
		$images[$i]['img']   = htmlspecialchars($params->get("image{$i}", ''));
		$images[$i]['title'] = htmlspecialchars($params->get("image{$i}title", ''));
		$images[$i]['url']   = htmlspecialchars($params->get("image{$i}url", ''));
	}
}
$target = $params->get('linksNewWindow', '');
if ($target) {
	$target = 'target="_blank"';
}

$arrowSize  = (string) $params->get('arrowSize', 60);
$arrowColor = $params->get('arrowColor', '#fff');

$document->addStyleDeclaration("
	.slick-prev::before, .slick-next::before {
		font-size: {$arrowSize}px;
		color: $arrowColor;
}");

$showArrows 	= $params->get('arrows', false) ? 'true' : 'false';
$fade 			= $params->get('fade', false) ? 'true' : 'false';
$fadeSpeed  	= (string) $params->get('fadeSpeed', '500');
$autoPlay 		= $params->get('autoplay', false) ? 'true' : 'false';
$autoPlaySpeed	= (string) $params->get('autoplaySpeed', 2000);
$showDots 		= $params->get('showDots', false) ? 'true' : 'false';
$showCaptions	= $params->get('showCaptions', false);
$infinite		= (string) $params->get('infinite', false) ? 'true' : 'false';
$swipe			= (string) $params->get('touchMove', false) ? 'true' : 'false';
// centerMode will remove the border
$centerMode		= $params->get('centerMode') ? 'true' : 'false';
$slidesToShow	= (string) $params->get('slidesToShow', 3);
$slidesToScroll = (string) $params->get('slidesToScroll', 3);
$pauseOnHover   = $params->get('pauseOnHover', true) ? 'true' : 'false';
$adaptiveHeight	= $params->get('adaptiveHeight', true) ? 'true' : 'false';
$fitImages		= $params->get('fitImages', true) ? 'true' : 'false';
$variableWidth  = intval($slidesToShow) > 1 ? 'true' : 'false';
$showArrowOnHover = $params->get('showArrowOnHover', false) ? 'show-arrow-on-hover' : '';

if ($slidesToShow <= 1) {
	$slidesToShow = 1;
	$slidesToScroll = 1;
}

$document->addScriptDeclaration(<<< JS

	jQuery(document).ready(function() {

		settings = {
			speed: 250,
			draggable: true,
			infinite: $infinite,
			swipe: $swipe,
			arrows: $showArrows,
			pauseOnHover: $pauseOnHover,
			dots: $showDots,
			centerMode: $centerMode,
			slidesToShow: $slidesToShow,
			slidesToScroll: $slidesToScroll,
		}

		if ($adaptiveHeight) {
			settings.adaptiveHeight = true;
			settings.variableWidth = false;
		} else {
			if ($fitImages) {
				settings.variableWidth = false;
			} else {
				settings.variableWidth = $variableWidth;
			}
		}

		if ($autoPlay) {
			settings.autoplay = true;
			settings.autoplaySpeed = $autoPlaySpeed;
		}

		if ($fade && $slidesToShow < 2) {
			settings.fade = true;
			settings.speed = $fadeSpeed;
			settings.cssEase = 'linear';
		}

		jQuery('.slide-container').slick(settings);

		caption = jQuery('.caption').css('margin-top');
		if (caption !== undefined) {
			jQuery('.slick-arrow').css('margin-top', "-" + caption);
		}

	});
JS
);
?>

<div class="slick<?php echo $moduleclass_sfx ?>">

	<div align='center' class='slide-container <?php echo $showArrowOnHover ?>' >

		<?php
		for ($i = 1; $i <= 10; $i++) {
			if (!isset($images[$i]['img'])) {
				continue;
			}
			$img   = $images[$i]['img'];
			$title = $images[$i]['title'];
			$url   = $images[$i]['url'];
			$caption = '';
			if ($showCaptions) {
				$caption = "<div class='caption'>{$title}</div>";
			}
			if ($url && $img) {
				echo "<div><a href='{$url}' {$target}><img src='{$img}' alt='{$title}' title='{$title}' /></a>{$caption}</div>";
			} else if ($img) {
				echo "<div><img src='{$img}' alt='{$title}' title='{$title}' /></div>";
			}
		}
		?>

	</div>

</div>
