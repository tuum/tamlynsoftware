<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class bfsurveyModelMyrequests extends FOFModel
{
	public function buildQuery($overrideLimits = false)
	{
		$user = JFactory::getUser();

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('bfsurvey_1result_id AS id, name, email, \'1\' AS catid, created_on, projectName, status');
		$query->from('#__bfsurvey_1results');
		$query->where('Name='.$db->quote($user->name));
		$query->order('created_on DESC');

		// union with the other results table
		$sub = clone($query);
		$sub->clear('select');
		$sub->select('bfsurvey_2result_id AS id, name, email, \'2\' AS catid, created_on, projectName, status');
		$sub->clear('from');
		$sub->from('#__bfsurvey_2results');
		$query->union($sub);

		return $query;
	}
}