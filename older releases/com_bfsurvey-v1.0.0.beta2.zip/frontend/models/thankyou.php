<?php
/*
 * @package BF Survey
* @copyright Copyright (c)2014 Tamlyn Software
* @license GNU General Public License version 2 or later
*/

defined('_JEXEC') or die();

class BfsurveyModelThankyou extends FOFModel
{
	public static function getThankyou()
	{
		$catid = JRequest::getVar( 'catid', 0, '', 'int' );

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('a.thankyouText, a.redirectURL, a.showReferenceNo');
		$query->from('#__bfsurvey_categories AS a');
		$query->where('a.bfsurvey_category_id = '.(int)$catid);

		$db->setQuery((string)$query);
		$result = $db->loadObjectList();

		return $result[0];
	}

}