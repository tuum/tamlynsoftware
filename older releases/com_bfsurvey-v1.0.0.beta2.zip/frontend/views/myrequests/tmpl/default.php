<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="table table-striped" id="emailList">
    <thead>
        <tr>
            <th class="title">
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_DATE' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_REQUEST_NUMBER' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_PROJECT_NAME' ); ?>
            </th>
            <th>
                <?php echo JText::_( 'COM_BFSURVEY_TITLE_STATUS' ); ?>
            </th>
        </tr>
    </thead>

    <?php
    $k = 0;
    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row =& $this->items[$i];
        $link 		= JRoute::_( 'index.php?option=com_bfsurvey&view='.$row->catid.'result&layout=form&id='.(int)$row->id );
        $checked 	= JHTML::_('grid.id',   $i, $row->id );
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo JHTML::_('date',  $row->created_on, "d-m-Y H:i" ); ?></a>
			</td>
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo $row->catid == 1 ? '#SR-':'#MR-'; ?><?php echo str_pad($row->id, 4, '0'); ?></a>
			</td>
            <td class="nowrap">
				<a href="<?php echo $link; ?>"><?php echo $row->projectName; ?></a>
			</td>
			<td class="nowrap">
				<?php
					switch($row->status){
						case 0 :	echo JText::_('COM_BFSURVEY_TITLE_NEW_REQUEST');
									break;
						case 1 :	echo JText::_('COM_BFSURVEY_TITLE_WERE_WORKING_ON_IT');
									break;
						case 2 :	echo JText::_('COM_BFSURVEY_TITLE_WAITING_FOR_CUSTOM_SAMPLES');
									break;
						case 3 :	echo JText::_('COM_BFSURVEY_TITLE_DONE_AND_DUSTED');
									break;
						default:    echo '';
					}
				?>
			</td>
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>

<input type="hidden" name="option" value="com_bfsurvey" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="" />

</form>