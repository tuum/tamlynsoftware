<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

FOFTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.jqplot.min.css');

AkeebaStrapper::addJSfile('media://com_bfsurvey/js/excanvas.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jquery.jqplot.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.highlighter.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.dateAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.barRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pieRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.hermite.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/cpanelgraphs.js');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

$graphDayFrom = gmdate('Y-m-d', time() - 30 * 24 * 3600);
// end loading files for graphs

$lang = JFactory::getLanguage();
$icons_root = JURI::base().'media/com_bfsurvey/images/';

$groups = array('basic','tools','update');

FOFTemplateUtils::addCSS('media://com_bfsurvey/css/backend.css');
?>

<?php
//content history feature was added in Joomla 3.2
if (version_compare(JVERSION, '3.2.0', 'lt'))
{
?>
<div class="alert alert-info">
	<a class="close" data-dismiss="alert" href="#">×</a>
	<p><?php echo JText::_('COM_BFSURVEY_JOOMLA_VERSION_REQUIRED'); ?></p>
</div>
<?php } ?>

<div id="cpanel" class="row-fluid">
	<div class="span11">

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=categories">
				<div class="bfsurvey-icon-category"> </div>
				<span>Survey Categories</span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=questions">
				<div class="bfsurvey-icon-question"> </div>
				<span>Questions</span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=emailitems">
				<div class="bfsurvey-icon-email"> </div>
				<span>Email Template</span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=resultscategories">
				<div class="bfsurvey-icon-results"> </div>
				<span>Results</span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=reports">
				<div class="bfsurvey-icon-reports"> </div>
				<span>Reports</span>
			</a>
		</div>

		<div class=icon>
			<a href="index.php?option=com_bfsurvey&view=maintenance">
				<div class="bfsurvey-icon-maintenance"> </div>
				<span>Maintenance</span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/documentation/bfsurvey.html" target="_blank">
				<div class="bfsurvey-icon-documentation"> </div>
				<span>User Guide</span>
			</a>
		</div>

		<div class=icon>
			<a href="http://tamlynsoftware.com/contact-us/support-tickets.html" target="_blank">
				<div class="bfsurvey-icon-help"> </div>
				<span>Support Tickets</span>
			</a>
		</div>

	</div>
</div>

<div class="ak_clr"></div>

<div class="row-fluid footer">
<div class="span12">
	<?php global $bfsurvey_version; ?>
	<p style="font-size: small" class="well">Copyright &copy;<?php echo date('Y');?> Tamlyn Software. All Rights Reserved.
		<?php echo JText::_( 'COM_BFSURVEY_VERSION'); ?>
		<?php echo $bfsurvey_version; ?>
	</p>
</div>
</div>

<!-- stuff for graphs -->
<script type="text/javascript">

bfsurvey_cpanel_graph_from = "<?php echo $graphDayFrom ?>";

(function($) {
	$(document).ready(function(){
		bfsurvey_cpanel_graphs_load();

		$('#bfsurvey_graph_reload').click(function(e){
			bfsurvey_cpanel_graphs_load();
		})
	});
})(akeeba.jQuery);
</script>
<!-- end stuff for graphs -->