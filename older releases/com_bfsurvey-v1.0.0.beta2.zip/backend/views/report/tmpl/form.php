<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();
JHtml::_('formbehavior.chosen', 'select');

$viewTemplate = $this->getRenderedForm();
echo $viewTemplate;

?>