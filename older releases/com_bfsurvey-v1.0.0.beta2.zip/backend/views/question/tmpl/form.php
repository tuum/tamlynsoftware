<?php
/*
 * @package BFSurvey
 * @copyright Copyright (c)2014 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

//$viewTemplate = $this->getRenderedForm();
//echo $viewTemplate;
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');

if(version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

FOFTemplateUtils::addCSS('media://com_bfsurvey/css/backend.css');
FOFTemplateUtils::addJS('media://com_bfsurvey/js/question.js');
?>
<form action="<?php echo JRoute::_('index.php?option=com_bfsurvey&layout=question&id='.(int) $this->item->bfsurvey_question_id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
	<input type="hidden" name="bfsurvey_question_id" id="bfsurvey_question_id" value="<?php echo $this->item->bfsurvey_question_id ?>" />
	<input type="hidden" name="option" value="com_bfsurvey" />
	<input type="hidden" name="view" value="question" />

	<!-- Begin Question -->
	<div class="span10 form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_BFSURVEY_TITLE_DETAILS') : JText::sprintf('COM_BFSURVEY_EDIT_QUESTION', $this->item->id); ?></a></li>
			<li><a href="#options" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_OPTIONS');?></a></li>
			<li><a href="#visibility" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_VISIBILITY');?></a></li>
			<li><a href="#advanced" data-toggle="tab"><?php echo JText::_('COM_BFSURVEY_TITLE_ADVANCED');?></a></li>
		</ul>
		<div class="tab-content">

			<div class="tab-pane active" id="details">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('bfsurvey_category_id'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('bfsurvey_category_id'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_name'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_name'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('question_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('question_type'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('mandatory'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('mandatory'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('parent'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('parent'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('helpText'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('helpText'); ?></div>
				</div>
			</div>

			<div class="tab-pane" id="options">
				<div class="control-group">
					<?php for ($i=1, $n=21; $i < $n; $i++ ) { ?>
						<?php $tempvalue='option'.$i; ?>
						<div class="control-label"><?php echo $this->form->getLabel($tempvalue); ?></div>
						<div class="controls"><?php echo $this->form->getInput($tempvalue); ?></div>
					<?php } ?>
				</div>
			</div>

			<div class="tab-pane" id="visibility">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('hide_question'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('hide_question'); ?> = <?php echo $this->form->getInput('hide_options'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('show_question'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('show_question'); ?> = <?php echo $this->form->getInput('show_options'); ?></div>
				</div>
			</div>

			<div class="tab-pane" id="advanced">
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suppressQuestion'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suppressQuestion'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('myclass'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('myclass'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('field_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('field_type'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('fieldSize'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('fieldSize'); ?></div>
				</div>

				<!--
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('validation_type'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('validation_type'); ?></div>
				</div>
				-->
				<input type="hidden" name="validation_type" value="" />

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('titles'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('titles'); ?></div>
				</div>

				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('sql'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('sql'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('key_field'); ?><?php echo $this->form->getLabel('total'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('key_field'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('value_field'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('value_field'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('horizontal'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('horizontal'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('prefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('prefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('suffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('suffix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('otherprefix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('otherprefix'); ?></div>
				</div>
				<div class="control-group">
					<div class="control-label"><?php echo $this->form->getLabel('othersuffix'); ?></div>
					<div class="controls"><?php echo $this->form->getInput('othersuffix'); ?></div>
				</div>
			</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
		</div>
	</fieldset>

	</div>
	<!-- End Question -->

	<!-- Begin Sidebar -->
	<div class="span2">
		<h4><?php echo JText::_('JDETAILS');?></h4>
		<hr />
		<fieldset class="form-vertical">
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('enabled'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('enabled'); ?>
				</div>
			</div>
			<div class="control-group">
				<div class="control-label">
					<?php echo $this->form->getLabel('version_note'); ?>
				</div>
				<div class="controls">
					<?php echo $this->form->getInput('version_note'); ?>
				</div>
			</div>
		</fieldset>
	</div>
	<!-- End Sidebar -->
</form>

<script language="javascript" type="text/javascript">
<!--
hideType();
//-->
</script>