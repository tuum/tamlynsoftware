ALTER TABLE `#__bfsurvey_categories` ADD `customJS` text;
ALTER TABLE `#__bfsurvey_categories` ADD `nextText` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `#__bfsurvey_categories` ADD `previousText` varchar(255) NOT NULL DEFAULT '';