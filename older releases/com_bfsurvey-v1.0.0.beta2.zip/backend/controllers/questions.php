<?php
/**
 *  @package bfsurvey
 *  @copyright Copyright (c)2014 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfsurveyControllerQuestions extends FOFController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'questions';
	}

	public function fixDatabase()
	{
		$this->setRedirect( 'index.php?option=com_bfsurvey&view=questions' );
		require_once JPATH_COMPONENT.'/helpers/answertable.php';

		$errors = answerTable::buildAnswerTables();
		if($errors){
			JError::raiseWarning(100, $errors);
		}else{
			$this->setMessage( JText::_( 'COM_BFSURVEY_DATABASE_FIXED' ) );
		}
	}

	// Tim's note: this next bit doesn't work yet
	/**
	 * Method to load a row from version history
	 *
	 * @return  mixed  True if the record can be added, a error object if not.
	 *
	 * @since   3.2
	 */
	public function loadhistory()
	{
		$app = JFactory::getApplication();
		$lang  = JFactory::getLanguage();
		$model = $this->getModel();
		$table = $model->getTable();
		$historyId = $app->input->get('version_id', null, 'integer');
		$context = "$this->option.edit.$this->context";

		if (!$model->loadhistory($historyId, $table))
		{
			$this->setMessage($model->getError(), 'error');

			$this->setRedirect(
					JRoute::_(
							'index.php?option=' . $this->option . '&view=' . $this->view_list
							. $this->getRedirectToListAppend(), false
					)
			);

			return false;
		}

		// Determine the name of the primary key for the data.
		if (empty($key))
		{
			$key = $table->getKeyName();
		}

		$recordId = $table->$key;

		// To avoid data collisions the urlVar may be different from the primary key.
		$urlVar = empty($this->urlVar) ? $key : $this->urlVar;

		// Access check.
		if (!$this->allowEdit(array($key => $recordId), $key))
		{
			$this->setError(JText::_('JLIB_APPLICATION_ERROR_EDIT_NOT_PERMITTED'));
			$this->setMessage($this->getError(), 'error');

			$this->setRedirect(
					JRoute::_(
							'index.php?option=' . $this->option . '&view=' . $this->view_list
							. $this->getRedirectToListAppend(), false
					)
			);
			$table->checkin();

			return false;
		}

		$table->store();
		$this->setRedirect(
				JRoute::_(
						'index.php?option=' . $this->option . '&view=' . $this->view_item
						. $this->getRedirectToItemAppend($recordId, $urlVar), false
				)
		);

		$this->setMessage(JText::sprintf('JLIB_APPLICATION_SUCCESS_LOAD_HISTORY', $model->getState('save_date'), $model->getState('version_note')));

		// Invoke the postSave method to allow for the child class to access the model.
		$this->postSaveHook($model);

		return true;
	}
}