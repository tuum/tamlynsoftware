<?php
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Survey is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die();

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.jqplot.min.css');

AkeebaStrapper::addJSfile('media://com_bfsurvey/js/excanvas.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jquery.jqplot.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.highlighter.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.dateAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.barRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pieRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.hermite.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.categoryAxisRenderer.min.js');
AkeebaStrapper::addJSfile('media://com_bfsurvey/js/jqplot.pointLabels.min.js');

$params = JFactory::getApplication()->getParams();
$showThisWeekNextWeek=$params->get('showThisWeekNextWeek');

if($showThisWeekNextWeek)
{

	$startDate = JFactory::getApplication()->input->get('startDate', '','STRING');
	$endDate = JFactory::getApplication()->input->get('endDate', '','STRING');

	$dateFormat = 'Y-m-d H:i:s';

	//get current date
	$now = JFactory::getDate();
	$date=$now->format('Y-m-d H:i:s');

	$startDateThisWeek = JHTML::_('date',  strtotime( 'tuesday this week' ), $dateFormat );
	$endDateThisWeek = JHTML::_('date',  strtotime( 'sunday this week' ), $dateFormat );


	$startDateLastWeek = JHTML::_('date',  strtotime( 'tuesday last week' ), $dateFormat );

	if(JHTML::_('date',  $date, 'N') === '1')
	{
		//include Monday in last weeks stats
		$endDateLastWeek = JHTML::_('date',  strtotime( 'today' ), $dateFormat );
	}else{
		$endDateLastWeek = JHTML::_('date',  strtotime( 'month this week' ), $dateFormat );
	}

?>

	<div style="width: 100%; padding:10px;" class="daterange">
		<div style="width:48%; float:left; text-align:center;" class="thisweek">
			<a href="<?php echo JRoute::_('index.php?option=com_bfsurvey&view=stats&startDate='.$startDateThisWeek.'&endDate='.$endDateThisWeek); ?>"><?php echo JText::_('COM_BFSURVEY_STATS_THIS_WEEK') ?></a>
		</div>

		<div style="width:48%; float:left; text-align:center;" class="lastweek">
			<a href="<?php echo JRoute::_('index.php?option=com_bfsurvey&view=stats&startDate='.$startDateLastWeek.'&endDate='.$endDateLastWeek); ?>"><?php echo JText::_('COM_BFSURVEY_STATS_LAST_WEEK') ?></a>
		</div>
	</div>

<?php
} //end show this week and next week links
?>

<?php foreach ($this->items as $i => $row) : ?>
	<?php
	$options = array($row->option1, $row->option2, $row->option3, $row->option4, $row->option5, $row->option6, $row->option7, $row->option8, $row->option9, $row->option10, $row->option11, $row->option12, $row->option13, $row->option14, $row->option15, $row->option16, $row->option17, $row->option18, $row->option19, $row->option20);
	$options = array_filter($options);
	$data = array();

	$catid = $row->bfsurvey_category_id;
	$question_type = $row->question_type;
	//now get the stats count for each option
	for ($x=1; $x < 21; $x++)
	{
		$question=$row->field_name;
		$name = 'option'.$x;
		$response=$row->$name;
		if($response != '' && $response != null)
		{
			if($question_type == 2){ //checkbox
				if($response == "_OTHER_"){
					$value = BfsurveyModelStats::getStatsOther($question, $response, $catid);
					$options[$x-1] = $row->otherprefix;
				}else{
					$value = BfsurveyModelStats::getStatsCheckbox($question, $response, $catid);
				}
			}else if($question_type == 0 | $question_type == 3 | $question_type == 5 | $question_type == 8 | $question_type == 9 | $question_type == 13){
				$value="";
			}else{
				if($response == "_OTHER_"){
					$value = BfsurveyModelStats::getStatsOther($question, $response, $catid);
					$options[$x-1] = trim($row->otherprefix." ".$row->othersuffix);
				}else{
					$value = BfsurveyModelStats::getStats($question, $response, $catid);
				}
			}

			$data[$x-1]=$value;
		}
	}

	if($question_type == 0 || $question_type == 3 || $question_type == 12){ //text or Textarea
		$answers = BfsurveyModelStats::getStatsText($row->field_name, $catid);
		$field_name = $row->field_name;
		echo "<hr>";
		echo "<h3>".$row->title."</h3>";
		foreach($answers AS $answer){
			if($answer->$field_name){
				echo trim($answer->$field_name)."<br>";
			}
		}
		echo "<hr>";
	}else if($question_type == 10 || $question_type == 4 || $question_type == 11 || $question_type == 7 || $question_type == 5 || $question_type == 13){ //heading or attachment or SQL or userlist or date or helptext
		// do nothing
	}else if($question_type == 9){ //rating

		$mylabels = array();
		if($row->titles == ""){
			// do nothing
		}else{
			$mylabels = preg_split("/;/",$row->titles);
		}

		for($z=0; $z < 20; $z++)
		{
			$data = array();
			$total = 0;
			$options = array();
			$myAnswer = array();
			$tempvalue="option".($z+1);

			if($row->$tempvalue != "" && $row->$tempvalue != null){

				$field=$row->field_name;
				$question=$field.'_'.($z+1);

				for($y=1; $y < $row->key_field+1; $y++){
					if($row->titles == ""){
						$response = $y;
					}else{
						$response = $mylabels[$y-1];
					}
					$answer = BfsurveyModelStats::getStats($question, $response, $catid);
					$options[$y]=$response;
					if($answer > 0){
						$total=$total + $answer;
					}

					$data[$y-1]=$answer;
					$max_y = max($data) + 1;
				}

			echo '<div id="chart'.$row->bfsurvey_question_id.'_'.$z.'" style="margin-top:20px; margin-left:20px; width:800px;"></div>';
			?>

			<script class="code" type="text/javascript">
				(function($)
				{
					$(document).ready(function()
					{

						var data = [ '<?php echo implode("', '", $data); ?>'];

						var ticks = [ '<?php echo implode("', '", $options); ?>'];

						var plot1 = $.jqplot ('chart<?php echo $row->bfsurvey_question_id; ?>_<?php echo $z; ?>', [data],
						{
							title: '<?php echo $row->$tempvalue; ?>',
							seriesDefaults: {
								// Make this a bar chart.
								renderer:$.jqplot.BarRenderer,
								rendererOptions: {
									fillToZero: true,
							  varyBarColor: true
								}
							},
							legend: { show:false },

							axes: {
								// Use a category axis on the x axis and use our custom ticks.
								xaxis: {
									renderer: $.jqplot.CategoryAxisRenderer,
									ticks: ticks
								},
								// Pad the y axis just a little so bars can get close to, but
								// not touch, the grid boundaries.  1.2 is the default padding.
								yaxis: {
									max: <?php echo $max_y ?>,
									pad: 1.05,
									tickOptions: {formatString: '%d'}
								}
							}

						}
						);
					})
				})(jQuery);
				</script>

			<?php
				// Reindex, start with rating value of 1
				$new_data = array_combine(range(1, count($data)), array_values($data));
				$total = 0;
				$count = 0;
				foreach ($new_data as $k => $v) {
					$sum = 0;
					for ($i = 1; $i < $v+1; $i++) {
						$sum += $k;
						$count++;
					}
					$total += $sum;
				}
				if ($total > 0) {
					$avg = $total / $count;
				}
			?>
			<?php if ($total > 0): ?>
				<div class="row">
					<div class="span6" style="margin-left: 60px; margin-top: 20px;">
						<table class="table table-striped table-condensed">
							<tr>
								<th class="span6">Option</th>
								<th class="span2">Count</th>
								<th class="span2">Percent</th>
								<th class="span2">&nbsp;</th>
							</tr>
							<?php for ($i =1; $i < count($new_data)+1; $i++): ?>
								<tr>
									<td><?php echo "($i) ".$options[$i] ?></td>
									<td><?php echo $new_data[$i] ?></td>
									<td><?php echo $pct = number_format(((int) $new_data[$i] / $count) * 100, 1) ?>%</td>
									<td style='vertical-align: middle' width="300px"><div class='graph<?php echo $i+1 ?>' style='height: 10px; width:<?php echo $pct ?>%'></div></td>
								</tr>
							<?php endfor; ?>
							<tr>
								<td style='text-align:right'><strong>Total</strong></td>
								<td><?php echo $count ?></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
							</tr>
							<tr>
								<td style='text-align:right'><strong>Average Rating</strong></td>
								<td><?php echo number_format($avg, 1) ?></td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
							</tr>
						</table>
					</div>
				</div>
			<?php endif; ?>

			<?php
			}
		}

	}else{
		//show graph for other question types
		echo '<div id="chart'.$row->bfsurvey_question_id.'" style="margin-top:20px; margin-left:20px; width:800px;"></div>';
	?>

	<?php
		$total = 0;
		foreach ($data as $datum) {
			$total += $datum;
		}
	?>
	<?php if ($total > 0): ?>
		<div class="row">
			<div class="span6" style="margin-left: 60px; margin-top: 20px;">
			<table class="table table-striped table-condensed">
				<tr>
					<th class="span6">Option</th>
					<th class="span2">Count</th>
					<th class="span2">Percent</th>
					<th class="span2">&nbsp;</th>
				</tr>
				<?php for ($i = 0; $i < count($data); $i++): ?>
					<tr>
						<td><?php echo $row->{'option'.($i+1)} ?></td>
						<td><?php echo $data[$i] ?></td>
						<td><?php echo $pct = number_format(((int) $data[$i] / $total) * 100, 1) ?>%</td>
						<td style='vertical-align: middle' width="300px"><div class='graph<?php echo $i+1 ?>' style='height: 10px; width:<?php echo $pct ?>%'></div></td>
					</tr>
				<?php endfor; ?>
				<tr>
					<td style='text-align:right'><strong>Total</strong></td>
					<td><?php echo $total ?></td>
					<td></td>
					<td></td>
				</tr>
			</table>
			</div>
		</div>
	<?php endif; ?>

	<script class="code" type="text/javascript">
	(function($)
	{
		$(document).ready(function()
		{
			//var data = [ <?php echo ($question_type == 2)? implode(",", $data) : "'".implode("', '", $data)."'"; ?>];
			var data = [ <?php echo ($question_type == 2 || $question_type == 1)? implode(",", $data) : "'".implode("', '", $data)."'"; ?>];

			var ticks = [ '<?php echo implode("', '", $options); ?>'];

			var plot1 = $.jqplot ('chart<?php echo $row->bfsurvey_question_id; ?>', [data],
			{
				title: '<?php echo $row->title; ?>',
				seriesDefaults: {
					// Make this a bar chart.
					renderer:$.jqplot.BarRenderer,
					rendererOptions: {
						fillToZero: true,
				  varyBarColor: true
					}
				},
				legend: { show:false },

				axes: {
					// Use a category axis on the x axis and use our custom ticks.
					xaxis: {
						renderer: $.jqplot.CategoryAxisRenderer,
						ticks: ticks
					},
					// Pad the y axis just a little so bars can get close to, but
					// not touch, the grid boundaries.  1.2 is the default padding.
					yaxis: {
						pad: 1.05,
						tickOptions: {formatString: '%d'}
					}
				}

			}
			);

			//Generate the img version of the graph for PDF export
 			$('#chart<?php echo $row->bfsurvey_question_id; ?>').jqplotSaveImage();

		})

		$.fn.jqplotSaveImage = function() {
	    	var imgData = $('#chart<?php echo $row->bfsurvey_question_id; ?>').jqplotToImageStr({});
	    	if (imgData) {
	        	//window.location.href = imgData.replace("image/png", "image/octet-stream");
	    	}
		};
	})(jQuery);
	</script>

	<?php } ?>

 <?php endforeach; ?>

<!--
<div id="chart1" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
		  var data = [
		    ['Heavy Industry', 12],['Retail', 9], ['Light Industry', 14],
		    ['Out of home', 16],['Commuting', 7], ['Orientation', 9]
		  ];
		  var plot1 = $.jqplot ('chart1', [data],
		    {
		      title: 'Bubble Chart with Gradient Fills',
		      seriesDefaults: {
		        // Make this a pie chart.
		        renderer: $.jqplot.PieRenderer,
		        rendererOptions: {
		          // Put data labels on the pie slices.
		          showDataLabels: true,
		          dataLabels: 'all'
		        }
		      },
		      legend: { show:true, location: 'e' }
		    }
		  );
	})
})(jQuery);
</script>
 -->

<!--
<div id="chart2" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
	  var data = [
	    12, 9, 14, 16, 7, 9
	  ];

	  var ticks = ['Heavy Industry', 'Retail', 'Light Industry', 'Out of home', 'Commuting', 'Orientation'];

	  var plot1 = $.jqplot ('chart2', [data],
	    {
	      title: 'Second Chart example',
	      seriesDefaults: {
	        // Make this a bar chart.
			renderer:$.jqplot.BarRenderer,
	        rendererOptions: {
	          fillToZero: true,
			  varyBarColor: true
	        }
	      },
	      legend: { show:false },

	      axes: {
	          // Use a category axis on the x axis and use our custom ticks.
	          xaxis: {
	              renderer: $.jqplot.CategoryAxisRenderer,
	              ticks: ticks
	          },
	          // Pad the y axis just a little so bars can get close to, but
	          // not touch, the grid boundaries.  1.2 is the default padding.
	          yaxis: {
	              pad: 1.05,
	              tickOptions: {formatString: '%d'}
	          }
	      }

	    }
	  );
	})
})(jQuery);
</script>
 -->

<!--
<div id="chart3" style="margin-top:20px; margin-left:20px; width:800px; height:600px;"></div>

<script class="code" type="text/javascript">
(function($)
{
	$(document).ready(function()
	{
		  var data = [
		    [12,1], [9,2], [14,3], [16,4], [7,5], [9,6]
		  ];

		  var ticks = ['Heavy Industry', 'Retail', 'Light Industry', 'Out of home', 'Commuting', 'Orientation'];

		  var plot1 = $.jqplot ('chart3', [data],
		    {
		      title: 'Second Chart example',
		      seriesDefaults: {
		        // Make this a bar chart.
				renderer:$.jqplot.BarRenderer,
		        rendererOptions: {
		          fillToZero: true,
		          barDirection: 'horizontal',
		          varyBarColor: true
		        },
		        shadowAngle: 135,
		      },
		      legend: { show:false },

		      axes: {
		          // Use a category axis on the x axis and use our custom ticks.
		          yaxis: {
		              renderer: $.jqplot.CategoryAxisRenderer,
		              ticks: ticks
		          },
		          // Pad the y axis just a little so bars can get close to, but
		          // not touch, the grid boundaries.  1.2 is the default padding.
		          xaxis: {
		              pad: 1.05,
		              tickOptions: {formatString: '%d'}
		          }
		      }
		    }
		  );
	})
})(jQuery);
</script>
 -->