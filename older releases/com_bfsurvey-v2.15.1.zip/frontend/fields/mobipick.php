<?php defined('_JEXEC') or die('Restricted access');
/*
 * @package bfsurvey
 * @copyright Copyright (c)2015 Tamlyn Software
 * @license GNU General Public License version 3 or later
 * @link http://www.tamlynsoftware.com
 *
* Mobile Friendly Calendar Pop-up
*
* @author Tim Plummer
*
* Mobi Pick - An Android-style datepicker widget for jQuery Mobile.
* Created by Christoph Baudson.
* @license Licensed under MIT license
* @link https://github.com/sustainablepace/mobipick
* @version 0.9
* */

jimport('joomla.form.formfield');

F0FTemplateUtils::addCSS('media://com_bfsurvey/css/jquery.mobile-1.4.5.min.css');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/jquery.mobile-1.4.5.js');
F0FTemplateUtils::addCSS('media://com_bfsurvey/css/mobipick.css');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/xdate.js');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/xdate.i18n.js');
F0FTemplateUtils::addJS('media://com_bfsurvey/js/mobipick.js');

class JFormFieldMobipick extends JFormField {

	/**
	 * field type
	 * @var string
	 */
	protected $type = 'Mobipick';

	/**
	 * Method to get the field input markup
	 */
	protected function getInput() {

		//script in parent

		$js = 'jQuery(document).ready(function(){
				window.addEvent(\'domready\',function(){
					jQuery( "input.mobipickcalendar" ).mobipick({
						dateFormat: "dd-MM-yyyy"
					});
				});
});';

		JFactory::getDocument()->addScriptDeclaration($js);

		// The input field
		// class='required' for client side validation
		$class = ' class="mobipickcalendar"';

		if ($this->required) {

			$class = ' class="mobipickcalendar required"';
		}

		$html = array();
		$html[] = '<input ' . $class . ' type="text" name="' . $this->name . '" id="' . $this->id . '" placeholder="' . $this->hint . '" size="30" value="' . $this->value . '" />';

		return implode("\n", $html);
	}

}