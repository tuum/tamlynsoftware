ALTER TABLE [#__bfsurvey_categories] ADD [customJS] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_categories] ADD [nextText] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfsurvey_categories] ADD [previousText] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfsurvey_categories] ADD [accessStats] [int] NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] CHANGE [sendTo] [sendTo] [nvarchar](max) NOT NULL;
ALTER TABLE [#__bfsurvey_emailitems] ADD [sendToGroup] [bigint] NOT NULL;