<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/**
 * $Id: default.php 58 2014-03-08 08:42:59Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
?>
<?php
if($this->uid == 0){
   echo JText::_("COM_BFSURVEYPLUS_ERROR_YOU_MUST_LOG_IN_VIEW");
}else{

$Itemid = JRequest::getVar('Itemid');

$readOnly = $this->params->get( 'readOnly' );

$session = JFactory::getSession();
$session->set('readOnly', $readOnly);

?>

<div id="editcell">
    <table width="100%">
    <thead>
        <tr class="bfsurvey_plusQuestion">
			<th align="center">
				<?php echo JText::_( 'COM_BFSURVEYPLUS_SURVEY_ID' ); ?>
			</th>
            <th align="center">
                <?php echo JText::_( 'COM_BFSURVEYPLUS_TITLE_DATE' ); ?>
            </th>
            <th align="center">
                <?php echo JText::_( 'COM_BFSURVEYPLUS_SURVEY_NAME' ); ?>
            </th>
            <th align="center">
                &nbsp;
            </th>
        </tr>
    </thead>
    <?php
    $k = 0;

	if(!$this->items){
	   //do nothing
	}else{
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row =& $this->items[$i];
			?>
			<tr class="bfsurvey_plusOptions">
				<td align="center">
					<?php echo str_pad($row->id, 5, '0', STR_PAD_LEFT); ?>
				</td>
				<td align="center">
					<?php echo $row->DateReceived; ?>
				</td>
				<td align="center">
					<?php echo $row->title; ?>
				</td>
				<td align="center">
					<form action="<?php echo JRoute::_( 'index.php?option=com_bfsurvey_plus&view=edit' ); ?>" method="post" name="adminForm">
						<input name="Submit" type="submit" id="Submit" value="<?php echo JText::_( 'COM_BFSURVEYPLUS_EDIT' ); ?>" />
						<input type="hidden" name="option" value="com_bfsurvey_plus" />
						<input type="hidden" name="task" value="edit" />
						<input type="hidden" name="catid" value="<?php echo $row->catid ?>" />
						<input type="hidden" name="id" value="<?php echo $row->id ?>" />
						<input type="hidden" name="Itemid" value="<?php echo $Itemid ?>" />
					</form>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
	}
    ?>
    </table>
</div>


<?php
}
?>