<?php
/**
 * $Id: controller.php 61 2014-07-20 05:08:04Z tuum $
 * bfsurvey_plus default controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');
class BFSurveyPlusController extends JControllerLegacy
{
	public static function getQuestions()
	{
	    $catid	= JRequest::getVar( 'catid', 0, '', 'int' );

	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get questions
		if($catid == 0)
		{
			$query->from('#__bfsurvey_plus AS a');
			$query->select('a.*,  c.title AS category_name');
			$query->join('LEFT', '#__categories AS c ON c.id = a.catid');
			$query->where('(a.state IN (0, 1))');
			$query->order('a.catid, a.ordering');
		} else {
		    $query->from('#__bfsurvey_plus AS a');
			$query->select('a.*');
			$query->where('(a.state IN (0, 1))');
			$query->where('a.catid = '.(int) $catid);
			$query->order('a.ordering');
		}

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows;
	}

	static function getSQL($query)
	{
	    $db		= JFactory::getDbo();

 	    $db->setQuery((string)$query);
  		$rows = $db->loadObjectList();
   		if ($db->getErrorNum())
   		{
   			echo $db->stderr();
   			return false;
   		}
		return $rows;
	}

	public static function getAnswers($id, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from('#__bfsurveyplus_'.(int)$catid.' AS a');
		$query->select('a.*');
		$query->where('a.id = '.(int) $id);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}
		return $rows;
	}

	public static function getNextQuestion($question, $response)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);


		// get questions
		$catid	= JRequest::getVar( 'catid', 0, '', 'int' );
		if ($catid == 0){
			$query->from('#__bfsurvey_plus AS a');
			$query->select('a.*');
			$query->where('(state IN (0, 1))');
			$query->where('a.id = '.(int) $question);
		} else {
			$query->from('#__bfsurvey_plus AS a');
			$query->select('a.*');
			$query->where('(state IN (0, 1))');
			$query->where('a.catid = '.(int) $catid);
			$query->where('a.id = '.(int) $question);
		}
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$next_question=0;

		if ($rows[0]->question_type == 0)	// textbox
		{
		   $next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->question_type == 3)	// textarea
		{
			$next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->question_type == 5)	// date
		{
			$next_question = $rows[0]->next_question1;
		}

		if ($rows[0]->option1 == $response)
		{
		   $next_question = $rows[0]->next_question1;
		} else if ($rows[0]->option2 == $response){
		   $next_question = $rows[0]->next_question2;
		} else if ($rows[0]->option3 == $response){
		   $next_question = $rows[0]->next_question3;
		} else if ($rows[0]->option4 == $response){
		   $next_question = $rows[0]->next_question4;
		} else if ($rows[0]->option5 == $response){
		   $next_question = $rows[0]->next_question5;
		} else if ($rows[0]->option6 == $response){
		   $next_question = $rows[0]->next_question6;
		} else if ($rows[0]->option7 == $response){
		   $next_question = $rows[0]->next_question7;
		} else if ($rows[0]->option8 == $response){
		   $next_question = $rows[0]->next_question8;
		} else if ($rows[0]->option9 == $response){
		   $next_question = $rows[0]->next_question9;
		} else if ($rows[0]->option10 == $response){
		   $next_question = $rows[0]->next_question10;
		} else if ($rows[0]->option11 == $response){
		   $next_question = $rows[0]->next_question11;
		} else if ($rows[0]->option12 == $response){
		   $next_question = $rows[0]->next_question12;
		} else if ($rows[0]->option13 == $response){
		   $next_question = $rows[0]->next_question13;
		} else if ($rows[0]->option14 == $response){
		   $next_question = $rows[0]->next_question14;
		} else if ($rows[0]->option15 == $response){
		   $next_question = $rows[0]->next_question15;
		} else if ($rows[0]->option16 == $response){
		   $next_question = $rows[0]->next_question16;
		} else if ($rows[0]->option17 == $response){
		   $next_question = $rows[0]->next_question17;
		} else if ($rows[0]->option18 == $response){
		   $next_question = $rows[0]->next_question18;
		} else if ($rows[0]->option19 == $response){
		   $next_question = $rows[0]->next_question19;
		} else if ($rows[0]->option20 == $response){
		   $next_question = $rows[0]->next_question20;
		}

		if ($rows[0]->question_type == 9)	// rating
		{
			$next_question = $rows[0]->next_question1;
		}

		//for SQL lookup
		if($rows[0]->sql != "" & $rows[0]->sqlfield != ""){
   			$next_question = $rows[0]->next_question1;
		}

		//special case for checkbox
		//take the lowest next question id out of those selected
		$check_msg="";
		if ($rows[0]->question_type == 2 & $response != NULL)	// checkbox
		{
			if(isset($response)){
				foreach($response as $value)
         		{
            	   $check_msg .= "$value\n";
           		}
			}
       		$response = $check_msg;

			for($i=0; $i < 20; $i++){
	             $myoption="option".($i+1);
	             $mynextquestion="next_question".($i+1);

	             if($rows[0]->$myoption){
	                //does answer contain this option
	                $response=" ".$response;
	                if(strpos(strtoupper($response), strtoupper($rows[0]->$myoption) )){
						//is next question id lower than current?
	                	if($rows[0]->$mynextquestion < $next_question | $next_question==0){
							$next_question=$rows[0]->$mynextquestion;
						}
			  	    }
			  	 }
	          }
		}

		return $next_question;
	}

	public static function getQuestion($question)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get question
		$query->from('#__bfsurvey_plus AS a');
		$query->select('question');
		$query->where('a.id = '.(int) $question);

		$db->setQuery((string)$query);
		$result=$db->loadResult();

	    return $result;
    }

	public static function save($name, $company, $email, $table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// todays date
		$now = JFactory::getDate();
		if(is_callable(array('JDate', 'toSql'))){
			$dateReceived	= $now->toSql();
		}else{
			$dateReceived 	= $now->toMySQL();
		}

		$ip = BFSurveyPlusController::getIP();

		// save data
		$query->clear();
		$query->insert($table);
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->columns(array($db->quoteName('Name'), $db->quoteName('Company'), $db->quoteName('Email'), $db->quoteName('DateReceived'), $db->quoteName('ip'), $db->quoteName('state') ));
			$query->values($db->quote( $db->escape( $name ), false ).', '.$db->quote( $db->escape( $company ), false ).', '.$db->quote( $db->escape( $email ), false ).', '.$db->quote( $dateReceived, false).', '.$db->quote($ip, false).',1' );
		}else{
			//joomla 1.6 support
	        $query->set('`Name` = '.$db->quote( $db->escape( $name ), false ) );
	        $query->set('`Company` = '.$db->quote( $db->escape( $company ), false ) );
	        $query->set('`Email` = '.$db->quote( $db->escape( $email ), false ) );
	        $query->set('`DateReceived` = '.$db->quote( $dateReceived, false) );
	        $query->set('`ip` = '.$db->quote($ip, false) );
		}
		$db->setQuery((string)$query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return $db->insertid();
	}

	public static function checkIP($table, $ip)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	   	$query->from($table.' AS a');
		$query->select('count(a.ip)');
		$query->where('a.ip = '. $db->quote($ip).'AND a.state>-1' );

		$db->setQuery((string)$query);
	   	$result=$db->loadResult();

	   	return $result;
	}

	public static function checkEmail($table, $myemail)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		if ($myemail == "")
		{
			// don't check anonymous responses
			return 0;
		} else {
			$query->from($db->quoteName($table).' AS a');
			$query->select('count(a.Email)');
			$query->where('a.Email = '.$db->quote( $db->escape( $myemail ), false ).'AND a.state>-1' );

			$db->setQuery((string)$query);
			$result=$db->loadResult();

			return $result;
	   }
	}

	function getField($id, $field_name, $table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// get answer
		$query->from($db->quoteName($table));
		$query->select($field_name);
		$query->where('id = '.(int)$id );

		$db->setQuery((string)$query);
		$result=$db->loadResult();

	    return $result;
	}

	public static function saveField($id, $field_name, $answer, $table)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		// save data
		$query->update($db->quoteName($table));
		$query->set($field_name.' = '.$db->quote( $db->escape( $answer ), false ) );
		$query->where('id = '.(int)$id );

		$db->setQuery((string)$query);
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

	function updateOnePage()
	{
	    JRequest::checkToken() or jexit( JText::_( 'COM_BFSURVEYPLUS_ERROR_INVALID_TOKEN') );
		//get parameters
		$Itemid = JRequest::getVar('Itemid');
		$menu = JMenu::getInstance('site');

		$app		= JFactory::getApplication();
		$params		= $app->getParams();

		$allowAuthorEmail = $params->get( 'authorEmail' );
		$allowEmail = $params->get( 'allowEmail' );
		$sendEmailTo = $params->get( 'sendEmailTo' );

		$use_captcha = $params->get( 'use_captcha' );
		/**
		Captcha
		*/
		$correct=1;
		if ($use_captcha)
		{
			if (class_exists('plgSystemBigocaptcha')) {
	   			$correct=BFSurveyPlusController::_checkCaptcha();
	   			if (!$correct)
	   			{
		   			JError::raiseWarning("666", JText::_( 'COM_BFSURVEYPLUS_ERROR_WRONG_CAPTCHA') );
	   				$page_no=1;
	   				$start_qn = -1;
	   				$end_qn = 0;
	   			} else {
		   		   // 	captcha is correct
				}
			}else{
				/* Recaptcha */
				$post = JRequest::get('post');
				JPluginHelper::importPlugin('captcha');

				$plugin = JPluginHelper::getPlugin('captcha');
				$pluginParams = new JRegistry();
				$pluginParams->loadString($plugin[0]->params);
				$pubkey = $pluginParams->get('public_key', '');
				if ($pubkey == null || $pubkey == ''){
					//do nothing
				}else{
					$dispatcher = JDispatcher::getInstance();
					$res = $dispatcher->trigger('onCheckAnswer',$post['recaptcha_response_field']);
					if(!$res[0]){
						//JError::raiseWarning( "666", JText::_( 'COM_BFSURVEYPLUS_ERROR_WRONG_CAPTCHA') );
						$msg = JText::_( 'COM_BFSURVEYPLUS_ERROR_WRONG_CAPTCHA');
						$page_no=1;
						$start_qn = -1;
						$end_qn = 0;
						$correct = 0;
						$catid = JRequest::getVar( 'catid', 0, '', 'int' );
						$Itemid = JRequest::getVar( 'Itemid', 0, '', 'int' );
						$link = 'index.php?option=com_bfsurvey_plus&view=onepage&catid='.$catid.'&Itemid='.$Itemid;
						$this->setRedirect($link, $msg);
					}
				}
				/* End Recaptcha */
			}
		}

		if ($correct)
		{
			$session = JFactory::getSession();

			$fullname = JRequest::getVar( 'fullname', "", 'post', 'string' );
			$company = JRequest::getVar( 'company', "", 'post', 'string' );
			$email = JRequest::getVar( 'email', "", 'post', 'string' );
			$catid = JRequest::getVar( 'catid', 0, '', 'int' );

			$anonymous = JRequest::getVar( 'anonymous', "No", 'post', 'string' );
			if ($anonymous == 'Yes') {
				$fullname = "Anonymous";
				$company = "";
				$email = "";
			}

			$session->set('fullname', $fullname);
			$session->set('company', $company);
			$session->set('email', $email);

			$table="#__bfsurveyplus_".(int)$catid;

			$preventMultipleEmail = JRequest::getVar( 'preventMultipleEmail', "", 'post', 'string' );

			$emailcount = BFSurveyPlusController::checkEmail($table,$email);

			$user = JFactory::getUser();

			if ($emailcount < 1 | $preventMultipleEmail != "1")	// check if email address has already completed survey
			{
			//are you using edit view?
			$qid = JRequest::getVar( 'qid', "", 'post', 'string' );
			$id=null;
			if (!empty($qid))
			{
				$id=$qid;
				BFSurveyPlusController::saveField($id, "Name", $fullname, $table);
				BFSurveyPlusController::saveField($id, "Company", $company, $table);
				BFSurveyPlusController::saveField($id, "Email", $email, $table);
			} else {
	    		// save basic details to db, and generate id
				$id = BFSurveyPlusController::save($fullname, $company, $email, $table);
				$session = JFactory::getSession();
				$session->set('referenceNo', $id);
			}

			//save uid
			BFSurveyPlusController::saveField($id,"uid", $user->id, $table);

			$items = BFSurveyPlusController::getQuestions();

			$total_qns=count( $items );
			$emailBody="";

			for ($i=0; $i < $total_qns; $i++)
			{
		    	$check_msg = "";
				$row = $items[$i];
				$fieldName = $row->field_name;

				if ($row->question_type == 1)	// radio
				{
					if (JRequest::getVar($fieldName) == "_OTHER_")
					{
		         		$temp = $fieldName;
			      	    $temp .= '_OTHER_';
		         		$answer = JRequest::getVar($temp);
		      		} else {
		        	 	$answer = JRequest::getVar($fieldName);
		      		}
		    	} else if ($row->question_type == "2"){	// Checkbox
			   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );
					if ($name == "")
					{
					   //do nothing
					} else {
			   			foreach ($name as $value)
			   			{
			    		   	if ($value == "_OTHER_")
			    		   	{
			    		      	$temp = $fieldName;
			        	        $temp .= '_OTHER_';
						      	$value = JRequest::getVar($temp);
        				   	}
				 			$check_msg .= "$value\n";
				 		}
			   		}
				    $answer = $check_msg;
				} else if ($row->question_type == "8"){	// Summation
			   		$name = JRequest::getVar( ''.$fieldName.'', array(), 'post', 'array' );

			   		foreach ($name as $value)
			   		{
					   	$check_msg .= "$value\n";
			   		}
				    $answer = $check_msg;
				} else if ($row->question_type == "9"){   // Rating
				   $emailBody .= "<br>".$row->question.": <br>";
				   for ($z=0; $z < 20; $z++)
				   {
				      $field = $fieldName;
				      $field .= ($z+1);
				      $answer = JRequest::getVar($field);
				      $tempvalue="option".($z+1);

				      if ($answer != "" & $answer != "NULL"){
				         BFSurveyPlusController::saveField($id, $field, $answer, $table);
				         $emailBody .= "<br>".$row->$tempvalue.": <br>".JText::_("Answer").": ".$answer."<br>";
				      }
				   }

		    		// skip the next bit as we've already done it. '
		    		$answer="";
		    		$fieldName = "";
				} else {
				   $answer = JRequest::getVar($fieldName);
				}

				if ($answer == "")
				{
				    // do nothing
	 	    	} else {
				   $emailBody .= "<br>".$row->question.": <br>".JText::_("COM_BFSURVEYPLUS_ANSWER").": ".$answer."<br>";
   				}

				if ($fieldName == "")
				{
				   // do nothing
				} else {
					if($row->question_type == 10){  //heading
						//do nothing
					}else{
  				   		BFSurveyPlusController::saveField($id, $fieldName, $answer, $table);
					}
  				}
			}

			//------------------------------------ email ------------------------------------------------------------
			//send email confirmation
			if($allowEmail){
				BFSurveyPlusController::triggerEmails("Admin", $sendEmailTo, $emailBody, $catid);
			}
			if($allowAuthorEmail == "1" & $session->get('email')!=""){
				BFSurveyPlusController::triggerEmails("Author", $session->get('email'), $emailBody, $catid);
			}
			//------------------------------------ end email ------------------------------------------------------------

			BFSurveyPlusController::myRedirect();

			} else {
			   echo JText::_( 'COM_BFSURVEYPLUS_ERROR_EMAIL_ALREADY_COMPLETED' );
      		}
      	}
	}

	public static function myRedirect()
	{
	   $thankyouText = JRequest::getVar( 'thankyouText', "", 'post', 'string' );
	   $redirectURL = JRequest::getVar( 'redirectURL', "", 'post', 'string' );
	   $showReferenceNo = JRequest::getVar( 'showReferenceNo', "0", 'post', 'int' );
	   $session = JFactory::getSession();
	   $referenceNo = $session->get('referenceNo');

	   $msg=JText::_( $thankyouText );
	   if($showReferenceNo){
	      $msg.=JText::_( 'COM_BFSURVEYPLUS_YOUR_REFERENCE_NUMBER_IS' )." ".str_pad($referenceNo, 5, '0', STR_PAD_LEFT);
	   }
	   $app = JFactory::getApplication();

	   if ($redirectURL=="")
	   {
	      $app->enqueueMessage($msg);
	   } else {
		   $app->redirect( JRoute::_($redirectURL, false), $msg );
	   }
	}

	/**
     * Send the notification email at completion of survey
     *
     * @param string	$body			contents of the email
     * @param string	$sendEmailTo	email address to send to
     * @param string	$emailSubject	subject of the email
     */
    static function sendHTMLNotificationEmail($body, $sendEmailTo, $emailSubject)
    {
    	$conf	= JFactory::getConfig();

    	$mailfrom 	= $conf->get('config.mailfrom');
    	$fromname 	= $conf->get('config.fromname');

    	$emailBody = $body;
    	$mode = 1;

    	$mysendEmailTo = 	explode( ',', $sendEmailTo );
    	foreach($mysendEmailTo AS $sendEmailTo)
    	{
    		JFactory::getMailer()->sendMail($mailfrom, $fromname, $sendEmailTo, $emailSubject, $emailBody, $mode);
    	}

    }

	function showlist()
	{
		$page_no=$_SESSION['page_no'];
		$page_no=$page_no-1;
		$fieldName=$_SESSION['field_name'.$page_no];

		$input=JRequest::getVar($fieldName);

	    $_SESSION['listvalue']=$input;
	    $tempdisplay = ereg_replace("_", " ", $input);
		$tempdisplay = ereg_replace(", ", "<br>", $tempdisplay);
		echo "<center>";
		?>
		<strong><?php echo JText::_('COM_BFSURVEYPLUS_YOU_HAVE_SELECTED'); ?></strong>
		<?php
		echo "<br> ".$tempdisplay."";
		echo "<br><br>";
		?>
		<i><?php echo JText::_('COM_BFSURVEYPLUS_BROWSER_REFRESH'); ?></i><br><br>

		<button onClick="window.close();window.parent.location.reload(true);"><?php echo JText::_('Save'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;

		<button onClick="window.location.href='index2.php?option=com_bfsurvey_plus&task=list';"><?php echo JText::_('try again'); ?></button>

<?php
		echo "</center>";
	}

	public static function getIP()
	{
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip=$_SERVER['REMOTE_ADDR'];
	    }
		return $ip;
	}

	public static function getStatsCheckbox($question, $response, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
		$query->select('*');
		$query->where($db->escape( $question ) .' like '.$db->quote('%'.$db->escape( $response, true ).'%') );
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStats($question, $response, $catid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	  	$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
		$query->select('*');
		if($response == 1 || $response == 10){
			$query->where(trim($db->escape( $question )).' = '.$db->quote(trim($db->escape( $response, true ))) );
		}else{
			$query->where(trim($db->escape( $question )).' = '.$db->quote(trim( $response, true )) );
		}

		$query->where('(state IN (0, 1))');

		//this is require to allow percentage signs in the options
		//$query=preg_replace('/\\\\/','',$query);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}
		$n = count($rows);
		return $n;
	}

	public static function getStatsOther($question, $response, $catid){
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true);

			$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
			$query->select('*');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}
			$total = count($rows);

			$query->clear();
			//now get all the question
			$query->from($db->quoteName('#__bfsurvey_plus'));
			$query->select('*');
			$query->where('field_name='.$db->quote($db->escape( $question )));

			$db->setQuery( $query);
			$rows2 = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				return false;
			}

			$count=0;
			foreach($rows2 as $qn){
				for($i=1; $i < 21; $i++){
					$tempoption="option".$i;
					if(JString::trim($db->escape( $qn->$tempoption, true ))){
						$query->clear();
						$query->select('*');
						$query->from($db->quoteName('#__bfsurveyplus_'.(int)$catid));
						//$query->where( $db->quote(JString::trim($db->escape( $question )))."=". $db->quote(JString::trim($db->escape( $qn->$tempoption, true ))) );
						$query->where( JString::trim($db->escape( $question ))."=". $db->quote(JString::trim($db->escape( $qn->$tempoption, true ))) );

						$db->setQuery( $query);
						$rows = $db->loadObjectList();
						if ($db->getErrorNum())
						{
							return false;
						}

						$count=$count+count($rows);
					}
				}
			}

			$num = $total-$count;
			if($num < 0){
				$num = 0;
			}

			return $num;
	}

	/**
		Captcha functions!
	*/
	function displaycaptcha()
	{
		$app = JFactory::getApplication();

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 0, '', 'int');

		if ($use_captcha)
		{
			$Ok = null;
			$app->triggerEvent('onCaptcha_Display', array($Ok));
			if (!$Ok)
			{
				echo JText::_('COM_BFSURVEYPLUS_ERROR_DISPLAYING_CAPTCHA');
			}
		}
	}

	/**
	@return boolean
	*/
	function _checkCaptcha()
	{
		$app = JFactory::getApplication();

		$catid = JRequest::getVar('catid', 0, '', 'int');
		$use_captcha = JRequest::getVar('use_captcha', 1, '', 'int');

		// not using captcha!
		if (!$use_captcha)
		{
			return true;
		}
		$return = false;
		$word = JRequest::getVar('word', false, '', 'CMD');

		$app->triggerEvent('onCaptcha_confirm', array($word, &$return));
		if ($return)
		{
			return true;
		} else return false;
	}

	public static function getNumChildren($pid)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		//find out how many children
		$query->from($db->quoteName('#__bfsurvey_plus').' AS a');
		$query->select('COUNT(a.id) as count');
		$query->where('(a.state IN (0, 1))');
		$query->where('a.parent = '.(int) $pid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->count;
	}

	function getOption($qid,$myoption)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		// get data
		$query->from($db->quoteName('#__bfsurvey_plus').' AS a');
		$query->select( $db->quote( $db->escape( $myoption ), false ) );
		$query->where('a.id = '.(int) $qid);

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		return $rows[0]->$myoption;
	}

	function sendEmailAuthor($body,$author)
	{
       $allowEmail = JRequest::getVar( 'allowEmail', "", 'post', 'string' );

      if ($allowEmail)
      {
          // Send email
         $sendEmailTo = $author;
         $emailSubject = JRequest::getVar( 'emailSubject', "", 'post', 'string' );
         $emailBody = JRequest::getVar( 'emailBody', "", 'post', 'string' );
         BFSurveyPlusController::sendNotificationEmail($body, $sendEmailTo, $emailSubject, $emailBody);
      } else {
         // do nothing
      }
    }

	/**
	* displays the results of completed survey for currently logged in user
	*/
	public static function getmysurveys($uid)
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

		//get all survey category id numbers
		$query->from($db->quoteName('#__categories'));
		$query->select('id,  title');
		$query->where('extension = '.$db->quote('com_bfsurvey_plus') );
		$query->where('published');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$app = JFactory::getApplication();
		$dbtype = $app->getCfg('dbtype');

		$query->clear();

		$i=0;
		foreach ($rows as $row){
			if ($i==0)
			{
				//$query->from($db->quoteName('#__bfsurveyplus_'.(int)$row->id));
				//$query->select('id, uid, DATE_FORMAT(DateReceived,"%D %M %Y %H:%i") as DateReceived, DateReceived as DateTimeReceived, "'.$db->escape( $row->title ).'" AS title, "'.(int)$row->id.'" AS catid');
				//$query->where('uid='.(int)$uid );

				//$query->union doesn't work yet, so here's the old way instead
				//This isn't going to work for SQL Server
				// SQL Server doesn't support DATE_FORMAT

				if($dbtype == 'sqlsrv'){
			    	$query .= "SELECT id, uid, CONVERT(VARCHAR(11), DateReceived, 106) as DateReceived, DateReceived as DateTimeReceived, ".$db->quote( $db->escape( $row->title ), false )." AS title, '".(int)$row->id."' AS catid FROM #__bfsurveyplus_".(int)$row->id." WHERE uid=".(int)$uid;
				}else{
					$query .= "SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y %H:%i') as DateReceived, DateReceived as DateTimeReceived, ".$db->quote( $db->escape( $row->title ), false )." AS title, '".(int)$row->id."' AS catid FROM #__bfsurveyplus_".(int)$row->id." WHERE uid=".(int)$uid;
				}

			} else {
		      	//$query->from($db->quoteName('#__bfsurveyplus_'.(int)$row->id));
				//$query->union('id, uid, DATE_FORMAT(DateReceived,"%D %M %Y %H:%i") as DateReceived, DateReceived as DateTimeReceived, "'.$db->escape( $row->title ).'" AS title, "'.(int)$row->id.'" AS catid');
				//$query->where('uid='.(int)$uid );

				//$query->union doesn't work yet, so here's the old way instead
				//This isn't going to work for SQL Server

				if($dbtype == 'sqlsrv'){
					$query .= " UNION SELECT id, uid, CONVERT(VARCHAR(11), DateReceived, 106) as DateReceived, DateReceived as DateTimeReceived, ".$db->quote( $db->escape( $row->title ), false )." AS title, '".(int)$row->id."' AS catid FROM #__bfsurveyplus_".(int)$row->id." WHERE uid=".(int)$uid;
				}else{
					$query .= " UNION SELECT id, uid, DATE_FORMAT(DateReceived,'%D %M %Y %H:%i') as DateReceived, DateReceived as DateTimeReceived, ".$db->quote( $db->escape( $row->title ), false )." AS title, '".(int)$row->id."' AS catid FROM #__bfsurveyplus_".(int)$row->id." WHERE uid=".(int)$uid;
				}
		   }
		$i++;
		}

		//$query->order(' DateTimeReceived DESC');
		$query .= " ORDER BY DateTimeReceived DESC";

		$db->setQuery((string)$query);
		$rows2 = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			return false;
		}

		return $rows2;
	}

	/**
	 * Get the email template based on the name
	 *
	 * @param 	string 	$title	Name of the email template
	 *
	 * @return	array	Data for that email tempalte
	 */
	function getEmailTemplate($title, $catid)
    {
       	$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	  	$query->from($db->quoteName('#__bfsurveyplus_email').' AS a');
		$query->select('a.*,  c.title AS category_name');
		$query->join('LEFT', '`#__categories` AS c ON c.id = a.catid');
		$query->where('a.state');
		$query->where('a.title = '.$db->quote($title));
		$query->where('a.catid = '.(int) $catid);
		$query->order('a.title');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		if(!isset($rows[0])){
			//no email for that category, so just pick the first one
			$query->clear();

			$query->from($db->quoteName('#__bfsurveyplus_email').' AS a');
			$query->select('a.*,  c.title AS category_name');
			$query->join('LEFT', '`#__categories` AS c ON c.id = a.catid');
			$query->where('a.state');
			$query->where('a.title = '.$db->quote($title));
			$query->order('a.title');

			$db->setQuery((string)$query);
			$rows = $db->loadObjectList();
			if ($db->getErrorNum())
			{
				echo $db->stderr();
				return false;
			}
		}

		return $rows;
    }

	/**
	 * Check to see if person with this user id (UNID) has completed the survey
	 *
	 * @param string	$table	Answer table
	 * @param int		$myUID	User id number of the current user
	 *
	 * @return	int		Number of times this user has completed the survey
	 */
	function checkUID($table,$myUID){
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);

	   	if($myUID == "" | $myUID == 0){
			// don't check anonymous responses
			return 0;
		}else{
	      	$query->from($db->quoteName($table));
			$query->select('count(uid)');
			$query->where('uid = '.(int) $myUID.' AND state>-1');

			$db->setQuery((string)$query);
			$result=$db->loadResult();

			return $result;
	   }
	}

	function triggerEmails($emailType, $sendEmailTo, $emailBody, $catid){
		$session = JFactory::getSession();
		$myemail = BFSurveyPlusController::getEmailTemplate($emailType, $catid);

		if($myemail == null){
		   //no email template found so don't send anything
		   return false;
		}

		//repace fields with actual data
		$myemail[0]->description=preg_replace('/{category}/', $myemail[0]->category_name , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{name}/', $session->get('fullname') , $myemail[0]->description); // insert item description
		$myemail[0]->description=preg_replace('/{company}/', $session->get('company') , $myemail[0]->description); // insert item company
		$myemail[0]->description=preg_replace('/{email}/', $session->get('email') , $myemail[0]->description); // insert item email

		$myemail[0]->subject=preg_replace('/{category}/', $myemail[0]->category_name , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{name}/', $session->get('fullname') , $myemail[0]->subject); // insert item description
		$myemail[0]->subject=preg_replace('/{company}/', $session->get('company') , $myemail[0]->subject); // insert item company
		$myemail[0]->subject=preg_replace('/{email}/', $session->get('email') , $myemail[0]->subject); // insert item email

		$subject = $myemail[0]->subject;
		$body = $myemail[0]->description;
		if($myemail[0]->showQuestions == 1){
			$body .= $emailBody;
		}

		BFSurveyPlusController::sendHTMLNotificationEmail($body, $sendEmailTo, $subject);

		return true;
	}

	public static function getStatsText($field_name, $catid){

		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$table="#__bfsurveyplus_".$catid;

		$query->from($db->quoteName($table));
		$query->select($db->escape( $field_name ));
		$query->where('(state IN (0, 1))');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
		return $rows;
	}

}
?>
