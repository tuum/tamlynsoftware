<?php
/**
 * $Id: file.script.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined( '_JEXEC' ) or die;

class Com_bfquiz_plusInstallerScript {

function install($parent) {
	$db = JFactory::getDbo();
	$app = JFactory::getApplication();
	$query	= $db->getQuery(true);

	//check for sample data
	$tablelist = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfquiz_plus", $tablelist)) {
		$query->clear();
		$query->select('id');
		$query->from('#__bfquiz_plus');
		$db->setQuery((string)$query);
		$result=$db->loadResult();
	}else{
		$result = 0;
	}

	if($result){
		//no need for sample data
	}else{
		//install sample data
		$query->clear();
		$query->insert('#__categories');
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			//new way of doing this to support multiple database types such as SQL Server
			$query->columns(array($db->quoteName('parent_id'), $db->quoteName('title'), $db->quoteName('alias'), $db->quoteName('extension'), $db->quoteName('published'), $db->quoteName('level'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('metadesc'), $db->quoteName('metakey'), $db->quoteName('metadata'), $db->quoteName('lft'), $db->quoteName('rgt') ));
			$query->values('1, '.$db->quote( $db->escape('Example'), false ).', '.$db->quote( $db->escape('example'), false ).', '.$db->quote('com_bfquiz_plus').', 1, 1, 1, '.$db->quote('*').', '.$db->quote('').' , '.$db->quote('').' ,'.$db->quote('{"page_title":"","author":"","robots":""}').', 1, 2' );
		}else{
			//the following is required to support Joomla 1.6. Remove this when we drop 1.6 support.
			$query->set('`parent_id` = 1');
	        $query->set('`title` = '.$db->quote( $db->escape('Example'), false ));
	        $query->set('`alias` = '.$db->quote( $db->escape('example'), false ));
	        $query->set('`extension` = '.$db->quote('com_bfquiz_plus'));
	        $query->set('`published` = 1');
	        $query->set('`level` = 1');
	        $query->set('`access` = 1');
			$query->set('`lft` = 1');
			$query->set('`rgt` = 2');
		}

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		$query->select('max(id) AS id');
		$query->from('#__categories');
		$db->setQuery((string)$query);
		$catid=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$query->clear();
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->insert('#__bfquiz_plus');
			$query->columns(array($db->quoteName('catid'),
				$db->quoteName('question'),
				$db->quoteName('question_type'),
				$db->quoteName('date'),
				$db->quoteName('checked_out'),
				$db->quoteName('checked_out_time'),
				$db->quoteName('state'),
				$db->quoteName('ordering'),
				$db->quoteName('parent'),
				$db->quoteName('option1'),
				$db->quoteName('option2'),
				$db->quoteName('option3'),
				$db->quoteName('option4'),
				$db->quoteName('option5'),
				$db->quoteName('option6'),
				$db->quoteName('option7'),
				$db->quoteName('option8'),
				$db->quoteName('option9'),
				$db->quoteName('option10'),
				$db->quoteName('option11'),
				$db->quoteName('option12'),
				$db->quoteName('option13'),
				$db->quoteName('option14'),
				$db->quoteName('option15'),
				$db->quoteName('option16'),
				$db->quoteName('option17'),
				$db->quoteName('option18'),
				$db->quoteName('option19'),
				$db->quoteName('option20'),
				$db->quoteName('answer1'),
				$db->quoteName('answer2'),
				$db->quoteName('answer3'),
				$db->quoteName('answer4'),
				$db->quoteName('answer5'),
				$db->quoteName('answer6'),
				$db->quoteName('answer7'),
				$db->quoteName('answer8'),
				$db->quoteName('answer9'),
				$db->quoteName('answer10'),
				$db->quoteName('answer11'),
				$db->quoteName('answer12'),
				$db->quoteName('answer13'),
				$db->quoteName('answer14'),
				$db->quoteName('answer15'),
				$db->quoteName('answer16'),
				$db->quoteName('answer17'),
				$db->quoteName('answer18'),
				$db->quoteName('answer19'),
				$db->quoteName('answer20'),
				$db->quoteName('score1'),
				$db->quoteName('score2'),
				$db->quoteName('score3'),
				$db->quoteName('score4'),
				$db->quoteName('score5'),
				$db->quoteName('score6'),
				$db->quoteName('score7'),
				$db->quoteName('score8'),
				$db->quoteName('score9'),
				$db->quoteName('score10'),
				$db->quoteName('score11'),
				$db->quoteName('score12'),
				$db->quoteName('score13'),
				$db->quoteName('score14'),
				$db->quoteName('score15'),
				$db->quoteName('score16'),
				$db->quoteName('score17'),
				$db->quoteName('score18'),
				$db->quoteName('score19'),
				$db->quoteName('score20'),
				$db->quoteName('next_question1'),
				$db->quoteName('next_question2'),
				$db->quoteName('next_question3'),
				$db->quoteName('next_question4'),
				$db->quoteName('next_question5'),
				$db->quoteName('next_question6'),
				$db->quoteName('next_question7'),
				$db->quoteName('next_question8'),
				$db->quoteName('next_question9'),
				$db->quoteName('next_question10'),
				$db->quoteName('next_question11'),
				$db->quoteName('next_question12'),
				$db->quoteName('next_question13'),
				$db->quoteName('next_question14'),
				$db->quoteName('next_question15'),
				$db->quoteName('next_question16'),
				$db->quoteName('next_question17'),
				$db->quoteName('next_question18'),
				$db->quoteName('next_question19'),
				$db->quoteName('next_question20'),
				$db->quoteName('prefix'),
				$db->quoteName('suffix'),
				$db->quoteName('field_name'),
				$db->quoteName('fieldSize'),
				$db->quoteName('mandatory'),
				$db->quoteName('helpText'),
				$db->quoteName('horizontal'),
				$db->quoteName('solution'),
				$db->quoteName('publish_down'),
				$db->quoteName('archived'),
				$db->quoteName('approved'),
				$db->quoteName('access'),
				$db->quoteName('language'),
				$db->quoteName('created'),
				$db->quoteName('created_by'),
				$db->quoteName('modified'),
				$db->quoteName('modified_by'),
				$db->quoteName('publish_up'),
				$db->quoteName('field_type'),
				$db->quoteName('validation_type'),
				$db->quoteName('suppressQuestion')	));
			$query->values($catid.", 'Which type of extinguisher should be used on a gas fire?', '1', '', 0, '', 1, 1, 0, 'Pressurised Water', 'Carbon Dioxide', 'Dry Chemical', 'Foam', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'extinguisher', 255, 1, 'It is important to use the <strong>correct</strong> extinguishing agent on a fire or you''ll make the situation worse.\r\n<br /><br />\r\n<table width=\"100%\" bgcolor=\"#ffffff\" border=\"1\">\r\n<tr>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Water.jpg\" WIDTH=\"30\" HEIGHT=\"77\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Co2.jpg\" WIDTH=\"29\" HEIGHT=\"78/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Dry-chem.jpg\" WIDTH=\"30\" HEIGHT=\"84/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Foam.jpg\" WIDTH=\"31\" HEIGHT=\"93/\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\">Water</td>\r\n<td align=\"center\">Co2</td>\r\n<td align=\"center\">Chemical</td>\r\n<td align=\"center\">Foam</td>\r\n\r\n</tr>\r\n</table>', 0, 'Dry Chemical extinguisher can be used for chemical, flammable liquid, electrical, gases.\r\n<br />\r\n<img src=\"./components/com_bfquiz_plus/images/Dry-chem.jpg\" WIDTH=30\" HEIGHT=\"84\" />','','','','','*','','','','','','','',0");
			$query->values($catid.", 'When lifting is required, you should:', '1', '', 0, '', 1, 2, 0, 'Bend your back and pick it up as quickly as possible', 'Find someone stronger to lift it for you', 'Bend at the knees and keep your back straight', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'manualH', 255, 1, '<img src=\"./components/com_bfquiz_plus/images/manualHandling.jpg\" /><br />', 0, '','','','','','*','','','','','','','',0");
			$query->values($catid.", 'Which shoe is most appropriate for an office environment?', '1', '', 0, '', 1, 3, 0, 'A', 'B', 'C', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'shoe', 255, 1, '<table>\r\n<tr>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe1.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe2.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe3.jpg\" /></td>\r\n</tr>\r\n</table>', 1, '','','','','','*','','','','','','','',0");
			$query->values($catid.", 'What does the abbreviation IT stand for?', '0', '', 0, '', 1, 4, 0, 'Information Technology', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'abbreviation', 255, 1, '<i>Hint: It is the department that you would call if you had a problem with your computer.</i><br />', 0, '','','','','','*','','','','','','','',0");
			$query->values($catid.", 'When you greet a visitor in your office, do you', '1', '', 0, '', 1, 5, 0, 'say nothing and let them sit wherever they wish', 'tell them where to sit', 'say Just sit anywhere', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'visitor', 255, 1, '', 0, 'You should indicate where your guest should sit to make them feel more comfortable.','','','','','*','','','','','','','',0");
		}else{
			//the following is required to support Joomla 1.6. Remove this when we drop 1.6 support.
$query = "INSERT INTO `#__bfquiz_plus` (`id`, `catid`, `question`, `question_type`, `date`, `checked_out`, `checked_out_time`, `state`, `ordering`, `parent`, `option1`, `option2`, `option3`, `option4`, `option5`, `option6`, `option7`, `option8`, `option9`, `option10`, `option11`, `option12`, `option13`, `option14`, `option15`, `option16`, `option17`, `option18`, `option19`, `option20`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`, `answer6`, `answer7`, `answer8`, `answer9`, `answer10`, `answer11`, `answer12`, `answer13`, `answer14`, `answer15`, `answer16`, `answer17`, `answer18`, `answer19`, `answer20`, `score1`, `score2`, `score3`, `score4`, `score5`, `score6`, `score7`, `score8`, `score9`, `score10`, `score11`, `score12`, `score13`, `score14`, `score15`, `score16`, `score17`, `score18`, `score19`, `score20`, `next_question1`, `next_question2`, `next_question3`, `next_question4`, `next_question5`, `next_question6`, `next_question7`, `next_question8`, `next_question9`, `next_question10`, `next_question11`, `next_question12`, `next_question13`, `next_question14`, `next_question15`, `next_question16`, `next_question17`, `next_question18`, `next_question19`, `next_question20`, `prefix`, `suffix`, `field_name`, `fieldSize`, `mandatory`, `helpText`, `horizontal`, `solution`) VALUES
(1, ".$catid.", 'Which type of extinguisher should be used on a gas fire?', '1', '2009-04-08 03:28:21', 0, '0000-00-00 00:00:00', 1, 1, 0, 'Pressurised Water', 'Carbon Dioxide', 'Dry Chemical', 'Foam', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'extinguisher', 255, 1, 'It is important to use the <strong>correct</strong> extinguishing agent on a fire or you''ll make the situation worse.\r\n<br /><br />\r\n<table width=\"100%\" bgcolor=\"#ffffff\" border=\"1\">\r\n<tr>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Water.jpg\" WIDTH=\"30\" HEIGHT=\"77\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Co2.jpg\" WIDTH=\"29\" HEIGHT=\"78/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Dry-chem.jpg\" WIDTH=\"30\" HEIGHT=\"84/\" /></td>\r\n<td align=\"center\" width=\"25%\"><img src=\"./components/com_bfquiz_plus/images/Foam.jpg\" WIDTH=\"31\" HEIGHT=\"93/\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\">Water</td>\r\n<td align=\"center\">Co2</td>\r\n<td align=\"center\">Chemical</td>\r\n<td align=\"center\">Foam</td>\r\n\r\n</tr>\r\n</table>', 0, 'Dry Chemical extinguisher can be used for chemical, flammable liquid, electrical, gases.\r\n<br />\r\n<img src=\"./components/com_bfquiz_plus/images/Dry-chem.jpg\" WIDTH=30\" HEIGHT=\"84\" />'),
(2, ".$catid.", 'When lifting is required, you should:', '1', '2009-04-08 02:44:59', 0, '0000-00-00 00:00:00', 1, 2, 0, 'Bend your back and pick it up as quickly as possible', 'Find someone stronger to lift it for you', 'Bend at the knees and keep your back straight', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'manualH', 255, 1, '<img src=\"./components/com_bfquiz_plus/images/manualHandling.jpg\" /><br />', 0, ''),
(3, ".$catid.", 'Which shoe is most appropriate for an office environment?', '1', '2009-04-08 02:44:50', 0, '0000-00-00 00:00:00', 1, 3, 0, 'A', 'B', 'C', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'shoe', 255, 1, '<table>\r\n<tr>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe1.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe2.jpg\" /></td>\r\n<td><img src=\"./components/com_bfquiz_plus/images/shoe3.jpg\" /></td>\r\n</tr>\r\n</table>', 1, ''),
(4, ".$catid.", 'What does the abbreviation IT stand for?', '0', '2009-04-08 02:59:24', 0, '0000-00-00 00:00:00', 1, 4, 0, 'Information Technology', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'abbreviation', 255, 1, '<i>Hint: It is the department that you would call if you had a problem with your computer.</i><br />', 0, ''),
(5, ".$catid.", 'When you greet a visitor in your office, do you', '1', '2009-04-08 03:28:42', 0, '0000-00-00 00:00:00', 1, 5, 0, 'say nothing and let them sit wherever they wish', 'tell them where to sit', 'say Just sit anywhere', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 'visitor', 255, 1, '', 0, 'You should indicate where your guest should sit to make them feel more comfortable.')";
		}
		$db->setQuery( $query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

	//check for email sample data
	$tablelist = $db->getTableList();
	if (in_array($app->getCfg('dbprefix')."bfquiz_plus", $tablelist)) {
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);
		$query->clear();
		$query->select('id');
		$query->from('#__bfquiz_plus_email');
		$db->setQuery((string)$query);
		$result=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}else{
		$result = 0;
	}

	if($result){
		//no need for sample email data
	}else{
		$query->clear();
		$query->select('max(id) AS id');
		$query->from('#__categories');
		$db->setQuery((string)$query);
		$catid=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		//install email data
		$query->clear();
		if(is_callable(array('JDatabaseQuery', 'columns'))){
			$query->insert('#__bfquiz_plus_email');
			$query->columns(array($db->quoteName('catid'), $db->quoteName('title'), $db->quoteName('subject'), $db->quoteName('description'), $db->quoteName('date'), $db->quoteName('checked_out'), $db->quoteName('checked_out_time'), $db->quoteName('state'), $db->quoteName('ordering'), $db->quoteName('showQuestions'), $db->quoteName('showIncorrect'), $db->quoteName('publish_down'), $db->quoteName('archived'), $db->quoteName('approved'), $db->quoteName('access'), $db->quoteName('language'), $db->quoteName('created'), $db->quoteName('created_by'), $db->quoteName('modified'), $db->quoteName('modified_by'), $db->quoteName('parent'), $db->quoteName('publish_up') ));
			$query->values($catid.", 'Admin', 'Automated BF Quiz Plus Notification - {name}', '<p>{name} ({email}) has completed the {category} quiz with a score of {score}</p>', '', 0, '', 1, 0, 1, 1, '','','','','*','','','','',0,''");
			$query->values($catid.", 'Author', 'Automated BF Quiz Plus Notification', '<p>Thank you {name} for completing the {category} quiz.</p>\r\n<p> </p>\r\n<p>Congratulations your score was {score}</p>', '', 0, '', 1, 2, 1, 1, '','','','','*','','','','',0,''");
		}else{
			//joomla 1.6 support
			$query = "INSERT INTO `#__bfquiz_plus_email` (`id`, `catid`, `title`, `subject`, `description`, `date`, `checked_out`, `checked_out_time`, `state`, `ordering`, `showQuestions`, `showIncorrect`) VALUES
			(1, ".$catid.", 'Admin', 'Automated BF Quiz Plus Notification - {name}', '<p>{name} ({email}) has completed the {category} quiz with a score of {score}</p>', '2010-06-19 11:43:53', 0, '0000-00-00 00:00:00', 1, 0, 1, 1),
			(2, ".$catid.", 'Author', 'Automated BF Quiz Plus Notification', '<p>Thank you {name} for completing the {category} quiz.</p>\r\n<p> </p>\r\n<p>Congratulations your score was {score}</p>', '2010-06-19 11:00:31', 0, '0000-00-00 00:00:00', 1, 2, 1, 1)";
		}
		$db->setQuery( $query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}
	}

?>

<div><strong>BF Quiz Plus</strong> Component <em>for Joomla!</em></div>
<center>
<table width = "100%" border = "0">
  <tr>
    <td width = "10%">
    </td>

    <td width = "90%">
      <p>

		<img src="./components/com_bfquiz_plus/images/bflogo.jpg"><br/>

        <br/>  Copyright &copy; 2016 - Tamlyn Software. All rights reserved.
        <br />

                <br/>This Joomla! 2.5.x / 3.x Component is released under the GNU GPL.
                <br/>
                <br/>Congratulations, you have successfully installed BF Quiz Plus!
        </p>
    </td>
  </tr>
  <tr>
    <td>
    </td>
    <td>
            <strong><code>I N S T A L L :</code></strong>

                <br/>

                <br/>

                STEP 1 : <font color = "Green">Succesfull</font>
                <br>
                <br>
                STEP 2 : Navigate to Components, BF Quiz Plus->Questions, and setup questions as required.
                <br>
                <br>
                STEP 3 : Add a "BF Quiz Plus" menu item. (Optional) Make sure you configure email address in "Parameters - Component", and select Category in "Parameters - Basic".
				<br>
                <br>
                STEP 4 : (optional) If you wish to make radio or checkbox fields mandatory, you need to install <a href="http://www.tamlynsoftware.com/download/free-downloads/free-downloads-joomla-3-extensions.html" target="_blank">BF Validate Plus</a> plugin.
				<br>
                <br>
                STEP 5 : (optional) If you wish to use Video or audio, you need to install <a href="http://extensions.joomla.org/extensions/extension/multimedia/multimedia-players/allvideos" target="_blank">AllVideos</a> plugin.
				<br>
                <br>

    </td>
  </tr>
    </table>
</center>
<?php
	}

	function uninstall($parent) {
		?>
		<div>BF Quiz Plus has now been removed from your system.</div>
		<p>
		We're sorry to see you go! Please feel free to post reasons on our forum to help us to improve our product.<br>
		<br>
		Don't forget to delete any BF Quiz Plus menu items.
		<br>
		<br>
		</p>
		<?php
	}

	function update($parent) {
		$app = JFactory::getApplication();
		$dbtype = $app->getCfg('dbtype');
		$db = JFactory::getDbo();
		$tablelist = $db->getTableList();

		if($dbtype == 'sqlsrv'){
   			//do nothing as database schema is all good for SQLSRV
		}else if (!in_array($app->getCfg('dbprefix')."bfquiz_plus", $tablelist)) {
			// do nothing
		}else{
			$db = JFactory::getDbo();
			$query	= $db->getQuery(true);

			//check if upgrade required
			$table="#__bfquiz_plus";
			$fields = $db->getTableColumns( $table, true );
			if( sizeof( $fields ) ) {
				// We found some fields so let's create the HTML list
				$options = array();
				foreach( $fields as $field => $type ) {
					$options[] = JHTML::_( 'select.option', $field, $field );
				}
			}

			//CHECK FOR V1.0.1 UPGRADE
			$found=0;
			foreach( $fields as $field => $type ) {
				if ($field == "scorecatid") {
					$found=1;
				}
			}

			if($found == 0){
				$query="ALTER table `#__bfquiz_plus` ADD `scorecatid` int(11) NOT NULL default '0'
	  		  	    	   ;";
				$db->setQuery( $query);
				if (!$db->query())
				{
					echo $db->getErrorMsg();
					return false;
				}
			}

			//add the score category table in case it doesn't exist yet.
			$query	= $db->getQuery(true);
			$query->clear();
			$query="CREATE TABLE IF NOT EXISTS `#__bfquiz_plus_scorecat` (
	  					`id` int(11) unsigned NOT NULL auto_increment,
			  			`description` text,
	  					`date` datetime NOT NULL default '0000-00-00 00:00:00',
			  			`checked_out` int(11) NOT NULL default '0',
	  					`checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
	  					`state` tinyint(3) NOT NULL default '0',
	  					`ordering` int(11) NOT NULL default '0',
	  					`archived` tinyint(1) NOT NULL DEFAULT '0',
	  					`approved` tinyint(1) NOT NULL DEFAULT '1',
	  					`access` int(11) NOT NULL DEFAULT '1',
	  					`language` char(7) NOT NULL DEFAULT '',
	  					`created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	  					`created_by` int(10) unsigned NOT NULL DEFAULT '0',
	  					`modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	  					`modified_by` int(10) unsigned NOT NULL DEFAULT '0',
	  					`parent` int(11) NOT NULL,
	  					`publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	  					`publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	  					`congratulationsText` text,
	  					`additionalInformationText` text,
		  				PRIMARY KEY  (`id`)
					);
				";

			$db->setQuery( $query);
			if (!$db->query())
			{
				echo $db->getErrorMsg();
				return false;
			}
		}
	}

	function preflight( $type, $parent ) {
		$jversion = new JVersion();

		// Installing component manifest file version
		$this->release = $parent->get( "manifest" )->version;

		// Manifest file minimum Joomla version
		$this->minimum_joomla_release = $parent->get( "manifest" )->attributes()->version;

		// Show the essential information at the install/update back-end
		echo '<br />Current Joomla version = ' . $jversion->getShortVersion();

		// abort if the current Joomla release is older
		if( version_compare( $jversion->getShortVersion(), $this->minimum_joomla_release, 'lt' ) ) {
			Jerror::raiseWarning(null, 'Cannot install com_bfquiz_plus in a Joomla release prior to '.$this->minimum_joomla_release);
			return false;
		}

		// abort if the component being installed is not newer than the currently installed version
		if ( $type == 'update' ) {
			$oldRelease = $this->getParam('version');
			$rel = $oldRelease . ' to ' . $this->release;
			if ( version_compare( $this->release, $oldRelease, 'le' ) ) {
				Jerror::raiseWarning(null, 'Incorrect version sequence. Cannot upgrade ' . $rel);
				return false;
			}
		}
        else { $rel = $this->release; }
	}

	/**
	* method to run after an install/update/uninstall method
	*
	* @return void
	*/
	function postflight($type, $parent)  {
        // define the following parameters only if it is an original install
        if ( $type == 'install' ) {
				$params['showResults'] = '1';
				$params['showIncorrect'] = '1';
				$params['showCorrect'] = '1';
				$params['answerAfterQuestion'] = '1';
				$params['scoringMethod'] = '0';
				$params['timedQuiz'] = '0';
				$params['timeLimit'] = '10';
				$params['randomOptions'] = '0';
                $params['allowEmail'] = '0';
				$params['sendEmailTo'] = 'insertemail@youremailaddress.com';
				$params['authorEmail'] = '0';
				$params['anonymous'] = '0';
				$params['anonymousText'] = 'I prefer to respond anonymously:';
				$params['anonymousYes'] = 'Yes';
				$params['anonymousNo'] = 'No';
				$params['showName'] = '1';
				$params['showEmail'] = '1';
				$params['nameText'] = 'Name';
				$params['emailText'] = 'Email';
				$params['quizTitle'] = 'BF Quiz Plus';
				$params['introText'] = 'Please take a moment to complete this quiz.';
				$params['thankyouText'] = 'Thank you again for completing this quiz.';
				$params['submitText'] = 'Next';
				$params['errorText'] = 'Some values are not acceptable. Please retry.';
				$params['timerText'] = 'Time Remaining';
				$params['timerCompleteText'] = 'The time is up. Your quiz has now been submitted automatically.';
				$params['use_captcha'] = '0';
				$params['useCSS'] = '1';
				$params['registeredUsers'] = '0';
				$params['preventMultiple'] = '0';
				$params['preventMultipleEmail'] = '0';
				$params['preventMultipleUID'] = '0';
				$params['questionColour'] = '#abc';
				$params['optionColour'] = '#eee';
				$params['saveAndQuit'] = '0';

				$this->setParams( $params );
        }
	}

	/*
	* get a variable from the manifest file (actually, from the manifest cache).
	*/
	function getParam( $name ) {
		$db = JFactory::getDbo();
		$db->setQuery('SELECT manifest_cache FROM #__extensions WHERE name = "com_bfquiz_plus"');
		$manifest = json_decode( $db->loadResult(), true );
		return $manifest[ $name ];
	}

 	/*
	* sets parameter values in the component's row of the extension table
	*/
	function setParams($param_array) {
		if ( count($param_array) > 0 ) {
			// read the existing component value(s)
			$db = JFactory::getDbo();
			$db->setQuery('SELECT params FROM #__extensions WHERE name = "com_bfquiz_plus"');
			$params = json_decode( $db->loadResult(), true );
			// add the new variable(s) to the existing one(s)
			foreach ( $param_array as $name => $value ) {
				$params[ (string) $name ] = (string) $value;
			}
			// store the combined new and existing values back as a JSON string
			$paramsString = json_encode( $params );
			$db->setQuery('UPDATE #__extensions SET params = ' .
			$db->quote( $paramsString ) .
				' WHERE name = "com_bfquiz_plus"' );
			$db->query();
		}
	}
}
