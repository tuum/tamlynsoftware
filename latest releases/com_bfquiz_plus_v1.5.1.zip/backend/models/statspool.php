<?php
/**
 * $Id: statspool.php 63 2014-03-04 10:44:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

/**
 * Stats Pool Model
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusModelStatsPool extends JModelLegacy
{
	/**
	 * Constructor that retrieves the ID from the request
	 *
	 * @access	public
	 * @return	void
	 */
	function __construct()
	{
		parent::__construct();

		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);

		$poolid	= JRequest::getVar( 'poolid', 0, '', 'int' );
		$this->setPoolId((int)$poolid);
	}

	/**
	 * Method to set the identifier
	 *
	 * @access	public
	 * @param	int scorerange Answer identifier
	 * @return	void
	 */
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}


	function setPoolId($poolid)
	{
		$this->_poolid= $poolid;
	}


	/**
	 * Method to get Answer
	 * @return object with data
	 */
	function &getData()
	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__bfquizplus_'.$this->_poolid.'_pool '
					.'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->question = null;
		}
		return $this->_data;
	}

	function &getDataPool()
	{
	    global $mainframe;
	    $db = JFactory::getDBO();

		$query = 'SELECT *'
						. ' FROM #__bfquiz_plus_pool'
						. ' WHERE state=1 AND id = '.(int)$this->_poolid
		;

		$this->_db->setQuery( $query );
		$this->_datapool = $this->_db->loadObject();
		return $this->_datapool;
	}

}
?>
