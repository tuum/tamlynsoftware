-- <?php /* $Id: uninstall.sqlsrv.utf8.sql 14 2012-01-07 03:40:21Z tuum $ */ defined('_JEXEC') or die() ?>;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus]
END;	

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_matrix]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus_matrix]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_scorerange]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus_scorerange]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_pool]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus_pool]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_email]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus_email]		
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__bfquiz_plus_scorecat]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__bfquiz_plus_scorecat]		
END;

DELETE FROM [#__categories] WHERE extension='com_bfquiz_plus';
