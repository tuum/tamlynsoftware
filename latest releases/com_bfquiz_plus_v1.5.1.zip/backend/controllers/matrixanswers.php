<?php
/**
 * $Id: matrixanswers.php 65 2014-12-15 23:49:59Z tuum $
 * bfquiz_plus matrix controller
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controlleradmin');

/**
 * bfquiz_plus matrix Controller
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusControllerMatrixAnswers extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function getModel($name = 'Matrixanswer', $prefix = 'bfquiz_plusModel', $config = array('ignore_request' => true))
	{
		$model = parent::getModel($name, $prefix, $config);
		return $model;
	}

    /**
     * Method to copy email items
     *
     * @return    boolean    True on success
     * @since    1.6
     */
    public function copyItem()
    {
    	$cid	= JRequest::getVar( 'cid', null, 'post', 'array' );

    	JTable::addIncludePath(JPATH_COMPONENT.'/tables');
        $row = JTable::getInstance('Matrixanswer', 'Table');

        $this->setRedirect( 'index.php?option=com_bfquiz_plus&view=matrixanswers' );

        $n		= count( $cid );

		if ($n > 0)
		{
        	foreach ($cid as $id)
        	{
            	// load the row from the db table
            	$row->load((int) $id);
            	$row->description		= JText::_('COM_BFQUIZPLUS_COPY_OF').' '. $row->description;
            	$row->id             	= 0;
            	$row->state     		= 0;
            	$table->default			= 0;

            	if (!$row->check()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
            	if (!$row->store()) {
	                return JError::raiseWarning(500, $row->getError());
            	}
        	}
		}else{
			return JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ERROR_NO_ITEMS_SELECTED' ) );
		}

        $this->setMessage( JText::sprintf( 'COM_BFQUIZPLUS_ITEMS_COPIED', $n ) );

        return true;
    }

	/**
	* Sets default ABCD  answer matrix
	*/
	function setdefault()
	{
		$app		= JFactory::getApplication();

		// Check for request forgeries
		JSession::checkToken() or jexit( 'Invalid Token' );

		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$user 		= JFactory::getUser();
		$cid		= JRequest::getVar('cid', array(), '', 'array');
		$option		= JRequest::getCmd('option');
		JArrayHelper::toInteger($cid);

		if (empty( $cid )) {
			JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ERROR_NO_ITEMS_SELECTED' ) );
			$app->redirect( 'index.php?option='. $option .'&view=matrixanswers' );
		}

		$cids = implode( ',', $cid );

		//get category id
		$query->select('catid');
		$query->from($db->quoteName('#__bfquiz_plus_matrix'));
		$query->where('id = '.(int) $cid[0]);

		$db->setQuery((string)$query);
		$catid=$db->loadResult();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		//remove all defaults for that category
		$query->clear();
		$query->update($db->quoteName('#__bfquiz_plus_matrix').' AS a');
		$query->set('a.default = 0' );
		$query->where('catid = '.(int)$catid );

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		//set new default
		$query->clear();
		$query->update($db->quoteName('#__bfquiz_plus_matrix').' AS a');
		$query->set('a.default = 1' );
		$query->where('id = '.(int)$cid[0] );

		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum())
		{
			echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
			return;
		}

		$app->redirect( JRoute::_('index.php?option='. $option .'&view=matrixanswers', false) );
    }

	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   3.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}
}