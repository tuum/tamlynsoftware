<?php
/**
 * $Id: view.html.php 63 2014-03-04 10:44:40Z tuum $
 * bfquiz_plusViewResultPools View for BFQuiz_Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2016 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  BF Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Quiz Plus from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.view' );

/**
 * bfquiz_plusViewResults View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfquiz_plusViewResultPools extends JViewLegacy
{
    /**
     * Hellos view display method
     * @return void
     **/
    function display($tpl = null)
    {
        $randomid	= JRequest::getVar( 'randomid', 0, '', 'int' );
        $catid	= JRequest::getVar( 'cid', 0, '', 'int' );
        $session = JFactory::getSession();

		if(empty($randomid) | $randomid==0){
			//do nothing
		}else{
			$session->set('randomid',$randomid);
		}

    	if(empty($catid) | $catid==0){
			//do nothing
		}else{
		    $session->set('catid', $catid);
		}

        // Get data from the model
        $items = $this->get( 'Data');

	    if(!$items){
	      $app = JFactory::getApplication('administrator');
	      JError::raiseWarning( 500, JText::_( 'COM_BFQUIZPLUS_ERROR_NO_RESULTS') );
		  $app->redirect( 'index.php?option=com_bfquiz_plus' );
	    }

        $pagination = $this->get('Pagination');

        $this->assignRef( 'items', $items );
        $this->assignRef('pagination', $pagination);
        $this->assignRef('randomid', $session->get('randomid') );
        $this->assignRef('catid', $session->get('catid') );

		$this->addToolbar();

        parent::display($tpl);
    }

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfquiz_plus.php';

		$state	= $this->get('State');
		$canDo	= bfquiz_plusHelper::getActions($state->get('filter.category_id'));

		JToolBarHelper::title( JText::_( 'COM_BFQUIZPLUS_TOOLBAR_RESULTS' ), 'bfquiz_toolbar_title' );

		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'resultpools.delete','JTOOLBAR_EMPTY_TRASH');
			JToolBarHelper::divider();
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('resultpools.remove','JTOOLBAR_TRASH');
			JToolBarHelper::divider();
		}

		JToolbarHelper::back('JTOOLBAR_CLOSE', 'index.php?option=com_bfquiz_plus');
	}
}