ALTER TABLE [#__bfsurvey_plus] ADD [alias] [nvarchar](255) NOT NULL;
ALTER TABLE [#__bfsurveyplus_email] ADD [alias] [nvarchar](255) NOT NULL;