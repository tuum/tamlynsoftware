DROP TABLE IF EXISTS `#__bfsurvey_plus`;
DROP TABLE IF EXISTS `#__bfsurveyplus_email`;
DELETE FROM `#__categories` WHERE extension="com_bfsurvey_plus";