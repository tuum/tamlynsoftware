<?php
/**
 * $Id: view.html.php 58 2014-03-08 08:42:59Z tuum $
 * Questions View for bfsurvey_plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Survey Plus from the developer (Tamlyn Creative Pty Ltd),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */

defined('_JEXEC') or die;

/**
 * Questions View
 *
 * @package    Joomla
 * @subpackage Components
 */
class bfsurvey_plusViewQuestions extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;

	/**
	 * BFSurveys view display method
	 * @return void
	 **/
	public function display($tpl = null)
	{
		$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->ordering = array();

		// Preprocess the list of items to find ordering divisions.
		foreach ($this->items as $item) {
			$this->ordering[$item->parent][] = $item->id;
		}

		$this->addToolbar();
		bfsurvey_plusHelper::addSubmenu('questions');
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT.'/helpers/bfsurvey_plus.php';

		$state	= $this->get('State');
		$canDo	= bfsurvey_plusHelper::getActions($state->get('filter.category_id'));
		$user	= JFactory::getUser();
		// Get the toolbar object instance
		$bar = JToolBar::getInstance('toolbar');

		JToolBarHelper::title(JText::_('COM_BFSURVEYPLUS_TOOLBAR_QUESTION_MANAGER'), 'bfsurvey_toolbar_title');
		//probably should do it like core below, but I think this will cause unnecessary confusion.
		//if (count($user->getAuthorisedCategories('com_bfsurvey_plus', 'core.create')) > 0) {
		if ($canDo->get('core.create')) {
			JToolbarHelper::addNew('question.add');
		}
		if ($canDo->get('core.edit')) {
			JToolbarHelper::editList('question.edit');
		}
		if ($canDo->get('core.edit.state')) {

			JToolbarHelper::publish('questions.publish', 'JTOOLBAR_PUBLISH', true);
			JToolbarHelper::unpublish('questions.unpublish', 'JTOOLBAR_UNPUBLISH', true);

			JToolbarHelper::archiveList('questions.archive');
			JToolbarHelper::checkin('questions.checkin');
		}
		if ($state->get('filter.state') == -2 && $canDo->get('core.delete')) {
			JToolBarHelper::deleteList('', 'questions.delete','JTOOLBAR_EMPTY_TRASH');
		} else if ($canDo->get('core.edit.state')) {
			JToolBarHelper::trash('questions.trash','JTOOLBAR_TRASH');
		}

		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::custom( 'questions.copy', 'copy.png', 'copy_f2.png', 'COM_BFSURVEYPLUS_TOOLBAR_COPY', true );
			// TODO get editCSS working in j1.6
			//JToolBarHelper::custom( 'questions.chooseCSS', 'css', 'css', 'Edit CSS', false, false );
			JToolBarHelper::custom( 'questions.copyCategory', 'copy.png', 'copy_f2.png', 'COM_BFSURVEYPLUS_TOOLBAR_COPY_SURVEY', true );
			JToolBarHelper::custom( 'questions.fixDatabase', 'refresh', 'refresh', 'COM_BFSURVEYPLUS_TOOLBAR_FIX_DATABASE', false );
		}

		if ($canDo->get('core.admin')) {
			JToolBarHelper::preferences('com_bfsurvey_plus');
		}

		$version = new JVersion();
		if( floatval($version->RELEASE) >= 3 ) {
			JSubMenuHelper::setAction('index.php?option=com_bfsurvey_plus&view=questions');

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_PUBLISHED'),
				'filter_published',
				JHtml::_('select.options', JHtml::_('jgrid.publishedOptions'), 'value', 'text', $this->state->get('filter.published'), true)
			);

			JSubMenuHelper::addFilter(
				JText::_('JOPTION_SELECT_CATEGORY'),
				'filter_category_id',
				JHtml::_('select.options', JHtml::_('category.options', 'com_bfsurvey_plus'), 'value', 'text', $this->state->get('filter.category_id'))
			);
		}
	}

	/**
	 * Returns an array of fields the table can be sorted by
	 *
	 * @return  array  Array containing the field name to sort by as the key and display text as value
	 *
	 * @since   3.0
	 */
	protected function getSortFields()
	{
		return array(
			'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
			'a.state' => JText::_('JSTATUS'),
			'a.title' => JText::_('JGLOBAL_TITLE'),
			//'a.access' => JText::_('JGRID_HEADING_ACCESS'),
			//'a.hits' => JText::_('JGLOBAL_HITS'),
			//'a.language' => JText::_('JGRID_HEADING_LANGUAGE'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}

}