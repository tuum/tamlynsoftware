ALTER TABLE [#__ueman_customfields] ADD [access] [int] NOT NULL DEFAULT '1';
ALTER TABLE [#__ueman_customfields] ADD [public_profile] [smallint] NOT NULL;