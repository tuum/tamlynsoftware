ALTER TABLE `#__ueman_customfields` ADD `default_value` varchar(255) NOT NULL;
ALTER TABLE `#__ueman_customfields` ADD `placeholder` varchar(255) NOT NULL;