ALTER TABLE `#__ueman_customfields` ADD `access` int(5) NOT NULL DEFAULT '1';
ALTER TABLE `#__ueman_customfields` ADD `public_profile` tinyint(1) NOT NULL;