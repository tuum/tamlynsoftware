-- <?php /* $Id$ */ defined('_JEXEC') or die() ?>;

SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_profiles]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__ueman_profiles](
	[ueman_profile_id] [bigint] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[slug] [nvarchar](50) NOT NULL,
	[enabled] [smallint] NOT NULL,
	[gravataremail] [nvarchar](255) NOT NULL,
	[ordering] [int] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
	[myclass] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__ueman_profiles_ueman_profile_id] PRIMARY KEY CLUSTERED
(
	[ueman_profile_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;



SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_cron]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__ueman_cron](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[datetime] [datetime],
 CONSTRAINT [PK_#__ueman_cron_id] PRIMARY KEY CLUSTERED
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;

SET QUOTED_IDENTIFIER ON;

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_customfields]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__ueman_customfields](
	[ueman_customfield_id] [bigint] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	[slug] [nvarchar](50) NOT NULL,
	[enabled] [smallint] NOT NULL,
	[field_type] [nvarchar](255) NOT NULL,
	[options] [nvarchar](max) NOT NULL,
	[mandatory] [smallint] NOT NULL,
	[registration_form] [smallint] NOT NULL,
	[admin_form] [smallint] NOT NULL,
	[user_form] [smallint] NOT NULL,
	[profile_form] [smallint] NOT NULL,
	[access] [int] NOT NULL DEFAULT '1',
	[public_profile] [smallint] NOT NULL,
	[default_value] [nvarchar](255) NOT NULL,
	[placeholder] [nvarchar](255) NOT NULL,
	[ordering] [int] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
	[myclass] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_#__ueman_customfields_ueman_customfield_id] PRIMARY KEY CLUSTERED
(
	[ueman_customfield_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_logs]') AND type in (N'U'))
BEGIN
CREATE TABLE [#__ueman_logs](
	[ueman_log_id] [bigint] IDENTITY(1,1) NOT NULL,
	[uid] [int],
	[site] [smallint],
	[visitDate] [datetime],
	[login] [smallint],
	[ip] [nvarchar](50) NOT NULL,
	[enabled] [smallint] NOT NULL,
	[ordering] [int] NOT NULL,
	[created_by] [bigint] NOT NULL,
	[created_on] [datetime] NOT NULL,
	[modified_by] [bigint] NOT NULL,
	[modified_on] [datetime] NOT NULL,
	[locked_by] [bigint] NOT NULL,
	[locked_on] [datetime] NOT NULL,
 CONSTRAINT [PK_#__ueman_logs_ueman_log_id] PRIMARY KEY CLUSTERED
(
	[ueman_log_id] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF)
)
END;