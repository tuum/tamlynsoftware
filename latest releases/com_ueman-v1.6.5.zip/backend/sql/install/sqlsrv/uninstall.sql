-- <?php /* $Id$ */ defined('_JEXEC') or die() ?>;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_profiles]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__ueman_profiles]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_cron]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__ueman_cron]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_customfields]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__ueman_customfields]
END;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[#__ueman_logs]') AND type in (N'U'))
BEGIN
	DROP TABLE [#__ueman_logs]
END;