CREATE TABLE IF NOT EXISTS `#__ueman_profiles` (
  `ueman_profile_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `gravataremail` varchar(255) NOT NULL,
  `ordering` int(10) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` bigint(20) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` bigint(20) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ueman_profile_id`)
) DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__ueman_cron` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`id`)
);

INSERT INTO `#__ueman_cron` (`datetime`) VALUES
        ('2012-07-30 05:38:47');

CREATE TABLE IF NOT EXISTS `#__ueman_customfields` (
  `ueman_customfield_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `field_type` varchar(255) NOT NULL,
  `options` text,
  `mandatory` tinyint(1) NOT NULL,
  `registration_form` tinyint(1) NOT NULL,
  `admin_form` tinyint(1) NOT NULL,
  `user_form` tinyint(1) NOT NULL,
  `profile_form` tinyint(1) NOT NULL,
  `access` int(5) NOT NULL DEFAULT '1',
  `public_profile` tinyint(1) NOT NULL,
  `default_value` varchar(255) NOT NULL,
  `placeholder` varchar(255) NOT NULL,
  `ordering` int(10) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` bigint(20) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` bigint(20) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ueman_customfield_id`)
) DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__ueman_logs` (
	`ueman_log_id` int(11) NOT NULL AUTO_INCREMENT,
	`uid` int(11) NOT NULL,
	`site` tinyint(4) NOT NULL DEFAULT '0',
	`visitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`login` tinyint(4) NOT NULL DEFAULT '0',
	`ip` varchar(50) default NULL,
	`enabled` tinyint(3) NOT NULL DEFAULT '1',
	`ordering` int(10) NOT NULL DEFAULT '0',
	`created_by` bigint(20) NOT NULL DEFAULT '0',
	`created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`modified_by` bigint(20) NOT NULL DEFAULT '0',
	`modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`locked_by` bigint(20) NOT NULL DEFAULT '0',
	`locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`ueman_log_id`)
) DEFAULT CHARSET=utf8;