DROP TABLE IF EXISTS `#__ueman_profiles`;
DROP TABLE IF EXISTS `#__ueman_cron`;
DROP TABLE IF EXISTS `#__ueman_customfields`;
DROP TABLE IF EXISTS `#__ueman_logs`;