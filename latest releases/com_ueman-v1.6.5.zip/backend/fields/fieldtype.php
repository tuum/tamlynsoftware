<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Question_Type Form Field class
 */
class JFormFieldFieldtype extends JFormFieldList
{
        /**
         * The field type.
         *
         * @var         string
         */
        protected $type = 'fieldtype';

        /**
         * Method to get a list of options for a list input.
         *
         * @return      array           An array of JHtml options.
         */
        protected function getOptions()
        {
        		$options = array();

				$options[] = JHtml::_('select.option',  '0', JText::_( 'COM_UEMAN_FIELDTYPE_TEXT' ) );
				$options[] = JHtml::_('select.option',  '1', JText::_( 'COM_UEMAN_FIELDTYPE_RADIO' ) );
				$options[] = JHtml::_('select.option',  '2', JText::_( 'COM_UEMAN_FIELDTYPE_CHECKBOX' ) );
				$options[] = JHtml::_('select.option',  '3', JText::_( 'COM_UEMAN_FIELDTYPE_TEXTAREA' ) );
				$options[] = JHtml::_('select.option',  '5', JText::_( 'COM_UEMAN_FIELDTYPE_DATE' ) );
				$options[] = JHtml::_('select.option',  '6', JText::_( 'COM_UEMAN_FIELDTYPE_DROPDOWN' ) );
				$options[] = JHtml::_('select.option',  '12', JText::_( 'COM_UEMAN_FIELDTYPE_URL' ) );

                $options = array_merge(parent::getOptions(), $options);
                return $options;
        }

        public function getRepeatable()
        {
        	$html = htmlspecialchars(self::getOptionName($this->getOptions(), $this->value), ENT_COMPAT, 'UTF-8');

        	return $html;
        }

        public static function getOptionName($data, $selected = null, $optKey = 'value', $optText = 'text')
        {
        	$ret = null;

        	foreach ($data as $elementKey => &$element)
        	{
        		if (is_array($element))
        		{
        			$key = $optKey === null ? $elementKey : $element[$optKey];
        			$text = $element[$optText];
        		}
        		elseif (is_object($element))
        		{
        			$key = $optKey === null ? $elementKey : $element->$optKey;
        			$text = $element->$optText;
        		}
        		else
        		{
        			// This is a simple associative array
        			$key = $elementKey;
        			$text = $element;
        		}

        		if (is_null($ret))
        		{
        			$ret = $text;
        		}
        		elseif ($selected == $key)
        		{
        			$ret = $text;
        		}
        	}

        	return $ret;
        }
}
