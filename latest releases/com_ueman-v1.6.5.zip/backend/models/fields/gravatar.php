<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

// import the list field type
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

// If we want to custom the html of a field in the list page, we have to extend JFormFieldlist class 
class JFormFieldGravatar extends JFormFieldList {

        protected $type = 'gravatar';

        public function getLabel() {

        }

        public function getInput() {
            $email = md5( strtolower( trim( htmlspecialchars(JStringPunycode::emailToUTF8($this->value), ENT_COMPAT, 'UTF-8') ) ) );

            $return = '<input type="email" id="'.$this->id.'" name="'.$this->name.'" value="'
            . htmlspecialchars(JStringPunycode::emailToUTF8($this->value), ENT_COMPAT, 'UTF-8') . '"' . '/>';

            if ($this->value) {
                $return .= "<img id='gravataImage' src='http://www.gravatar.com/avatar/".$email."' />";
            }

            return $return;
        }

        
        /* ================================================ */
        /* This function generates the html for the field
        /* in the profiles list page
        /* ================================================ */
        public function getRepeatable() {
            
            $email = md5( strtolower( trim( htmlspecialchars(JStringPunycode::emailToUTF8($this->value), ENT_COMPAT, 'UTF-8') ) ) );

            $return = '';

            if ($this->value) {
                $return .= "<img class='gravatar-list-thumb'  src='http://www.gravatar.com/avatar/".$email."' />";
            }

            return $return;
        }

}
