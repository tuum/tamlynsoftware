<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

class UemanModelLogs extends F0FModel
{
	public function buildQuery($overrideLimits = false)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('a.ueman_log_id, a.uid, a.visitDate, a.enabled, a.ip, b.name, b.username, b.email, b.block, b.activation');
		$query->select("CONCAT_WS(',',
  IF(FIND_IN_SET('0', a.site), '".JText::_( 'COM_UEMAN_TITLE_INACTIVE' )."', NULL),
  IF(FIND_IN_SET('1', a.site), '".JText::_( 'COM_UEMAN_TITLE_FRONTEND' )."', NULL),
  IF(FIND_IN_SET('2', a.site), '".JText::_( 'COM_UEMAN_TITLE_BACKEND' )."' , NULL)
) AS site");
		$query->select("CONCAT_WS(',',
  IF(FIND_IN_SET('0', a.login), '".JText::_( 'COM_UEMAN_TITLE_INACTIVE' )."', NULL),
  IF(FIND_IN_SET('1', a.login), '".JText::_( 'COM_UEMAN_TITLE_LOGIN' )."', NULL),
  IF(FIND_IN_SET('2', a.login), '".JText::_( 'COM_UEMAN_TITLE_LOGOUT' )."' , NULL)
) AS login");
		$query->from('#__ueman_logs AS a');

		$query->join('LEFT', '#__users AS b ON b.id = a.uid');

		if (!$overrideLimits)
		{
			$order = $this->getState('filter_order', null, 'cmd');
			if(isset($order)){
				$order = $db->qn($order);
			}

			$dir = strtoupper($this->getState('filter_order_Dir', 'ASC', 'cmd'));
			$dir = in_array($dir, array('DESC', 'ASC')) ? $dir : 'ASC';

			// If the table cache is broken you may end up with an empty order by.
			if (!empty($order) && ($order != $db->qn('')))
			{
				$query->order($order . ' ' . $dir);
			}
			else
			{
				$query->order('a.visitDate DESC');
			}
		}
		else
		{
			$query->order('a.visitDate DESC');
		}

		return $query;
	}

	public function isPluginEnabled()
	{
		$db = JFactory::getDbo();
		$sql = $db->getQuery(true)
		->select('enabled')
		->from($db->qn('#__extensions'))
		->where($db->qn('type') . ' = ' . $db->q('plugin'))
		->where($db->qn('element') . ' = ' . $db->q('uem_log'));
		$db->setQuery($sql);
		$pluginEnabled = $db->loadResult();

		return $pluginEnabled;
	}
}