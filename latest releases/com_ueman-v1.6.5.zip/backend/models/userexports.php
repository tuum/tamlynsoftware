<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

class UemanModelUserexports extends F0FModel
{
	public function __construct($config = array()) {
		$config['table'] = 'users';
		parent::__construct($config);

		$this->setState('limit', 0);
	}

	public function buildQuery($overrideLimits = false)
	{
		$db = JFactory::getDbo();

		$query	= $db->getQuery(true);
		$query->from($db->quoteName('#__ueman_customfields'));
		$query->select('*');
		$query->where('enabled = 1');
		$query->order('ordering');
		$db->setQuery((string)$query);
		$myitems = $db->loadObjectList();

		$query->clear();
		$query = $db->getQuery(true);
		$query->select('aaa.id, aaa.name, aaa.username, aaa.email, aaa.password, aaa.block, aaa.sendEmail, aaa.registerDate, aaa.lastvisitDate, aaa.activation, aaa.params, aaa.lastResetTime, aaa.resetCount, aaa.otpKey, aaa.otep, aaa.requireReset');
		$query->from('#__users AS aaa');

		//standard fields
		$query->join('LEFT', '#__user_profiles AS aa ON aa.user_id = aaa.id AND aa.profile_key = \'ueman.expiryDate\'');
		$query->select('aa.profile_value AS expiryDate');
		$query->join('LEFT', '#__user_profiles AS ab ON ab.user_id = aaa.id AND ab.profile_key = \'ueman.biography\'');
		$query->select('ab.profile_value AS biography');
		$query->join('LEFT', '#__user_profiles AS ac ON ac.user_id = aaa.id AND ac.profile_key = \'ueman.googlePlus\'');
		$query->select('ac.profile_value AS googlePlus');
		$query->join('LEFT', '#__user_profiles AS ad ON ad.user_id = aaa.id AND ad.profile_key = \'ueman.facebook\'');
		$query->select('ad.profile_value AS facebook');
		$query->join('LEFT', '#__user_profiles AS ae ON ae.user_id = aaa.id AND ae.profile_key = \'ueman.linkedin\'');
		$query->select('ae.profile_value AS linkedin');
		$query->join('LEFT', '#__user_profiles AS af ON af.user_id = aaa.id AND af.profile_key = \'ueman.twitter\'');
		$query->select('af.profile_value AS twitter');
		$query->join('LEFT', '#__user_profiles AS ag ON ag.user_id = aaa.id AND ag.profile_key = \'ueman.website\'');
		$query->select('ag.profile_value AS website');
		$query->join('LEFT', '#__user_profiles AS ah ON ah.user_id = aaa.id AND ah.profile_key = \'ueman.phone\'');
		$query->select('ah.profile_value AS phone');

		//fields from core jooomla user profile plugin
		$query->join('LEFT', '#__user_profiles AS aab ON aaa.id = aab.user_id AND aab.profile_key = \'profile.address1\'');
		$query->select('aab.profile_value AS address1');
		$query->join('LEFT', '#__user_profiles AS ba ON aaa.id = ba.user_id AND ba.profile_key = \'profile.address2\'');
		$query->select('ba.profile_value AS address2');
		$query->join('LEFT', '#__user_profiles AS ca ON aaa.id = ca.user_id AND ca.profile_key = \'profile.city\'');
		$query->select('ca.profile_value AS city');
		$query->join('LEFT', '#__user_profiles AS da ON aaa.id = da.user_id AND da.profile_key = \'profile.region\'');
		$query->select('da.profile_value AS region');
		$query->join('LEFT', '#__user_profiles AS ea ON aaa.id = ea.user_id AND ea.profile_key = \'profile.postcode\'');
		$query->select('ea.profile_value AS postcode');
		$query->join('LEFT', '#__user_profiles AS fa ON aaa.id = fa.user_id AND fa.profile_key = \'profile.country\'');
		$query->select('fa.profile_value AS country');
		$query->join('LEFT', '#__user_profiles AS ga ON aaa.id = ga.user_id AND ga.profile_key = \'profile.phone\'');
		$query->select('ga.profile_value AS phone');

		$counter=65;
		foreach($myitems AS $item)
		{
			$mytable = chr($counter);
			$query->join('LEFT', '#__user_profiles AS '.$mytable.' ON '.$mytable.'.user_id = aaa.id AND '.$mytable.'.profile_key = \'ueman.'.$item->title.'\'');
			$query->select(''.$mytable.'.profile_value AS \''.$item->title.'\'');
			$counter++;
		}

		$db->setQuery($query);
		$db->query();

		return $query;
	}
}
