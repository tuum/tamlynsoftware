<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

$app = JFactory::getApplication();
if ($app->isAdmin())
{
?>

<div class="control-group">
	<?php echo JText::_( 'COM_UEMAN_EMAIL_TEST_INTRO'); ?>
</div>

<form name="adminForm" action="index.php" action="post" id="adminForm" class="form form-horizontal">
	<input type="hidden" name="option" value="com_ueman" />
	<input type="hidden" name="view" value="emailtests" />
	<input type="hidden" name="task" value="emailtest" />
	<input type="hidden" name="format" value="raw" />

	<div class="control-group">
		<div class="control-label">
			<?php echo JText::_( 'COM_UEMAN_EMAIL_ADDRESS'); ?>
		</div>
		<div class="controls">
			<input type="emailToTest" aria-required="true" required="required"
				size="30"
				id="email"
				class="validate-email required"
				name="emailToTest"
				aria-invalid="false"
				>
		</div>
	</div>

	<div class="form-actions">
		<input type="submit" class="btn btn-primary btn-large" value="<?php echo JText::_('COM_UEMAN_TESTEMAIL_BUTTON') ?>" />
	</div>
</form>

<div class="ak_clr"></div>

<div class="row-fluid">
	<div class="span12">
		<?php
		$app = JFactory::getApplication();

		if($app->getCfg('mailonline') == 0)
		{
			?>
		<div class="alert alert-error">
			<a class="close" data-dismiss="alert" href="#">×</a>
			<p><?php echo JText::_('COM_UEMAN_SEND_MAIL_TURNED_OFF'); ?></p>
		</div>
		<?php
		}

		if($app->getCfg('mailer') == 'mail')
		{
		?>
		<div class="alert alert-info">
			<a class="close" data-dismiss="alert" href="#">×</a>
			<p><?php echo JText::_('COM_UEMAN_PHP_MAIL'); ?></p>
		</div>
		<?php
		}

		if($app->getCfg('mailer') == 'sendmail')
		{
		?>
		<div class="alert alert-info">
			<a class="close" data-dismiss="alert" href="#">×</a>
			<p><?php echo JText::_('COM_UEMAN_SENDMAIL'); ?></p>
		</div>
		<?php
		}

		if($app->getCfg('smtphost') == 'localhost')
		{
		?>
		<div class="alert alert-info">
			<a class="close" data-dismiss="alert" href="#">×</a>
			<p><?php echo JText::_('COM_UEMAN_LOCALHOST'); ?></p>
		</div>
		<?php
		}

		//echo "<p>".JText::_('COM_UEMAN_MAILER_LABEL').": " . $app->getCfg('mailer') . "</p>";
		//echo "<p>".JText::_('COM_UEMAN_SMTPAUTH_LABEL').": " . $app->getCfg('smtpauth') . "</p>";
		//echo "<p>".JText::_('COM_UEMAN_SMTPUSER_LABEL').": " . $app->getCfg('smtpuser') . "</p>";
		//echo "<p>".JText::_('COM_UEMAN_SMTPPASS_LABEL').": " . $app->getCfg('smtppass') . "</p>";
		//echo "<p>".JText::_('COM_UEMAN_SMTPHOST_LABEL').": " . $app->getCfg('smtphost') . "</p>";
		//echo "<p>".JText::_('COM_UEMAN_SMTPPORT_LABEL').": " . $app->getCfg('smtpport') . "</p>";
		?>
	</div>
</div>

<?php
}
?>