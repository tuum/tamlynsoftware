<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

//$viewTemplate = $this->getRenderedForm();
//echo $viewTemplate;
?>

<div class="col width-65">
	<fieldset class="adminform">

	<table class="adminlist">
	<thead>
		<tr class="uemanHeader">
		<th width="100">
			<?php echo JText::_( 'COM_UEMAN_TITLE_USERNAME' ); ?>:
		</th>
		<th width="100">
			<?php echo JText::_( 'COM_UEMAN_TITLE_EMAIL' ); ?>:
		</th>
		</tr>
		</thead>

		<?php
		for ($i=0, $n=count( $this->items ); $i < $n; $i++)
		{
			$row = $this->items[$i];
			?>
			<tr class="uemanBody">
			<td>
			   <?php echo $row->username; ?>
			</td>
			<td>
			   <?php echo $row->email; ?>
			</td>
			</tr>
		<?php
		} //end for$row
		?>

	</table>


	</fieldset>
</div>
<div class="col width-35">
	&nbsp;
</div>
<div class="clr"></div>