<?php
/*
 * @package ueman
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die();

$app = JFactory::getApplication();
if ($app->isAdmin())
{
	$session = JFactory::getSession();
	$availableFields = $session->get('availableFields');
	$csvheader = $session->get('csvheader');
	$contents = $session->get('contents');
	$usergroups = $session->get('usergroups');
?>

<form name="adminForm" action="index.php" method="post" id="adminForm" class="form form-horizontal" enctype="multipart/form-data">
	<input type="hidden" name="option" value="com_ueman" />
	<input type="hidden" name="view" value="userimports" />
	<input type="hidden" name="task" value="importcsv" />

	<div class="control-group">
		<div class="control-label">
			<?php echo JText::_( 'COM_UEMAN_USER_GROUP_IMPORT'); ?>
		</div>
		<div class="controls">
			<select name="userGroup">
				<?php foreach($usergroups AS $group){ ?>
					<option value="<?php echo $group->id; ?>" <?php echo ($group->title == 'Registered') ? 'selected="selected"':""; ?>><?php echo $group->title; ?></option>
				<?php } ?>
			</select>
		</div>
	</div>

	<div class="control-group">
		<div class="control-label">
			<?php echo JText::_( 'COM_UEMAN_USER_NOTIFY_NEW_USER_IMPORT'); ?>
		</div>
		<div class="controls">
			<input type="radio" name="notifyNewUser" value="1"><?php echo JText::_( 'JYES'); ?>
			<input type="radio" name="notifyNewUser" value="0" checked><?php echo JText::_( 'JNO'); ?>
		</div>
	</div>

	<div class="control-group">
		<?php echo JText::_( 'COM_UEMAN_CSV_MAPPING'); ?>
	</div>

	<?php
	$myFields = explode(',', $availableFields);
	foreach($myFields AS $field)
	{
		$field = trim($field);
		?>
		<div class="control-group">
			<div class="control-label">
				<?php echo $field; ?>
			</div>
			<div class="controls">
				<select name="<?php echo $field; ?>">
					<option value=""><?php echo JText::_( 'COM_UEMAN_PLEASE_SELECT'); ?></option>
					<?php foreach($csvheader AS $myoption){ ?>
					<option value="<?php echo trim($myoption); ?>" <?php echo $field == trim($myoption) ? 'selected="selected"': '' ?>><?php echo trim($myoption); ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
	<?php } ?>

	<div class="form-actions">
		<input type="submit" class="btn btn-primary btn-large" value="<?php echo JText::_('COM_UEMAN_IMPORT_USERS_BUTTON') ?>" />
	</div>
</form>

<?php
}
?>