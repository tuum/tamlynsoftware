(function($)
{
	$(document).ready(function()
	{
		//when user click on checkbox
		$("input[type=checkbox]").change(function(){
        	if($(this).is(":checked")){
				//checked

        		//is this checkbox required?
        		if($( this ).attr('required') || $( this ).hasClass('required')) {
        			//find out how many checkboxes are selected
        			var myparent = '#' + $( this ).parent().parent().parent().attr('id');
        			var allInputElements = $( "input" );
        			var options = $( myparent ).find( allInputElements );

        			var nl, i;

        			//remove required from other checkboxes in this group
        			for (i=0, nl = options; i<nl.length; i++) {
        				var el1 = $('#'+nl[i].id);
        				el1.attr('required', null);
        				el1.attr('aria-invalid', 'false');
        				el1.attr('class', 'validate-checkbox');
        			}
        		}
        	}else{
        		// Unchecked

           		var myparent = '#' + $( this ).parent().parent().parent().attr('id');

           		if($( myparent ).attr('aria-required')) {
           			var allInputElements = $( "input" );
           			var options = $( myparent ).find( allInputElements );
           			var nl, i;

        			var counter=0;
        			//	find out how many checkboxes are selected
        			for (i=0, nl = options; i<nl.length; i++) {
        				if (nl[i].checked){
        					counter++;
        				}
        			}

        			if($(this).hasClass('validate-checkbox') && counter>0){
        				//do nothing, as at aleast one checkbox is already selected
        			}else{
        				//add required to other checkboxes in this group
        				for (i=0, nl = options; i<nl.length; i++) {
           					var el1 = $('#'+nl[i].id);
           					el1.attr('required', 'required');
           					el1.attr('aria-invalid', 'true');
           					el1.attr('class', 'required validate-checkbox');
           				}
        			}
           		}
           	}
        });

	});

})(jQuery);