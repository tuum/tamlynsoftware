<?php
/*
 * @package ueman system plugin
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plgSystemUeman extends JPlugin
{
	protected $autoloadLanguage = true;

	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	function onAfterInitialise()
	{
		//keep track of lasturl for logout button
		$uri = clone JURI::getInstance();
		$session = JFactory::getSession();
		$lasturl = $session->get('currenturl', '');
		$session->set('lasturl', $lasturl);
		$session->set('currenturl', $uri);

		//see when plugin ran last
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('datetime');
		$query->from('#__ueman_cron');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum())
		{
			echo $db->stderr();
			return false;
		}

		$lastrun = $rows[0]->datetime;

 		//should plugin run again
 		$frequency		= $this->params->get('frequency',		15);
 		$resetAfter		= $this->params->get('resetAfter',		0);
 		$disableAfter	= $this->params->get('disableAfter',		0);
 		$emailResetUsers	= $this->params->get('emailResetUsers',		1);

		$date = JFactory::getDate();
		$date->modify("-".$frequency." mins");

 		if($date > $lastrun){
 			//when should it run next
 			$nextrun = JFactory::getDate();
			$nextrun->modify("+".$frequency." mins");

			// check to see if the user has past their expiry date
			plgSystemUeman::process();

			// is user expiry turned on?
			$app = JFactory::getApplication();
			$params = JComponentHelper::getParams('com_ueman');
			$userExpiry = $params->get('userExpiry');
			$expireAfter = $params->get('expireAfter');
			$superUserExemption = $params->get('superUserExemption');
			if($userExpiry == 1 || $userExpiry == -2 )
			{
				plgSystemUeman::processUserExpiry($userExpiry, $expireAfter, $superUserExemption);
			}

			$query->clear();
			$query->update('#__ueman_cron');
			$query->set('datetime = '.$db->quote( $db->escape($nextrun), false ));

			$db->setQuery((string)$query);
			$db->query();
			if ($db->getErrorNum())
			{
				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
				return;
			}

			//see if any users need their password reset forced
			plgSystemUeman::processPasswordReset($resetAfter, $disableAfter, $emailResetUsers);

 		}else{
 			// not time to run yet
 		}
 	}

 	static function process(){
 		$db = JFactory::getDbo();
 		$query	= $db->getQuery(true);

 		$query->select('a.id, b.profile_value AS expiryDate');
 		$query->from('#__users AS a');
 		$query->join('LEFT', '#__user_profiles AS b ON b.user_id = a.id AND b.profile_key = \'ueman.expiryDate\'');
 		$query->where('block = 0');

 		$db->setQuery((string)$query);

 		try
 		{
 			$rows = $db->loadObjectList();
 		}
 		catch (RuntimeException $e)
 		{
 			$this->_subject->setError($e->getMessage());
 			return false;
 		}

 		$now = JFactory::getDate();
 		$currentDate=$now->format('Y-m-d H:i:s');

 		$app = JFactory::getApplication();
 		$params = JComponentHelper::getParams('com_ueman');
 		$superUserExemption = $params->get('superUserExemption', 1);

 		foreach($rows as $row){

			if(isset($row->expiryDate) && $row->expiryDate!=NULL && $row->expiryDate!='null')
 			{
		 		$date = new JDate(json_decode($row->expiryDate,true));
		 		$row->date = $date->format('Y-m-d');

		 		//is current date time after the expiry date?
		 		if($currentDate > $row->date){
		 			//this user expiry date has passed, so block user

		 			$query->clear();
		 			$query->update('#__users AS a');
		 			$query->set('a.block = 1');
		 			$query->where('a.id = '.(int)$row->id);

		 			if($superUserExemption)
		 			{
		 				$query->join('LEFT', '#__user_usergroup_map AS map ON map.user_id = a.id');
		 				$query->join('LEFT', '#__usergroups AS g2 ON g2.id = map.group_id');
		 				$query->where("g2.title <> 'Super Users'");
		 			}

		 			$db->setQuery((string)$query);
		 			$db->query();
		 			if ($db->getErrorNum())
		 			{
		 				echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
		 				return;
		 			}
	 			}
 			}
 		}

 	}

 	static function processUserExpiry($userExpiry, $expireAfter, $superUserExemption)
 	{
 		$now = JFactory::getDate();
 		$currentDate=$now->format('Y-m-d H:i:s');

		// set expiry date to be x days before now
		$expiryDate = JFactory::getDate();
		$expiryDate->modify("-".$expireAfter." days");

		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		switch($userExpiry)
		{
			case 1: // block users
					$query->update('#__users AS a');
					$query->set('a.block = 1');
					$query->where("a.lastvisitDate < '".$expiryDate."'");

					if($superUserExemption)
					{
						$query->join('LEFT', '#__user_usergroup_map AS map ON map.user_id = a.id');
						$query->join('LEFT', '#__usergroups AS g2 ON g2.id = map.group_id');
						$query->where("g2.title <> 'Super Users'");
					}

					$db->setQuery((string)$query);
					$db->query();
					if ($db->getErrorNum())
					{
						echo JText::sprintf('JLIB_DATABASE_ERROR_FUNCTION_FAILED', $db->getErrorNum(), $db->getErrorMsg()).'<br />';
						return;
					}
					break;
			case -2: //delete users

					//select which users to delete
					$query->select('a.*');
					$query->from('#__users AS a');
					$query->where("a.lastvisitDate < '".$expiryDate."'");

					if($superUserExemption)
					{
						$query->join('LEFT', '#__user_usergroup_map AS map ON map.user_id = a.id');
						$query->join('LEFT', '#__usergroups AS g2 ON g2.id = map.group_id');
						$query->where("g2.title <> 'Super Users'");
					}

					$db->setQuery((string)$query);

			 		try
			 		{
			 			$rows = $db->loadObjectList();
			 		}
			 		catch (RuntimeException $e)
			 		{
			 			$this->_subject->setError($e->getMessage());
			 			return false;
			 		}

			 		foreach($rows as $row)
			 		{
			 			//delete user
			 			$query->clear();
			 			$query->delete('#__users');
			 			$query->where('id = '.(int)$row->id );
			 			$db->setQuery((string)$query);
			 			$db->query();

			 			//delete user group maps
			 			$query->clear();
			 			$query->delete('#__user_usergroup_map');
			 			$query->where('user_id = '.(int)$row->id );
			 			$db->setQuery((string)$query);
			 			$db->query();

			 			//delete user profile
			 			$query->clear();
			 			$query->delete('#__user_profiles');
			 			$query->where('user_id = '.(int)$row->id );
			 			$db->setQuery((string)$query);
			 			$db->query();

			 			//delete user notes
			 			$query->clear();
			 			$query->delete('#__user_notes');
			 			$query->where('user_id = '.(int)$row->id );
			 			$db->setQuery((string)$query);
			 			$db->query();
			 		}
					break;
		}
 	}

 	static function processPasswordReset($resetAfter, $disableAfter, $emailResetUsers)
 	{
 		$db = JFactory::getDbo();
 		$query	= $db->getQuery(true);

 		// disable accounts after x days if they have not reset their password
 		if($disableAfter == 0)
 		{
 			//disble after feature disabled
 		}
		else
		{
	 		// set disable date to be x days before now
	 		$disableDate = JFactory::getDate();
	 		$disableDate->modify("-".(int)$disableAfter." days");

	 		//when was the last time the user changed their password
	 		$query->select('a.*');
	 		$query->from('#__users AS a');
	 		$query->where("a.lastResetTime < '".$disableDate."'");
	 		$db->setQuery((string)$query);
	 		$myitems = $db->loadObjectList();

	 		foreach($myitems AS $item)
	 		{
	 			//user needs their password reset
	 			$query->clear();
	 			$query->update('#__users');
	 			$query->set('block = 1');
	 			$query->where('id = '.(int)$item->id );
	 			$db->setQuery((string)$query);
	 			$db->query();
	 		}
		}

 		if($resetAfter == 0)
 		{
 			//reset after feature disabled
 		}
		else
		{
	 		// set reset date to be x days before now
	 		$resetDate = JFactory::getDate();
	 		$resetDate->modify("-".(int)$resetAfter." days");

	 		$now = JFactory::getDate();
	 		$currentDate=$now->format('Y-m-d H:i:s');


	 		//when was the last time the user changed their password
	 		$query->clear();
	 		$query->select('*');
	 		$query->from('#__users');
	 		$query->where("lastResetTime < '".$resetDate."'");
	 		$query->where('block = 0');
	 		$query->where('requireReset = 0');

	 		$db->setQuery((string)$query);
	 		$myitems = $db->loadObjectList();

	 		foreach($myitems AS $item)
	 		{
		 		//user needs their password reset
		 		$query->clear();
		 		$query->update('#__users');
		 		$query->set('requireReset = 1');
		 		$query->where('id = '.(int)$item->id );
		 		$db->setQuery((string)$query);
		 		$db->query();

		 		$query->clear();
		 		$query->update('#__users');
		 		$query->set('lastResetTime = '.$db->quote($currentDate));
		 		$query->where('id = '.(int)$item->id );
		 		$db->setQuery((string)$query);
		 		$db->query();

		 		//do we need to let this user know via email that their password is forced reset
		 		if($emailResetUsers)
		 		{
		 			//yes we do
		 			$conf	= JFactory::getConfig();

		 			$emailRecipient = $item->email;
					$mailfrom     = $conf->get('mailfrom', $conf->get('config.mailfrom'));
					$fromname     = $conf->get('fromname', $conf->get('config.fromname'));
					$sitename	= $conf->get('sitename', $conf->get('config.sitename'));

		 			$emailBody = JText::_('PLG_SYSTEM_UEMAN_PASSWORDFORCERESET_EMAIL_BODY').'<br><a href="'.JURI::base().'index.php?option=com_users&task=login" target="_blank">'.JURI::base().'index.php?option=com_users&task=login</a>';
		 			$emailSubject = JText::_('PLG_SYSTEM_UEMAN_PASSWORDFORCERESET_SUBJECT').' '.$sitename;
		 			$mode = 1;

		 			JFactory::getMailer()->sendMail($mailfrom, $fromname, $emailRecipient, $emailSubject, $emailBody, $mode);
		 		}
 			}
 		}
 	}
}