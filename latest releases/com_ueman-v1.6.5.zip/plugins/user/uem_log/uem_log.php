<?php
/*
 * @package UE Man Log user plugin
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('JPATH_BASE') or die;

class plgUserUem_log extends JPlugin
{
	protected $autoloadLanguage = true;

	/**
	 * Tracks user logins
	 *
	 * @access  public
	 * @param   array   holds the user data
	 * @param   array    extra options
	 * @return  boolean True on success
	 */
	public function onUserLogin($user, $options = array())
	{
		jimport('joomla.user.helper');
		$uid = intval(JUserHelper::getUserId($user['username']));

		$db			= JFactory::getDBO();
		$query	= $db->getQuery(true);

		$app = JFactory::getApplication();
		$site = $app->isAdmin() ? '2' : '1';
		$login = 1;

		$now = JFactory::getDate();
		$currentDate=$now->format('Y-m-d H:i:s');

		//get IP Address
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip=$_SERVER['REMOTE_ADDR'];
		}

		$query->insert('#__ueman_logs');
		$query->columns( array($db->quoteName('uid'), $db->quoteName('site'), $db->quoteName('visitDate'), $db->quoteName('login'), $db->quoteName('enabled'), $db->quoteName('ip'), $db->quoteName('ordering') ) );
		$query->values( (int)$uid.', '.(int)$site.', '.$db->quote($currentDate, false ).', '.(int)$login.', 1 , '.$db->quote($ip, false ).', 1 ' );

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

	/**
	 * Tracks user logouts
	 *
	 * @access public
	 * @param array holds the user data
	 * @return boolean True on success
	 */
	public function onUserLogout($user, $options = array())
	{
		jimport('joomla.user.helper');
		$uid = intval(JUserHelper::getUserId($user['username']));

		$db			= JFactory::getDBO();
		$query	= $db->getQuery(true);

		$app = JFactory::getApplication();
		$site = $app->isAdmin() ? '2' : '1';
		$login = 2;

		$now = JFactory::getDate();
		$currentDate=$now->format('Y-m-d H:i:s');

		//get IP Address
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip=$_SERVER['REMOTE_ADDR'];
		}

		$query->insert('#__ueman_logs');
		$query->columns( array($db->quoteName('uid'), $db->quoteName('site'), $db->quoteName('visitDate'), $db->quoteName('login'), $db->quoteName('enabled'), $db->quoteName('ip'), $db->quoteName('ordering') ) );
		$query->values( (int)$uid.', '.(int)$site.', '.$db->quote($currentDate, false ).', '.(int)$login.', 1, '.$db->quote($ip, false).', 1 ' );

		$db->setQuery( $query );
		if (!$db->query())
		{
			echo $db->getErrorMsg();
			return false;
		}

		return true;
	}

}