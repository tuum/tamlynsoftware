<?php
/*
 * @package ueman user plugin
 * @copyright Copyright (c)2015 UE Man
 * @license GNU General Public License version 3 or later
 *
 *	  UE Man is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('JPATH_BASE') or die;
require_once JPATH_ADMINISTRATOR.'/components/com_ueman/fields/showgravatar.php';
require_once JPATH_ADMINISTRATOR.'/components/com_ueman/fields/checkboxes.php';

class plgUserUeman extends JPlugin
{
	/**
	 * Expiry Date.
	 *
	 * @var    string
	 */
	private $expiryDate = '';

	protected $autoloadLanguage = true;

	public function onContentPrepareData($context, $data)
	{
		// Check we are manipulating a valid form.
		if (!in_array($context, array('com_users.profile', 'com_users.user', 'com_users.registration', 'com_admin.profile')))
		{
			return true;
		}

		if (is_object($data))
		{
			$userId = isset($data->id) ? $data->id : 0;

			if (!isset($data->uemanprofile) and $userId > 0)
			{
				// Load the profile data from the database.
				$db = JFactory::getDbo();
				$db->setQuery(
					'SELECT profile_key, profile_value FROM #__user_profiles' .
						' WHERE user_id = ' . (int) $userId . " AND profile_key LIKE 'ueman.%'" .
						' ORDER BY ordering'
				);

				try
				{
					$results = $db->loadRowList();
				}
				catch (RuntimeException $e)
				{
					$this->_subject->setError($e->getMessage());

					return false;
				}

				// Merge the profile data.
				$data->uemanprofile = array();

				foreach ($results as $v)
				{
					$k = str_replace('ueman.', '', $v[0]);
					$data->uemanprofile[$k] = json_decode($v[1], true);

					if ($data->uemanprofile[$k] === null)
					{
						if($v[1] != 'null'){
							$data->uemanprofile[$k] = $v[1];
						}else{
							$data->uemanprofile[$k] = '';
						}
					}
				}
			}

			if(isset($results[0]->profile_key))
			{
				if($results[0]->profile_key == 'ueman.expiryDate' && $results[0]->profile_value == null)
				{
					//make sure there are no NULL expiryDates
					$db = JFactory::getDbo();
					$query	= $db->getQuery(true);

					$query->update('#__user_profiles');
					$query->set('profile_value = \'\'');
					$query->where('profile_key = \'ueman.expiryDate\'');
					$query->where('profile_value = \'null\'');

					$db->setQuery((string)$query);
					$db->query();
				}
			}

			if (!JHtml::isRegistered('users.expiryDate'))
			{
				JHtml::register('users.expiryDate', array(__CLASS__, 'expiryDate'));
			}
		}

		return true;
	}

	/**
	 * returns html markup showing a date picker
	 *
	 * @param   string  $value  valid date string
	 *
	 * @return  mixed
	 */
	public static function expiryDate($value)
	{
		if (empty($value))
		{
			return JHtml::_('users.value', $value);
		}
		else
		{
			return JHtml::_('date', $value, null, null);
		}
	}

	public function onContentPrepareForm($form, $data)
	{
		if (!($form instanceof JForm))
		{
			$this->_subject->setError('JERROR_NOT_A_FORM');

			return false;
		}

		// Check we are manipulating a valid form.
		$name = $form->getName();

		if (!in_array($name, array('com_admin.profile', 'com_users.user', 'com_users.profile', 'com_users.registration')))
		{
			return true;
		}

		//make sure there are no NULL expiryDates
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->update('#__user_profiles');
		$query->set('profile_value = \'\'');
		$query->where('profile_key = \'ueman.expiryDate\'');
		$query->where('profile_value = \'null\'');

		$db->setQuery((string)$query);
		$db->query();

		// Add the registration fields to the form.
		JForm::addFormPath(__DIR__ . '/profiles');
		$form->loadFile('profile', false);

		$fields = array(
				'expiryDate',
		);

		return true;
	}

	public function onUserBeforeSave($user, $isnew, $data)
	{
		// Check that the date is valid.
		if (!empty($data['uemanprofile']['expiryDate']))
		{
			try
			{
				$date = new JDate($data['uemanprofile']['expiryDate']);
				$this->date = $date->format('Y-m-d H:i:s');
			}
			catch (Exception $e)
			{
				// Throw an exception if date is not valid.
				throw new InvalidArgumentException(JText::_('PLG_USER_PROFILE_ERROR_INVALID_DOB'));
			}
		}

		return true;
	}

	public function onUserAfterSave($data, $isNew, $result, $error)
	{
		$userId = JArrayHelper::getValue($data, 'id', 0, 'int');

		if ($userId && $result && isset($data['uemanprofile']) && (count($data['uemanprofile'])))
		{
			try
			{
				// Sanitize the date
				$data['uemanprofile']['expiryDate'] = $this->date;

				$db = JFactory::getDbo();
				$query = $db->getQuery(true)
				->delete($db->quoteName('#__user_profiles'))
				->where($db->quoteName('user_id') . ' = ' . (int) $userId)
				->where($db->quoteName('profile_key') . ' LIKE ' . $db->quote('ueman.%'));
				$db->setQuery($query);
				$db->execute();

				$tuples = array();
				$order = 1;

				foreach ($data['uemanprofile'] as $k => $v)
				{
					$tuples[] = '(' . $userId . ', ' . $db->quote('ueman.' . $k) . ', ' . $db->quote(json_encode($v)) . ', ' . ($order++) . ')';
				}

				$db->setQuery('INSERT INTO #__user_profiles VALUES ' . implode(', ', $tuples));
				$db->execute();
			}
			catch (RuntimeException $e)
			{
				$this->_subject->setError($e->getMessage());

				return false;
			}
		}

		return true;
	}

	public function onUserAfterDelete($user, $success, $msg)
	{
		if (!$success)
		{
			return false;
		}

		$userId = JArrayHelper::getValue($user, 'id', 0, 'int');

		if ($userId)
		{
			try
			{
				$db = JFactory::getDbo();
				$db->setQuery(
						'DELETE FROM #__user_profiles WHERE user_id = ' . $userId .
						" AND profile_key LIKE 'ueman.%'"
				);

				$db->execute();
			}
			catch (Exception $e)
			{
				$this->_subject->setError($e->getMessage());

				return false;
			}
		}

		return true;
	}

}