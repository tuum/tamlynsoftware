<?php
/*
* @copyright Copyright (c) 2015 UE Man
* @license GNU General Public License version 3 or later
*
 *	  UE Man is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
*    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die;

$user = JFactory::getUser($row->created_by);

require_once JPATH_SITE.'/plugins/content/ueman_content_profiles/helper.php';
$userdetails = plgContentUeman_content_profilesHelper::getUserProfileDetails($user->id);
?>

<div class="well">
	<div CLASS="row-fluid">
		<div class="span2">
			<?php
			$email = md5( strtolower( trim( htmlspecialchars(JStringPunycode::emailToUTF8($user->email), ENT_COMPAT, 'UTF-8') ) ) );
			echo "<img class='thumbnail m' id='gravataImage' src='http://www.gravatar.com/avatar/".$email."' />";
			?>

			<ul class="social4">
				<?php if($userdetails['googlePlus'] && $userdetails['googlePlus']!='https://plus.google.com/'){ ?>
					<li class="social4"><a href="<?php echo $userdetails['googlePlus']; ?>"><i class="fa fa-google-plus-square fa-2x"></i>Google+</a></li>
				<?php } ?>
				<?php if($userdetails['facebook'] && $userdetails['facebook']!='https://www.facebook.com/'){ ?>
					<li class="social4"><a href="<?php echo $userdetails['facebook']; ?>"><i class="fa fa-facebook-square fa-2x"></i>Facebook</a></li>
				<?php } ?>
				<?php if($userdetails['linkedin'] && $userdetails['linkedin']!='https://www.linkedin.com/in/'){ ?>
					<li class="social4"><a href="<?php echo $userdetails['linkedin']; ?>"><i class="fa fa-linkedin-square fa-2x"></i>LinkedIn</a></li>
				<?php } ?>
				<?php if($userdetails['twitter'] && $userdetails['twitter']!='https://twitter.com/'){ ?>
					<li class="social4"><a href="<?php echo $userdetails['twitter']; ?>"><i class="fa fa-twitter-square fa-2x"></i>Twitter</a></li>
				<?php } ?>
				<?php if($userdetails['website'] && $userdetails['website']!='http://'){ ?>
					<li class="social4"><a href="<?php echo $userdetails['website']; ?>"><i class="fa fa-globe fa-2x"></i>Website</a></li>
				<?php } ?>
				<?php if($userdetails['phone']){ ?>
					<li class="social4"><a href="tel:<?php echo $userdetails['phone']; ?>"><i class="fa fa-phone-square fa-2x"></i><?php echo $userdetails['phone']; ?></a></li>
				<?php } ?>
			</ul>
		</div>

		<?php if($userdetails['biography']){ ?>
		<div class="span10">
				<div CLASS="row-fluid">
					<div class="span12">
						<h3 class="media-heading"><?php echo $user->name; ?></h3>
						<h4>Biography</h4>
						<?php echo $userdetails['biography']; ?>
					</div>
				</div>
		</div>
		<?php } ?>
	</div>
</div>