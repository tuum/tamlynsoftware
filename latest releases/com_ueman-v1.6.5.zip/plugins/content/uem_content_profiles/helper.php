<?php
/*
* @copyright Copyright (c) 2015 UE Man
* @license GNU General Public License version 3 or later
*
 *	  UE Man is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    UE Man is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
*    along with UE Man.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die;

class plgContentUeman_content_profilesHelper
{
	public static function getUserProfileDetails($uid)
	{
		//$userdetails = new stdClass();
		$userdetails = array();

		if ($uid > 0)
		{
			// Load the profile data from the database.
			$db = JFactory::getDbo();
			$db->setQuery(
					'SELECT profile_key, profile_value FROM #__user_profiles' .
					' WHERE user_id = ' . (int) $uid . " AND profile_key LIKE 'ueman.%'" .
					' ORDER BY ordering'
			);

			try
			{
				$results = $db->loadRowList();
			}
			catch (RuntimeException $e)
			{
				$this->_subject->setError($e->getMessage());

				return false;
			}

			foreach ($results as $v)
			{
				$k = str_replace('ueman.', '', $v[0]);
				$userdetails[$k] = json_decode($v[1], true);

				if ($userdetails[$k] === null)
				{
					$userdetails[$k] = $v[1];
				}
			}
		}

		//fix urls if needed
		if (strpos($userdetails['googlePlus'],'plus.google.com') !== false) {
			//this a full url, so don't do anything
		}
		else
		{
			$userdetails['googlePlus'] = 'https://plus.google.com/'.$userdetails['googlePlus'];
		}
		if (strpos($userdetails['facebook'],'facebook.com') !== false) {
			//this a full url, so don't do anything
		}
		else
		{
			$userdetails['facebook'] = 'https://www.facebook.com/'.$userdetails['facebook'];
		}
		if (strpos($userdetails['linkedin'],'linkedin.com') !== false) {
			//this a full url, so don't do anything
		}
		else
		{
			$userdetails['linkedin'] = 'https://www.linkedin.com/in/'.$userdetails['linkedin'];
		}
		if (strpos($userdetails['twitter'],'twitter.com') !== false) {
			//this a full url, so don't do anything
		}
		else
		{
			$userdetails['twitter'] = 'https://twitter.com/'.$userdetails['twitter'];
		}
		if (strpos($userdetails['website'],'http') !== false) {
			//this a full url, so don't do anything
		}
		else
		{
			$userdetails['website'] = 'http://'.$userdetails['website'];
		}

		return $userdetails;
	}
}