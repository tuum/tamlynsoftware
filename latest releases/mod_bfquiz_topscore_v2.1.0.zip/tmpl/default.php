<?php // no direct access
defined('_JEXEC') or die('Restricted access');
$showTimeTaken = trim($params->get('showTimeTaken'));
$showRanking = trim($params->get('showRanking'));
$showHeading = trim($params->get('showHeading'));

$rankTitle = trim($params->get('rankTitle'));
$nameTitle = trim($params->get('nameTitle'));
$scoreTitle = trim($params->get('scoreTitle'));
$timeTakenTitle = trim($params->get('timeTakenTitle'));
$i=1;

//adjust width of Name if columns are hidden
$nameClass="BFTopScoreName";  // default, all columns are shown
if( !($showRanking) & !($showTimeTaken) ){ //both ranking and time are hidden
	$nameClass="BFTopScoreName85";
}else if( !($showRanking) | !($showTimeTaken) ){ //either ranking or time are hidden (but not both)
	$nameClass="BFTopScoreName70";
}
?>

<div class="BFTopScore<?php echo $moduleclass_sfx ?>">

<?php if($showHeading){ ?>
			<div class="BFTopScoreResultTitle">
				<?php if($showRanking){ ?>
				<div class="BFTopScoreRankingTitle">
				<?php echo $rankTitle; ?>
				</div>
				<?php } ?>
			   	<div class="<?php echo $nameClass; ?><?php echo "Title"; ?>">
				<?php echo $nameTitle; ?>
				</div>
				<div class="BFTopScoreScoreTitle">
				<?php echo $scoreTitle; ?>
				</div>
				<?php if($showTimeTaken){ ?>
				<div class="BFTopScoreTimeTakenTitle">
				<?php echo $timeTakenTitle; ?>
				</div>
				<?php } ?>
			</div>
<?php } ?>

<?php foreach ($list as $item) : ?>
			<div class="BFTopScoreResult">
				<?php if($showRanking){ ?>
				<div class="BFTopScoreRanking">
				<?php echo $i; ?>
				</div>
				<?php } ?>
			   	<div class="<?php echo $nameClass; ?>">
				<?php echo $item->text; ?>
				</div>
				<div class="BFTopScoreScore">
				<?php echo $item->score; ?>
				</div>
				<?php if($showTimeTaken){ ?>
				<div class="BFTopScoreTimeTaken">
				<?php echo $item->TimeTaken; ?>
				</div>
				<?php } ?>
			</div>
			<?php $i++; ?>
<?php endforeach; ?>

</div>