<?php
/**
 * $Id: mod_bfquiz_topscore.php 2 2013-02-06 00:58:15Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2013 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  Mod BFQuiz Top Score is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BFQuiz Top Score is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BFQuiz Top Score.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).'/helper.php');

$document = JFactory::getDocument();
$cssFile = './modules/mod_bfquiz_topscore/css/style.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$list = modBFQuizTopScoreHelper::getList($params);

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require(JModuleHelper::getLayoutPath('mod_bfquiz_topscore'));

?>