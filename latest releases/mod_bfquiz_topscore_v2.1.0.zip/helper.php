<?php
/**
 * $Id: helper.php 2 2013-02-06 00:58:15Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com/
 * @copyright	Copyright (c) 2014 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  Mod BFQuiz Top Score is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BFQuiz Top Score is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BFQuiz Top Score.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class modBFQuizTopScoreHelper
{
	static function getList(&$params)
	{
		global $mainframe;

		$db			= JFactory::getDBO();

		$component  = trim($params->get('component'));
		$count		= intval($params->get('count', 5));
		$catid		= trim($params->get('catid'));
		$showName  = trim($params->get('showName'));

		// see if there is a random question pool
		$query = 'SELECT DISTINCT a.id, b.title, a.catid'
			. ' FROM #__bfquiz_plus_pool AS a'
			. ' INNER JOIN #__categories as b ON a.catid=b.id'
			. ' WHERE a.state = 1'
		;

		$db->setQuery( $query );
		$categoryPool = $db->loadObjectList( );

		$randomPool=0;
		foreach($categoryPool as $row){
			if($row->catid == $catid){
				$randomPool=(int)$row->id;
			}
		}

		if($randomPool){
			$table=$component.'_'.(int)$randomPool.'_pool';
		}else{
			$table=$component.'_'.(int)$catid;
		}

		if($showName=="username"){
			$query = 'SELECT *, TIMEDIFF(a.DateCompleted, a.DateReceived) as TimeTaken FROM #__'.$table.' AS a'
						. ' INNER JOIN #__users AS b ON a.uid=b.id '
						. ' ORDER by score DESC, TimeTaken'
			;
		}else{
			$query = 'SELECT *, TIMEDIFF(DateCompleted, DateReceived) as TimeTaken FROM #__'.$table
						. ' ORDER by score DESC, TimeTaken'
			;
		}

		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();

		$i		= 0;
		$lists	= array();
		if($rows){
			foreach ( $rows as $row )
			{
				$lists[$i] = new stdClass;
				if($showName=="username"){
					$lists[$i]->text = htmlspecialchars( $row->username );
				}else{
					$lists[$i]->text = htmlspecialchars( $row->Name );
				}
				$lists[$i]->score= htmlspecialchars( $row->score );
				$lists[$i]->TimeTaken= htmlspecialchars( $row->TimeTaken );
				$i++;
			}
		}

		return $lists;
	}
}
