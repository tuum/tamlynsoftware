<?php
/**
 * $Id: helper.php 4 2013-02-17 09:24:53Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  Mod BF Recent Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF Recent Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF Recent Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class modBFRecentAuctionPlusHelper
{
	public static function getList(&$params)
	{
		$app = JFactory::getApplication();

		$db		= JFactory::getDbo();

		$component  = trim($params->get('component'));
		$count		= intval($params->get('count', 5));
		$catid		= trim($params->get('catid'));
		$Itemid		= trim($params->get('Itemid'));

		$bfcurrency = JComponentHelper::getParams('com_bfauction_plus')->get('bfcurrency');

		if($catid > 0){
			$query = 'SELECT * FROM #__'.$component
						. ' WHERE state IN (1) AND catid='.(int)$catid
						. ' AND winEmailSent=0'
						. ' ORDER by date DESC'
			;
		}else{
			$query = 'SELECT * FROM #__'.$component
						. ' WHERE state IN (1)'
						. ' AND winEmailSent=0'
						. ' ORDER by date DESC'
			;
		}

		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();

		$i		= 0;
		$lists	= array();
		foreach ( $rows as $row )
		{
			$lists[$i] = new stdClass;
			$lists[$i]->text = htmlspecialchars( $row->title );
			$lists[$i]->currentBid = htmlspecialchars( $row->currentBid );
			$lists[$i]->id = htmlspecialchars( $row->id );
			$lists[$i]->link = JRoute::_('index.php?option=com_'.$component.'&task=bid&cid='.(int)$row->id.'&Itemid='.(int)$Itemid);
			$lists[$i]->currency = htmlspecialchars( $bfcurrency );

			$i++;
		}

		return $lists;
	}

}
