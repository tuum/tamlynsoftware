<?php
/**
 * $Id: default.php 5 2013-02-18 11:09:21Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  Mod BF Recent Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF Recent Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF Recent Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<div class="BFRecentAuctionPlus<?php echo $moduleclass_sfx ?>">

<?php $i=0; ?>
<?php foreach ($list as $item) : ?>
			<div class="BFRecentAuctionPlusRow">
				<div class="BFRecentAuctionPlusImage">
				<?php
				$a_pic = JPATH_SITE."/images/com_bfauction_plus/".$item->id."img1.jpg";
				if (file_exists($a_pic)){
					echo '<a href="./images/com_bfauction_plus/'.$item->id.'img1.jpg?time='.time().'"  rel="lytebox[myimages'.$i.']"><img src="./images/com_bfauction_plus/'.$item->id.'img1_t.jpg?time='.time().'" height="25"/></a>';
				}else{
					echo '&nbsp;';
				}
				?>
				</div>
			   	<div class="BFRecentAuctionPlusTitle">
			   		<a href="<?php echo $item->link; ?>">
						<?php echo $item->text; ?>
					</a>
				</div>
				<div class="BFRecentAuctionPlusCurrentBid">
				<?php echo $item->currency?><?php echo $item->currentBid; ?>
				</div>
			</div>
			<?php $i++; ?>
<?php endforeach; ?>

</div>