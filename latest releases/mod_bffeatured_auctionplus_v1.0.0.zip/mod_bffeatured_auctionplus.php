<?php
/**
 * $Id: mod_bffeatured_auctionplus.php 2 2013-02-15 03:49:53Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  Mod BF Featured Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF Featured Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF Featured Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).'/helper.php');

$document = JFactory::getDocument();
$cssFile = './modules/mod_bffeatured_auctionplus/css/style.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$list = modBFFeaturedAuctionPlusHelper::getList($params);
require(JModuleHelper::getLayoutPath('mod_bffeatured_auctionplus'));

?>