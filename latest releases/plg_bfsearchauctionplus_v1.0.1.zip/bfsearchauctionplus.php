<?php
/**
 * $Id: bfsearch_auctionplus.php 1 2011-03-08 02:17:11Z  $
 * Search Plugin for BF Auction Plus Component
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2010 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF Search Auction Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Search Auction Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Search Auction Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * BF Auction Plus Search plugin
 *
 * @package		Joomla.Plugin
 * @subpackage	Search.weblinks
 * @since		1.6
 */
class plgSearchBFSearchAuctionPlus extends JPlugin
{
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	/**
	 * @return array An array of search areas
	 */
	function onContentSearchAreas() {
		static $areas = array(
			'bfauctionplus' => 'BF Auction Plus'
			);
			return $areas;
	}

	/**
	 * BF Auction Plus Search method
	 *
	 * The sql must return the following fields that are used in a common display
	 * routine: href, title, section, created, text, browsernav
	 * @param string Target search string
	 * @param string mathcing option, exact|any|all
	 * @param string ordering option, newest|oldest|popular|alpha|category
	 * @param mixed An array if the search it to be restricted to areas, null if search all
	 */
	function onContentSearch($text, $phrase='', $ordering='', $areas=null)
	{
		$db		= JFactory::getDbo();
		$app	= JFactory::getApplication();
		$user	= JFactory::getUser();
		$groups	= implode(',', $user->getAuthorisedViewLevels());

		$searchText = $text;

		if (is_array($areas)) {
			if (!array_intersect($areas, array_keys($this->onContentSearchAreas()))) {
				return array();
			}
		}

		$sContent		= $this->params->get('search_content',		1);
		$sArchived		= $this->params->get('search_archived',		1);
		$limit			= $this->params->def('search_limit',		50);

		$Itemid 		= $this->params->def( 'Itemid', "" );
		$component 		= $this->params->def( 'component', "bfauction_pro" );

		$state = array();
		if ($sContent) {
			$state[]=1;
		}
		if ($sArchived) {
			$state[]=2;
		}

		$text = trim($text);
		if ($text == '') {
			return array();
		}
		$section	= JText::_('PLG_SEARCH_BFAUCTION_PLUS');

		$wheres	= array();
		switch ($phrase)
		{
			case 'exact':
				$text		= $db->Quote('%'.$db->escape($text, true).'%', false);
				$wheres2	= array();
				$wheres2[]	= 'a.description LIKE '.$text;
				$wheres2[]	= 'LOWER(a.title) LIKE '.$text;
				$where		= '(' . implode(') OR (', $wheres2) . ')';
				break;

			case 'all':
			case 'any':
			default:
				$words	= explode(' ', $text);
				$wheres = array();
				foreach ($words as $word)
				{
					$word		= $db->Quote('%'.$db->escape($word, true).'%', false);
					$wheres2	= array();
					$wheres2[]	= 'a.description LIKE '.$word;
					$wheres2[]	= 'LOWER(a.title) LIKE '.$word;
					$wheres[]	= implode(' OR ', $wheres2);
				}
				$where	= '(' . implode(($phrase == 'all' ? ') AND (' : ') OR ('), $wheres) . ')';
				break;
		}

		switch ($ordering)
		{
			case 'oldest':
				$order = $db->quoteName('date') . ' ASC';
				break;

			case 'alpha':
				$order = 'a.title ASC';
				break;

			case 'category':
				$order = $db->quoteName('catid') . ' ASC';
				break;

			//newest first
			case 'newest':
				$order = $db->quoteName('endDate') . ' DESC';
	            break;

			case 'popular':

			default:
				$order = 'a.title ASC';
		}

		if($component == "bfauction_plus"){
			$searchBFSearch_AuctionPlus = JText::_( 'BF Auction Plus' );
		}else{
			$searchBFSearch_AuctionPlus = JText::_( 'BF Auction PlusTrial' );
		}

		$return = array();
		if (!empty($state)) {
			$query	= $db->getQuery(true);
			$query->select('a.title AS title, a.date, a.id, a.date AS created, c.extension_id AS componentid, a.description, '
						.'CONCAT_WS(" / ", '.$db->Quote($searchBFSearch_AuctionPlus).', b.title) AS section, "1" AS browsernav');
			$query->from('#__'.$component.' AS a');
			$query->innerJoin('#__categories AS b ON b.id = a.catid');
			$query->innerJoin('#__extensions AS c ON c.element="com_'.$component.'"');
			$query->where('('.$where.')' . ' AND a.state in ('.implode(',',$state).') AND  b.published=1');
			$query->order($order);

			// Filter by language
			if ($app->isSite() && $app->getLanguageFilter()) {
				$tag = JFactory::getLanguage()->getTag();
				$query->where('a.language in (' . $db->Quote($tag) . ',' . $db->Quote('*') . ')');
			}

			$db->setQuery($query, 0, $limit);
			$rows = $db->loadObjectList();

			$return = array();
			if ($rows) {
				foreach($rows as $key => $row) {
					$mnu = array();
					if($Itemid == ""){
						//get the first BF Auction Pro menu item and use the Itemid for parameters.
						$query->clear();
						$query->select('*');
						$query->from('#__menu');
						$query->where('component_id='.(int)$row->componentid.' LIMIT 1');

						$db->setQuery($query, 0);
						$mnu = $db->loadObjectList();
						$mnu[0]->Itemid = $mnu[0]->id;
					}else{
						$mnu[0]->Itemid = $Itemid;
					}

					$rows[$key]->href = 'index.php?option=com_'.$component.'&task=bid&cid='.(int)$row->id.'&Itemid='.(int)$mnu[0]->Itemid;
				}
			}
		}
		return $rows;
	}
}