<?php
/**
 *  @package BF Auction
 *  @copyright Copyright (c)2016 Tamlyn Software
 *  @license GNU General Public License version 3, or later
 *  @version $Id$
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class BfauctionTableLog extends F0FTable
{
	function __construct( $table, $key, &$db )
	{
		$table = '#__bfauction_logs';
		$key = 'bfauction_log_id';
		parent::__construct($table, $key, $db);
	}
}