<?php

defined('_JEXEC') or die();

class BfauctionModelPayment extends F0FModel
{
	public function getItemByOrderId($orderId)
	{
		$user = JFactory::getUser();
		$user_name = $user->username;

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__bfauction_items');
		$query->where('orderId='.$orderId);
		$query->where("highBidder='$user_name'");
		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();
		if (empty($rows) || $db->getErrorNum()) {
			return false;
		} else {
			return $rows[0];
		}
	}

	public function updateOrder($data)
	{
		$now = JFactory::getDate()->toSql();

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__bfauction_items');
		$query->set("orderStatus='{$data['orderStatus']}'");
		$query->set("orderDate='$now'");
		$query->set("txnId='{$data['txnId']}'");
		$query->set("totalAmount=".$data['totalAmount']);
		$query->set("buyerEmail='{$data['buyerEmail']}'");
		$query->set("rawData='{$data['rawData']}'");
		$query->where('orderId=' . (int)$data['orderId']);
		$db->setQuery((string)$query);
		$db->query();
		if ($db->getErrorNum()) {
			return false;
		}
	}


}