<?php
/*
 * @package bfauction
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 * @link http://www.tamlynsoftware.com
 *
 *	  BF Auction is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    BF Auction is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Auction.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * Author's notes: When GNU speaks of free software, it is referring to freedom, not price.
 * We encourage you to purchase your copy of BF Auction from the developer (Tamlyn Software),
 * so that we can continue to make this product better and continue to provide a high quality of support.
 *
 */
defined('_JEXEC') or die();

// Load FOF if not already loaded
if (!defined('F0F_INCLUDED'))
{
	$paths = array(
			(defined('JPATH_LIBRARIES') ? JPATH_LIBRARIES : JPATH_ROOT . '/libraries') . '/f0f/include.php',
			__DIR__ . '/fof/include.php',
	);

	foreach ($paths as $filePath)
	{
		if (!defined('F0F_INCLUDED') && file_exists($filePath))
		{
			@include_once $filePath;
		}
	}
}

// Pre-load the installer script class from our own copy of FOF
if (!class_exists('F0FUtilsInstallscript', false))
{
	@include_once __DIR__ . '/fof/utils/installscript/installscript.php';
}

// Pre-load the database schema installer class from our own copy of FOF
if (!class_exists('F0FDatabaseInstaller', false))
{
	@include_once __DIR__ . '/fof/database/installer.php';
}

// Pre-load the update utility class from our own copy of FOF
if (!class_exists('F0FUtilsUpdate', false))
{
	@include_once __DIR__ . '/fof/utils/update/update.php';
}

// Pre-load the cache cleaner utility class from our own copy of FOF
if (!class_exists('F0FUtilsCacheCleaner', false))
{
	@include_once __DIR__ . '/fof/utils/cache/cleaner.php';
}

class Com_BfauctionInstallerScript extends F0FUtilsInstallscript
{
	/**
	 * The title of the component (printed on installation and uninstallation messages)
	 *
	 * @var string
	 */
	protected $componentTitle = 'BF Auction';

	/**
	 * The component's name
	 *
	 * @var   string
	 */
	protected $componentName = 'com_bfauction';

	/**
	 * The list of extra modules and plugins to install on component installation / update and remove on component
	 * uninstallation.
	 *
	 * @var   array
	 */
	protected $installation_queue = array
	(
			'plugins' => array(
					'user' => array(
							'bfauctionuserlogs' => 1,
					),
					'payment' => array(
							'paypal' => 1,
							'cod' => 1,
					),
			),
	);

	/**
	 * Runs after install, update or discover_update
	 * @param string $type install, update or discover_update
	 * @param JInstaller $parent
	 */
	function postflight($type, $parent)
	{
		parent::postflight($type, $parent);

		jimport( 'joomla.filesystem.file' );

		// define the following parameters only if it is an original install
        if ( $type == 'install' ) {
                $params['showDisclaimer'] = '0';
                $params['allowEmail'] = '1';
				$params['bfcurrency'] = '$';
				$params['bfcurrency_code'] = 'USD';
				$params['dateFormat'] = 'd-m-Y H:i';
				$params['bidIncrement'] = '1';
				$params['dst'] = '0';
				$params['reverseAuction'] = '0';
				$params['ownBidsOnly'] = '0';
				$params['hideBid'] = '1';
				$params['increaseEndTime'] = '0';
				$params['increaseEndTimeLastMinutes'] = '5';
				$params['increaseEndTimeAmount'] = '5';
				$params['includeCommission'] = '0';
				$params['commissionAmount'] = '15';
				$params['includeCommission'] = '0';
				$params['includeTax'] = '0';
				$params['taxAmount'] = '10';
				$params['showTotalPrice'] = '0';
				$params['mainImageSize'] = '200';
				$params['max_width'] = '250';
				$params['max_height'] = '250';
				$params['max_width_t'] = '90';
				$params['max_height_t'] = '90';
				$params['max_image_size'] = '2048000';

				$this->setParams( $params );
        }

		if(!file_exists(JPATH_SITE . "/images/com_bfauction/")){
			JFolder::create(JPATH_SITE. "/images/com_bfauction/");
		};

		if(!file_exists(JPATH_SITE. "/images/com_bfauction/index.html")){
			JFile::copy(JPATH_SITE."/components/com_bfauction/index.html",JPATH_SITE. "/images/com_bfauction/index.html");
		};

		//content history feature was added in Joomla 3.2
		if (version_compare(JVERSION, '3.1.6', 'gt'))
		{
			$table = JTable::getInstance('Contenttype', 'JTable');
					if(!$table->load(array('type_alias' => 'com_bfauction.question')))
			{
				$common = new stdClass;
				$common->core_content_item_id = 'bfauction_item_id';
				$common->core_title = 'title';
				$common->core_state = 'enabled';
				$common->core_alias = 'slug';
				$common->core_created_time = 'created_on';
				$common->core_modified_time = 'modified_on';
				//$common->core_access = 'access';
				$common->core_ordering = 'ordering';
				$common->core_catid = 'bfauction_category_id';
				$common->asset_id = null;
				$field_mappings = new stdClass;
				$field_mappings->common[] = $common;
				$field_mappings->special = array();
				$special = new stdClass;
				$special->dbtable = '#__bfauction_items';
				$special->key = 'bfauction_item_id';
				$special->type = 'MyItem';
				$special->prefix = 'BFAuctionTable';
				$special->config = 'array()';
				$table_object = new stdClass;
				$table_object->special = $special;
				$contenttype['type_title'] = 'BFAuction';
				$contenttype['type_alias'] = 'com_bfauction.item';
				$contenttype['table'] = json_encode($table_object);
				$contenttype['rules'] = '';
				$contenttype['router'] = 'BFAuctionHelperRoute::getBFAuctionRoute';
				$contenttype['field_mappings'] = json_encode($field_mappings);
				$contenttype['formFile'] = 'administrator\\/components\\/com_bfauction\\/views\\/item\\/tmpl\\/form.form.xml';
				$contenttype['hideFields'] = '["locked_by","locked_on"]';
				$contenttype['ignoreChanges'] = '["modified_by", "modified_on", "locked_by","locked_on"]';
				$contenttype['convertToInt'] = '["ordering"]';
				$contenttype['displayLookup'] = '[{"sourceColumn":"bfauction_category_id","targetTable":"#__bfauction_categories","targetColumn":"bfauction_category_id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]';

				$table->save($contenttype);
			}
		}
	}

	function setParams($param_array) {
            if ( count($param_array) > 0 ) {
                    // read the existing component value(s)
                    $db = JFactory::getDbo();
                    $db->setQuery('SELECT params FROM #__extensions WHERE name = "com_bfauction"');
                    $params = json_decode( $db->loadResult(), true );
                    // add the new variable(s) to the existing one(s)
                    foreach ( $param_array as $name => $value ) {
                            $params[ (string) $name ] = (string) $value;
                    }
                    // store the combined new and existing values back as a JSON string
                    $paramsString = json_encode( $params );
                    $db->setQuery('UPDATE #__extensions SET params = ' .
                            $db->quote( $paramsString ) .
                            ' WHERE name = "com_bfauction"' );
                            $db->query();
            }
    }

	/**
	 * Renders the post-installation message
	 */
	private function _renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent)
	{
		?>
		<img src="../media/com_bfauction/images/bfauction-48.png" width="48" height="48" alt="BF Auction" align="right"/>

		<h2>Welcome to BF Auction!</h2>

		<?php
		parent::renderPostInstallation($status, $fofInstallationStatus, $strapperInstallationStatus, $parent);
		?>

		<?php
	}
}