<?php
/**
 *  @package	Slick Slider
 *  @copyright	Copyright (c)2016 Tim Plummer / TamlynSoftware.com
 *  @license	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Slick Slider is a third party JQuery library developed by Ken Wheeler
 *  http://kenwheeler.github.io/slick
 *  Copyright (c) 2014 Ken Wheeler
 *  Licensed under the MIT license.
 */

// no direct access
defined('_JEXEC') or die('');

JHtml::_('jquery.framework');

$document = JFactory::getDocument();

$cssFile = JURI::base().'media/mod_slick/css/slick.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/slick-theme.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$cssFile = JURI::base().'media/mod_slick/css/style.css';
$document->addStyleSheet($cssFile, 'text/css', null, array());

$document->addScript(JURI::base().'media/mod_slick/js/slick.min.js' );

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

/*------------------------- For updates ------------------------------- */

	$dlid = $params->get('downloadid', '');

	if (!empty($dlid)){
		$extra_query = "'dlid=$dlid'";

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
		->update('#__update_sites')
		->set('extra_query = '.$extra_query)
		->where('name = "Slick Slider"');
		$db->setQuery($query);
		$db->execute();
	}

/*------------------------- End For updates ------------------------------- */

$images = array();


/* ---- JSON loading --- */
$jsondatasource = $params->get('jsondatasource', '');
$jsonimage = $params->get('jsonimage', '');
$jsontitle = $params->get('jsontitle', '');
$jsonurl = $params->get('jsonurl', '');

if($jsondatasource != ''){
	$json = file_get_contents($jsondatasource);
	$obj = json_decode($json);

	$i = 0;
	foreach ($obj as $image) {
		$i++;
		$images[$i]['img'] 	 = $image->$jsonimage;
		$images[$i]['title'] = $image->$jsontitle;
		$images[$i]['url']   = $image->$jsonurl;
		$images[$i]['text']   = '';
	};
}
/* ------------ end JSON loading -------- */

$imageFolder = $params->get('imageFolder', '');
$urlPath = "images/$imageFolder";
$dir = JPATH_BASE."/$urlPath/";
if (is_dir($dir)) {
	$i = 0;
	foreach (glob("$dir/*") as $image) {
		$i++;
		$images[$i]['img'] 	 = "$urlPath/".basename($image);
		$images[$i]['title'] = '';
		$images[$i]['url']   = '';
		$images[$i]['text']   = '';
	};
} else if ($jsondatasource == '') {
	for ($i = 1; $i <= 10; $i++) {
		$images[$i]['img']   = htmlspecialchars($params->get("image{$i}", ''));
		$images[$i]['title'] = htmlspecialchars($params->get("image{$i}title", ''));
		$images[$i]['url']   = htmlspecialchars($params->get("image{$i}url", ''));
		$images[$i]['text']   = htmlspecialchars($params->get("image{$i}text", ''));
	}
}
$target = $params->get('linksNewWindow', '');
if ($target) {
	$target = 'target="_blank"';
}

$arrowSize  = (string) $params->get('arrowSize', 60);
$arrowColor = $params->get('arrowColor', '#fff');

$document->addStyleDeclaration("
	.slick-prev::before, .slick-next::before {
		font-size: {$arrowSize}px;
		color: $arrowColor;
}");

$showArrows 	= $params->get('arrows', false) ? 'true' : 'false';
$fade 			= $params->get('fade', false) ? 'true' : 'false';
$fadeSpeed  	= (string) $params->get('fadeSpeed', '500');
$autoPlay 		= $params->get('autoplay', false) ? 'true' : 'false';
$autoPlaySpeed	= (string) $params->get('autoplaySpeed', 2000);
$showDots 		= $params->get('showDots', false) ? 'true' : 'false';
$showCaptions	= $params->get('showCaptions', false);
$infinite		= (string) $params->get('infinite', false) ? 'true' : 'false';
$swipe			= (string) $params->get('touchMove', false) ? 'true' : 'false';
// centerMode will remove the border
$centerMode		= $params->get('centerMode') ? 'true' : 'false';
$slidesToShow	= (string) $params->get('slidesToShow', 3);
$slidesToScroll = (string) $params->get('slidesToScroll', 3);
$pauseOnHover   = $params->get('pauseOnHover', true) ? 'true' : 'false';
$adaptiveHeight	= $params->get('adaptiveHeight', true) ? 'true' : 'false';
$fitImages		= $params->get('fitImages', true) ? 'true' : 'false';
$variableWidth  = intval($slidesToShow) > 1 ? 'true' : 'false';
$showArrowOnHover = $params->get('showArrowOnHover', false) ? 'show-arrow-on-hover' : '';

$textbackground = $params->get('textBackgroundColour', '#2d2d35');
$textColour = $params->get('textColour', '#fff');
$textheight = $params->get('textHeight', '250');
$textPaddingTop = $params->get('textPaddingTop', '15');
$textPaddingLeft = $params->get('textPaddingLeft', '15');
$textPaddingRight = $params->get('textPaddingRight', '15');

if ($slidesToShow <= 1) {
	$slidesToShow = 1;
	$slidesToScroll = 1;
}

$breakpoint1				= (string) $params->get('breakpoint1', 1024);
$slidesToShowBreakpoint1 	= (string) $params->get('slidesToShowBreakpoint1', 3);
$slidesToScrollBreakpoint1 	= (string) $params->get('slidesToScrollBreakpoint1', 3);

$breakpoint2				= (string) $params->get('breakpoint2', 600);
$slidesToShowBreakpoint2 	= (string) $params->get('slidesToShowBreakpoint2', 3);
$slidesToScrollBreakpoint2 	= (string) $params->get('slidesToScrollBreakpoint2', 3);

$breakpoint3				= (string) $params->get('breakpoint3', 480);
$slidesToShowBreakpoint3 	= (string) $params->get('slidesToShowBreakpoint3', 3);
$slidesToScrollBreakpoint3 	= (string) $params->get('slidesToScrollBreakpoint3', 3);


$random = rand();

$document->addScriptDeclaration(<<< JS

	jQuery(document).ready(function() {

		settings$random = {
			speed: 250,
			draggable: true,
			infinite: $infinite,
			swipe: $swipe,
			arrows: $showArrows,
			pauseOnHover: $pauseOnHover,
			dots: $showDots,
			centerMode: $centerMode,
			slidesToShow: $slidesToShow,
			slidesToScroll: $slidesToScroll,
			responsive: [
			  {
				  breakpoint: $breakpoint1,
			      settings: {
			        slidesToShow: $slidesToShowBreakpoint1,
			        slidesToScroll: $slidesToScrollBreakpoint1,
			      }
			    },
			    {
			      breakpoint: $breakpoint2,
			      settings: {
			        slidesToShow: $slidesToShowBreakpoint2,
			        slidesToScroll: $slidesToScrollBreakpoint2
			      }
			    },
			    {
			      breakpoint: $breakpoint3,
			      settings: {
			        slidesToShow: $slidesToShowBreakpoint3,
			        slidesToScroll: $slidesToScrollBreakpoint3
			    }
			   }
			]
		}

		if ($adaptiveHeight) {
			settings$random.adaptiveHeight = true;
			settings$random.variableWidth = false;
		} else {
			if ($fitImages) {
				settings$random.variableWidth = false;
			} else {
				settings$random.variableWidth = $variableWidth;
			}
		}

		if ($autoPlay) {
			settings$random.autoplay = true;
			settings$random.autoplaySpeed = $autoPlaySpeed;
		}

		if ($fade && $slidesToShow < 2) {
			settings$random.fade = true;
			settings$random.speed = $fadeSpeed;
			settings$random.cssEase = 'linear';
		}

		jQuery('.slide-container$random').slick(settings$random);

		caption = jQuery('.caption').css('margin-top');
		if (caption !== undefined) {
			jQuery('.slick-arrow').css('margin-top', "-" + caption);
		}

	});
JS
);
?>

<div class="slick<?php echo $moduleclass_sfx ?>">

	<div align='center' class='slide-container<?php echo $random; ?> <?php echo $showArrowOnHover ?>' >

		<?php
		for ($i = 1; $i <= 10; $i++) {
			if (!isset($images[$i]['img']) && !isset($images[$i]['text']) ) {
				continue;
			}
			$img   = $images[$i]['img'];
			$title = $images[$i]['title'];
			$url   = $images[$i]['url'];
			$text  = $images[$i]['text'];

			$caption = '';

			if ($showCaptions) {
				$caption = "<div class='caption'>{$title}</div>";
			}
			if ($url && $img) {
				echo "<div><a href='{$url}' {$target}><img src='{$img}' alt='{$title}' title='{$title}' /></a>{$caption}</div>";
			} else if ($img) {
				echo "<div><img src='{$img}' alt='{$title}' title='{$title}' /></div>";
			} else if ($text) {
				echo "<div style=\"background:{$textbackground}; color:{$textColour}; min-height:{$textheight}px; padding-top:{$textPaddingTop}px; padding-left:{$textPaddingLeft}px; padding-right:{$textPaddingRight}px\">".htmlspecialchars_decode($text)."</div>";
			}
		}
		?>

	</div>

</div>
