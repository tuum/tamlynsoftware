<?php
/**
 * $Id: install.php 2 2012-11-18 05:18:56Z tuum $
 * BF User log Plus Plugin for Joomla
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2012 - Tamlyn Creative Pty Ltd.
 * @license		GNU GPL
 *
 *	  BF User Log Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF User Log Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF User Log Plus.  If not, see <http://www.gnu.org/licenses/>.
 */

// No direct access
defined('_JEXEC') or die;

class plgbfuserlog_plusInstallerScript
{
	/**
	 * Post-flight extension installer method.
	 *
	 * This method runs after all other installation code.
	 *
	 * @param	$type
	 * @param	$parent
	 *
	 * @return	void
	 */
	function postflight($type, $parent)
	{
		?>
		<p><big><strong>BF User Log Plus</strong> version %s has been successfully installed for the first time or upgraded.</big></p>
		<?php
	}
}

?>