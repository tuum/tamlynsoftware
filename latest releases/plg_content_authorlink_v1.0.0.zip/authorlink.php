<?php
/**
 * plg_content_authorlink
 *
 * @package    Joomla
 * @subpackage Components
 * @link http://www.timplummer.com.au
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU GPL
 *
 *	  Author Link Plugin is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as state by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Author Link Plugin is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Author Link Plugin.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plgContentAuthorlink extends JPlugin
{
	function plgContentAuthorlink( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	public function onContentPrepare($context, &$row, &$params, $page = 0)
	{
		// Do not run this plugin when the content is being indexed
		if ($context == 'com_finder.indexer')
		{
			return true;
		}

		if (is_object($row))
		{
			return $this->_authorLink($row->author, $params);
		}
		return $this->_authorLink($row, $params);
	}

	protected function _authorLink(&$author, &$params)
	{
		$url		= $this->params->get('url');

		$replacement =	'<span itemprop="author" itemscope="" itemtype="http://schema.org/Person">'
							.'<span itemprop="name">'
								.'<a href="'.$url.'?rel=author" itemprop="url">'.$author.'</a>'
		    				.'</span>'
        				.'</span>';

		$author = $replacement;

        return true;
	}
}