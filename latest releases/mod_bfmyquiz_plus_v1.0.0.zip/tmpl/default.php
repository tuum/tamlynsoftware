<?php
/**
 * $Id: default.php 4 2012-09-23 04:42:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright c 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  Mod BF My Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF My Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF My Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die;
$showHeading = trim($params->get('showHeading'));
$showProgress = trim($params->get('showProgress'));
$showActions = trim($params->get('showActions'));

$nameTitle = trim($params->get('nameTitle'));
$progressTitle = trim($params->get('progressTitle'));
$actionsTitle = trim($params->get('actionsTitle'));
$scoreTitle = trim($params->get('scoreTitle'));
$totalTitle = trim($params->get('totalTitle'));
$i=1;

//adjust width of Name if columns are hidden
$nameClass="BFMyQuizPlusName";  // default, all columns are shown

$user	= JFactory::getUser();
if($user->id == 0){
	$joomlaLoginUrl = 'index.php?option=com_users&view=login';
    $finalUrl = $joomlaLoginUrl;

	echo "<br><a href='".$finalUrl."'>".JText::_( 'log in')."</a><br>";
}else{
?>

<?php if($showHeading){ ?>
			<div class="BFMyQuizPlusResultTitle">
			   	<div class="BFMyQuizPlusNameTitle">
					<?php echo $nameTitle; ?>
				</div>
				<?php if($showProgress){ ?>
				<div class="BFMyQuizPlusProgressTitle">
					<?php echo $progressTitle; ?>
				</div>
				<?php } ?>
				<?php if($showActions){ ?>
				<div class="BFMyQuizPlusActionsTitle">
					<?php echo $actionsTitle; ?>
				</div>
				<?php } ?>
				<div class="BFMyQuizPlusScoreTitle">
					<?php echo $scoreTitle; ?>
				</div>
			</div>
<?php } ?>

<?php foreach ($list as $item) : ?>
			<div class="BFMyQuizPlusResult">
			   	<div class="BFMyQuizPlusName">
					<?php echo $item->text; ?>
				</div>
				<?php if($showProgress){ ?>
				<?php
				$progressClass="BFMyQuizPlusProgress";
				if($item->progress == "Completed"){
					$progressClass="BFMyQuizPlusProgress1";
				}else if($item->progress == "In Progress"){
					$progressClass="BFMyQuizPlusProgress2";
				}else if($item->progress == "Not Started"){
					$progressClass="BFMyQuizPlusProgress3";
				}
				?>
				<div class="<?php echo $progressClass; ?>">
					<?php echo $item->progress; ?>
				</div>
				<?php } ?>
				<?php if($showActions){ ?>
				<div class="BFMyQuizPlusActions">
					<?php if($item->url != ""){ ?>
						<a href="<?php echo $item->url; ?>">
					<?php }	?>
					<?php echo $item->actions; ?>
					<?php if($item->url != ""){ ?>
						</a>
					<?php }	?>
				</div>
				<?php } ?>
				<div class="BFMyQuizPlusScore">
					<?php echo $item->score; ?>
				</div>
			</div>
			<?php $i++; ?>
<?php endforeach; ?>

<div class="BFMyQuizPlusResult">
	<div class="BFMyQuizPlusTotalTitle">
		<?php echo $totalTitle; ?>
		<?php echo "&nbsp;" ?>
		<?php echo "&nbsp;" ?>
	</div>
	<div class="BFMyQuizPlusTotal">
		<?php echo $list[0]->totalScore; ?>
	</div>
</div>
<div class="clr"></div>

<?php } ?>