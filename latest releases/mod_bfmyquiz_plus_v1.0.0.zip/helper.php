<?php
/**
 * $Id: helper.php 5 2012-11-15 00:31:39Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright c 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  Mod BF My Quiz Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF My Quiz Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF My Quiz Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// no direct access
defined('_JEXEC') or die;

class modBFMyQuizPlusHelper
{
	static function getList(&$params)
	{
	    $db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
   		$app = JFactory::getApplication();
   		$dbtype = $app->getCfg('dbtype');
   		$user	= JFactory::getUser();

		//get all quiz category id numbers
		$query->from($db->quoteName('#__categories'));
		$query->select('id,  title');
		$query->where('extension = "com_bfquiz_plus"');

		$db->setQuery((string)$query);
		$rows = $db->loadObjectList();

		$query->clear();

		$component  = trim($params->get('component'));

		//get the component id for BF Quiz Plus
		$query->from($db->quoteName('#__extensions'));
		$query->select('extension_id');
		$query->where('element = "com_'.$component.'"');
		$db->setQuery((string)$query);
		$myrow = $db->loadObjectList();

		$component_id = $myrow[0]->extension_id;
		$query->clear();

		$totalScore = 0;
		$i=0;
		if($rows){
			foreach ( $rows as $row )
			{
				$mytable = preg_replace('/_/', '' , $component);
				$table='#__'.$mytable.'_'.(int)$row->id;

				//get the menu item details for this quiz
				//assume first one is the one we want
				$query->clear();
				$query->from($db->quoteName('#__menu'));
				$query->select('id, link');
				$query->where('component_id = '.$component_id);
				$query->where("link LIKE '%catid=".(int)$row->id."%'");
				$query->where("link NOT LIKE '%view=myquizzes%'");
				$db->setQuery((string)$query, 0, 1);
				$mymenu = $db->loadObjectList();
				$query->clear();

				$query	= $db->getQuery(true);
				//get the most recent instance of the quiz for that user
				$query->from($db->quoteName($table));
				$query->select('id, score');
				$query->where('uid = '.$user->id);
				$query->order('id DESC');

				$db->setQuery((string)$query, 0, 1);  //limit 1
				$rows2 = $db->loadObjectList();

				if($rows2){
					$rows[$i]->progress="Completed";
					$rows[$i]->actions="View/Edit Responses";
					$rows[$i]->score=$rows2[0]->score;
					$totalScore = $totalScore + (int)$rows2[0]->score;
					if($mymenu){
						$rows[$i]->url="index.php?option=com_".trim(strtolower($component))."&view=edit&id=".$rows2[0]->id."&catid=".(int)$row->id."&Itemid=".$mymenu[0]->id;
					}else{
						$rows[$i]->url="";  // there is no menu item defined for this quiz.
					}
				}else{
					//user hasn't taken this quiz yet
					$rows[$i]->progress="Not Started";
					$rows[$i]->actions="Get Started";
					$rows[$i]->score="N/A";
					if($mymenu){
						$rows[$i]->url=$mymenu[0]->link."&Itemid=".$mymenu[0]->id;
					}else{
						$rows[$i]->url="";  // there is no menu item defined for this quiz.
					}
				}
				$i++;
			}
		}

		$i		= 0;
		$lists	= array();
		if($rows){
			foreach ( $rows as $row )
			{
				$lists[$i]->text= htmlspecialchars( $row->title );
				$lists[$i]->progress= htmlspecialchars( $row->progress );
				$lists[$i]->actions= htmlspecialchars( $row->actions );
				$lists[$i]->score= htmlspecialchars( $row->score );
				$lists[$i]->url= htmlspecialchars( $row->url );
				$i++;
			}
		}
		$lists[0]->totalScore= htmlspecialchars( $totalScore );

		return $lists;
	}
}
