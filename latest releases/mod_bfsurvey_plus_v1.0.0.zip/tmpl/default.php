<?php
/**
 * $Id: default.php 4 2012-09-23 04:42:40Z tuum $
 *
 * @package    Joomla
 * @subpackage Modules
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright c 2014 - Tamlyn Software.
 * @license		GNU GPL
 *
 *	  Mod BF Survey Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Mod BF Survey Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Mod BF Survey Plus.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

defined('_JEXEC') or die;
$showHeading = trim($params->get('showHeading'));
$showProgress = trim($params->get('showProgress'));
$showActions = trim($params->get('showActions'));

$nameTitle = trim($params->get('nameTitle'));
$progressTitle = trim($params->get('progressTitle'));
$actionsTitle = trim($params->get('actionsTitle'));
$i=1;

$user	= JFactory::getUser();

//adjust width of Name if columns are hidden
$nameClass="BFSurveyPlusName";  // default, all columns are shown
?>
<?php if($showHeading){ ?>
			<div class="BFSurveyPlusResultTitle">
			   	<div class="<?php echo ($user->id == 0) ? 'BFSurveyPlusNameTitle99' : 'BFSurveyPlusNameTitle';?>">
					<?php echo $nameTitle; ?>
				</div>
				<?php if($showProgress && $user->id != 0){ ?>
				<div class="BFSurveyPlusProgressTitle">
					<?php echo $progressTitle; ?>
				</div>
				<?php } ?>
				<?php if($showActions && $user->id != 0){ ?>
				<div class="BFSurveyPlusActionsTitle">
					<?php echo $actionsTitle; ?>
				</div>
				<?php } ?>
			</div>
<?php } ?>

<?php foreach ($list as $item) : ?>
			<div class="BFSurveyPlusResult">
			   	<div class="<?php echo ($user->id == 0) ? 'BFSurveyPlusName99' : 'BFSurveyPlusName';?>">
			   		<?php if($user->id == 0){ ?>
						<a href="<?php echo $item->url; ?>">
							<?php echo $item->text; ?>
						</a>
					<?php }else{ ?>
						<?php echo $item->text; ?>
					<?php } ?>
				</div>
				<?php if($showProgress && $user->id != 0){ ?>
				<?php
				$progressClass="BFSurveyPlusProgress";
				if($item->progress == "Completed"){
					$progressClass="BFSurveyPlusProgress1";
				}else if($item->progress == "In Progress"){
					$progressClass="BFSurveyPlusProgress2";
				}else if($item->progress == "Not Started"){
					$progressClass="BFSurveyPlusProgress3";
				}
				?>
				<div class="<?php echo $progressClass; ?>">
					<?php echo $item->progress; ?>
				</div>
				<?php } ?>
				<?php if($showActions && $user->id != 0){ ?>
				<div class="BFSurveyPlusActions">
					<?php if($item->url != ""){ ?>
						<a href="<?php echo $item->url; ?>">
					<?php }	?>
					<?php echo $item->actions; ?>
					<?php if($item->url != ""){ ?>
						</a>
					<?php }	?>
				</div>
				<?php } ?>
			</div>
			<?php $i++; ?>
			<div class="clr"></div>
<?php endforeach; ?>

<div class="clr"></div>