<?php
/*
 * @package BF SEO
* @copyright Copyright (c)2016 Tamlyn Software
* @license GNU General Public License version 2 or later
*/
defined('_JEXEC') or die();

class BfseoViewCustom404 extends F0FViewHtml
{
	protected function onAdd($tpl = null)
	{
		$model = $this->getModel();

		$lang = JFactory::getLanguage()->getDefault();

		$this->items = $model->getItems($lang);

		$this->ordering              = $model->checkOrdering();

		return true;
	}
}
