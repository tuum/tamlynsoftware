<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

JHtml::_('behavior.formvalidation');
JHtml::_('behavior.modal');

if (version_compare(JVERSION, '3.0', 'ge')) {
	JHTML::_('behavior.framework');
} else {
	JHTML::_('behavior.mootools');
}

F0FTemplateUtils::addCSS('media://com_bfseo/css/backend.css');
F0FTemplateUtils::addJS('media://com_bfseo/js/checkmeta.js');

$input = JFactory::getApplication()->input;
$options = JComponentHelper::getParams('com_bfseo');
$minDescLength = $options->get('minDescLength', 6);
$maxDescLength = $options->get('maxDescLength', 160);
$minWarningText = $options->get('minWarningText', 'Too short');
$maxWarningText = $options->get('maxWarningText', 'Too long');

?>

<div class="row">
	<form id="adminForm" name="adminForm" method="post" action="<?php echo JRoute::_('index.php?option=com_bfseo') ?>">
		<div class="row">
			<div class="span8" style='margin-left: 50px'><?php echo bfseoHelper::createDropDown($input->get('view')); ?></div>
			<div class="span1" style='margin-left: -50px'">
				<select id="list_limit" name="listlimit" class="input-mini" onchange="this.form.submit()">
					<?php $selected = 'selected="selected"' ?>
					<option value="5"  <?php if ($this->listlimit == 5) echo $selected ?>>5</option>
					<option value="10" <?php if ($this->listlimit == 10) echo $selected ?>>10</option>
					<option value="15" <?php if ($this->listlimit == 15) echo $selected ?>>15</option>
					<option value="20" <?php if ($this->listlimit == 20) echo $selected ?>>20</option>
					<option value="25" <?php if ($this->listlimit == 25) echo $selected ?>>25</option>
					<option value="30" <?php if ($this->listlimit == 30) echo $selected ?>>30</option>
					<option value="50" <?php if ($this->listlimit == 50) echo $selected ?>>50</option>
					<option value="100" <?php if ($this->listlimit == 100) echo $selected ?>>100</option>
					<option value="0" <?php if ($this->listlimit == 0) echo $selected ?>>All</option>
				</select>
			</div>
		</div>
		<div class="row">
			<div class='span12'>
				<table class='table table-condensed metatable'>
					<tr>
						<th class='menu-id'><?php echo JText::_('COM_BFSEO_TITLE_ARTICLEID'); ?></th>
						<th class='category'><?php echo JText::_('COM_BFSEO_TITLE_TITLE'); ?></th>
						<th class='descrip'><?php echo JText::_('COM_BFSEO_TITLE_METADESCRIPTION'); ?></th>
					</tr>
					<?php foreach ($this->menuItems as $article): ?>
						<tr>
							<td class='menu-id'><?php echo $article->id ?>
								<input type='hidden' name='id[<?php echo $article->id ?>]' value='<?php echo $article->id ?>'>
							</td>
							<td class='category'>
								<?php echo $article->title ?>
								<br>
								<a href="index.php?option=com_content&task=article.edit&id=<?php echo $article->id; ?>"  class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-edit"></span></a>
								<a href="<?php echo JURI::root(); ?>index.php?option=com_content&view=article&id=<?php echo $article->id; ?>" class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-preview"></span></a>
								<?php $link = JUri::root().'index.php?option=com_content&view=article&id='.$article->id; ?>
								<a href="index.php?option=com_bfseo&view=pagecheck&task=check&<?php echo JSession::getFormToken(); ?>=1&urltocheck=<?php echo base64_encode($link); ?>"  class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-wrench"></span></a>
								<a href="index.php?option=com_bfseo&view=checklinks&task=check&<?php echo JSession::getFormToken(); ?>=1&urltocheck=<?php echo base64_encode($link); ?>"  class="modal" rel="{handler: 'iframe', size: {x: 1000, y: 600}}"><span class="icon-link"></span></a>
							</td>
							<?php
							$id = $article->id;
							$desc = $article->metadesc;

							$borderColor = "border-color: ";
							$warning='';
							$textColor = 'color: ';

							//check for duplicate
							foreach ($this->menuItems as $temparticle){
								$tempid = $temparticle->id;
								$tempdesc = $temparticle->metadesc;
								if($tempdesc == $desc && $tempid != $id && $desc != ''){
									$warning= JText::_('COM_BFSEO_ERROR_DUPLICATE_CONTENT');
									$borderColor = 'border-color: red';
									$textColor = 'color: red';
								}
							}
							?>
							<td><?php
								if (!empty($desc)) {
									if (strlen($desc) < $minDescLength) {
										$borderColor .= "DarkViolet";
										$warning=$minWarningText;
										$textColor .= "DarkViolet";
									} else if (strlen($desc) > $maxDescLength) {
										$borderColor .= "yellow";
										$warning=$maxWarningText;
										$textColor .= "DeepPink";
									}
								}
								?>
								<textarea rows=1 class='metaDescCat metaDesc' style='<?php echo $borderColor ?>'
										  name='desc[<?php echo $article->id ?>]'
										  id='desc<?php echo $article->id ?>'><?php echo $desc ?></textarea>
								<div id="warningdesc<?php echo $article->id ?>" style="width:100%; <?php echo $textColor ?>"><?php echo $warning; ?></div>
							</td>
						</tr>
					<?php endforeach ?>
				</table>
			</div>
		</div>

		<?php if (!empty($this->menuItems)): ?>
			<div class="row">
				<div class='span6 offset3'>
					<?php echo $this->pagination; ?>
				</div>
			</div>
		<?php endif ?>

		<input type="hidden" name="task" value="metatagarts.view"/>
		<?php echo JHtml::_('form.token'); ?>

		</div>
	</form>
	<script>
		var minDescLength = <?php echo $minDescLength ?>;
		var maxDescLength = <?php echo $maxDescLength ?>;
		var minWarningText = '<?php echo $minWarningText ?>';
		var maxWarningText = '<?php echo $maxWarningText ?>';
	</script>
</div>