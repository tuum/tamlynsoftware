<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoModelMetatags extends F0FModel
{
	public function __construct($config = array()) {
		$config['table'] = 'menu';
		parent::__construct($config);
	}

	static function getMenuItems()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('#__menu.id, #__menu.title, #__menu.alias, #__menu.params, #__menu.link');
		$query->from('#__menu');
		$query->innerJoin('#__menu_types');
		$query->where('#__menu.published = 1');
		$query->where('#__menu.menutype = #__menu_types.menutype');
		$query->where('#__menu.type != '.$db->quote('alias'));
		$db->setQuery($query);
		$db->query();
		if ($db->getErrorNum()) {

		}
		$rows = $db->loadObjectList();
		if (empty($rows)) {
			if ($db->getErrorNum()) {
				// err msg
			}
		}

		return $rows;
	}

	static function updateMeta($param, $others, $id)
	{
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->clear();
		$query->update('#__menu');
		$query->set("`params`='".$param."'");
		$query->set("`alias`='".$others['alias']."'");
		$query->where('id='.(int)$id);
		$db->setQuery($query);
		if(!$db->query()){
			return false;
		}

		return true;
	}

	static function getParams($id){
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('params');
		$query->from('#__menu');
		$query->where("id=".$id);
		$db->setQuery($query);
		$db->query();

		$result_string = $db->loadColumn();
		$result_string = $result_string["0"];
		$result = json_decode($result_string, true);

		return $result;
	}

	static function updateRedirect($others, $id)
	{
		// Get the menu current alias
		$db = JFactory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('alias, link, id');
		$query->from('#__menu');
		$query->where("id=".$id);
		$db->setQuery($query);
		$db->query();

		$result = $db->loadObjectList();
		$alias = $result[0]->alias;

		//has alias changed?
		if($alias == $others['alias'])
		{
			//nothing has changed
			return false;
		}
		else
		{
			//alias has changed. Lets create an automatic redirect

			//check to see if com_redirect is enabled
			include_once(JPATH_ADMINISTRATOR.'/components/com_redirect/helpers/redirect.php');
			$enabled              = RedirectHelper::isEnabled();
			$collect_urls_enabled = RedirectHelper::collectUrlsEnabled();


			if ($enabled) :
				if ($collect_urls_enabled) :
					//what was the old menu url?
					$current = JUri::root().$alias;

					// See if the current url exists in the database as a redirect.
					$db    = JFactory::getDbo();
					$query = $db->getQuery(true)
					->select($db->quoteName(array('new_url', 'header')))
					->select($db->quoteName('published'))
					->from($db->quoteName('#__redirect_links'))
					->where($db->quoteName('old_url') . ' = ' . $db->quote($current));
					$db->setQuery($query, 0, 1);
					$link = $db->loadObject();

					if (!$link)
					{
						$new_url = JUri::root().$others['alias'];
						$referer = '';

						//now let's create the redirect
						$columns = array(
								$db->quoteName('old_url'),
								$db->quoteName('new_url'),
								$db->quoteName('referer'),
								$db->quoteName('comment'),
								$db->quoteName('hits'),
								$db->quoteName('published'),
								$db->quoteName('created_date')
						);
						$query->clear()
						->insert($db->quoteName('#__redirect_links'), false)
						->columns($columns)
						->values(
								$db->quote($current) . ', ' . $db->quote($new_url) .
								' ,' . $db->quote($referer) . ', ' . $db->quote('') . ',1,1, ' .
								$db->quote(JFactory::getDate()->toSql())
								);

						$db->setQuery($query);
						$db->execute();
					}
				endif;
			endif;
		}
	}
}