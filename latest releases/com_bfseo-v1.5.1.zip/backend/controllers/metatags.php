<?php
/*
 * @package BF SEO
 * @copyright Copyright (c)2016 Tamlyn Software
 * @license GNU General Public License version 2 or later
 */

defined('_JEXEC') or die();

class BfseoControllerMetatags extends F0FController
{
	public function __construct($config = array()) {
		parent::__construct($config);

		$this->modelName = 'metatags';
	}

	public function execute($task) {
		if(!in_array($task, array('save','selectTagType'))) $task = 'add';

		parent::execute($task);
	}


	public function save()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		$model = $this->getThisModel();

		$app = JFactory::getApplication();
		$input = $app->input;

		$data = $input->getArray();
		$ids = $data['id'];

		foreach ($ids as $id) {

			$others['alias'] = JFilterOutput::stringURLSafe($data['alias'][$id]);

			//get the current parameters
			$params = $model->getParams($id);

			$title = $data['title'][$id];
			$desc = $data['desc'][$id];

			//now update title and desc
			$params["page_title"] = $title;
			$params["menu-meta_description"] = $desc;

			$param = json_encode($params);
			$param = str_replace("'", "''", $param);
			$param = str_replace("\\", "\\\\", $param);

			$model->updateRedirect($others, $id);

			$model->updateMeta($param, $others, $id);
		}

		$menuTable = JTable::getInstance('menu');
		$menuTable->rebuild();

		$this->setMessage( JText::_( 'COM_BFSEO_METADATA_SAVED' ) );

		$this->setRedirect( 'index.php?option=com_bfseo&view=metatags' );
		return true;
	}

	public function selectTagType()
	{
		$input = JFactory::getApplication()->input;
		$view  = $input->get('tagType');
		$this->setRedirect('index.php?option=com_bfseo&view='.$view);
	}
}