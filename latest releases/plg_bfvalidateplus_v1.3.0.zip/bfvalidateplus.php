<?php
/**
 * $Id: bfvalidateplus.php 4 2012-11-26 10:44:30Z tuum $
 * BF Validate Plus Plugin
 *
 * @link http://www.tamlynsoftware.com
 * @copyright	Copyright (c) 2013 - Tamlyn Software
 * @license		GNU General Public License version 3 or later.
 *
 *	  BF Validate Plus is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    BF Validate Plus is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with BF Validate Plus.  If not, see <http://www.gnu.org/licenses/>.
 */
defined( '_JEXEC' ) or die;

class plgBFValidatePlus extends JPlugin
{
	function __construct() { }

	static function formbfvalidation() {
		static $loaded = false;

		// only load once
		if ($loaded) {
				return;
		}

		// Include mootools framework
		self::framework();

		//JHtml::_('script','../../plugins/system/bfvalidateplus/bfvalidateplus.js', true, true);
		$jsFile = rtrim(JURI::base(),'/').'/plugins/system/bfvalidateplus/bfvalidateplus.js';
		JHtml::_('script',$jsFile, true, true);

		$loaded = true;
	}

	/**
	 * Method to load the mootools framework into the document head
	 *
	 * - If debugging mode is on an uncompressed version of mootools is included for easier debugging.
	 *
	 * @param	string	$extras	Mootools file to load
	 * @param	boolean	$debug	Is debugging mode on? [optional]
	 *
	 * @return	void
	 * @since	1.6
	 */
	public static function framework($extras = false, $debug = null)
	{
		static $loaded = array();

		$type = $extras ? 'more' : 'core';

		// Only load once
		if (!empty($loaded[$type])) {
			return;
		}

		//JHtml::core($debug);

		// If no debugging value is set, use the configuration setting
		if ($debug === null) {
			$config = JFactory::getConfig();
			$debug = $config->get('debug');
		}

		$uncompressed	= $debug ? '-uncompressed' : '';

		if ($type != 'core' && empty($loaded['core'])) {
			self::framework(false, $debug);
		}

		JHtml::_('script','system/mootools-'.$type.$uncompressed.'.js', false, true, false, false);
		$loaded[$type] = true;

		return;
	}

}
?>