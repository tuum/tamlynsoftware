<?php
/**
 * $Id$
 * Bigo CAPTCHA Plugin
 *
 * @link http://www.tamlyncreative.com.au/software
 * @copyright	Copyright (c) 2011 - Tamlyn Creative Pty Ltd.
 * @license		GNU General Public License version 3 or later.
 * @author Tim Plummer - converted plugin for Joomla 1.7
 * @author bigodines - original author of Bigo CAPTCHA for Joomla 1.5
 * <b>info</b>: http://www.bigodines.com or (in portuguese) http://www.joomla.com.br
 *
 *	  Bigo CAPTCHA is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Bigo CAPTCHA is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with Bigo CAPTCHA.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Generic Captcha Plugin for Joomla! 1.7
 *
 *
 * I'm using [almost] the  same plugin structure as 'OSTCaptcha' by CoolAcid so you can easily replace one to the other.
 * If you can't find the features you want here, maybe you should try his:
 * http://forum.joomla.org/index.php/topic,218637.0.html
 */

// CHANGELOG:
//17-11-2007: added "guessing protection".

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * @package		Joomla
 */
class plgSystemBigocaptcha extends JPlugin
{

	var $max_tries = 6;

	// Function wrappers for TriggerEvent usage
	function onCaptcha_Display() {
		$session =& JFactory::getSession();
		$plugin =& JPluginHelper::getPlugin('system', 'bigocaptcha');

		require_once JPATH_SITE.'/plugins/system/bigocaptcha/Captcha04/Functions.php'; // string generator, crypt/decrypt functions
		require_once JPATH_SITE.'/plugins/system/bigocaptcha/Captcha04/GIFEncoder.class.php'; // gif animation
		$tries = $session->get('attempts');
		if ($tries > $this->max_tries) $rnd = 'You are a spambot';
		else $rnd = rnd_string	(intval($this->params->get('word_len')) );
		$cid = md5_encrypt	( $rnd );
		$uid = "54;".$cid;

		$session->set('bigo_uid',$cid); // secret word

		require_once JPATH_SITE.'/plugins/system/bigocaptcha/Captcha04/CaptchaImage.php'; // creates the magic!
		exit();
	}

	function onCaptcha_confirm($word, &$return) {
		$app	= JFactory::getApplication();
		require_once JPATH_SITE.'/plugins/system/bigocaptcha/Captcha04/Functions.php';
		$session =& JFactory::getSession();

		// guessing protection
		$tries = 0;
		$tries = $session->get('attempts');
		$session->set('attempts', ++$tries);

		if (!$word || $tries > $this->max_tries) {
			return false;
		}

  		$correct = md5_decrypt ( $session->get('bigo_uid') );
  		$session->set('bigo_uid', null);
  		if (strtolower($word) == strtolower($correct)) {
  			$session->set('attempts',0);
  			$return = true;
  		} else $return = false;

		return $return;
	}

}